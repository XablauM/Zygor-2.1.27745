ZGV.Quest_Cache_Accept_Alliance = {
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 1, Capturing Sanctum)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11496,11524,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Activating Portal)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11538,11532,11513,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Portal Activated)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11538,11532,11547,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Forge Rebuilt)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11537,11533,11547,11542,11539,11536,11544,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Rebuilding Forge)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11537,11533,11547,11542,11539,11535,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Alchemy Lab Built)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11521,11546,11537,11533,11547,11545,11543,11540,11536,11544,11541,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Fully Built)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11521,11546,11537,11533,11547,11548,11543,11540,11536,11544,11541,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Monument Built)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11537,11533,11547,11548,11543,11540,11536,11544,11520,11541,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, No Alchemy Lab or Monument)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11537,11533,11547,11545,11543,11540,11536,11544,11520,11541,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Cooking Dailies"] = {
		{ids="13103,13101,13100,13107,13102", cond_if=[[questpossible]]},
		{ids="13087"},
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Fishing Dailies"] = {
		{ids="13833,13834,13832,13836,13830", cond_if=[[questpossible]]},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Death's Rise Dailies"] = {
		{ids="12813,12838,12815"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Shadowvault Dailies"] = {
		{ids="12995,13069,13071"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\The Skybreaker Dailies"] = {
		{ids="13309,13284", cond_if=[[completedq(13341)]]},
		{ids="13322", cond_if=[[completedq(13321)]]},
		{ids="13292", cond_if=[[completedq(13291)]]},
		{ids="13280", cond_if=[[completedq(13296)]]},
		{ids="13289", cond_if=[[completedq(13288)]]},
		{ids="13344", cond_if=[[completedq(13342)]]},
		{ids="13297", cond_if=[[completedq(13295)]]},
		{ids="13382,13404", cond_if=[[completedq(13381)]]},
		{ids="13300", cond_if=[[completedq(13308)]]},
		{ids="13333", cond_if=[[completedq(13314)]]},
		{ids="13323", cond_if=[[completedq(13318)]]},
		{ids="13336"},
	},
	["DAILIES\\Wrath of the Lich King\\Jewelcrafting Dailies"] = {
		{ids="12958,12962,12959,12961,12963,12960", cond_if=[[questpossible]]},
		{ids="13041"},
	},
	["DAILIES\\Wrath of the Lich King\\The Kalu'ak Dailies"] = {
		{ids="11504,11507,11508,11509,11469,11472,11945,11960"},
		{ids="11573", cond_if=[[Alliance]]},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\Frenzyheart Tribe Dailies"] = {
		{ids="12758,12734,12741,12732,12703,12760,12759", cond_if=[[questpossible]]},
		{ids="12654,12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12578,12580,12579,12581,12582,12692,12702"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\The Oracles Dailies"] = {
		{ids="12735,12737,12736,12726,12761,12762,12705", cond_if=[[questpossible]]},
		{ids="12654,12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12578,12580,12579,12581,12689,12695,12704"},
	},
	["DAILIES\\Wrath of the Lich King\\The Sons of Hodir\\The Sons of Hodir Dailies"] = {
		{ids="13421", cond_if=[[completedq(13420)]]},
		{ids="13559", cond_if=[[rep("The Sons of Hodir") < Exalted]]},
		{ids="13006", cond_if=[[rep("The Sons of Hodir") >= Friendly and completedq(12987)]]},
		{ids="12994", cond_if=[[rep("The Sons of Hodir") >= Honored]]},
		{ids="13046", cond_if=[[rep("The Sons of Hodir") >= Revered]]},
		{ids="13003", cond_if=[[rep("The Sons of Hodir") >= Honored and completedq(13001)]]},
		{ids="13001", cond_if=[[rep("The Sons of Hodir") >= Honored and not completedq(13001)]]},
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,13062,12886,13064,12915,12922,12956,12924,12966,12967,13009,12981,12975,13050,13051,13010,12976,13011,12985,12987,12977,13006,13057,13005,13035,13047,13108,12981,12977"},
	},
	["DAILIES\\Wrath of the Lich King\\Wyrmrest Accord Dailies"] = {
		{ids="12000", cond_if=[[completedq(12435)]]},
		{ids="12000", cond_if=[[not completedq(12435)]]},
		{ids="12004,12055,12060,12065,12067,12083,12098,12107,12119,12766,12460,12416,12417,12418,12419,12768,12123,12435,12372,11918,11936,11919,13412,13413,11940,13414"},
	},
	["DAILIES\\The Burning Crusade\\Netherwing\\Netherwing Daily Quests"] = {
		{ids="11018", cond_if=[[skill("Mining") >= 350]]},
		{ids="11101", cond_if=[[rep("The Aldor") >= Friendly and rep("Netherwing") >= Revered]]},
		{ids="11055,11076,11077", cond_if=[[rep("Netherwing") >= Friendly]]},
		{ids="11097", cond_if=[[rep("The Scryers") >= Friendly and rep("Netherwing") >= Revered]]},
		{ids="11086", cond_if=[[rep("Netherwing") >= Honored]]},
		{ids="11017", cond_if=[[skill("Herbalism") >= 350]]},
		{ids="11016", cond_if=[[skill("Skinning") >= 350]]},
		{ids="11020,11035,11015"},
	},
	["DAILIES\\The Burning Crusade\\Ogri'la\\Ogri'la Daily Quests"] = {
		{ids="11080", cond_if=[[completedq(11058)]]},
		{ids="11023", cond_if=[[completedq(11010,11102)]]},
		{ids="11066", cond_if=[[completedq(11065)]]},
		{ids="11051", cond_if=[[completedq(11026)]]},
	},
	["DAILIES\\The Burning Crusade\\Sha'tari Skyguard\\Sha'tari Skyguard Daily Quests"] = {
		{ids="11008,11085,11023,11066"},
	},
	["DAILIES\\The Burning Crusade\\Sha'tari Skyguard\\Sha'tari Skyguard Terokk Farming"] = {
		{ids="11006,11074"},
	},
	["DAILIES\\The Burning Crusade\\Shattrath Cooking Dailies"] = {
		{ids="11381,11379,11380,11377"},
	},
	["DUNGEONS\\Classic\\Blackfathom Deeps Quests"] = {
		{ids="3765,971,1275,1199,1198,1200"},
	},
	["DUNGEONS\\Classic\\Blackrock Depths Quests"] = {
		{ids="4324,3702,3701,4128,4126,4286,4182,4262,4341,4241,3441,3442,3443,3452,3453,3454,3462,3463,3481,4123,4136,4022,4024,3801,3802,4264,4342,4361,4242,4282,4201,4322,4263,4362,4363"},
	},
	["DUNGEONS\\Classic\\Dire Maul East Quests"] = {
		{ids="5527,5526,7488,7441"},
	},
	["DUNGEONS\\Classic\\Dire Maul North Quests"] = {
		{ids="7482,5518,5528,7703"},
	},
	["DUNGEONS\\Classic\\Dire Maul West Quests"] = {
		{ids="7461,7462"},
	},
	["DUNGEONS\\Classic\\Gnomeregan Quests"] = {
		{ids="2923,2928,2925,2924,2922,2927,2930,2929,2926,2962"},
	},
	["DUNGEONS\\Classic\\Lower Blackrock Spire Quests"] = {
		{ids="3520,3527,4787,3528,5065,4788,4701,4866,4729,4862,4867,5001,5002,5081,4742"},
	},
	["DUNGEONS\\Classic\\Maraudon Quests"] = {
		{ids="7070,7041,7065,7028,7067,7044,7046,7066"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Blackwing Lair Attunement"] = {
		{ids="7761"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Molten Core Attunement"] = {
		{ids="7848"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Naxxramas Attunement"] = {
		{ids="9123", cond_if=[[rep("Argent Dawn") == Exalted or completedq(9123)]]},
		{ids="9122", cond_if=[[rep("Argent Dawn") == Revered or completedq(9122)]]},
		{ids="9121", cond_if=[[rep("Argent Dawn") < Revered or completedq(9121)]]},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Onyxia's Lair Attunement"] = {
		{ids="4182,4241,4242,4264,4282,4322,6402,6403,6501,6502"},
	},
	["DUNGEONS\\Classic\\Razorfen Downs Quests"] = {
		{ids="3636,6626,3523,3525"},
	},
	["DUNGEONS\\Classic\\Razorfen Kraul Quests"] = {
		{ids="1221,1100,1101,1142,1144"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Armory Quests"] = {
		{ids="6141,261,1052,1053"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Cathedral Quests"] = {
		{ids="6141,261,1052,1053"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Library Quests"] = {
		{ids="6141,261,1052,1053,1050"},
	},
	["DUNGEONS\\Classic\\Scholomance Quests"] = {
		{ids="5091,4726,4808,4809,4810,4907,4734,4735,5522,5531,5529,4771,5092,5097,5533,5537,5538,5801,5803,5505,5343,5382,5515,5582,5384,5461,5462,5463,5464,5465,5466"},
	},
	["DUNGEONS\\Classic\\Stratholme - Live Side Quests"] = {
		{ids="5214,5251,5281,5282,5542,5543,5544,5742,5781,5845,5846,5848,5122,5262"},
	},
	["DUNGEONS\\Classic\\Stratholme - Undead Side Quests"] = {
		{ids="5382,5515,5384,5461,5462,5463,5251,5262,5263,5212,5243,5125,5125,5464,5213"},
	},
	["DUNGEONS\\Classic\\Temple of Atal'Hakkar Quests"] = {
		{ids="1448,1449,1450,1451,1452,3445,1469,1475,3444,3446,3520,3527,4787,1446,3528,4141,4142,4143,3447,3373"},
	},
	["DUNGEONS\\Classic\\The Deadmines Quests"] = {
		{ids="167,168,2040,65,132,135,141,142,155,166,214,373"},
	},
	["DUNGEONS\\Classic\\The Stockade Quests"] = {
		{ids="303,378,386,377,388,373,389,391,387"},
	},
	["DUNGEONS\\Classic\\Uldaman Quests"] = {
		{ids="2278,2279,2439", cond_if=[[level >=40]]},
		{ids="2198,2199,2200,2398,720,721,722,723,724,707,725,726,762,2500,738,739,704,2202,1139,2201,2240,2204"},
	},
	["DUNGEONS\\Classic\\Upper Blackrock Spire Quests"] = {
		{ids="4766,4764,4726,4182,4241,4242,4264,4282,4322,6402,6403,6501,4808,4809,4810,6502,4907,4734,6804,6805,6821,5089,5102,5160,5047,4735,5164"},
	},
	["DUNGEONS\\Classic\\Wailing Caverns Quests"] = {
		{ids="865,1491,959,1486,1487,3366,6981,3370"},
	},
	["DUNGEONS\\Classic\\Zul'Farrak Quests"] = {
		{ids="2988,2989,2990,2991,2846,2770,3520,3527,2768,2865,3042"},
	},
	["DUNGEONS\\The Burning Crusade\\Auchenai Crypts Quests"] = {
		{ids="10227,10228,10231,10251,10252,10253,10164,9928,9927,9931,9932,10168"},
	},
	["DUNGEONS\\The Burning Crusade\\Black Temple Attunement"] = {
		{ids="10568", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10684,10685,10575", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10571,10574,10575", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10683", cond_if=[[rep('The Scryers')>=Neutral]]},
		{ids="10622,10628,10705,10706,10707,10708,10944,10946,10947,10948,10949,10985"},
	},
	["DUNGEONS\\The Burning Crusade\\Blood Furnace Quests"] = {
		{ids="9607,9589"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Citadel Attunement"] = {
		{ids="10754,10762,10763,10764"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Ramparts Quests"] = {
		{ids="9575,9587"},
	},
	["DUNGEONS\\The Burning Crusade\\Karazhan Attunement"] = {
		{ids="11216,9824,9825,9826,9829,9831,9832,9836,9837,9838"},
	},
	["DUNGEONS\\The Burning Crusade\\Mana-Tombs Quests"] = {
		{ids="10216,10165,10218,10969,10970,10425,10971,10973,10974,10975,10975,10976,10977"},
	},
	["DUNGEONS\\The Burning Crusade\\Mount Hyjal Attunement"] = {
		{ids="10445"},
	},
	["DUNGEONS\\The Burning Crusade\\Old Hillsbrad Foothills Quests"] = {
		{ids="12513,10279,10277,10282,10283,10284,10285"},
	},
	["DUNGEONS\\The Burning Crusade\\Serpentshrine Cavern Attunement"] = {
		{ids="10901,9630,9638,9639,9640,9645,9680,9631,9637,9644"},
	},
	["DUNGEONS\\The Burning Crusade\\Sethekk Halls Quests"] = {
		{ids="10180,10097,10098"},
	},
	["DUNGEONS\\The Burning Crusade\\Shadow Labyrinth Quests"] = {
		{ids="10687", cond_if=[[rep('The Scryers')>=Neutral]]},
		{ids="10587,10637,10640", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10688,10689", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10641,10668,10669,10646,10649,10621,10626,10662,10664,10666,11216,9824,9825,9826,9829,9831,10177,10094,10178,10885,10091,10095"},
	},
	["DUNGEONS\\The Burning Crusade\\Shattered Halls Quests"] = {
		{ids="9492,9492,10883,10884"},
	},
	["DUNGEONS\\The Burning Crusade\\Tempest Keep Attunement"] = {
		{ids="10883,10884,10885,10886,10888"},
	},
	["DUNGEONS\\The Burning Crusade\\The Arcatraz Quests"] = {
		{ids="10568", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10684,10685,10575", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10683", cond_if=[[rep('The Scryers')>=Neutral]]},
		{ids="10571,10574,10575", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10704,10622,10628,10705,10706,11216,9824,9825,9826,9829,9831,9832"},
	},
	["DUNGEONS\\The Burning Crusade\\The Black Morass Quests"] = {
		{ids="10902", cond_if=[[skill("Alchemy") < 0]]},
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["DUNGEONS\\The Burning Crusade\\The Botanica Quests"] = {
		{ids="10897", cond_if=[[skill("Alchemy") < 0]]},
		{ids="10257,10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10704"},
	},
	["DUNGEONS\\The Burning Crusade\\The Cipher of Damnation"] = {
		{ids="10680,10458,10480,10481,10513,10514,10515,10519,10521,10527,10546,10522,10523,10528,10537,10540,10541,10547,10550,10570,10576,10577,10578,10579,10588"},
	},
	["DUNGEONS\\The Burning Crusade\\The Mechanar Quests"] = {
		{ids="10621,10626,10662,10664,10665"},
	},
	["DUNGEONS\\The Burning Crusade\\The Slave Pens Quests"] = {
		{ids="9738"},
	},
	["DUNGEONS\\The Burning Crusade\\The Steamvault Quests"] = {
		{ids="10621,10626,10662,10664,10666,10667,9763,9764,10885"},
	},
	["DUNGEONS\\The Burning Crusade\\The Underbog Quests"] = {
		{ids="9715,9717,9719,9738"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Ahn'kahet: The Old Kingdom Quests"] = {
		{ids="13187,13204"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Azjol-Nerub Quests"] = {
		{ids="13167,13182"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Drak'Tharon Keep Quests"] = {
		{ids="12210,11984,11989,11990,11991,12007,12042,12802,12068,12238,12484,12029,12037"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Gundrak Quests"] = {
		{ids="13111,13098"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Lightning Quests"] = {
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12996,12997,13061,13062,12886,13064,12915,12922,12956,12924,12966,12967,13009,13050,13051,13010,13011,12975,12976,13057,13005,13035,13047,13108,13109"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Stone Quests"] = {
		{ids="13207"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Culling of Stratholme Quests"] = {
		{ids="13149,13151"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Nexus Quests"] = {
		{ids="11733,11900,11910,11941,11943,11905,11911,13094,11946,11951,11957,11967,11969,11973"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Oculus Quests"] = {
		{ids="13124,13126,13127,13128"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Violet Hold Quests"] = {
		{ids="13158,13159"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Keep Quests"] = {
		{ids="11252,13205"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Pinnacle Quests"] = {
		{ids="13131,13132"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Month"] = {
		{ids="12420"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Year"] = {
		{ids="12420"},
	},
	["EVENTS\\Brewfest\\Achievements\\Direbrewfest"] = {
		{ids="12062"},
	},
	["EVENTS\\Brewfest\\Achievements\\Down With The Dark Iron"] = {
		{ids="12020"},
	},
	["EVENTS\\Brewfest\\Brewfest Dailies"] = {
		{ids="11293,11294,12020,12318,12062"},
	},
	["EVENTS\\Brewfest\\Brewfest Quests"] = {
		{ids="12022,11318,11122,12193,11117,11118,12318,12062"},
	},
	["EVENTS\\Children's Week\\Children's Week Main Questline"] = {
		{ids="1468,1479,1558,1687,4822,558,171"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Chronos Turn-Ins (Elwynn Forest)"] = {
		{ids="7881,7882,7883,7884,7885,7941"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Kerri Hicks Turn-Ins (Elwynn Forest)"] = {
		{ids="7889,7890,7891,7892,7893,7939"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Rinling Turn-Ins (Elwynn Forest)"] = {
		{ids="7894,7895,7896,7897,7898,7942"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Sayge's Fortunes (Elwynn Forest)"] = {
		{ids="7937,7938,7944,7945"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Spawn of Jubjub (Elwynn Forest)"] = {
		{ids="7946"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Yebb Neblegear Turn-Ins (Elwynn Forest)"] = {
		{ids="7899,7900,7901,7902,8222,8223"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Chronos Turn-Ins (Mulgore)"] = {
		{ids="7881,7882,7883,7884,7885,7941"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Kerri Hicks Turn-Ins (Mulgore)"] = {
		{ids="7889,7890,7891,7892,7893,7939"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Rinling Turn-Ins (Mulgore)"] = {
		{ids="7894,7895,7896,7897,7898,7942"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Sayge's Fortunes (Mulgore)"] = {
		{ids="7937,7938,7944,7945"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Spawn of Jubjub (Mulgore)"] = {
		{ids="7946"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Yebb Neblegear Turn-Ins (Mulgore)"] = {
		{ids="7899,7900,7901,7902,8222,8223"},
	},
	["EVENTS\\Feast of Winter Veil\\Feast of Winter Veil Quest"] = {
		{ids="7062,7063,7022,7025,7042,7043,7045,8762"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Hallowed Be Thy Name"] = {
		{ids="12404,12409", cond_if=[[rep ('The Scryers')>=Neutral]]},
		{ids="12404,12409", cond_if=[[rep ('The Aldor')>=Neutral]]},
		{ids="11356,11360,12133,11131,12135,12133,8373,1658,12336,12286,12340,12344,12397,12396,12349,12398,12399,12401,12350,12348,12347,12345,12400,12338,12334,12331,12337,12333,12341,12343,12339,12335,12339,12346,12351,12402,12342,12352,12353,12356,12360,12357,12403,12354,12355,12358,12359,12406,12407,12408"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Rotten Hallow"] = {
		{ids="8373,1658"},
	},
	["EVENTS\\Hallow's End\\Achievements\\The Savior of Hallow's End"] = {
		{ids="11356,11360,12133,11131,12135,12133"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Trick or Treat!"] = {
		{ids="12336"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Tricks and Treats of Azeroth"] = {
		{ids="12404,12409", cond_if=[[rep ('The Scryers')>=Neutral]]},
		{ids="12404,12409", cond_if=[[rep ('The Aldor')>=Neutral]]},
		{ids="12336,12286,12340,12344,12397,12396,12349,12398,12399,12401,12350,12348,12347,12345,12400,12338,12334,12331,12337,12333,12341,12343,12339,12335,12339,12346,12351,12402,12342,12352,12353,12356,12360,12357,12403,12354,12355,12358,12359,12406,12407,12408"},
	},
	["EVENTS\\Hallow's End\\Hallow's End Candy Buckets"] = {
		{ids="12404,12409", cond_if=[[rep ('The Scryers')>=Neutral]]},
		{ids="12404,12409", cond_if=[[rep ('The Aldor')>=Neutral]]},
		{ids="12336,12286,12340,12344,12397,12396,12349,12398,12399,12401,12350,12348,12347,12345,12400,12338,12334,12331,12337,12333,12341,12343,12339,12335,12339,12346,12351,12402,12342,12352,12353,12356,12360,12357,12403,12354,12355,12358,12359,12406,12407,12408"},
	},
	["EVENTS\\Hallow's End\\Hallow's End Daily Quests"] = {
		{ids="11356,11131,12135,12133,11404"},
	},
	["EVENTS\\Hallow's End\\Hallow's End Quests"] = {
		{ids="11135", cond_if=[[level >= 75]]},
		{ids="8311,8356,12336,11356,11360,12133,8353,12335,8355,8357,12334,8373,1658,11135"},
	},
	["EVENTS\\Harvest Festival\\Harvest Festival Quest"] = {
		{ids="8149"},
	},
	["EVENTS\\Love is in the Air\\Gift Giving"] = {
		{ids="8993,8993,8993"},
	},
	["EVENTS\\Love is in the Air\\Love is in the Air Quests"] = {
		{ids="8903,9024,9025,9026,9027,9028,9029"},
	},
	["EVENTS\\Lunar Festival\\Lunar Festival Main Questline"] = {
		{ids="8870,8867,8883,8864,8865,8863,8862"},
	},
	["EVENTS\\Lunar Festival\\Lunar Festival Optimized Elders Path"] = {
		{ids="8714,8722,8652,8648,8645,8650,8688,8643,8642,8866,8653,8651,8683,8636,8646,8649,8647,8675,8716,8674,8680,8670,8677,8717,8686,8673,8678,8682,8724,8684,8671,8681,8719,8654,8685,8679,8720,8672,8726,8723,8725,8721,8718,8715,8676,8635,8713,8619,8644,8727"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Bonfires"] = {
		{ids="9365", cond_if=[[haveq(9324,9325,9326,11935) or completedq(9324,9325,9326,11935)]]},
		{ids="11816,11832,11801,11808,11781,11814,11583,11822,11810,11768,11766,11820,11813,11828,11804,11764,11819,11776,11827,11826,11784,11580,9326,11786,11774,11772,11935,11811,11824,11806,11809,11834,11803,11805,11765,11783,11770,9324,11780,11812,11769,11817,11773,11831,11800,11833,11802,11785,11815,11771,11777,9325,11818,11775,11799,11830,11767,11807,11787,11829,11778,11821,11782,11825,11779,11823"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Dailies"] = {
		{ids="11954", cond_if=[[level >= 64]]},
		{ids="11917", cond_if=[[level >= 22 and level <= 31]]},
		{ids="11952", cond_if=[[level >= 51 and level <= 59]]},
		{ids="11948", cond_if=[[level >= 43 and level <= 50]]},
		{ids="11947", cond_if=[[level >= 32 and level <= 42]]},
		{ids="11953", cond_if=[[level >= 60 and level <= 63]]},
		{ids="11921,11924"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Quests"] = {
		{ids="11964,11886,11731,11657,11816,11882,11891,12012,11955,11696,11691,11972"},
	},
	["GOLD\\Gathering\\Frostweave Cloth"] = {
		{ids="13272"},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Cloak Quest"] = {
		{ids="8557", cond=[[Warrior]]},
		{ids="8695", cond=[[Paladin]]},
		{ids="8690", cond=[[Shaman]]},
		{ids="8693", cond=[[Rogue]]},
		{ids="8691", cond=[[Mage]]},
		{ids="8692", cond=[[Druid]]},
		{ids="8689", cond=[[Priest]]},
		{ids="8696", cond=[[Hunter]]},
		{ids="8694", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Ring Quest"] = {
		{ids="8556", cond=[[Warrior]]},
		{ids="8703", cond=[[Paladin]]},
		{ids="8698", cond=[[Shaman]]},
		{ids="8701", cond=[[Rogue]]},
		{ids="8699", cond=[[Mage]]},
		{ids="8700", cond=[[Druid]]},
		{ids="8697", cond=[[Priest]]},
		{ids="8704", cond=[[Hunter]]},
		{ids="8702", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Weapon Quest"] = {
		{ids="8558", cond=[[Warrior]]},
		{ids="8711", cond=[[Paladin]]},
		{ids="8706", cond=[[Shaman]]},
		{ids="8709", cond=[[Rogue]]},
		{ids="8707", cond=[[Mage]]},
		{ids="8708", cond=[[Druid]]},
		{ids="8705", cond=[[Priest]]},
		{ids="8712", cond=[[Hunter]]},
		{ids="8710", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Signet Ring of the Bronze Dragonflight"] = {
		{ids="8753,8754,8755,8756", cond_if=[[completedq(8752)]]},
		{ids="8758,8759,8760,8761", cond_if=[[completedq(8757)]]},
		{ids="8766", cond_if=[[completedq(8756)]]},
		{ids="8764", cond_if=[[completedq(8751)]]},
		{ids="8765", cond_if=[[completedq(8761)]]},
		{ids="8748,8749,8750,8751", cond_if=[[completedq(8747)]]},
		{ids="8757,8747,8752"},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Boots Quest"] = {
		{ids="8559", cond=[[Warrior]]},
		{ids="8655", cond=[[Paladin]]},
		{ids="8621", cond=[[Shaman]]},
		{ids="8637", cond=[[Rogue]]},
		{ids="8634", cond=[[Mage]]},
		{ids="8665", cond=[[Druid]]},
		{ids="8596", cond=[[Priest]]},
		{ids="8626", cond=[[Hunter]]},
		{ids="8660", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Chest Quest"] = {
		{ids="8562,8562", cond=[[Warrior]]},
		{ids="8627,8627", cond=[[Paladin]]},
		{ids="8622,8622", cond=[[Shaman]]},
		{ids="8638,8638", cond=[[Rogue]]},
		{ids="8633,8633", cond=[[Mage]]},
		{ids="8666,8666", cond=[[Druid]]},
		{ids="8603,8603", cond=[[Priest]]},
		{ids="8656,8656", cond=[[Hunter]]},
		{ids="8661,8661", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Helm Quest"] = {
		{ids="8561", cond=[[Warrior]]},
		{ids="8628", cond=[[Paladin]]},
		{ids="8623", cond=[[Shaman]]},
		{ids="8639", cond=[[Rogue]]},
		{ids="8632", cond=[[Mage]]},
		{ids="8667", cond=[[Druid]]},
		{ids="8592", cond=[[Priest]]},
		{ids="8657", cond=[[Hunter]]},
		{ids="8662", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Legs Quest"] = {
		{ids="8560", cond=[[Warrior]]},
		{ids="8629", cond=[[Paladin]]},
		{ids="8624", cond=[[Shaman]]},
		{ids="8640", cond=[[Rogue]]},
		{ids="8631", cond=[[Mage]]},
		{ids="8668", cond=[[Druid]]},
		{ids="8593", cond=[[Priest]]},
		{ids="8658", cond=[[Hunter]]},
		{ids="8663", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Shoulder Quest"] = {
		{ids="8544", cond=[[Warrior]]},
		{ids="8630", cond=[[Paladin]]},
		{ids="8602", cond=[[Shaman]]},
		{ids="8641", cond=[[Rogue]]},
		{ids="8625", cond=[[Mage]]},
		{ids="8669", cond=[[Druid]]},
		{ids="8594", cond=[[Priest]]},
		{ids="8659", cond=[[Hunter]]},
		{ids="8664", cond=[[Warlock]]},
	},
	["LEVELING\\Alterac Mountains (39-39)"] = {
		{ids="551", cond_if=[[itemcount(3706) > 0]]},
		{ids="1713,1792", cond_if=[[Warrior]]},
		{ids="500,537,512,603,1450,1451,1452,554"},
	},
	["LEVELING\\Arathi Highlands (33-33)"] = {
		{ids="681,658"},
	},
	["LEVELING\\Arathi Highlands (39-41)"] = {
		{ids="1661", cond_if=[[Paladin]]},
		{ids="691,642,651,657,660,661,693,663,662,664,665,666,668,669"},
	},
	["LEVELING\\Ashenvale (22-24)"] = {
		{ids="9508,9509", cond_if=[[Shaman]]},
		{ids="970,1010,1020,973,1008,991,1054,1033,1034,1023,1007,1009,741,942"},
	},
	["LEVELING\\Badlands (42-43)"] = {
		{ids="707,2500,738,720,719,718,733,703,1108,739,1137,710,711,712"},
	},
	["LEVELING\\Bloodmyst Isle (14-20)"] = {
		{ids="9501,9503,9504", cond_if=[[Shaman]]},
		{ids="9667", cond_if=[[completedq(9544)]]},
		{ids="9624,9634,9663,9629,9646,9567,9693,9581,9694,9641,9580,9643,9648,9594,9576,9663,9569,9620,9574,9578,9779,9696,9698,9628,9687,9584,10064,10063,9649,9699,9700,9548,9549,9550,9557,9585,9561,9703,9647,9669,9579,9706,9711,9748,10065,9741,10067,10066,9670,9632,9688,9633"},
	},
	["LEVELING\\Boosted Characters\\Boosted Druid Intro"] = {
		{ids="64028,64031,64034,64035,64038,10119"},
	},
	["LEVELING\\Boosted Characters\\Boosted Hunter Intro"] = {
		{ids="9757,9591,9592,9593,9675", cond_if=[[Draenei Hunter]]},
		{ids="64028,64031,64034,64035,64038,10119"},
	},
	["LEVELING\\Boosted Characters\\Boosted Mage Intro"] = {
		{ids="64028,64031,64034,64035,64038,10119"},
	},
	["LEVELING\\Boosted Characters\\Boosted Paladin Intro"] = {
		{ids="64028,64031,64034,64035,64038,10119"},
	},
	["LEVELING\\Boosted Characters\\Boosted Priest Intro"] = {
		{ids="64028,64031,64034,64035,64038,10119"},
	},
	["LEVELING\\Boosted Characters\\Boosted Rogue Intro"] = {
		{ids="64028,64031,64034,64035,64038,10119"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warlock Intro"] = {
		{ids="64028,64031,64034,64035,64038,10119"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warrior Intro"] = {
		{ids="64028,64031,64034,64035,64038,10119"},
	},
	["LEVELING\\Burning Steppes (53-54)"] = {
		{ids="3823,4283,4182,3824,4726,4296,4022,3825,4808,5159"},
	},
	["LEVELING\\Cenarion Battlegear"] = {
		{ids="8800,8548,8572,8573,8574"},
	},
	["LEVELING\\Cenarion Field Duty Combat Assignments"] = {
		{ids="8773", cond_if=[[itemcount(21248) >= 1 or haveq(8773)]]},
		{ids="8771", cond_if=[[itemcount(21750) >= 1 or haveq(8771)]]},
		{ids="8501", cond_if=[[itemcount(20941) >= 1 or haveq(8501)]]},
		{ids="8777", cond_if=[[itemcount(21256) >= 1 or haveq(8777)]]},
		{ids="8776", cond_if=[[itemcount(21255) >= 1 or haveq(8776)]]},
		{ids="8775", cond_if=[[itemcount(21253) >= 1 or haveq(8775)]]},
		{ids="8774", cond_if=[[itemcount(21252) >= 1 or haveq(8774)]]},
		{ids="8770", cond_if=[[itemcount(21749) >= 1 or haveq(8770)]]},
		{ids="8687", cond_if=[[itemcount(21251) >= 1 or haveq(8687)]]},
		{ids="8502", cond_if=[[itemcount(20942) >= 1 or haveq(8502)]]},
		{ids="8772", cond_if=[[itemcount(21250) >= 1 or haveq(8772)]]},
		{ids="8539", cond_if=[[itemcount(21249) >= 1 or haveq(8539)]]},
		{ids="8507,8508"},
	},
	["LEVELING\\Cenarion Field Duty Logistics Assignments"] = {
		{ids="8778", cond_if=[[itemcount(21257) >= 1 or haveq(8778)]]},
		{ids="8497", cond_if=[[itemcount(20807) >= 1 or haveq(8497)]]},
		{ids="8783", cond_if=[[itemcount(21265) >= 1 or haveq(8783)]]},
		{ids="8541", cond_if=[[itemcount(20940) >= 1 or haveq(8541)]]},
		{ids="8782", cond_if=[[itemcount(21262) >= 1 or haveq(8782)]]},
		{ids="8780", cond_if=[[itemcount(21263) >= 1 or haveq(8780)]]},
		{ids="8829", cond_if=[[itemcount(21514) >= 1 or haveq(8829)]]},
		{ids="8805", cond_if=[[itemcount(20939) >= 1 or haveq(8805)]]},
		{ids="8781", cond_if=[[itemcount(21260) >= 1 or haveq(8781)]]},
		{ids="8496", cond_if=[[itemcount(20806) >= 1 or haveq(8496)]]},
		{ids="8779", cond_if=[[itemcount(21259) >= 1 or haveq(8779)]]},
		{ids="8507,8508"},
	},
	["LEVELING\\Cenarion Field Duty Tactical Assignments"] = {
		{ids="8738", cond_if=[[itemcount(21166) >= 1 or haveq(8738)]]},
		{ids="8536", cond_if=[[itemcount(21751) >= 1 or haveq(8536)]]},
		{ids="8740", cond_if=[[itemcount(20944) >= 1 or haveq(8740)]]},
		{ids="8498", cond_if=[[itemcount(20943) >= 1 or haveq(8498)]]},
		{ids="8739", cond_if=[[itemcount(21167) >= 1 or haveq(8739)]]},
		{ids="8538", cond_if=[[itemcount(20948) >= 1 or haveq(8538)]]},
		{ids="8537", cond_if=[[itemcount(20945) >= 1 or haveq(8537)]]},
		{ids="8535", cond_if=[[itemcount(20947) >= 1 or haveq(8535)]]},
		{ids="8534", cond_if=[[itemcount(21165) >= 1 or haveq(8534)]]},
		{ids="8737", cond_if=[[itemcount(21245) >= 1 or haveq(8737)]]},
		{ids="8507,8508"},
	},
	["LEVELING\\Class Quests\\Druid Class Quests"] = {
		{ids="5923,5921,5929,5931,6001,6121,6122,6123,6124,6125,26,29,272,5061,9063,9052,9051,9053", cond_if=[[NightElf Druid]]},
	},
	["LEVELING\\Class Quests\\Hunter Class Quests"] = {
		{ids="6063,6101,6102,6103", cond_if=[[NightElf Hunter]]},
		{ids="6064,6084,6085,6086", cond_if=[[Dwarf Hunter]]},
		{ids="8151,8153,8231,8232,7632,7633,7636,7635,7635", cond_if=[[Hunter]]},
	},
	["LEVELING\\Class Quests\\Mage Class Quests"] = {
		{ids="1860,1861,1920,1921,1941,1939,1938,1940,1942,1947,1949,1950,1951,1952,1953,1954,1955,1956,1957,1958,2861,2846,7463", cond_if=[[Mage]]},
		{ids="1919", cond_if=[[Human Mage]]},
		{ids="1919", cond_if=[[Gnome Mage]]},
	},
	["LEVELING\\Class Quests\\Paladin Class Quests"] = {
		{ids="2998,1641,1642,1643,1644,1780,1781,1786,1787,1788", cond_if=[[Human Paladin]]},
		{ids="1794,1793,1649,1650,1651,1652,1653,1654,1655,1442,1442,1806,1661,8415,8414,8416,8418,7638,7637,7639,7640,7641,7642,7648,7643,7645,7644,7646,7647", cond_if=[[Paladin]]},
		{ids="2997,1645,1646,1646,1647,1648,1778,1779,1783,1784,1785", cond_if=[[Dwarf Paladin]]},
	},
	["LEVELING\\Class Quests\\Priest Class Quests"] = {
		{ids="5635,5641", cond_if=[[Dwarf Priest]]},
		{ids="5637,5676", cond_if=[[Human Priest]]},
		{ids="5629,5673", cond_if=[[NightElf Priest]]},
	},
	["LEVELING\\Class Quests\\Rogue Class Quests"] = {
		{ids="2360,2359,2607,2608,8233,8234,3503,8235,3421,3503,8236", cond_if=[[Rogue]]},
	},
	["LEVELING\\Class Quests\\Shaman Class Quests"] = {
		{ids="9449,9450,9451,9462,9464,9465,9467,9468,9461,9555,9502", cond_if=[[Draenei Shaman]]},
		{ids="9501,9503,9504,9508,9509,9552,9553,9554,8412,8413", cond_if=[[Shaman]]},
		{ids="8410"},
	},
	["LEVELING\\Class Quests\\Warlock Class Quests"] = {
		{ids="1688,1689", cond=[[Human Warlock]]},
		{ids="1598", cond_if=[[Human Warlock]]},
		{ids="1717,1716,1738,1739,1798,1758,1802,1804,1471,4487,4490,7601,7602,8420,8421,8421,8422,7603,7562,7563,7564,7623,7626,7627,7628,7630,7624,7625,7629,7631", cond_if=[[Warlock]]},
		{ids="1599,1715,1688,1689", cond_if=[[Gnome Warlock]]},
	},
	["LEVELING\\Class Quests\\Warrior Class Quests"] = {
		{ids="1718,1719,1791,1712,1714,1713,1792,8417,8423,8424,8425", cond_if=[[Warrior]]},
		{ids="1638,1639,1640,1665", cond_if=[[Human Warrior]]},
		{ids="1679,1678", cond_if=[[(Dwarf Warrior) or (Gnome Warrior)]]},
		{ids="1684,1683", cond_if=[[NightElf Warrior]]},
	},
	["LEVELING\\Darkshore (11-14)"] = {
		{ids="963,983,3524,954,958,2118,984,4681,4811,2138,985,4761,4812,4813,4762,955,956,957,4722,953"},
	},
	["LEVELING\\Darkshore (20-22)"] = {
		{ids="1138,4740,947,729,982,4763,10752,2139,986,965,4725,4727,2098,2078,966,967,948,993,944,731,949,950,945,994"},
		{ids="26,6121,29,6122,272,6123,6124,6125", cond_if=[[NightElf Druid]]},
	},
	["LEVELING\\Desolace (35-37)"] = {
		{ids="1437,1387,1382,1454,1458,1459,1465,5501,5741,1455,6161,5561,1384,1456,1438,1439,1440,6027,1370,1457,1114,1106,1115,1186,1187"},
	},
	["LEVELING\\Duskwood (25-27)"] = {
		{ids="66,101,56,67,163,165,164,174,175,177,5,95,226,148,225,68,93,240,57,69,227,149,154,157,230,262,158,70,72,74,335,265,266,453,156,268,323,269,159"},
	},
	["LEVELING\\Duskwood (30-31)"] = {
		{ids="1179,325,1274,1241,1242,1243,181,173,58,1244,221,337,75,78,133,134,160,79,80,97,251,401,252,98,222,1245"},
	},
	["LEVELING\\Dustwallow Marsh (33-33)"] = {
		{ids="11126,11123,1265,1219,1177,1284,1252,1253"},
	},
	["LEVELING\\Dustwallow Marsh (34-34)"] = {
		{ids="1719,1791", cond_if=[[Warrior]]},
		{ids="1220,1259,1319,1285,1320,1180,1112"},
	},
	["LEVELING\\Dustwallow Marsh (41-42)"] = {
		{ids="1286,11212,1204,11214,11128,11191,11133,11134,11192,11193,11194,11209,11210,11174,11207,11208,11173,1287,11184,11158,11198,11177,11143,11136,1266,11137,11138,11139,11140,11141,1218,11180,1206,11181,11183,11146,11144,11148,1324,1267,1222,11145,11147,11149,1203,11142"},
	},
	["LEVELING\\Dustwallow Marsh (44-45)"] = {
		{ids="11160,11161,11217,11159,11156,11150,11185,11151,11211,11162,11152"},
	},
	["LEVELING\\Eastern Plaguelands (57-58)"] = {
		{ids="5542,5543,5544,5149,5152,5241,6021,5281,5211,6164,5742"},
	},
	["LEVELING\\Extra Zones\\Westfall"] = {
		{ids="6181,6281,6261,6285", cond_if=[[Human]]},
		{ids="64,36,151,9,22,38,153,12,102,13,14,65,132,135,141,142,155,103,104"},
	},
	["LEVELING\\Felwood (52-53)"] = {
		{ids="4101,5155,4421,5157,4906,5156,8460,8462,939,5158,4441,5882"},
	},
	["LEVELING\\Felwood (55-56)"] = {
		{ids="5202", cond_if=[[itemcount(13140) > 0]]},
		{ids="5165,4442"},
	},
	["LEVELING\\Feralas (46-47)"] = {
		{ids="3022,2821,4124,2866,2939,2982,4125,2867,3130,2869,2870,2766,4127,4129,2871,4130,4131,2969,2970,2972,4135,4281,4265,3445,4266,4267,3661,2940,2941"},
	},
	["LEVELING\\Hillsbrad Foothills (32-33)"] = {
		{ids="564,9435,536,555,559,560,561,505,562,563,510,511,514,659"},
	},
	["LEVELING\\Redridge Mountains (25-25)"] = {
		{ids="2282,2360,2359,2607,2608", cond_if=[[Rogue]]},
		{ids="94,244,20,127,150,34"},
	},
	["LEVELING\\Redridge Mountains (27-28)"] = {
		{ids="128,19,115,91,180,248,219,2923,270"},
	},
	["LEVELING\\Scepter of the Shifting Sands"] = {
		{ids="8286,8288,8301,8302,8303,8305,8519,8555,8575,8576,8577,8584,8597,8599,8598,8606,8585,8586,8620,8578,8733,8734,8735,8736,8741,8587,8730,8728,8729,8742,8743,8745"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Darnassus)"] = {
		{ids="9262,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Ironforge)"] = {
		{ids="9261,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Stormwind)"] = {
		{ids="9260,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (The Exodar)"] = {
		{ids="12817,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Searing Gorge (50-51)"] = {
		{ids="7723,7724,7727,7701,7728,7729,7722,3441,3442,4451,3443,3452,3453,3454,3462,3463,4449,3367,3368,3481,2661,2662"},
	},
	["LEVELING\\Silithus (59-60)"] = {
		{ids="8280,8277,8284,8318,8304,8308,8281,8278"},
	},
	["LEVELING\\Starter Guides (1-11)\\Draenei Starter (1-11)"] = {
		{ids="9288,9757,9591,9592,9593,9675", cond_if=[[Draenei Hunter]]},
		{ids="9369", cond_if=[[not Draenei]]},
		{ids="9421,9449,9450,9451,9462,9464,9465,9467,9468,9461,9555", cond_if=[[Draenei Shaman]]},
		{ids="9279,9280,9283,9463,9473", cond_if=[[Draenei]]},
		{ids="9595", cond_if=[[Draenei Mage]]},
		{ids="9287,10366,9598,9600", cond_if=[[Draenei Paladin]]},
		{ids="9586", cond_if=[[Draenei Priest]]},
		{ids="9289,9582,10350", cond_if=[[Draenei Warrior]]},
		{ids="9409,9371,10302,9293,9799,9294,9305,9303,9309,10303,9311,9798,9312,9313,9314,9452,9453,9455,9454,9456,9506,9512,9530,9513,9523,9531,10324,10428,9538,9539,9540,9541,9542,9544,9514,9527,9537,9602,9515,9559,9623,9625,9560,9562,9616,9564,9573,9565,9566,9570,9571,9622"},
	},
	["LEVELING\\Starter Guides (1-11)\\Dwarf & Gnome Starter (1-11)"] = {
		{ids="3112", cond=[[Gnome Warrior]]},
		{ids="5637", cond_if=[[Human Priest]]},
		{ids="6064,6084,6085,6086", cond_if=[[Dwarf Hunter]]},
		{ids="1638,1639,1640,1665", cond_if=[[(Dwarf or Gnome) and Warrior]]},
		{ids="308", cond_if=[[haveq(310)]]},
		{ids="5625", cond_if=[[Dwarf Priest]]},
		{ids="3107", cond=[[Dwarf Paladin]]},
		{ids="3113", cond=[[Gnome Rogue]]},
		{ids="6387,6391,6388", cond_if=[[Dwarf or Gnome]]},
		{ids="3109", cond=[[Dwarf Rogue]]},
		{ids="3110", cond=[[Dwarf Priest]]},
		{ids="1599,1715,6661,6662", cond_if=[[Gnome Warlock]]},
		{ids="3115,1688,1689", cond=[[Gnome Warlock]]},
		{ids="3106", cond=[[Dwarf Warrior]]},
		{ids="2999,1645,1646,1647,1648,1778,1779,1783,1784,1785", cond_if=[[Dwarf Paladin]]},
		{ids="3108", cond=[[Dwarf Hunter]]},
		{ids="3114", cond=[[Gnome Mage]]},
		{ids="179,233,170,234,183,3364,3361,3365,182,218,282,420,2160,384,400,317,313,5541,287,318,412,312,319,315,310,320,413,311,291,314,433,432,419,417,414,1339,1338,6661,6662"},
	},
	["LEVELING\\Starter Guides (1-11)\\Human Starter (1-11)"] = {
		{ids="3104", cond=[[Human Mage]]},
		{ids="5623,5624,5635", cond_if=[[Human Priest]]},
		{ids="3102", cond=[[Human Rogue]]},
		{ids="1598,1685", cond_if=[[Human Warlock]]},
		{ids="3100", cond=[[Human Warrior]]},
		{ids="3105,1688,1689", cond=[[Human Warlock]]},
		{ids="6181,6281", cond_if=[[Human]]},
		{ids="1638,1639,1640,1665", cond_if=[[Human Warrior]]},
		{ids="184", cond_if=[[itemcount(1972) > 0]]},
		{ids="3103", cond=[[Human Priest]]},
		{ids="3101", cond=[[Human Paladin]]},
		{ids="783,7,5261,33,15,21,18,3903,6,3904,3905,54,2158,62,60,47,85,86,106,84,111,107,87,40,35,76,61,112,37,52,45,5545,71,83,39,109,114,239,1097,11,36"},
	},
	["LEVELING\\Starter Guides (1-11)\\Night Elf Starter (1-11)"] = {
		{ids="3117,6063,6101,6102,6103", cond_if=[[NightElf Hunter]]},
		{ids="1684,1683", cond_if=[[Warrior]]},
		{ids="3118", cond_if=[[NightElf Rogue]]},
		{ids="3119,5629,5627", cond_if=[[NightElf Priest]]},
		{ids="2241,2242", cond_if=[[Rogue]]},
		{ids="6344,6341,6342", cond_if=[[NightElf]]},
		{ids="5622,5621", cond_if=[[Priest]]},
		{ids="3120,5921,5929,5931,6001", cond_if=[[NightElf Druid]]},
		{ids="3116", cond_if=[[NightElf Warrior]]},
		{ids="456,4495,458,457,459,916,3519,917,3521,920,921,3522,928,2159,488,997,475,932,2438,929,918,919,922,476,489,2459,933,4161,930,7383,487,937,931,938,940,923,952,2519,2518,935,2520"},
	},
	["LEVELING\\Stranglethorn Vale (31-32)"] = {
		{ids="1718", cond_if=[[Warrior]]},
		{ids="215,583,185,190,223,1246,690,1301,336,1447,1247,1248,538,1302,1249,1250,1264"},
	},
	["LEVELING\\Stranglethorn Vale (34-35)"] = {
		{ids="1712", cond_if=[[Warrior]]},
		{ids="1181,605,201,198,616,213,578,1182,575,203,204,210,194,186,191,195,187,192,1183,700,1453"},
	},
	["LEVELING\\Stranglethorn Vale (37-38)"] = {
		{ids="577,189,601,207,574,200,328,329,196,188,1116,602,330,331"},
	},
	["LEVELING\\Stranglethorn Vale (43-44)"] = {
		{ids="1363,1364,1477,205,628,606,600,610,209,595,597,599,611,193,197,2864,607,2872"},
	},
	["LEVELING\\Stranglethorn Vale (45-46)"] = {
		{ids="609,580,621,587,604,617,576,608,594,630,624,623"},
	},
	["LEVELING\\Swamp of Sorrows (38-39)"] = {
		{ids="1448,1260,1396,1392,1389,1421,1393,1117,1449,525"},
	},
	["LEVELING\\Swamp of Sorrows (46-46)"] = {
		{ids="625,1395,1119,626,1120,1122"},
	},
	["LEVELING\\Tanaris (44-44)"] = {
		{ids="1118,1190,1188,1194,1707,1690,992,3520"},
	},
	["LEVELING\\Tanaris (47-49)"] = {
		{ids="2876", cond_if=[[itemcount(9250) > 0]]},
		{ids="351", cond_if=[[itemcount(8623) > 0]]},
		{ids="2605,1691,5863,2741,2944,2781,2875,3362,82,8365,8366,2873,3444,3161,1560,2874,4324,2606,2641,10,110,113,162"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains (67-68)"] = {
		{ids="9794,10927,10690,10455,10502,10555,10510,10511,10556,10456,10512,10504,10457,10506,10516,10517,10518,10580,10581,10608,10584,10609,10557,10710,10657,10620,10632,10674,10671,10594,10711,10675,10712,10682,10770,10771,10567,10795,10796,10753,10810,10812,10819,10607,10713,10717,10719,10747,10894,10820,10797,10798,10799,10800,10801,10802,10803,10893,10722,10825"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains Group Quests"] = {
		{ids="10797,10798,10799,10800,10801,10802,10818,10805,10806,10810,10812,10819,10820,10821,10516,10517,10518"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula (58-62)"] = {
		{ids="10119,10288,10140,10254,10141,10160,10055,10482,10078,10483,10142,10143,10484,10144,10895,10485,10903,10146,10340,10344,10163,10382,10394,10396,10397,10395,10236,9373,10238,10629,10630,9558,10058,10909,10916,10399,10047,10093,10050,9355,10079,10099,10161,9349,9361,9356,9351,10935,10936,10057,9390,9399,9398,9426,10443,9383,9423,9424,9543,9427,9430,9372,10159,9912,10255,10403,10367,10368,10369,9417,9385,9563,9420,9418,9545"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula Group Quests"] = {
		{ids="10119,10288,10140,10254,10160,10482,10483,10484,10485,10903,10909,10935,10936,10937,10395,10399,10400,9490,10132,10134,10349,10351"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Isle of Quel'danas"] = {
		{ids="11550,11526,11488,11517,11534,11490,29685"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Nagrand (65-67)"] = {
		{ids="9882", cond_if=[[rep ('The Consortium') < Friendly]]},
		{ids="10210,10211,10551,10552,9848,10116,9835,10115,9792,9854,9789,9857,9861,9855,9850,9858,9862,9818,9800,9815,9819,9913,9871,9900,9925,9914,9874,9878,9869,9917,9936,9940,10476,9956,10109,9923,9821,9804,9805,9849,9918,9924,9873,9920,9921,9922,9810,10108,9928,9927,9931,9932,9933,9962,9967,9970,9972,9973,9977"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Nagrand Group Quests"] = {
		{ids="10109,10111,9818,9819,9821,9849,9853,9854,9789,9855,9850,9858,9859,9851,9856,9852,10227,10228,10231,10251,10252,9923,9924,9954,9955,9962,9967,9970,9972,9977,9938,9982,9991,9999,10001,10004,10009,10010,10011"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm (68-70)"] = {
		{ids="10313,10243,10263,10245,10299,10321,10246,10322,10328,10431,10380,10381", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10189", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10193,10204,10264,10329,10194,10652,10197,10198,10330,10200,10341,10338,10202,10432", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10241", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10210,10211,10551,10552,10183,10190,10342,10186,10173,10191,10199,10203,10225,10224,10226,10265,10221,10262,10206,10300,10174,10205,10232,10333,10266,10334,10331,10184,10188,10185,10343,10305,10182,10307,10306,10337,10332,10312,10239,10316,10314,10319,10192,10240,10222,10301,10233,10209,10223,10176,10924,10267,10311,10234,10348,10417,10433,10434,10418,10235,10423,10268,10237,10426,10424,10336,10855,10335,10435,10269,10247,10427,10429,10317,10315,10318,10430,10856,10436,10440,10857,10270,10411,10437,10422,10345,10353,10438,10275,10339,10384,10385,10405,10271,10281,10272,10273"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm Group Quests"] = {
		{ids="10341,10202,10432,10193,10329,10194,10652,10197,10198,10330,10200,10338,10365,10264", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10243,10245,10299,10321,10322,10323,10263", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10508,10509,10189", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10407,10410,10409,10507,10309,10261,10701,10256,10265,10262,10205,10266,10267,10268,10269,10275,10276,10184,10312,10316,10314,10319,10320,10333,10234,10235,10237,10247,10248,10270,10271,10281,10272,10273,10274,10290,10293,10339,10384,10385,10405,10406,10408,10437,10438,10439,10310"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Shadowmoon Valley (70-70)"] = {
		{ids="10619,10568,10826", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10684", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10571", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10807,10824,10683", cond_if=[[rep('The Scryers')>=Neutral]]},
		{ids="10210,10211,10551,10552,10562,10563,10569,10642,10661,10680,10703,10458,10480,10677,10643,10759,10644,10572,10481,10777,10778,10564,10678,10573,10582,10583,10585,10586,10589,10621,10635,10804,10780,10782,10808"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest (63-65)"] = {
		{ids="10210,10037,10211,10551,10552,10554,10325,10021,10553,10412,9968,9971,9951,9978,9979,10033,9992,10038,10869,10863,9986,9998,10016,10026,10112,10917,10847,10022,10028,10849,10040,10042,10839,10852,10896,10878,10848,10840,10842,10880,10881,10030,9990,10002,10007,10012,9994,10444,9996,10446,10005,10887,10861,10913,10922,10873,10877,10914,10227,10031,10228,10920,10915"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest Group Quests"] = {
		{ids="10051,10898,10842,10877,10923,10033,10035,10922,10929,10930,9982,9991,9999,10001,10004,10009"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh (62-63)"] = {
		{ids="9957", cond_if=[[(rep('Cenarion Expedition') >= Friendly) and not completedq(9968)]]},
		{ids="9697", cond_if=[[(rep('Cenarion Expedition') >= Friendly) and not completedq(9709)]]},
		{ids="9747,9802,9895,9716,9778,9728,9782,9786,9901,9777,9781,9791,9827,9783,9896,10355,9780,9752,9788,10096,9894,9718,9720,9776,9790,9731,9848,10116,9835,10115,9839,9834,9830,9833,9902,9785,9724,9732,9911,9701,9739,9743,9919,9702,9708,9808,9806,9905,9787,9709,9801,9803,9793"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh Group Quests"] = {
		{ids="9730,9817,9817,10116,9894,9895,9729"},
	},
	["LEVELING\\The Hinterlands (49-50)"] = {
		{ids="485", cond_if=[[itemcount(8704) > 0]]},
		{ids="2988,2880,9469,9470,9471,9476,9475,2877,2989,3702,3701"},
	},
	["LEVELING\\Thousand Needles (33-34)"] = {
		{ids="1100,1110,1104,1105,1176,1175,1111,5762,1178"},
	},
	["LEVELING\\Un'Goro Crater (51-52)"] = {
		{ids="3884", cond_if=[[itemcount(11116) > 0]]},
		{ids="4289,4290,3844,3845,4141,4291,4292,3908,4284,4512,5090"},
	},
	["LEVELING\\Un'Goro Crater (54-55)"] = {
		{ids="4245", cond_if=[[haveq(4244) or completedq(4244)]]},
		{ids="4244", cond_if=[[(itemcount(10561) > 0) or (haveq(4244) or completedq(4244))]]},
		{ids="4504,4496,3881,3883,3882,4285,4287,4288,4501,4503,4243,4301,974,4492,4321,4491,980,3789,1047,3764,6761,3781,979,5250"},
	},
	["LEVELING\\Western Plaguelands (52-52)"] = {
		{ids="5092,5215,978,4493"},
	},
	["LEVELING\\Western Plaguelands (56-57)"] = {
		{ids="5216,5217,5021,5022,8275,5048,5050,6182,6183,6184,5219,5097,5401,6185,4984,5058,5060,5220,5051,5533,5537,5222,5903,5223,4985"},
	},
	["LEVELING\\Western Plaguelands (58-59)"] = {
		{ids="5225,6186,5904,5153,5154,4971,4972,5210,4986,5226,6389,6004,6023,5237"},
	},
	["LEVELING\\Wetlands (24-25)"] = {
		{ids="1793,1649,1650,1651,1652", cond_if=[[Paladin]]},
		{ids="2281", cond_if=[[Rogue]]},
		{ids="1716,1738,1739", cond_if=[[Warlock]]},
		{ids="5061", cond_if=[[NightElf Druid]]},
		{ids="1638,1639,1640,1665", cond_if=[[NightElf Warrior]]},
		{ids="484,279,288,463,470,469,276,277,471,637,683,686,689"},
	},
	["LEVELING\\Wetlands (28-30)"] = {
		{ids="9552,9553,9554", cond_if=[[Shaman]]},
		{ids="281,289,943,472,464,305,284,285,286,294,306,295,299,296,275,321,290,465,324,322,292,474,631,303,632,633,634,293"},
	},
	["LEVELING\\Winterspring (55-55)"] = {
		{ids="5083", cond_if=[[itemcount(12771) > 0]]},
		{ids="4842,5082,5084,8461,5085,8465,5086"},
	},
	["LEVELING\\Winterspring (56-56)"] = {
		{ids="5087,5244,5245,4861,3783,4863,4864,4901,6028,6030,5601,4902"},
	},
	["LEVELING\\Northrend (69-80)\\Borean Tundra (70-71)"] = {
		{ids="11945", cond_if=[[subzone("Kaskala")]]},
		{ids="11672,11727,11797,11789,11889,11920,11791,12141,11792,11897,11613,12471,11619,11620,11793,11928,11927,11575,11599,11794,11707,11901,11902,11903,11913,11908,11904,12035,11600,11962,11963,11601,11603,11965,11864,11866,11876,11869,11865,11587,11576,11612,11605,11868,11870,11871,11872,11604,11932,11582,11590,11646,11648,11663,11671,11679,11680,11681,11682,11607,11617,11609,11623,11610,11878,11879,12086,11949,11950,11961,11968,11944,12088,11956,11938,11942,12728,11733,11900,11910,11918,11912,11941,11943,11936,11914,11946,11951,11957,11967,11708,11712,11710,11704,11645,11673,11729,11730,11692,11788,11693,11694,11697,11698,11699,11700,11701,11725,11798,11726,11728,11795,11796,11873,11713,11715,11718,11571,11559,11560,11561,11562,11563,11564,11565,11566,11569,11570,11723,12157"},
	},
	["LEVELING\\Northrend (69-80)\\Dragonblight (71-73)"] = {
		{ids="11960", cond_if=[[subzone("Moa'ki Harbor")]]},
		{ids="12372", cond_if=[[subzone("Wyrmrest Temple")]]},
		{ids="12794", cond_if=[[not Mage]]},
		{ids="12172", cond=[[Mage]]},
		{ids="12000,12166,12171,12006,12004,12167,12168,12169,12055,12060,12013,12065,12067,12083,12092,12098,12107,11958,11959,12028,12030,12009,12011,12016,12017,12031,12032,12119,12174,12235,12237,12251,12253,12275,12258,12282,12276,12272,12269,12277,12281,12309,12287,12311,12312,12319,12320,12321,12325,12326,12455,12462,12457,12463,12465,12466,12290,12291,12301,12305,12475,12476,12477,12478,12766,12458,12447,12467,12142,12143,12146,12472,12473,12474,12460,12416,12417,12418,12419,12768,12262,12261,12263,12264,12265,12267,12266,12495,12123,12497,12435,12498,12454,12469,12043,12045,12044,12046,12047,12049,12052,12050,12112,12075,12076,12079,12077,12078,12499,13347,12790,12511"},
	},
	["LEVELING\\Northrend (69-80)\\Grizzly Hills (73-74)"] = {
		{ids="12225,12226,12212,12215,12292,12227,12216,12217,12293,12210,12294,12444,12295,12222,12223,12255,12443,12316,12323,11984,11989,11990,11991,12484,12029,12483,12007,12042,12190,12299,12307,12300,12302,12308,12310,12105,12109,12219,12220,12246,12247,12248,12250,12296,12268,12244,12289,12802,12068,12158,11998,12159,12160,12161,12328,12327,12329,12134,12330,12411,12279,12002,11981,11986,11988,12003,11993,12010,11982,12070,11985,12014,12128,12081,12113,12114,12116,12093,12094,12099,12082,12120,12121,12137,12152,12180,12129,12130,12183,12131,12184,12138,12185,12153,12154,12770"},
	},
	["LEVELING\\Northrend (69-80)\\Howling Fjord (69-71)"] = {
		{ids="11228,11243,11244,11255,11273,11333,11420,11343,11274,11290,11344,11276,11277,11288,11289,11299,11300,11278,11426,11291,11448,11427,11429,11430,11474,11475,11460,11465,11477,11483,11484,11421,11436,11485,11468,11489,11491,11494,11495,11470,11501,11155,11157,11190,11182,11187,11188,11199,11218,11573,11504,11202,11327,11328,11507,11508,11456,11457,11458,11509,11510,11434,11469,11455,11464,11511,11512,11519,11567,11466,11467,11473,11459,11476,11479,11480,11471,11527,11529,12117,12118,11530,11568,11572,11330,11331,11332,11248,11406,11224,11322,11154,11176,11393,11390,11391,11394,11395,11396,11422,11240,11329,11410,11302,11284,11292,11269,11346,11313,11314,11315,11316,11319,11349,11428,11348,11418,11325,11414,11416,11245,11246,11247,11249,11250,11235,11231,11237,11326,11236,11239,11432,11452"},
	},
	["LEVELING\\Northrend (69-80)\\Icecrown (79-80)"] = {
		{ids="13280", cond_if=[[subzone("Ymirheim")]]},
		{ids="13105", cond_if=[[DeathKnight]]},
		{ids="12995,13071,13069", cond_if=[[subzone("The Shadow Vault")]]},
		{ids="13292,13323,13344,13322", cond_if=[[zone("Icecrown")]]},
		{ids="12839", cond_if=[[haveq(12838)]]},
		{ids="13309", cond_if=[[subzone("The Valley of Lost Hope")]]},
		{ids="12813,12838,12815", cond_if=[[subzone("Death's Rise")]]},
		{ids="13104", cond_if=[[not DeathKnight]]},
		{ids="13418,13036,13008,13040,13039,13044,13045,13070,13086,13118,13122,13130,13135,13110,13125,13139,13141,13157,13068,13225,13231,12887,13336,13341,13300,13296,13072,12891,12893,12896,13284,13232,13073,13074,13075,13076,13286,13290,12898,13237,13291,12938,13106,12939,12955,12999,12943,12949,12951,13085,12992,12982,13084,13042,13092,13059,13043,13091,13121,12806,12807,12810,12814,12840,13117,13119,13120,13134,13221,13136,13138,13140,13077,13078,13079,13080,13264,13386,13387,13388,13389,13390,13391,13392,13081,13082,13083,13393,13315,13168,13169,13170,13171,13172,13174,13155,13133,13211,13152,13144,13212,13220,13235,13143,13145,13146,13147,13160,13394,13395,13396,13397,13318,13319,13320,13342,13345,13321,13398,13399,13332,13400,13401,13402,13403"},
	},
	["LEVELING\\Northrend (69-80)\\Sholazar Basin (76-77)"] = {
		{ids="12521,12489,12524,12624,12522,12688,12525,12523,12589,12592,12549,12520,12526,12550,12804,12634,12551,12543,12558,12644,12645,12560,12544,12556,12654,12569,12528,12595,12603,12605,12683,12681,12607,12658,12614,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12578,12699,12803,12671,12561,12611,12612,12805,12608,12617,12660,12620,12621,12559,12613,12691,12548,12547,12797,12546,12580,12579,12581,12689,12695,12582,12692"},
	},
	["LEVELING\\Northrend (69-80)\\The Storm Peaks (77-79)"] = {
		{ids="12833", cond_if=[[subzone("K3")]]},
		{ids="12818,12843,12844,12827,12836,12819,12826,12820,12828,12829,12830,12831,12832,12821,12822,12823,12824,12862,12846,12870,12854,12863,12864,12865,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,12925,12942,12968,13062,12886,13064,12915,12953,12866,12855,12867,12858,12922,12956,12924,12860,13415,12872,12871,12885,12930,12931,12937,12957,12964,12965,12978,12979,12980,12984,12988,12991,12993,12998,13007,12873,12874,12966,12967"},
	},
	["LEVELING\\Northrend (69-80)\\Zul'Drak (74-76)"] = {
		{ids="12637", cond_if=[[completedq(12631)]]},
		{ids="12643", cond_if=[[completedq(12638)]]},
		{ids="12795", cond_if=[[not completedq(12503)]]},
		{ids="12633,12663", cond_if=[[completedq(12238)]]},
		{ids="12649", cond_if=[[completedq(12643)]]},
		{ids="12638", cond_if=[[completedq(12633)]]},
		{ids="12629", cond_if=[[completedq(12637)]]},
		{ids="12648", cond_if=[[completedq(12629)]]},
		{ids="12631,12664", cond_if=[[not completedq(12238)]]},
		{ids="12859,12902,12861,12883,12884,12894,12903,12901,12912,12904,12914,12630,12652,12661,12916,12919,12669,12673,12677,12686,12676,12690,12710,12713,12503,12740,12565,12505,12596,12506,12597,12598,12512,12606,12553,12552,12583,12584,12555,12599,12932,12933,12934,12935,12936,12948,12799,12557,12609,12610,12504,12508,12507,12510,12562,12514,12527,12516,12623,12627,12615,12622,12628,12635,12640,12639,12632,12642,12650,13549,12655,12646,12647,12653,12659,12662,12665,12666,12667,12672,12668,12674,12675,12684,12685,12709,12712,12708,12707,13556"},
	},
	["LEVELING\\Starter Guides (1-12) & Death Knight (55-58)\\Death Knight Starter (55-58)"] = {
		{ids="12746", cond=[[Draenei]]},
		{ids="12743", cond=[[NightElf]]},
		{ids="12750", cond=[[Scourge]]},
		{ids="12748", cond=[[Orc]]},
		{ids="12745", cond=[[Gnome]]},
		{ids="12744", cond=[[Dwarf]]},
		{ids="12747", cond=[[BloodElf]]},
		{ids="12749", cond=[[Troll]]},
		{ids="12742", cond=[[Human]]},
		{ids="12739", cond=[[Tauren]]},
		{ids="12593,12619,12842,12848,12636,12641,12657,12850,12849,12670,12678,12680,12733,12679,12687,12711,12697,12698,12700,12701,12706,12714,12715,12716,12719,12722,12720,12717,12723,12724,12725,12727,12738,12751,12754,12755,12756,12757,12778,12779,12800,12801,13165,13166,13188"},
	},
	["PROFESSIONS\\Blacksmithing\\Blacksmithing (1-450)"] = {
		{ids="7652,7655,7654,7656"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Armorsmith\\Armorsmith Questline"] = {
		{ids="5283,2758,2759,2760,2761,2762,2763,2765,2764,2771,2772,2773,3321"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Axesmith Questline"] = {
		{ids="5306"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Hammersmith Questline"] = {
		{ids="5305"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Swordsmith Questline"] = {
		{ids="5307"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Weaponsmith Questline"] = {
		{ids="5284"},
	},
	["PROFESSIONS\\Cooking\\Cooking (1-450)"] = {
		{ids="8307,8313,13088,12521,12489,12524,12522,12525,12523,12549,12520,12634,12644,12645,13571"},
	},
	["PROFESSIONS\\Cooking\\Cooking + Fishing (1-450)"] = {
		{ids="6607,10116,9835,10115"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnome Engineer Membership Card Renewal"] = {
		{ids="3647"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnomish Engineering Questline"] = {
		{ids="3632,3640,3641"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineer Membership Card Renewal"] = {
		{ids="3644"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineering Questline"] = {
		{ids="4181,3639"},
	},
	["PROFESSIONS\\First Aid\\First Aid (1-450)"] = {
		{ids="13272"},
	},
	["PROFESSIONS\\Fishing\\Fishing (1-450)"] = {
		{ids="6607"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Dragonscale Leatherworking\\Dragonscale Leatherworking Questline"] = {
		{ids="5141"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Elemental Leatherworking\\Elemental Leatherworking Questline"] = {
		{ids="5144"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Tribal Leatherworking\\Tribal Leatherworking Questline"] = {
		{ids="2847,2848,2849,2850,2851,2852,2853,5143"},
	},
	["PROFESSIONS\\Lockpicking\\Lockpicking (1-300)"] = {
		{ids="2281,2282"},
	},
	["PROFESSIONS\\Tailoring\\Tailoring (1-450)"] = {
		{ids="13272,13272"},
	},
	["PROFESSIONS\\Tailoring\\Farming Guides\\Frostweave Cloth"] = {
		{ids="13272"},
	},
	["REPUTATIONS\\The Burning Crusade\\Cenarion Expedition"] = {
		{ids="9802,9784,9875"},
	},
	["REPUTATIONS\\The Burning Crusade\\Keepers of Time"] = {
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["REPUTATIONS\\The Burning Crusade\\Lower City"] = {
		{ids="10917,10918"},
	},
	["REPUTATIONS\\The Burning Crusade\\Netherwing"] = {
		{ids="11099,11100", cond_if=[[rep("The Aldor") >= Friendly]]},
		{ids="11094,11095", cond_if=[[rep("The Scryers") >= Friendly]]},
		{ids="10804,10811,10814,10836,10837,10854,10858,10866,10870,11012,11013,11014,11019,11049,11053,11075,11054,11083,11081,11082,11084,11063,11064,11067,11068,11069,11070,11071,11092,11041,11107,11108,11113,11114,11112,11111,11110,11109"},
	},
	["REPUTATIONS\\The Burning Crusade\\Ogri'la"] = {
		{ids="11102", cond_if=[[raceclass("Druid")]]},
		{ids="11010", cond_if=[[not raceclass("Druid")]]},
		{ids="10984,10983,10995,10996,10997,10998,11000,11022,11009,11025,11058,11030,11061,11062,11119,11065,11059,11078,11079,11091,11026"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sha'tari Skyguard"] = {
		{ids="11102", cond_if=[[raceclass("Druid")]]},
		{ids="11010", cond_if=[[not raceclass("Druid")]]},
		{ids="11096,11098,11093,11004,11005,11021,11024,11028,11056,11029,11885,11006,11074,11073,10984,10983,10995,10996,10997,10998,11000,11022,11009,11025,11058,11030,11062,11119,11065,11059,11078,11026"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sporeggar"] = {
		{ids="9714", cond_if=[[rep('Sporeggar')<Exalted]]},
		{ids="9742", cond_if=[[rep('Sporeggar')<Friendly]]},
		{ids="9739,9743,9919"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Aldor"] = {
		{ids="10210,10211,10551,10554,11038,10325,10653,10021,10420,10020,11038,10241,10313,10243,10245,10299,10321,10246,10322,10328,10431,10323,10380,10381,10407,10410,10409,10587,10619,10568,10816,10571,10637,10640,10574,10575,10669,10668,10641,10646,10649,10691,10651,10654,10421"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Consortium"] = {
		{ids="9913,9914,9882,9900,9925,9883,9886,9893,9892,10265,10262,10205,10266,10267,10311,10417,10348,10418,10423,10268,10310,10424,10269,10430,10436,10440,10275,10270,10422,10411,10339,10437,10384,10385,10405,10406,10425,10345,10353,10438,10439,10408,10290,10276,10335,10336,10855,10856,10857,10970,10971,10972,10308,9892"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Kurenai"] = {
		{ids="9776,9848,10116,9835,10115,9839,9834,9830,9833,9902,9905,9874,9878,9917,9936,9940,10476,9956,9923,9918,9924,9920,9921,9922,9879,10108,9954,9928,9927,9931,9932,9933,9955,9938,10477"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Scryers"] = {
		{ids="10338", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10204,10202,10432,10508", cond_if=[[rep ('The Scryers') >= Friendly]]},
		{ids="10210,10211,10552,10553,10412,10656,10416,11039,10189,10193,10329,10194,10652,10197,10198,10330,10200,10341,10509,10507,10687,10824,10683,10807,10688,10689,10817,10684,10685,10686,10669,10668,10641,10646,10649,10691,10692,10658,10419"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Sha'tar"] = {
		{ids="10568,10571,10574,10575,10622", cond_if=[[rep ('The Aldor') >= Friendly]]},
		{ids="10683,10684,10685,10686,10622", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10210,9983,9888,9889,9890,9891,9906,9907,9868,9991,9999,10001,10004,10009,10010,10011,10107,9928,9927,9931,9932,9934,10044,10045,10081,10082,10085,10101,10102,10167,10168,10227,10228,10231,10251,10252,10253,10877,10873,10920,10921,10926,10923,10883,10884,10885,10886,10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10704,10628,10705,10706,10707,11052,10793,10781"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Champion of the Naaru"] = {
		{ids="10680", cond_if=[[Alliance]]},
		{ids="10681", cond_if=[[Horde]]},
		{ids="10458,10480,10481,10513,10514,10515,10519,10521,10527,10546,10522,10523,10528,10537,10540,10541,10547,10550,10570,10576,10577,10578,10579,10588,10884,10885,10886,10888"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Hand of A'dal"] = {
		{ids="10568,10571,10574,10575,10622", cond_if=[[rep("The Aldor") >= Neutral]]},
		{ids="10683,10684,10685,10686,10622", cond_if=[[rep("The Scryers") >= Neutral]]},
		{ids="10445,10210,10211,10551,10552,10628,10705,10706,10707,10708,10944,10946,10947,10948,10949,10985"},
	},
	["TITLES\\Burning Crusade Titles\\Reputation\\of the Shattered Sun"] = {
		{ids="11549"},
	},
}
ZGV.Quest_Cache_Turnin_Alliance = {
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 1, Capturing Sanctum)"] = {
		{ids="11496", cond_if=[[haveq(11496) or completedq(11496)]]},
		{ids="11524", cond_if=[[haveq(11524) or completedq(11524)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Activating Portal)"] = {
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11532", cond_if=[[haveq(11532) or completedq(11532)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11513", cond_if=[[haveq(11513) or completedq(11513)]]},
		{ids="11538", cond_if=[[haveq(11538) or completedq(11538)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Portal Activated)"] = {
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11532", cond_if=[[haveq(11532) or completedq(11532)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11538", cond_if=[[haveq(11538) or completedq(11538)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Forge Rebuilt)"] = {
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11539", cond_if=[[haveq(11539) or completedq(11539)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11536,11544", cond_if=[[haveq(11536,11544) or completedq(11536,11544)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11542", cond_if=[[haveq(11542) or completedq(11542)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Rebuilding Forge)"] = {
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11539", cond_if=[[haveq(11539) or completedq(11539)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11535", cond_if=[[haveq(11535) or completedq(11535)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11542", cond_if=[[haveq(11542) or completedq(11542)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Alchemy Lab Built)"] = {
		{ids="11543", cond_if=[[haveq(11543) or completedq(11543)]]},
		{ids="11540", cond_if=[[haveq(11540) or completedq(11540)]]},
		{ids="11541", cond_if=[[haveq(11541) or completedq(11541)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11545", cond_if=[[haveq(11545) or completedq(11545)]]},
		{ids="11521,11546", cond_if=[[haveq(11521,11546) or completedq(11521,11546)]]},
		{ids="11536,11544", cond_if=[[haveq(11536,11544) or completedq(11536,11544)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11545", cond_if=[[readyq(11545)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Fully Built)"] = {
		{ids="11543", cond_if=[[haveq(11543) or completedq(11543)]]},
		{ids="11540", cond_if=[[haveq(11540) or completedq(11540)]]},
		{ids="11541", cond_if=[[haveq(11541) or completedq(11541)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11548", cond_if=[[readyq(11548)]]},
		{ids="11521,11546", cond_if=[[haveq(11521,11546) or completedq(11521,11546)]]},
		{ids="11548", cond_if=[[haveq(11548) or completedq(11548)]]},
		{ids="11536,11544", cond_if=[[haveq(11536,11544) or completedq(11536,11544)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Monument Built)"] = {
		{ids="11543", cond_if=[[haveq(11543) or completedq(11543)]]},
		{ids="11540", cond_if=[[haveq(11540) or completedq(11540)]]},
		{ids="11541", cond_if=[[haveq(11541) or completedq(11541)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11548", cond_if=[[readyq(11548)]]},
		{ids="11548", cond_if=[[haveq(11548) or completedq(11548)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11536,11544", cond_if=[[haveq(11536,11544) or completedq(11536,11544)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11520", cond_if=[[haveq(11520) or completedq(11520)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, No Alchemy Lab or Monument)"] = {
		{ids="11543", cond_if=[[haveq(11543) or completedq(11543)]]},
		{ids="11540", cond_if=[[haveq(11540) or completedq(11540)]]},
		{ids="11541", cond_if=[[haveq(11541) or completedq(11541)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11545", cond_if=[[haveq(11545) or completedq(11545)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11536,11544", cond_if=[[haveq(11536,11544) or completedq(11536,11544)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11545", cond_if=[[readyq(11545)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11520", cond_if=[[haveq(11520) or completedq(11520)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Cooking Dailies"] = {
		{ids="13101", cond_if=[[haveq(13101) or completedq(13101)]]},
		{ids="13100", cond_if=[[haveq(13100) or completedq(13100)]]},
		{ids="13102", cond_if=[[haveq(13102) or completedq(13102)]]},
		{ids="13103", cond_if=[[haveq(13103) or completedq(13103)]]},
		{ids="13107", cond_if=[[haveq(13107) or completedq(13107)]]},
		{ids="13087"},
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Fishing Dailies"] = {
		{ids="13830", cond_if=[[haveq(13830) or completedq(13830)]]},
		{ids="13832", cond_if=[[haveq(13832) or completedq(13832)]]},
		{ids="13834", cond_if=[[haveq(13834) or completedq(13834)]]},
		{ids="13836", cond_if=[[haveq(13836) or completedq(13836)]]},
		{ids="13833", cond_if=[[haveq(13833) or completedq(13833)]]},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Death's Rise Dailies"] = {
		{ids="12813", cond_if=[[haveq(12813) or completedq(12813)]]},
		{ids="12815", cond_if=[[haveq(12815) or completedq(12815)]]},
		{ids="12838", cond_if=[[haveq(12838) or completedq(12838)]]},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Shadowvault Dailies"] = {
		{ids="12995,13069,13071"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\The Skybreaker Dailies"] = {
		{ids="13309", cond_if=[[haveq(13309) or completedq(13309)]]},
		{ids="13292,13322", cond_if=[[haveq(13292,13322) or completedq(13292,13322)]]},
		{ids="13284", cond_if=[[haveq(13284) or completedq(13284)]]},
		{ids="13300", cond_if=[[haveq(13300) or completedq(13300)]]},
		{ids="13336", cond_if=[[haveq(13336) or completedq(13336)]]},
		{ids="13333", cond_if=[[haveq(13333) or completedq(13333)]]},
		{ids="13280", cond_if=[[haveq(13280) or completedq(13280)]]},
		{ids="13289,13323,13344,13297", cond_if=[[haveq(13289,13323,13344,13297) or completedq(13289,13323,13344,13297)]]},
		{ids="13382,13404", cond_if=[[haveq(13382,13404) or completedq(13382,13404)]]},
	},
	["DAILIES\\Wrath of the Lich King\\Jewelcrafting Dailies"] = {
		{ids="12960", cond_if=[[haveq(12960) or completedq(12960)]]},
		{ids="12959", cond_if=[[haveq(12959) or completedq(12959)]]},
		{ids="12961", cond_if=[[haveq(12961) or completedq(12961)]]},
		{ids="12963", cond_if=[[haveq(12963) or completedq(12963)]]},
		{ids="12958", cond_if=[[haveq(12958) or completedq(12958)]]},
		{ids="12962", cond_if=[[haveq(12962) or completedq(12962)]]},
		{ids="13041"},
	},
	["DAILIES\\Wrath of the Lich King\\The Kalu'ak Dailies"] = {
		{ids="11504,11507,11508,11509,11469,11472,11945,11960"},
		{ids="11573", cond_if=[[Alliance]]},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\Frenzyheart Tribe Dailies"] = {
		{ids="12732", cond_if=[[haveq(12732) or completedq(12732) or completedq(12732)]]},
		{ids="12758", cond_if=[[haveq(12758) or completedq(12758) or completedq(12758)]]},
		{ids="12734", cond_if=[[haveq(12734) or completedq(12734) or completedq(12734)]]},
		{ids="12703", cond_if=[[haveq(12703) or completedq(12703) or completedq(12703)]]},
		{ids="12741", cond_if=[[haveq(12741) or completedq(12741) or completedq(12741)]]},
		{ids="12760", cond_if=[[haveq(12760) or completedq(12760)]]},
		{ids="12759", cond_if=[[haveq(12759) or completedq(12759) or completedq(12759)]]},
		{ids="12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12654,12573,12574,12575,12576,12577,12578,12580,12579,12581,12692,12702"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\The Oracles Dailies"] = {
		{ids="12705", cond_if=[[haveq(12705) or completedq(12705)]]},
		{ids="12762", cond_if=[[haveq(12762) or completedq(12762)]]},
		{ids="12737", cond_if=[[haveq(12737) or completedq(12737)]]},
		{ids="12736", cond_if=[[haveq(12736) or completedq(12736)]]},
		{ids="12735", cond_if=[[haveq(12735) or completedq(12735)]]},
		{ids="12761", cond_if=[[haveq(12761) or completedq(12761)]]},
		{ids="12726", cond_if=[[haveq(12726) or completedq(12726)]]},
		{ids="12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12654,12573,12574,12575,12576,12577,12578,12580,12579,12581,12695,12704"},
	},
	["DAILIES\\Wrath of the Lich King\\The Sons of Hodir\\The Sons of Hodir Dailies"] = {
		{ids="13001", cond_if=[[not completedq(13001)]]},
		{ids="13046", cond_if=[[haveq(13046) or completedq(13046)]]},
		{ids="13003", cond_if=[[haveq(13003) or completedq(13003)]]},
		{ids="13420", cond_if=[[not completedq(13420)]]},
		{ids="13006,13006", cond_if=[[haveq(13006) or completedq(13006)]]},
		{ids="12981,12981", cond_if=[[haveq(12981) or completedq(12981)]]},
		{ids="12977,12977", cond_if=[[haveq(12977) or completedq(12977)]]},
		{ids="12994", cond_if=[[haveq(12994) or completedq(12994)]]},
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,13062,12886,13064,12922,12956,12915,12966,12967,12924,13009,13050,13051,12975,12976,12985,12987,13011,13010,13057,13005,13035,13047"},
	},
	["DAILIES\\Wrath of the Lich King\\Wyrmrest Accord Dailies"] = {
		{ids="12372", cond_if=[[not completedq(13413)]]},
		{ids="12372", cond_if=[[completedq(13413)]]},
		{ids="12000,12055,12004,12060,12065,12067,12083,12098,12107,12119,12766,12460,12416,12417,12418,12768,12419,12123,12435,11918,11936,11919,13412,13413,11940,13414"},
	},
	["DAILIES\\The Burning Crusade\\Netherwing\\Netherwing Daily Quests"] = {
		{ids="11077", cond_if=[[haveq(11077) or completedq(11077)]]},
		{ids="11076", cond_if=[[haveq(11076) or completedq(11076)]]},
		{ids="11015,11016,11018,11017", cond_if=[[haveq(11015,11016,11018,11017) or completedq(11015,11016,11018,11017)]]},
		{ids="11086,11097,11101", cond_if=[[haveq(11086,11097,11101) or completedq(11086,11097,11101)]]},
		{ids="11020,11035", cond_if=[[haveq(11020,11035) or completedq(11020,11035)]]},
		{ids="11055", cond_if=[[haveq(11055) or completedq(11055)]]},
	},
	["DAILIES\\The Burning Crusade\\Ogri'la\\Ogri'la Daily Quests"] = {
		{ids="11051", cond_if=[[haveq(11051) or completedq(11051)]]},
		{ids="11023", cond_if=[[haveq(11023) or completedq(11023)]]},
		{ids="11066", cond_if=[[haveq(11066) or completedq(11066)]]},
		{ids="11080", cond_if=[[haveq(11080) or completedq(11080)]]},
	},
	["DAILIES\\The Burning Crusade\\Sha'tari Skyguard\\Sha'tari Skyguard Daily Quests"] = {
		{ids="11008,11085,11023,11066"},
	},
	["DAILIES\\The Burning Crusade\\Shattrath Cooking Dailies"] = {
		{ids="11381,11379,11380,11377", cond_if=[[haveq(11381,11379,11380,11377) or completedq(11381,11379,11380,11377)]]},
	},
	["DUNGEONS\\Classic\\Blackfathom Deeps Quests"] = {
		{ids="3765,1198,1275,1199,1200,971"},
	},
	["DUNGEONS\\Classic\\Blackrock Depths Quests"] = {
		{ids="3702,4128,4182,3701,3441,3442,3443,3452,3453,3454,3462,3463,3481,4324,4022,3801,4341,4342,4241,4264,3802,4282,4322,4242,4286,4262,4361,4126,4123,4136,4024,4201,4362,4263,4363"},
	},
	["DUNGEONS\\Classic\\Dire Maul East Quests"] = {
		{ids="5527,7488,7441,5526"},
	},
	["DUNGEONS\\Classic\\Dire Maul North Quests"] = {
		{ids="5518,7429,7703,7482"},
	},
	["DUNGEONS\\Classic\\Dire Maul North Tribute (58-60)"] = {
		{ids="1193"},
	},
	["DUNGEONS\\Classic\\Dire Maul West Quests"] = {
		{ids="7461,7462"},
	},
	["DUNGEONS\\Classic\\Gnomeregan Quests"] = {
		{ids="2925,2923,2927,2926,2924,2922,2930,2929,2962,2928"},
	},
	["DUNGEONS\\Classic\\Lower Blackrock Spire Quests"] = {
		{ids="3520,3527,4787,3528,5065,5001,5002,4867,4742,5081,4701,4866,4729,4862,4788"},
	},
	["DUNGEONS\\Classic\\Maraudon Quests"] = {
		{ids="7044,7046,7067,7028,7041,7065,7070,7066"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Blackwing Lair Attunement"] = {
		{ids="7761"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Molten Core Attunement"] = {
		{ids="7848"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Naxxramas Attunement"] = {
		{ids="9123", cond_if=[[haveq(9123) or completedq(9123)]]},
		{ids="9122", cond_if=[[haveq(9122) or completedq(9122)]]},
		{ids="9121", cond_if=[[haveq(9121) or completedq(9121)]]},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Onyxia's Lair Attunement"] = {
		{ids="4182,4241,4242,4264,4282,4322,6402,6403,6501,6502"},
	},
	["DUNGEONS\\Classic\\Razorfen Downs Quests"] = {
		{ids="6626,3523,3525,3636"},
	},
	["DUNGEONS\\Classic\\Razorfen Kraul Quests"] = {
		{ids="1100,1144,1221,1101,1142"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Armory Quests"] = {
		{ids="6141,261,1052,1053"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Cathedral Quests"] = {
		{ids="6141,261,1052,1053"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Library Quests"] = {
		{ids="6141,261,1052,1053,1050"},
	},
	["DUNGEONS\\Classic\\Scholomance Quests"] = {
		{ids="4726,4808,4809,4810,4907,4734,4735,5522,5531,5091,5092,5097,5533,5537,5538,5801,5803,5382,5343,5529,4771,5515,5582,5384,5461,5462,5463,5463,5465,5466"},
	},
	["DUNGEONS\\Classic\\Stratholme - Live Side Quests"] = {
		{ids="5281,5542,5543,5544,5742,5781,5845,5846,5282,5848,5214,5251,5262"},
	},
	["DUNGEONS\\Classic\\Stratholme - Undead Side Quests"] = {
		{ids="5382,5515,5384,5461,5462,5251,5262,5463,5263,5212,5464,5243,5213"},
	},
	["DUNGEONS\\Classic\\Temple of Atal'Hakkar Quests"] = {
		{ids="1448,1449,1450,1451,1452,1469,3445,3444,3520,3527,4787,4141,4142,3446,3447,3373,1475,1446,4143,3528"},
	},
	["DUNGEONS\\Classic\\The Deadmines Quests"] = {
		{ids="65,132,135,141,142,155,166,214,373,2040,167,168"},
	},
	["DUNGEONS\\Classic\\The Stockade Quests"] = {
		{ids="303,373,389,391,387,388,377,386,378"},
	},
	["DUNGEONS\\Classic\\Uldaman Quests"] = {
		{ids="2278,2279", cond_if=[[level >=40]]},
		{ids="2198,2199,720,721,722,723,724,725,726,707,738,738,2500,762,2200,2398,2201,704,17,3448,2439,2204,2240,1139"},
	},
	["DUNGEONS\\Classic\\Upper Blackrock Spire Quests"] = {
		{ids="4766,4182,4241,4242,4264,4282,4322,6402,6403,4726,4808,4809,6501,4810,4907,6804,6805,5089,4734,4764,5102,5047,6502,5162,5164,6821,4735"},
	},
	["DUNGEONS\\Classic\\Wailing Caverns Quests"] = {
		{ids="6981", cond_if=[[haveq(6981) or completedq(6981)]]},
		{ids="3366", cond_if=[[haveq(3366) or completedq(3366)]]},
		{ids="865,1486,1487,1491,959,3370"},
	},
	["DUNGEONS\\Classic\\Zul'Farrak Quests"] = {
		{ids="2988,2989,2990,3520,3527,2768,2865,3042,2770,2846,2991"},
	},
	["DUNGEONS\\The Burning Crusade\\Auchenai Crypts Quests"] = {
		{ids="10227,10228,10231,10251,10252,10253,10107,9928,9927,9931,9932,10167,10168,10164"},
	},
	["DUNGEONS\\The Burning Crusade\\Black Temple Attunement"] = {
		{ids="10568,10571,10574", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10575,10622,10628,10705,10706,10707,10708,10944,10946,10947,10948,10949,10985"},
		{ids="10683,10684,10685", cond_if=[[rep ('The Scryers') >= Neutral]]},
	},
	["DUNGEONS\\The Burning Crusade\\Blood Furnace Quests"] = {
		{ids="9589,9607"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Citadel Attunement"] = {
		{ids="10754,10762,10763,10764"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Ramparts Quests"] = {
		{ids="9575,9587"},
	},
	["DUNGEONS\\The Burning Crusade\\Karazhan Attunement"] = {
		{ids="11216,9824,9825,9826,9829,9831,9832,9836,9837,9838"},
	},
	["DUNGEONS\\The Burning Crusade\\Mana-Tombs Quests"] = {
		{ids="10216,10165,10218,10969,10970,10425,10971,10973,10974,10976,10977"},
	},
	["DUNGEONS\\The Burning Crusade\\Mount Hyjal Attunement"] = {
		{ids="10445"},
	},
	["DUNGEONS\\The Burning Crusade\\Old Hillsbrad Foothills Quests"] = {
		{ids="10279,10277,10282,10283,10284,10285,12513"},
	},
	["DUNGEONS\\The Burning Crusade\\Serpentshrine Cavern Attunement"] = {
		{ids="9644", cond_if=[[haveq(9644) or completedq(9644)]]},
		{ids="9630,9638,9639,9640,9645,9680,9631,9637,10901"},
	},
	["DUNGEONS\\The Burning Crusade\\Sethekk Halls Quests"] = {
		{ids="10180,10097,10098"},
	},
	["DUNGEONS\\The Burning Crusade\\Shadow Labyrinth Quests"] = {
		{ids="10641,10668,10669,10646,10621,10626,10662,10664,11216,9824,9825,9826,9829,10177,10178,10094,10885,10666,10091,10095,9831,10649"},
		{ids="10587,10637,10640", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10687,10688", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10689", cond_if=[[rep ('The Scryers') >= Neutral]]},
	},
	["DUNGEONS\\The Burning Crusade\\Shattered Halls Quests"] = {
		{ids="10883,10884"},
	},
	["DUNGEONS\\The Burning Crusade\\Tempest Keep Attunement"] = {
		{ids="10883,10884,10885,10886,10888"},
	},
	["DUNGEONS\\The Burning Crusade\\The Arcatraz Quests"] = {
		{ids="10568,10571,10574", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10683,10684,10685", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10575,10622,10628,10705,10704,10706,11216,9824,9825,9826,9829,9831,9832"},
	},
	["DUNGEONS\\The Burning Crusade\\The Black Morass Quests"] = {
		{ids="10902", cond_if=[[skill("Alchemy") < 0]]},
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["DUNGEONS\\The Burning Crusade\\The Botanica Quests"] = {
		{ids="10897", cond_if=[[skill("Alchemy") < 0]]},
		{ids="10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10257,10704"},
	},
	["DUNGEONS\\The Burning Crusade\\The Cipher of Damnation"] = {
		{ids="10680,10458,10480,10481,10513,10514,10515,10519,10521,10522,10523,10527,10528,10537,10540,10546,10541,10547,10550,10570,10576,10577,10578,10579,10588"},
	},
	["DUNGEONS\\The Burning Crusade\\The Mechanar Quests"] = {
		{ids="10621,10626,10662,10664,10665"},
	},
	["DUNGEONS\\The Burning Crusade\\The Slave Pens Quests"] = {
		{ids="9738"},
	},
	["DUNGEONS\\The Burning Crusade\\The Steamvault Quests"] = {
		{ids="10621,10626,10662,10664,10666,9763,9764,10885,10667"},
	},
	["DUNGEONS\\The Burning Crusade\\The Underbog Quests"] = {
		{ids="9715,9717,9719,9738"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Ahn'kahet: The Old Kingdom Quests"] = {
		{ids="13187,13204"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Azjol-Nerub Quests"] = {
		{ids="13167,13182"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Drak'Tharon Keep Quests"] = {
		{ids="12210,11984,11989,11990,11991,12007,12042,12802,12068,12484,12029,12238,12037"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Gundrak Quests"] = {
		{ids="13111,13098"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Lightning Quests"] = {
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12996,12997,13061,13062,12886,13064,12922,12915,12956,12966,12967,12967,12924,13009,13050,13051,12975,12976,13010,13057,13005,13035,13047,13108,13109"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Stone Quests"] = {
		{ids="13207"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Culling of Stratholme Quests"] = {
		{ids="13149,13151"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Nexus Quests"] = {
		{ids="11733,11941,11900,11910,11943,11946,11951,11957,11967,11969,13094,11973,11905,11911"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Oculus Quests"] = {
		{ids="13124,13126,13127,13128"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Violet Hold Quests"] = {
		{ids="13158,13159"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Keep Quests"] = {
		{ids="13205,11252"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Pinnacle Quests"] = {
		{ids="13131,13132"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Month"] = {
		{ids="12420"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Year"] = {
		{ids="12420"},
	},
	["EVENTS\\Brewfest\\Achievements\\Direbrewfest"] = {
		{ids="12062"},
	},
	["EVENTS\\Brewfest\\Achievements\\Down With The Dark Iron"] = {
		{ids="12020"},
	},
	["EVENTS\\Brewfest\\Brewfest Dailies"] = {
		{ids="11293", cond_if=[[haveq(11293)]]},
		{ids="11294", cond_if=[[haveq(11294)]]},
		{ids="12020,12318,12062"},
	},
	["EVENTS\\Brewfest\\Brewfest Quests"] = {
		{ids="12193", cond_if=[[haveq(12193) or completedq(12193)]]},
		{ids="12022,11318,11122,11117,11118,12318,12062"},
	},
	["EVENTS\\Children's Week\\Children's Week Main Questline"] = {
		{ids="1468,1479,1558,1687,4822,558,171"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Sayge's Fortunes (Elwynn Forest)"] = {
		{ids="7937,7938,7944,7945"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Sayge's Fortunes (Mulgore)"] = {
		{ids="7937,7938,7944,7945"},
	},
	["EVENTS\\Feast of Winter Veil\\Feast of Winter Veil Quest"] = {
		{ids="7062,7063,7022,7025,7042,7043,7045,8762"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Hallowed Be Thy Name"] = {
		{ids="12133", cond_if=[[haveq(12133) or completedq(12133)]]},
		{ids="11131,12135,12133", cond_if=[[haveq(11131,12135,12133) or completedq(11131,12135,12133)]]},
		{ids="11356,11360,8373,1658"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Rotten Hallow"] = {
		{ids="8373,1658"},
	},
	["EVENTS\\Hallow's End\\Achievements\\The Savior of Hallow's End"] = {
		{ids="12133", cond_if=[[haveq(12133) or completedq(12133)]]},
		{ids="11131,12135,12133", cond_if=[[haveq(11131,12135,12133) or completedq(11131,12135,12133)]]},
		{ids="11356,11360"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Tricks and Treats of Azeroth"] = {
	},
	["EVENTS\\Hallow's End\\Hallow's End Daily Quests"] = {
		{ids="12133", cond_if=[[haveq(12133) or completedq(12133)]]},
		{ids="11131", cond_if=[[haveq(11131) or completedq(11131)]]},
		{ids="12135", cond_if=[[haveq(12135) or completedq(12135)]]},
		{ids="11356,11404"},
	},
	["EVENTS\\Hallow's End\\Hallow's End Quests"] = {
		{ids="12133", cond_if=[[haveq(12133) or completedq(12133)]]},
		{ids="8356,11356,11360,8353,8355,8357,8311,8373,1658,11135"},
	},
	["EVENTS\\Harvest Festival\\Harvest Festival Quest"] = {
		{ids="8149"},
	},
	["EVENTS\\Love is in the Air\\Love is in the Air Quests"] = {
		{ids="8903,9024,9025,9026,9027,9028"},
	},
	["EVENTS\\Lunar Festival\\Lunar Festival Main Questline"] = {
		{ids="8870,8867,8883"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Bonfires"] = {
		{ids="9324,9325,9326,11935", cond_if=[[haveq(9324,9325,9326,11935) or completedq(9324,9325,9326,11935)]]},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Dailies"] = {
		{ids="11947", cond_if=[[haveq(11947) or completedq(11947)]]},
		{ids="11953", cond_if=[[haveq(11953) or completedq(11953)]]},
		{ids="11917", cond_if=[[haveq(11917) or completedq(11917)]]},
		{ids="11948", cond_if=[[haveq(11948) or completedq(11948)]]},
		{ids="11954", cond_if=[[haveq(11954) or completedq(11954)]]},
		{ids="11952", cond_if=[[haveq(11952) or completedq(11952)]]},
		{ids="11921,11924"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Quests"] = {
		{ids="11731,11657,11964,11882,11886,11891,12012,11955,11696,11691,11972"},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Cloak Quest"] = {
		{ids="8557", cond=[[Warrior]]},
		{ids="8695", cond=[[Paladin]]},
		{ids="8690", cond=[[Shaman]]},
		{ids="8693", cond=[[Rogue]]},
		{ids="8691", cond=[[Mage]]},
		{ids="8692", cond=[[Druid]]},
		{ids="8689", cond=[[Priest]]},
		{ids="8696", cond=[[Hunter]]},
		{ids="8694", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Ring Quest"] = {
		{ids="8556", cond=[[Warrior]]},
		{ids="8703", cond=[[Paladin]]},
		{ids="8698", cond=[[Shaman]]},
		{ids="8701", cond=[[Rogue]]},
		{ids="8699", cond=[[Mage]]},
		{ids="8700", cond=[[Druid]]},
		{ids="8697", cond=[[Priest]]},
		{ids="8704", cond=[[Hunter]]},
		{ids="8702", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Weapon Quest"] = {
		{ids="8558", cond=[[Warrior]]},
		{ids="8711", cond=[[Paladin]]},
		{ids="8706", cond=[[Shaman]]},
		{ids="8709", cond=[[Rogue]]},
		{ids="8707", cond=[[Mage]]},
		{ids="8708", cond=[[Druid]]},
		{ids="8705", cond=[[Priest]]},
		{ids="8712", cond=[[Hunter]]},
		{ids="8710", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Boots Quest"] = {
		{ids="8559", cond=[[Warrior]]},
		{ids="8655", cond=[[Paladin]]},
		{ids="8621", cond=[[Shaman]]},
		{ids="8637", cond=[[Rogue]]},
		{ids="8634", cond=[[Mage]]},
		{ids="8665", cond=[[Druid]]},
		{ids="8596", cond=[[Priest]]},
		{ids="8626", cond=[[Hunter]]},
		{ids="8660", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Helm Quest"] = {
		{ids="8561", cond=[[Warrior]]},
		{ids="8628", cond=[[Paladin]]},
		{ids="8623", cond=[[Shaman]]},
		{ids="8639", cond=[[Rogue]]},
		{ids="8632", cond=[[Mage]]},
		{ids="8667", cond=[[Druid]]},
		{ids="8592", cond=[[Priest]]},
		{ids="8657", cond=[[Hunter]]},
		{ids="8662", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Legs Quest"] = {
		{ids="8560", cond=[[Warrior]]},
		{ids="8629", cond=[[Paladin]]},
		{ids="8624", cond=[[Shaman]]},
		{ids="8640", cond=[[Rogue]]},
		{ids="8631", cond=[[Mage]]},
		{ids="8668", cond=[[Druid]]},
		{ids="8593", cond=[[Priest]]},
		{ids="8658", cond=[[Hunter]]},
		{ids="8663", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Shoulder Quest"] = {
		{ids="8544", cond=[[Warrior]]},
		{ids="8630", cond=[[Paladin]]},
		{ids="8602", cond=[[Shaman]]},
		{ids="8641", cond=[[Rogue]]},
		{ids="8625", cond=[[Mage]]},
		{ids="8669", cond=[[Druid]]},
		{ids="8594", cond=[[Priest]]},
		{ids="8659", cond=[[Hunter]]},
		{ids="8664", cond=[[Warlock]]},
	},
	["LEVELING\\Alterac Mountains (39-39)"] = {
		{ids="1712,1713", cond_if=[[Warrior]]},
		{ids="525,602,1449,1450,1451,500,537,512,551"},
	},
	["LEVELING\\Arathi Highlands (33-33)"] = {
		{ids="690,659,681"},
	},
	["LEVELING\\Arathi Highlands (39-41)"] = {
		{ids="1661", cond_if=[[Paladin]]},
		{ids="642,658,657,660,691,693,651,663,665,662,664,666,668,661"},
	},
	["LEVELING\\Ashenvale (22-24)"] = {
		{ids="9504,9508,9509", cond_if=[[Shaman]]},
		{ids="967,1010,970,945,10752,1020,1054,1033,945,973,991,1007,1009,1023,1034,1008,4740,731,994,741"},
	},
	["LEVELING\\Badlands (42-43)"] = {
		{ids="554,707,720,719,718,1106,738,1108,710,711,712,703,733,2500,739"},
	},
	["LEVELING\\Bloodmyst Isle (14-20)"] = {
		{ids="9501,9503", cond_if=[[Shaman]]},
		{ids="9600", cond_if=[[Draenei Paladin]]},
		{ids="9625,9693,9624,9634,9567,9594,9641,9581,9576,9629,9574,9694,9779,9696,9620,9628,9648,9698,9699,10063,9548,9549,9550,9557,9584,9646,9700,9580,9643,9578,9579,9703,9706,10064,10066,10065,9670,10067,9569,9669,9585,9741,9748,9711,9647,9561,9687,9688,9649,9632"},
	},
	["LEVELING\\Boosted Characters\\Boosted Druid Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Hunter Intro"] = {
		{ids="9757,9591,9592,9593,9675", cond_if=[[Draenei Hunter]]},
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Mage Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Paladin Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Priest Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Rogue Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warlock Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warrior Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Burning Steppes (53-54)"] = {
		{ids="4512,3823,4324,4022,3824,4283,4182,4726,4296,3825,5158"},
	},
	["LEVELING\\Cenarion Battlegear"] = {
		{ids="8800,8548,8572,8573,8574"},
	},
	["LEVELING\\Cenarion Field Duty Combat Assignments"] = {
		{ids="8687", cond_if=[[haveq(8687)]]},
		{ids="8771", cond_if=[[haveq(8771)]]},
		{ids="8770", cond_if=[[haveq(8770)]]},
		{ids="8501", cond_if=[[haveq(8501)]]},
		{ids="8773", cond_if=[[haveq(8773)]]},
		{ids="8539", cond_if=[[haveq(8539)]]},
		{ids="8775", cond_if=[[haveq(8775)]]},
		{ids="8777", cond_if=[[haveq(8777)]]},
		{ids="8776", cond_if=[[haveq(8776)]]},
		{ids="8774", cond_if=[[haveq(8774)]]},
		{ids="8772", cond_if=[[haveq(8772)]]},
		{ids="8502", cond_if=[[haveq(8502)]]},
		{ids="8507"},
	},
	["LEVELING\\Cenarion Field Duty Logistics Assignments"] = {
		{ids="8782", cond_if=[[haveq(8782)]]},
		{ids="8779", cond_if=[[haveq(8779)]]},
		{ids="8541,8805", cond_if=[[haveq(8541,8805)]]},
		{ids="8497", cond_if=[[haveq(8497)]]},
		{ids="8496", cond_if=[[haveq(8496)]]},
		{ids="8783", cond_if=[[haveq(8783)]]},
		{ids="8778", cond_if=[[haveq(8778)]]},
		{ids="8829", cond_if=[[haveq(8829)]]},
		{ids="8781,8780", cond_if=[[haveq(8781,8780)]]},
		{ids="8507"},
	},
	["LEVELING\\Cenarion Field Duty Tactical Assignments"] = {
		{ids="8739", cond_if=[[haveq(8739)]]},
		{ids="8537,8535", cond_if=[[haveq(8537,8535)]]},
		{ids="8737,8536", cond_if=[[haveq(8737,8536)]]},
		{ids="8538,8498", cond_if=[[haveq(8538,8498)]]},
		{ids="8534,8738,8740", cond_if=[[haveq(8534,8738,8740)]]},
		{ids="8507"},
	},
	["LEVELING\\Class Quests\\Druid Class Quests"] = {
		{ids="5923,5921,5929,5931,6001,6121,6122,6123,6124,6125,26,29,272,5061,9063,9052,9051,9053", cond_if=[[NightElf Druid]]},
	},
	["LEVELING\\Class Quests\\Hunter Class Quests"] = {
		{ids="6063,6101,6102,6103", cond_if=[[NightElf Hunter]]},
		{ids="6064,6084,6085,6086", cond_if=[[Dwarf Hunter]]},
		{ids="8151,8153,8231,8232,7632,7636", cond_if=[[Hunter]]},
	},
	["LEVELING\\Class Quests\\Mage Class Quests"] = {
		{ids="1860,1861,1919,1920,1921,1939,1938,1940,1947,1949,1950,1951,1952,1953,1954,1955,1956,1957,2861,2846,7463", cond_if=[[Mage]]},
	},
	["LEVELING\\Class Quests\\Paladin Class Quests"] = {
		{ids="2998,1641,1642,1643,1644,1780,1781,1786,1787,1788", cond_if=[[Human Paladin]]},
		{ids="1649,1650,1651,1652,1653,1655,1654,1806,1661,8415,8414,8416,8418,7638,7637,7639,7640,7641,7642,7648,7645,7643,7644,7646,7647", cond_if=[[Paladin]]},
		{ids="2997,1646,1647,1648,1778,1779,1783,1784,1785", cond_if=[[Dwarf Paladin]]},
	},
	["LEVELING\\Class Quests\\Priest Class Quests"] = {
		{ids="5635,5641", cond_if=[[Dwarf Priest]]},
		{ids="5637,5676", cond_if=[[Human Priest]]},
		{ids="5629,5673", cond_if=[[NightElf Priest]]},
	},
	["LEVELING\\Class Quests\\Rogue Class Quests"] = {
		{ids="2360,2359,2607,2608,8233,8234,8235,8236", cond_if=[[Rogue]]},
	},
	["LEVELING\\Class Quests\\Shaman Class Quests"] = {
		{ids="9502,9501,9503,9504,9508,9509,9552,9553,9554,8410,8412,8413", cond_if=[[Shaman]]},
		{ids="9449,9450,9451,9462,9464,9465,9467,9468,9461,9555", cond_if=[[Draenei Shaman]]},
	},
	["LEVELING\\Class Quests\\Warlock Class Quests"] = {
		{ids="1685,1688", cond=[[Human Warlock]]},
		{ids="1598,1689", cond_if=[[Human Warlock]]},
		{ids="1717,1716,1738,1739,1798,1758,1802,1804,1471,4487,4490,7601,8420,8421,7602,8422,7603,7562,7563,7564,7626,7627,7628,7630,7623,7624,7625,7629,7631", cond_if=[[Warlock]]},
		{ids="1599,1715,1688,1689", cond_if=[[Gnome Warlock]]},
	},
	["LEVELING\\Class Quests\\Warrior Class Quests"] = {
		{ids="1718,1719,1791,1712,1713,8417,8423,8424,8425", cond_if=[[Warrior]]},
		{ids="1638,1639,1640,1665", cond_if=[[Human Warrior]]},
		{ids="1679,1678", cond_if=[[(Dwarf Warrior) or (Gnome Warrior)]]},
		{ids="1684,1683", cond_if=[[NightElf Warrior]]},
	},
	["LEVELING\\Darkshore (11-14)"] = {
		{ids="983,3524,4681,2118,984,4811,4812,4813,4761,954,955,956,4762,2138,953,957,958,985,4722,963"},
	},
	["LEVELING\\Darkshore (20-22)"] = {
		{ids="9633,2098,2078,965,966,982,4763,947,4727,4725,1138,2139,986,948,729,944,949,950,993"},
		{ids="26,6121,29,6122,6123,6124,6125", cond_if=[[NightElf Druid]]},
	},
	["LEVELING\\Desolace (35-37)"] = {
		{ids="1453,1458,1437,1454,5561,1382,1455,1459,1387,1465,5501,1438,1439,5741,6161,6027,1384,1370,1456,1440,1112,1114,1183,1186"},
	},
	["LEVELING\\Duskwood (25-27)"] = {
		{ids="66,174,175,163,164,165,226,67,5,93,56,68,225,227,101,148,177,149,154,95,240,230,157,69,70,72,262,265,266,158,453,268,323,156,57"},
	},
	["LEVELING\\Duskwood (30-31)"] = {
		{ids="322,293,1274,1241,1242,1243,173,74,75,159,133,134,325,78,58,79,80,160,251,401,252,97,221,1244,98,181"},
	},
	["LEVELING\\Dustwallow Marsh (33-33)"] = {
		{ids="11126,1302,1264,11123"},
	},
	["LEVELING\\Dustwallow Marsh (34-34)"] = {
		{ids="1718,1719", cond_if=[[Warrior]]},
		{ids="1219,1220,1284,1252,1253,1259,1285,1319,1320,1178,1111"},
	},
	["LEVELING\\Dustwallow Marsh (41-42)"] = {
		{ids="1260,11128,11133,11191,11192,11193,11134,11194,11209,11174,11207,11212,1286,11173,11208,11214,11184,11158,11210,11198,1287,1265,11136,11137,11138,11139,11140,11177,1218,11180,11181,11183,11143,1266,1324,11146,11145,11147,11144,11148,1177,1204,1222,1206,1203,11141,11142"},
	},
	["LEVELING\\Dustwallow Marsh (44-45)"] = {
		{ids="11160,11161,11149,11185,11156,11150,11211,11159,11162,11217,11151,11152"},
	},
	["LEVELING\\Eastern Plaguelands (57-58)"] = {
		{ids="5601,5149,6030,5241,5245,5281,6164,5542,5543,5544,5742,6021,5211"},
	},
	["LEVELING\\Extra Zones\\Westfall"] = {
		{ids="6181,6281,6261,6285", cond_if=[[Human]]},
		{ids="36,109,12,153,64,151,9,22,38,102,13,14,65,132,135,141,142,103,104,155"},
	},
	["LEVELING\\Felwood (52-53)"] = {
		{ids="5155,4421,8460,5157,939,4906,5156,4101,8462"},
	},
	["LEVELING\\Felwood (55-56)"] = {
		{ids="5159,4441,4442,5202"},
	},
	["LEVELING\\Feralas (46-47)"] = {
		{ids="4124,2866,2867,3130,2869,4125,4127,2870,2871,4129,4130,2766,2969,2970,4131,4135,2821,2982,4265,4266,3022,2939,2940,4267,2972,4281"},
	},
	["LEVELING\\Hillsbrad Foothills (32-33)"] = {
		{ids="538,536,559,560,561,562,564,511,9435,555,505,510"},
	},
	["LEVELING\\Redridge Mountains (25-25)"] = {
		{ids="2281,2282,2360,2359,2607,2608", cond_if=[[Rogue]]},
		{ids="244,34,20,127,150"},
	},
	["LEVELING\\Redridge Mountains (27-28)"] = {
		{ids="94,248,19,115,219,91,180,128,269,2923"},
	},
	["LEVELING\\Scepter of the Shifting Sands"] = {
		{ids="8286,8288,8301,8302,8303,8305,8519,8555,8575,8576,8599,8597,8598,8584,8585,8606,8577,8733,8734,8735,8736,8586,8578,8587,8620,8741,8730,8728,8729,8743"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Darnassus)"] = {
		{ids="9262,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Ironforge)"] = {
		{ids="9261,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Stormwind)"] = {
		{ids="9260,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (The Exodar)"] = {
		{ids="12817,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Searing Gorge (50-51)"] = {
		{ids="3441,3442,7701,7723,7724,7727,7728,7729,7722,3443,3452,3453,3454,3462,4451,4449,3367,3463,3481,580,1122,2874,2641,2661,2662,3444"},
	},
	["LEVELING\\Silithus (59-60)"] = {
		{ids="8275,8280,8277,8318,8308,8281,8278,8284,8304"},
	},
	["LEVELING\\Starter Guides (1-11)\\Draenei Starter (1-11)"] = {
		{ids="9586", cond_if=[[Draenei Priest]]},
		{ids="9757,9591,9592,9593,9675", cond_if=[[Draenei Hunter]]},
		{ids="9449,9450,9451,9462,9464,9465,9467,9468,9461,9555", cond_if=[[Draenei Shaman]]},
		{ids="9369", cond_if=[[haveq(9369) or completedq(9369)]]},
		{ids="9280", cond_if=[[haveq(9280) or completedq(9280)]]},
		{ids="9463", cond_if=[[haveq(9463) or completedq(9463)]]},
		{ids="9582,10350", cond_if=[[Draenei Warrior]]},
		{ids="9595", cond_if=[[Draenei Mage]]},
		{ids="10366,9598", cond_if=[[Draenei Paladin]]},
		{ids="9279", cond_if=[[haveq(9279) or completedq(9279)]]},
		{ids="9616", cond_if=[[haveq(9616) or completedq(9616)]]},
		{ids="9473", cond_if=[[haveq(9473) or completedq(9473)]]},
		{ids="9409,9371,10302,9799,9293,9283,9294,9305,9303,9309,10303,9311,9798,9312,9452,9453,9313,9314,9455,9512,9506,9530,9454,9538,9539,9540,9541,9542,10428,9527,9531,9523,9513,9514,9537,9515,10324,9544,9456,9602,9623,9559,9560,9564,9562,9565,9566,9573,9570,9571,9622"},
	},
	["LEVELING\\Starter Guides (1-11)\\Dwarf & Gnome Starter (1-11)"] = {
		{ids="3112", cond_if=[[Gnome Warrior]]},
		{ids="3109", cond_if=[[Dwarf Rogue]]},
		{ids="3107,2999,1646,1647,1648,1778,1779,1783,1784,1785", cond_if=[[Dwarf Paladin]]},
		{ids="3115,1599,6661,6662,1689", cond_if=[[Gnome Warlock]]},
		{ids="3108,6064,6084,6085,6086", cond_if=[[Dwarf Hunter]]},
		{ids="1715,1688", cond=[[Gnome Warlock]]},
		{ids="3110,5625,5635", cond_if=[[Dwarf Priest]]},
		{ids="3106", cond_if=[[Dwarf Warrior]]},
		{ids="1638,1639,1640,1665", cond_if=[[(Dwarf or Gnome) and Warrior]]},
		{ids="3114", cond_if=[[Gnome Mage]]},
		{ids="3113", cond_if=[[Gnome Rogue]]},
		{ids="6387,6391,6388", cond_if=[[Dwarf or Gnome]]},
		{ids="179,170,233,183,234,3364,3365,182,218,3361,282,420,2160,400,5541,384,317,313,312,318,319,315,310,320,311,412,287,314,433,432,419,417,413,414,307,1339,291,6661,6662,1338"},
	},
	["LEVELING\\Starter Guides (1-11)\\Human Starter (1-11)"] = {
		{ids="3101", cond_if=[[Human Paladin]]},
		{ids="3103,5623,5624,5635", cond_if=[[Human Priest]]},
		{ids="6181,6281", cond_if=[[Human]]},
		{ids="1598,3105,1689", cond_if=[[Human Warlock]]},
		{ids="3104", cond_if=[[Human Mage]]},
		{ids="1685,1688", cond=[[Human Warlock]]},
		{ids="3102", cond_if=[[Human Rogue]]},
		{ids="184", cond_if=[[haveq(184) or completedq(184)]]},
		{ids="3100,1638,1639,1640,1665", cond_if=[[Human Warrior]]},
		{ids="783,5261,33,7,15,18,3903,3904,6,21,3905,54,2158,85,86,106,111,84,87,47,40,62,60,107,35,37,45,5545,52,71,83,112,39,76,114,239,11,36,109,61"},
	},
	["LEVELING\\Starter Guides (1-11)\\Night Elf Starter (1-11)"] = {
		{ids="3117,6063,6101,6102,6103", cond_if=[[NightElf Hunter]]},
		{ids="1684,1683", cond_if=[[Warrior]]},
		{ids="3118", cond_if=[[NightElf Rogue]]},
		{ids="2241,2242", cond_if=[[Rogue]]},
		{ids="3119,5629", cond_if=[[NightElf Priest]]},
		{ids="6344,6341,6342", cond_if=[[NightElf]]},
		{ids="5622,5621", cond_if=[[Priest]]},
		{ids="3120,5921,5929,5931", cond_if=[[NightElf Druid]]},
		{ids="3116", cond_if=[[NightElf Warrior]]},
		{ids="456,458,4495,916,457,459,3519,917,920,3521,3522,921,2159,928,997,918,919,475,488,476,2438,929,4161,489,932,2459,933,937,938,922,940,2519,7383,930,931,487,923,935,2518,2520"},
	},
	["LEVELING\\Stranglethorn Vale (31-32)"] = {
		{ids="583,185,190,215,222,223,1245,335,1246,1447,1247,336,337,1301,1248,1249,1250"},
	},
	["LEVELING\\Stranglethorn Vale (34-35)"] = {
		{ids="1791", cond_if=[[Warrior]]},
		{ids="1180,616,1181,198,5762,194,186,191,605,201,210,213,1182,578,575,203,204,563,689,700,514"},
	},
	["LEVELING\\Stranglethorn Vale (37-38)"] = {
		{ids="1115,200,328,195,187,192,188,189,601,577,207,574,329,330,331"},
	},
	["LEVELING\\Stranglethorn Vale (43-44)"] = {
		{ids="1363,577,603,669,595,597,610,599,205,196,600,209,611,628,606,607"},
	},
	["LEVELING\\Stranglethorn Vale (45-46)"] = {
		{ids="1118,576,587,604,594,630,608,197,193,621,617,609"},
	},
	["LEVELING\\Swamp of Sorrows (38-39)"] = {
		{ids="1392,1396,1393,1389,1421,1116,1448,1457"},
	},
	["LEVELING\\Swamp of Sorrows (46-46)"] = {
		{ids="1477,624,1364,1395,623,625,1119,1120"},
	},
	["LEVELING\\Tanaris (44-44)"] = {
		{ids="2864,1117,1137,1187,1190,1194,1188,992,2872,1690,1707"},
	},
	["LEVELING\\Tanaris (47-49)"] = {
		{ids="3161", cond_if=[[not haveq(1560)]]},
		{ids="3161", cond_if=[[haveq(1560)]]},
		{ids="2941,3520,2781,1691,3445,1560,2875,8366,2876,2873,8365,2605,2606,82,3362,5863,351,10,110,113"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains (67-68)"] = {
		{ids="9794,10927,10555,10556,10455,10510,10511,10502,10456,10690,10457,10516,10517,10506,10504,10518,10512,10580,10581,10557,10584,10609,10632,10710,10657,10620,10608,10594,10711,10674,10671,10675,10712,10810,10812,10770,10771,10753,10567,10682,10717,10713,10719,10819,10820,10796,10795,10797,10798,10799,10800,10801,10894,10893,10803,10802,10607,10747,10722,10825"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains Group Quests"] = {
		{ids="10797,10798,10799,10800,10801,10802,10818,10805,10806,10810,10812,10819,10820,10821,10516,10517,10518"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula (58-62)"] = {
		{ids="10119,10288,10140,10254,10160,10055,10482,10141,10142,10078,10483,10143,10484,10895,10485,10144,10146,10340,10344,10163,10382,10394,10396,10397,10236,10238,10629,10630,10903,10916,10395,10047,10079,10099,9355,9349,9361,9356,10161,10058,10909,10935,10936,10050,10057,10093,9390,9423,9424,9426,9543,9427,9373,10443,10159,9372,10255,10403,10367,10368,10369,9558,9563,9385,9418,9420,9417,9430,9398,9399,9545,10399,9351,9383"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula Group Quests"] = {
		{ids="10119,10288,10140,10254,10160,10482,10483,10484,10485,10903,10909,10935,10936,10937,10395,10399,10400,9490,10132,10134,10349,10351"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Isle of Quel'danas"] = {
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11550,11526,11488,11490,29685"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Nagrand (65-67)"] = {
		{ids="9882", cond_if=[[haveq(9882) or completedq(9882)]]},
		{ids="10210,10211,9848,9835,10116,10115,9854,9789,9857,9861,9818,9913,9914,9900,9925,9792,9858,9850,9855,9819,9800,9815,9869,9862,9804,9821,9956,9878,9874,10476,9936,9940,9917,9923,9871,10109,9918,9920,9921,9849,9805,9810,9922,9924,9873,10108,9928,9927,9931,9932,9933,9962,9967,9970,9972,9973,9977"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Nagrand Group Quests"] = {
		{ids="9982", cond_if=[[haveq(9982) or completedq(9982)]]},
		{ids="10109,10111,9818,9819,9821,9849,9853,9854,9789,9857,9858,9850,9855,9859,9856,9851,10227,10228,10231,10251,10252,9923,9924,9954,9955,9962,9967,9970,9972,9977,9938,9991,9999,10001,10004,10009,10010,10011"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm (68-70)"] = {
		{ids="10241,10263,10243,10313,10245,10299,10246,10321,10328,10322,10431,10380", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10432", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10189,10264,10193,10204,10329,10194,10652,10197,10198,10330,10200,10338,10341,10202", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10381", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10210,10211,10190,10183,10191,10342,10186,10225,10224,10203,10265,10199,10173,10226,10221,10300,10262,10206,10205,10174,10334,10337,10331,10184,10305,10185,10182,10307,10306,10343,10332,10312,10316,10314,10319,10188,10239,10192,10301,10222,10240,10233,10209,10924,10223,10176,10266,10333,10433,10348,10417,10234,10418,10311,10267,10235,10423,10434,10268,10232,10237,10247,10426,10427,10317,10315,10318,10424,10336,10855,10335,10429,10430,10436,10440,10856,10435,10422,10345,10437,10353,10411,10269,10339,10384,10385,10405,10270,10271,10281,10272,10438,10273,10857,10275"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm Group Quests"] = {
		{ids="10341,10202,10189,10193,10329,10194,10652,10197,10198,10330,10200,10338,10365,10264", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10243,10245,10299,10321,10322,10323,10263", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10432,10508", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10407,10410,10409,10509,10507,10309,10261,10701,10256,10265,10262,10205,10266,10267,10268,10269,10275,10276,10184,10312,10316,10314,10319,10320,10333,10234,10235,10237,10247,10248,10270,10271,10281,10272,10273,10274,10290,10293,10339,10384,10385,10405,10406,10408,10437,10438,10439,10310"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Shadowmoon Valley (70-70)"] = {
		{ids="10826", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10683,10807,10684", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10619,10568,10571", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10824", cond_if=[[rep('The Scryers')>=Neutral]]},
		{ids="10210,10211,10562,10680,10458,10703,10661,10642,10569,10643,10563,10480,10759,10777,10572,10677,10564,10573,10582,10583,10585,10586,10589,10621,10644,10804,10635,10678,10481,10778,10780,10782,10808"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest (63-65)"] = {
		{ids="10325", cond_if=[[haveq(10325) or completedq(10325)]]},
		{ids="10021", cond_if=[[haveq(10021) or completedq(10021)]]},
		{ids="10412", cond_if=[[haveq(10412) or completedq(10412)]]},
		{ids="10210,10211,10554,10553,9951,9971,9968,9978,9793,10037,9979,10863,10026,10016,9992,10869,10847,10038,10040,10849,10839,10852,10896,10842,10878,10880,10840,10917,10112,10033,9986,10042,9998,10002,10007,9990,9994,10028,10012,10022,10444,9996,10446,10005,10848,10887,10881,10922,10913,10030,10227,10920,10873,10914,10877,10915,10861,10031,10228"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest Group Quests"] = {
		{ids="9982", cond_if=[[haveq(9982) or completedq(9982)]]},
		{ids="10051,10898,10842,10877,10923,10033,10035,10922,10929,10930,9991,9999,10001,10004,10009"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh (62-63)"] = {
		{ids="9697", cond_if=[[haveq(9697) or completedq(9697)]]},
		{ids="9912,9778,9782,9901,9777,9827,9791,9783,10355,9747,9802,9728,9895,9716,9752,9718,9781,9780,9776,9848,9835,10116,10115,10096,9788,9894,9785,9720,9731,9724,9732,9790,9911,9743,9739,9701,9702,9919,9806,9830,9833,9902,9834,9786,9896,9708,9808,9839,9905,9787,9709,9801,9803"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh Group Quests"] = {
		{ids="9730,10116,9894,9895,9729"},
	},
	["LEVELING\\The Hinterlands (49-50)"] = {
		{ids="485", cond_if=[[haveq(485) or completedq(485)]]},
		{ids="9469,1452,9476,9470,9471,9475,2880,2988,626,2877,2989,3702"},
	},
	["LEVELING\\Thousand Needles (33-34)"] = {
		{ids="1100,1179,1110,1104,1105,1176,1175"},
	},
	["LEVELING\\Un'Goro Crater (51-52)"] = {
		{ids="3844,4290,4291,4141,3845,3884,4284,3368"},
	},
	["LEVELING\\Un'Goro Crater (54-55)"] = {
		{ids="4244", cond_if=[[haveq(4244) or completedq(4244)]]},
		{ids="4245", cond_if=[[haveq(4245) or completedq(4245)]]},
		{ids="4493,4243,4289,4292,4503,4501,3882,3883,3881,4285,4287,4288,4321,4492,4491,4301,974,4504,4496,3789,1047,3764,6761,3781,978"},
	},
	["LEVELING\\Western Plaguelands (52-52)"] = {
		{ids="5090,5092,5215,3661,2944,162"},
	},
	["LEVELING\\Western Plaguelands (56-57)"] = {
		{ids="6028,5216,5021,5217,3701,5022,5048,6182,6183,6184,5219,5050,5051,5097,5533,5220,5222,4984"},
	},
	["LEVELING\\Western Plaguelands (58-59)"] = {
		{ids="5223,5537,6185,5903,5152,5153,4971,5154,4972,4985,5225,5904,6004,6023,5226,6389,5210,6186"},
	},
	["LEVELING\\Wetlands (24-25)"] = {
		{ids="1649,1650,1651,1652", cond_if=[[Paladin]]},
		{ids="1716,1738,1739", cond_if=[[Warlock]]},
		{ids="272,5061", cond_if=[[NightElf Druid]]},
		{ids="1638,1639,1640,1665", cond_if=[[NightElf Warrior]]},
		{ids="942,288,463,276,470,484,469,279,637,683,686"},
	},
	["LEVELING\\Wetlands (28-30)"] = {
		{ids="9552,9553,9554", cond_if=[[Shaman]]},
		{ids="270,281,284,285,305,294,295,299,296,277,275,943,289,286,471,464,321,324,306,290,465,472,303,631,632,633,634,292,474"},
	},
	["LEVELING\\Winterspring (53-53)"] = {
		{ids="3908"},
	},
	["LEVELING\\Winterspring (55-55)"] = {
		{ids="980,5082,5083,5084,8461,8465,5085"},
	},
	["LEVELING\\Winterspring (56-56)"] = {
		{ids="5086,5250,5244,4808,4861,4863,979,3783,4864,4842,5087,5165,4901,4902"},
	},
	["LEVELING\\Northrend (69-80)\\Borean Tundra (70-71)"] = {
		{ids="11945", cond_if=[[haveq(11945) or completedq(11945)]]},
		{ids="11672,11727,11797,11920,11791,11789,11889,12141,11613,12471,11619,11620,11792,11897,11927,11793,11794,11928,11901,11902,11913,11903,11908,11599,11904,12035,11962,11600,11601,11963,11965,11575,11865,11866,11876,11869,11870,11871,11603,11604,11576,11587,11590,11646,11648,11663,11671,11679,11680,11681,11682,11605,11612,11607,11617,11609,11623,11610,11868,11872,11878,11879,11932,11949,11950,11961,11968,12086,11944,12088,11956,11938,11942,11582,11733,11941,11910,11918,11943,11912,11946,11951,11957,11936,11967,11914,11900,11707,11708,11673,11645,11729,11710,11712,11692,11693,11694,11697,11699,11700,11698,11701,11788,11730,11725,11726,11728,11795,11796,11873,11798,11713,11715,11718,11704,11571,11559,11561,11560,11562,11563,11564,11565,11569,11566,11570,12728,11723,12157"},
	},
	["LEVELING\\Northrend (69-80)\\Dragonblight (71-73)"] = {
		{ids="12118", cond_if=[[haveq(12118) or completedq(12118)]]},
		{ids="11960", cond_if=[[haveq(11960) or completedq(11960)]]},
		{ids="12794", cond_if=[[not Mage]]},
		{ids="12372", cond_if=[[haveq(12372) or completedq(12372)]]},
		{ids="12172", cond=[[Mage]]},
		{ids="12117", cond_if=[[haveq(12117) or completedq(12117)]]},
		{ids="12171,12000,12166,12167,12168,12004,12055,12169,12006,12013,12060,12065,12067,12092,12083,12098,11958,11959,12028,12011,12016,12009,12017,12030,12031,12107,12174,12235,12237,12251,12275,12276,12269,12272,12277,12253,12281,12258,12282,12309,12311,12312,12319,12320,12321,12325,12326,12455,12457,12463,12465,12462,12287,12290,12291,12301,12305,12477,12476,12475,12119,12466,12142,12467,12478,12472,12473,12766,12146,12460,12416,12417,12418,12447,12262,12261,12263,12264,12265,12267,12474,12768,12266,12495,12123,12419,12497,12454,12458,12143,12469,12044,12045,12043,12046,12049,12047,12052,12050,12112,12075,12076,12077,12078,12079,12498,12435,12032,12499,12790,13347"},
	},
	["LEVELING\\Northrend (69-80)\\Grizzly Hills (73-74)"] = {
		{ids="12511", cond_if=[[haveq(12511) or completedq(12511)]]},
		{ids="12225,12226,12212,12215,12292,12293,12444,12227,12216,12217,12294,12223,12222,12323,12316,12443,12210,11984,11989,11990,12484,11991,12007,12483,12029,12295,12299,12307,12300,12302,12255,12308,12310,12105,12219,12220,12246,12247,12289,12244,12268,12296,12042,12802,12109,12158,12159,12160,12161,12328,12327,12329,12134,12330,12411,11998,11986,12002,11988,12003,11981,11982,12070,12010,11993,12014,11985,12190,12081,12093,12094,12279,12099,12068,12082,12113,12114,12116,12120,12121,12137,12152,12128,12129,12180,12130,12183,12131,12184,12138,12185,12153,12154,12248,12250"},
	},
	["LEVELING\\Northrend (69-80)\\Howling Fjord (69-71)"] = {
		{ids="11228,11243,11244,11333,11273,11255,11343,11274,11276,11288,11277,11299,11300,11289,11420,11290,11278,11426,11427,11429,11448,11474,11460,11477,11475,11430,11421,11436,11344,11483,11484,11465,11485,11489,11491,11468,11494,11495,11470,11291,11501,11182,11190,11155,11157,11187,11188,11573,11199,11202,11327,11504,11507,11456,11457,11508,11509,11434,11510,11464,11466,11455,11473,11459,11476,11479,11480,11469,11519,11527,11458,11471,11467,11529,11530,11511,11512,11567,11568,11572,11328,11330,11331,11332,11176,11390,11391,11393,11395,11394,11396,11422,11218,11224,11329,11406,11302,11313,11314,11315,11410,11346,11316,11319,11284,11349,11269,11292,11418,11428,11348,11240,11322,11325,11154,11414,11248,11247,11246,11245,11250,11249,11416,11326,11237,11235,11231,11432,11236,11452,11239"},
	},
	["LEVELING\\Northrend (69-80)\\Icecrown (79-80)"] = {
		{ids="13310", cond_if=[[haveq(13309) or completedq(13309)]]},
		{ids="12815", cond_if=[[haveq(12815) or completedq(12815)]]},
		{ids="13071", cond_if=[[haveq(13071) or completedq(13071)]]},
		{ids="13069", cond_if=[[haveq(13069) or completedq(13069)]]},
		{ids="13105", cond_if=[[DeathKnight]]},
		{ids="13322", cond_if=[[haveq(13322) or completedq(13322)]]},
		{ids="13280", cond_if=[[haveq(13280) or completedq(13280)]]},
		{ids="13318", cond_if=[[haveq(13318) or completedq(13318)]]},
		{ids="13292", cond_if=[[haveq(13292) or completedq(13292)]]},
		{ids="12813", cond_if=[[haveq(12813) or completedq(12813)]]},
		{ids="12995", cond_if=[[haveq(12995) or completedq(12995)]]},
		{ids="13300", cond_if=[[haveq(13300) or completedq(13300)]]},
		{ids="13344", cond_if=[[haveq(13344) or completedq(13344)]]},
		{ids="13336", cond_if=[[haveq(13336) or completedq(13336)]]},
		{ids="13284", cond_if=[[haveq(13284) or completedq(13284)]]},
		{ids="12838", cond_if=[[haveq(12838) or completedq(12838)]]},
		{ids="13264", cond_if=[[haveq(13264) or completedq(13264)]]},
		{ids="13104", cond_if=[[not DeathKnight]]},
		{ids="13036,13039,13040,13008,13044,13045,13070,13086,13130,13135,13118,13122,13110,13125,13139,13141,13157,13418,13225,13068,12887,12891,12893,13341,13296,13072,13073,13074,13075,13231,13232,12896,13286,13290,12898,12938,12955,12939,12949,12951,13085,12943,12999,13092,13059,13042,13043,13091,12992,12982,13084,12806,12807,12810,12839,12814,12840,13106,13117,13119,13120,13134,13136,13076,13077,13078,13079,13221,13237,13291,13386,13387,13388,13389,13390,13391,13080,13081,13082,13392,13168,13169,13170,13171,13172,13174,13121,13133,13138,13140,13211,13152,13144,13212,13220,13235,13155,13143,13145,13146,13147,13160,13393,13394,13395,13348,13315,13318,13319,13320,13398,13342,13397,13345,13321,13399,13400,13332,13401,13083,13402,13403"},
	},
	["LEVELING\\Northrend (69-80)\\Sholazar Basin (76-77)"] = {
		{ids="12695", cond_if=[[haveq(12695) or completedq(12695)]]},
		{ids="12692", cond_if=[[haveq(12692) or completedq(12692)]]},
		{ids="12624,12624,12624", cond_if=[[readyq(12624) or completedq(12624)]]},
		{ids="12521,12489,12524,12688,12522,12523,12525,12589,12520,12549,12526,12624,12550,12804,12634,12644,12592,12551,12543,12544,12645,12560,12654,12556,12558,12569,12595,12603,12605,12683,12607,12614,12681,12658,12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12699,12671,12803,12561,12611,12612,12805,12608,12617,12660,12620,12621,12559,12691,12613,12548,12547,12797,12546,12578,12580,12579,12581"},
	},
	["LEVELING\\Northrend (69-80)\\The Storm Peaks (77-79)"] = {
		{ids="12870,12870", cond_if=[[readyq(12870)]]},
		{ids="12833", cond_if=[[haveq(12833) or completedq(12833)]]},
		{ids="12818,12819,12826,12827,12836,12831,12829,12830,12820,12828,12832,12821,12823,12822,12824,12843,12844,12862,12863,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,13062,12886,13064,12864,12854,12865,12855,12925,12942,12968,12953,12922,12870,12866,12867,12915,12956,12858,12860,13415,12872,12885,12930,12931,12937,12957,12964,12965,12978,12979,12980,12984,12991,12988,12993,12998,13007,12871,12873,12966,12967,12924,12874"},
	},
	["LEVELING\\Northrend (69-80)\\Zul'Drak (74-76)"] = {
		{ids="12637", cond_if=[[haveq(12637) or completedq(12637)]]},
		{ids="12631", cond_if=[[haveq(12631) or completedq(12631)]]},
		{ids="12663", cond_if=[[haveq(12663) or completedq(12663)]]},
		{ids="12648", cond_if=[[haveq(12648) or completedq(12648)]]},
		{ids="12655", cond_if=[[itemcount(38551) >= 10]]},
		{ids="12795", cond_if=[[not completedq(12503)]]},
		{ids="12664", cond_if=[[haveq(12664) or completedq(12664)]]},
		{ids="12633", cond_if=[[haveq(12633) or completedq(12631)]]},
		{ids="12629", cond_if=[[haveq(12629) or completedq(12629)]]},
		{ids="12649", cond_if=[[haveq(12649) or completedq(12649)]]},
		{ids="12638", cond_if=[[haveq(12638) or completedq(12638)]]},
		{ids="12643", cond_if=[[haveq(12643) or completedq(12643)]]},
		{ids="12770,12902,12859,12861,12883,12894,12904,12901,12912,12903,12884,12630,12652,12914,12916,12661,12673,12669,12686,12677,12690,12710,12676,12713,12919,12565,12503,12740,12598,12512,12606,12552,12553,12583,12555,12932,12933,12934,12935,12936,12948,12557,12799,12609,12610,12505,12504,12508,12584,12506,12507,12597,12562,12510,12599,12596,12514,12527,12516,12623,12615,12627,12622,12628,12632,12635,12642,12655,12646,12647,12640,12639,12650,12653,12665,12666,12667,12672,12668,12674,12675,12684,12685,13549,12662,12659,13556,12708,12707,12709,12712"},
	},
	["LEVELING\\Starter Guides (1-12) & Death Knight (55-58)\\Death Knight Starter (55-58)"] = {
		{ids="12746", cond=[[Draenei]]},
		{ids="28649", cond=[[Worgen]]},
		{ids="12750", cond=[[Scourge]]},
		{ids="12748", cond=[[Orc]]},
		{ids="12745", cond=[[Gnome]]},
		{ids="12744", cond=[[Dwarf]]},
		{ids="12739", cond=[[Tauren]]},
		{ids="28650", cond=[[Goblin]]},
		{ids="12749", cond=[[Troll]]},
		{ids="12747", cond=[[BloodElf]]},
		{ids="12742", cond=[[Human]]},
		{ids="12743", cond=[[NightElf]]},
		{ids="12593,12619,12842,12848,12636,12641,12657,12850,12670,12733,12680,12687,12679,12678,12697,12698,12700,12701,12706,12714,12715,12719,12716,12717,12720,12722,12723,12725,12724,12727,12738,12751,12754,12755,12756,12757,12778,12779,12800,12801,13165,13166,13188"},
	},
	["PROFESSIONS\\Blacksmithing\\Blacksmithing (1-450)"] = {
		{ids="7655,7654,7656"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Armorsmith\\Armorsmith Questline"] = {
		{ids="2758,2759,2760,2761,2762,2763,2765,2764,2771,2772,2773,3321,5283"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Axesmith Questline"] = {
		{ids="5306"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Hammersmith Questline"] = {
		{ids="5305"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Swordsmith Questline"] = {
		{ids="5307"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Weaponsmith Questline"] = {
		{ids="5284"},
	},
	["PROFESSIONS\\Cooking\\Cooking (1-450)"] = {
		{ids="8307,8313,13088,12521,12489,12524,12522,12525,12523,12549,12520,12634,12644,12645,13571"},
	},
	["PROFESSIONS\\Cooking\\Cooking + Fishing (1-450)"] = {
		{ids="6607,9835,10116,10115"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnomish Engineering Questline"] = {
		{ids="3632,3640,3641"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineering Questline"] = {
		{ids="4181,3639"},
	},
	["PROFESSIONS\\Fishing\\Fishing (1-450)"] = {
		{ids="6607"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Dragonscale Leatherworking\\Dragonscale Leatherworking Questline"] = {
		{ids="5141"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Elemental Leatherworking\\Elemental Leatherworking Questline"] = {
		{ids="5144"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Tribal Leatherworking\\Tribal Leatherworking Questline"] = {
		{ids="2847,2848,2849,2850,2851,2852,2853,5143"},
	},
	["PROFESSIONS\\Lockpicking\\Lockpicking (1-300)"] = {
		{ids="2281,2282"},
	},
	["REPUTATIONS\\The Burning Crusade\\Cenarion Expedition"] = {
		{ids="9802,9875"},
	},
	["REPUTATIONS\\The Burning Crusade\\Keepers of Time"] = {
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["REPUTATIONS\\The Burning Crusade\\Lower City"] = {
		{ids="10917"},
	},
	["REPUTATIONS\\The Burning Crusade\\Netherwing"] = {
		{ids="11099,11100", cond_if=[[rep("The Aldor") >= Friendly]]},
		{ids="11094,11095", cond_if=[[rep("The Scryers") >= Friendly]]},
		{ids="10804,10811,10814,10836,10837,10854,10858,10866,10870,11013,11014,11049,11053,11075,11083,11081,11082,11054,11084,11064,11067,11068,11069,11070,11071,11092,11041,11107,11108"},
	},
	["REPUTATIONS\\The Burning Crusade\\Ogri'la"] = {
		{ids="11102", cond_if=[[raceclass("Druid")]]},
		{ids="11010", cond_if=[[not raceclass("Druid")]]},
		{ids="10984,10983,10995,10996,10997,10998,11000,11022,11009,11025,11058,11030,11062,11119,11059,11065,11078,11061,11079,11091,11026"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sha'tari Skyguard"] = {
		{ids="11102", cond_if=[[raceclass("Druid")]]},
		{ids="11010", cond_if=[[not raceclass("Druid")]]},
		{ids="11096,11098,11004,11093,11005,11021,11024,11028,11056,11029,11885,11073,10984,10983,10995,10996,10997,10998,11000,11022,11009,11025,11058,11030,11062,11119,11059,11065,11078,11026"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sporeggar"] = {
		{ids="9739,9743,9919"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Aldor"] = {
		{ids="10210,10211,10554,10325,10020,10021,11038,10241,10243,10313,10245,10299,10321,10246,10328,10322,10431,10380,10381,10323,10407,10653,10410,10420,10409,10619,10568,10587,10637,10816,10571,10574,10575,10640,10641,10668,10669,10646,10649,10650,10650"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Consortium"] = {
		{ids="9913,9882,9900,9925,9914,9893,10265,10262,10205,10266,10348,10417,10418,10267,10311,10310,10423,10268,10424,10430,10436,10440,10269,10339,10384,10385,10405,10406,10425,10422,10345,10411,10353,10437,10438,10439,10408,10270,10275,10290,10276,10335,10336,10855,10856,10857,10970,10970,10971,10972"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Kurenai"] = {
		{ids="9776,9848,9835,10116,10115,9839,9830,9833,9902,9834,9905,9792,9956,9878,9874,10476,9936,9940,9917,9923,9871,9918,9920,9921,9922,9879,9924,10108,9928,9927,9931,9932,9933,9954,9955,9938"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Scryers"] = {
		{ids="10341,10202,10432", cond_if=[[rep ('The Scryers') >= Friendly]]},
		{ids="10210,10211,10553,11039,10189,10193,10204,10329,10194,10652,10197,10198,10330,10200,10338,10508,10509,10507,10824,10687,10688,10807,10683,10684,10685,10686,10640,10641,10668,10669,10646,10649,10691,10692,10412,10656,10416"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Sha'tar"] = {
		{ids="10568,10571,10574,10575", cond_if=[[rep ('The Aldor') >= Friendly]]},
		{ids="9983", cond_if=[[haveq(9983) or completedq(9983)]]},
		{ids="10683,10684,10685,10686", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10210,9888,9889,9890,9891,9906,9991,9999,10001,10004,10009,10010,10011,9907,9868,10107,9928,9927,9931,9932,9934,10044,10045,10081,10082,10085,10101,10102,10167,10168,10227,10228,10231,10251,10252,10253,10920,10921,10877,10923,10883,10884,10885,10886,10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10704,10622,10628,10705,10706,10707,10793,10781,11052"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Champion of the Naaru"] = {
		{ids="10680", cond_if=[[Alliance]]},
		{ids="10681", cond_if=[[Horde]]},
		{ids="10458,10480,10481,10513,10514,10515,10519,10521,10522,10527,10528,10537,10540,10546,10547,10550,10570,10576,10577,10578,10523,10541,10579,10588,10884,10885,10886,10888"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Hand of A'dal"] = {
		{ids="10568,10571,10574,10575", cond_if=[[rep("The Aldor") >= Neutral]]},
		{ids="10683,10684,10685,10686", cond_if=[[rep("The Scryers") >= Neutral]]},
		{ids="10210,10211,10622,10628,10705,10706,10707,10708,10944,10946,10947,10948,10949,10985,10445"},
	},
	["TITLES\\Burning Crusade Titles\\Reputation\\of the Shattered Sun"] = {
		{ids="11549"},
	},
}
ZGV.Quest_Cache_Accept_Horde = {
	["DAILIES\\The Burning Crusade\\Netherwing\\Netherwing Daily Quests"] = {
		{ids="11018", cond_if=[[skill("Mining") >= 350]]},
		{ids="11101", cond_if=[[rep("The Aldor") >= Friendly and rep("Netherwing") >= Revered]]},
		{ids="11055,11076,11077", cond_if=[[rep("Netherwing") >= Friendly]]},
		{ids="11097", cond_if=[[rep("The Scryers") >= Friendly and rep("Netherwing") >= Revered]]},
		{ids="11086", cond_if=[[rep("Netherwing") >= Honored]]},
		{ids="11017", cond_if=[[skill("Herbalism") >= 350]]},
		{ids="11016", cond_if=[[skill("Skinning") >= 350]]},
		{ids="11020,11035,11015"},
	},
	["DAILIES\\The Burning Crusade\\Ogri'la\\Ogri'la Daily Quests"] = {
		{ids="11080", cond_if=[[completedq(11058)]]},
		{ids="11023", cond_if=[[completedq(11010,11102)]]},
		{ids="11066", cond_if=[[completedq(11065)]]},
		{ids="11051", cond_if=[[completedq(11026)]]},
	},
	["DAILIES\\The Burning Crusade\\Sha'tari Skyguard\\Sha'tari Skyguard Daily Quests"] = {
		{ids="11008,11085,11023,11066"},
	},
	["DAILIES\\The Burning Crusade\\Sha'tari Skyguard\\Sha'tari Skyguard Terokk Farming"] = {
		{ids="11006,11074"},
	},
	["DAILIES\\The Burning Crusade\\Shattrath Cooking Dailies"] = {
		{ids="11381,11379,11380,11377"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 1, Capturing Sanctum)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11496,11524,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Activating Portal)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11538,11532,11513,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Portal Activated)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11538,11532,11547,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Forge Rebuilt)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11537,11533,11547,11542,11539,11536,11544,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Rebuilding Forge)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11537,11533,11547,11542,11539,11535,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Alchemy Lab Built)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11521,11546,11537,11533,11547,11545,11543,11540,11536,11544,11541,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Fully Built)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11521,11546,11537,11533,11547,11548,11543,11540,11536,11544,11541,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Monument Built)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11537,11533,11547,11548,11543,11540,11536,11544,11520,11541,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, No Alchemy Lab or Monument)"] = {
		{ids="11875", cond_if=[[skill("Herbalism") >= 301 or skill("Mining") >= 301 or skill("Skinning") >= 301]]},
		{ids="11515,11516", cond_if=[[completedq(11526)]]},
		{ids="11550,11526,11488,11517,11534,11523,11525,11537,11533,11547,11545,11543,11540,11536,11544,11520,11541,11514,11877,11880"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Cooking Dailies"] = {
		{ids="13115,13113,13112,13116,13114", cond_if=[[questpossible]]},
		{ids="13089"},
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Fishing Dailies"] = {
		{ids="13833,13834,13832,13836,13830", cond_if=[[questpossible]]},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Death's Rise Dailies"] = {
		{ids="12813,12838,12815"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Orgrim's Hammer Dailies"] = {
		{ids="13276", cond_if=[[completedq(13264)]]},
		{ids="13365", cond_if=[[completedq(13358)]]},
		{ids="13310,13301", cond_if=[[completedq(13340)]]},
		{ids="13353", cond_if=[[completedq(13352)]]},
		{ids="13281", cond_if=[[completedq(13279)]]},
		{ids="13261", cond_if=[[completedq(13239)]]},
		{ids="13283", cond_if=[[completedq(13293)]]},
		{ids="13331", cond_if=[[completedq(13313)]]},
		{ids="13376,13406", cond_if=[[completedq(13374)]]},
		{ids="13357", cond_if=[[completedq(13356)]]},
		{ids="13302", cond_if=[[completedq(13308)]]},
		{ids="13330"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Shadowvault Dailies"] = {
		{ids="12995,13069,13071"},
	},
	["DAILIES\\Wrath of the Lich King\\Jewelcrafting Dailies"] = {
		{ids="12958,12962,12959,12961,12963,12960", cond_if=[[questpossible]]},
		{ids="13041"},
	},
	["DAILIES\\Wrath of the Lich King\\The Kalu'ak Dailies"] = {
		{ids="11504,11507,11508,11509,11469,11472,11945,11960"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\Frenzyheart Tribe Dailies"] = {
		{ids="12758,12734,12741,12732,12703,12760,12759", cond_if=[[questpossible]]},
		{ids="12654,12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12578,12580,12579,12581,12582,12692,12702"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\The Oracles Dailies"] = {
		{ids="12735,12737,12736,12726,12761,12762,12705", cond_if=[[questpossible]]},
		{ids="12654,12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12578,12580,12579,12581,12689,12695,12704"},
	},
	["DAILIES\\Wrath of the Lich King\\The Sons of Hodir\\The Sons of Hodir Dailies"] = {
		{ids="13421", cond_if=[[completedq(13420)]]},
		{ids="13559", cond_if=[[rep("The Sons of Hodir") < Exalted]]},
		{ids="13006", cond_if=[[rep("The Sons of Hodir") >= Friendly and completedq(12987)]]},
		{ids="12994", cond_if=[[rep("The Sons of Hodir") >= Honored]]},
		{ids="13046", cond_if=[[rep("The Sons of Hodir") >= Revered]]},
		{ids="13003", cond_if=[[rep("The Sons of Hodir") >= Honored and completedq(13001)]]},
		{ids="13001", cond_if=[[rep("The Sons of Hodir") >= Honored and not completedq(13001)]]},
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,13062,12886,13064,12915,12922,12956,12924,12966,12967,13009,12981,12975,13050,13051,13010,12976,13011,12985,12987,12977,13006,13057,13005,13035,13047,13108,12981,12977"},
	},
	["DAILIES\\Wrath of the Lich King\\Wyrmrest Accord Dailies"] = {
		{ids="11999", cond_if=[[completedq(12435)]]},
		{ids="11999", cond_if=[[not completedq(12435)]]},
		{ids="12005,12059,12061,12066,12084,12085,12106,12110,12122,12767,12461,12448,12449,12450,12419,12769,12124,12435,12372,11918,11936,11919,13412,13413,11940,13414"},
	},
	["DUNGEONS\\Classic\\Blackfathom Deeps Quests"] = {
		{ids="6563,6921,6564,6565,6561,6922"},
	},
	["DUNGEONS\\Classic\\Blackrock Depths Quests"] = {
		{ids="4324,4133,4134,3906,4081,4061,3441,3442,3443,3452,3453,3454,3462,3463,3481,4123,4136,4022,4024,4062,4063,3801,3802,4201,3907,4082,3981,3982,4001,4002,4003,4004"},
	},
	["DUNGEONS\\Classic\\Dire Maul East Quests"] = {
		{ids="5527,5526,7489,7441"},
	},
	["DUNGEONS\\Classic\\Dire Maul North Quests"] = {
		{ids="7481,5518,5528,7703"},
	},
	["DUNGEONS\\Classic\\Dire Maul West Quests"] = {
		{ids="7461,7462"},
	},
	["DUNGEONS\\Classic\\Gnomeregan Quests"] = {
		{ids="2841,2842,2843"},
	},
	["DUNGEONS\\Classic\\Lower Blackrock Spire Quests"] = {
		{ids="3520,3527,4787,3528,5065,4788,4866,4729,4862,4903,4981,4724,4867,4982,4983,4742"},
	},
	["DUNGEONS\\Classic\\Maraudon Quests"] = {
		{ids="7068,7029,7064,7028,7067,7044,7046,7066"},
	},
	["DUNGEONS\\Classic\\Ragefire Chasm Quests"] = {
		{ids="5723,5722,5725,5726,5727,5728,5761,5724"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Blackwing Lair Attunement"] = {
		{ids="7761"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Molten Core Attunement"] = {
		{ids="7848"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Naxxramas Attunement"] = {
		{ids="9123", cond_if=[[rep("Argent Dawn") == Exalted or completedq(9123)]]},
		{ids="9122", cond_if=[[rep("Argent Dawn") == Revered or completedq(9122)]]},
		{ids="9121", cond_if=[[rep("Argent Dawn") == Honored or completedq(9121)]]},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Onyxia's Lair Attunement"] = {
		{ids="4903,4941,4974,6566,6567,6568,6569,6570,6582,6583,6584,6585,6601,6602"},
	},
	["DUNGEONS\\Classic\\Razorfen Downs Quests"] = {
		{ids="6522,6521,3341,6626,3523,3525"},
	},
	["DUNGEONS\\Classic\\Razorfen Kraul Quests"] = {
		{ids="1109,1221,1102,6522,1144"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Armory Quests"] = {
		{ids="1048"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Cathedral Quests"] = {
		{ids="1048"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Graveyard Quests"] = {
		{ids="1109,1113,1051"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Library Quests"] = {
		{ids="1149,1150,1151,1152,1154,6627,1159,1160,1048"},
		{ids="1049", cond=[[Orc]]},
	},
	["DUNGEONS\\Classic\\Scholomance Quests"] = {
		{ids="5094,4726,4808,4809,4810,4907,4734,4735,5522,5531,5529,4771,5096,5098,838,964,5514,5802,5803,5511,5341,5382,5515,5582,5384,5461,5462,5463,5464,5465,5466"},
	},
	["DUNGEONS\\Classic\\Shadowfang Keep Quests"] = {
		{ids="1013,1014,1098"},
	},
	["DUNGEONS\\Classic\\Stratholme - Live Side Quests"] = {
		{ids="5214,5251,5281,5282,5542,5543,5544,5742,5781,5845,5846,5848,5122,5262"},
	},
	["DUNGEONS\\Classic\\Stratholme - Undead Side Quests"] = {
		{ids="5382,5515,5384,5461,5462,5463,5251,5262,5263,6022,6133,6042,6135,6136,6163,5212,5243,5125,5125,5464,5213"},
	},
	["DUNGEONS\\Classic\\Temple of Atal'Hakkar Quests"] = {
		{ids="3380,3444,3446,3520,3527,4787,1424,1429,1444,1446,3528,1445,4145,4147,4146,3447,3373"},
	},
	["DUNGEONS\\Classic\\Uldaman Quests"] = {
		{ids="2278,2280", cond_if=[[level >=40]]},
		{ids="2342,2418,709,2258,2202,2283,2284,2318,2338,2339,2340,2341"},
	},
	["DUNGEONS\\Classic\\Upper Blackrock Spire Quests"] = {
		{ids="4769,4768,4903,4726,4808,4809,4810,4907,4734,6804,6805,6821,4941,5160,5047,4941,4974,4735,5161,5162,5164,6566,6567,6568,6569,6570,6582,6583,6584,6585,6601,6602"},
	},
	["DUNGEONS\\Classic\\Wailing Caverns Quests"] = {
		{ids="886,962,870,877,880,1489,1490,914,865,1491,959,1486,1487,6981,3366,3369"},
	},
	["DUNGEONS\\Classic\\Zul'Farrak Quests"] = {
		{ids="2933,2934,2935,2936,2846,2770,3520,3527,2768,2865,3042"},
	},
	["DUNGEONS\\The Burning Crusade\\Auchenai Crypts Quests"] = {
		{ids="9400,9401,9405,9410,9406,9438,9441,10227,10228,10231,10251,10252,10253,10164,9888,9983,9889,9890,9891,9906,9907,9872,9868,9991,9999,10001,10004,10009,10010,10011,10107,9928,9927,9931,9932,9934,10044,10045,10081,10082,10085,10101,10102,10167,10168"},
	},
	["DUNGEONS\\The Burning Crusade\\Black Temple Attunement"] = {
		{ids="10568", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10684,10685,10575", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10571,10574,10575", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10683", cond_if=[[rep('The Scryers')>=Neutral]]},
		{ids="10622,10628,10705,10706,10707,10708,10944,10946,10947,10948,10949,10985"},
	},
	["DUNGEONS\\The Burning Crusade\\Blood Furnace Quests"] = {
		{ids="9608,9590"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Citadel Attunement"] = {
		{ids="10755,10756,10757,10758"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Ramparts Quests"] = {
		{ids="9407,10120,10289,10291,10121,10123,10124,9572,9588"},
	},
	["DUNGEONS\\The Burning Crusade\\Karazhan Attunement"] = {
		{ids="11216,9824,9825,9826,9829,9831,9832,9836,9837,9838"},
	},
	["DUNGEONS\\The Burning Crusade\\Mana-Tombs Quests"] = {
		{ids="10216,10165,10218,10969,10970,10425,10971,10973,10974,10975,10975,10976,10977"},
	},
	["DUNGEONS\\The Burning Crusade\\Mount Hyjal Attunement"] = {
		{ids="10445"},
	},
	["DUNGEONS\\The Burning Crusade\\Old Hillsbrad Foothills Quests"] = {
		{ids="12513,10279,10277,10282,10283,10284,10285"},
	},
	["DUNGEONS\\The Burning Crusade\\Serpentshrine Cavern Attunement"] = {
		{ids="10901,9630,9638,9639,9640,9645,9680,9631,9637,9644"},
	},
	["DUNGEONS\\The Burning Crusade\\Sethekk Halls Quests"] = {
		{ids="10180,10097,10098"},
	},
	["DUNGEONS\\The Burning Crusade\\Shadow Labyrinth Quests"] = {
		{ids="10687", cond_if=[[rep('The Scryers')>=Neutral]]},
		{ids="10587,10637,10640", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10688,10689", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10641,10668,10669,10646,10649,10623,10627,10663,10664,10666,11216,9824,9825,9826,9829,9831,10177,10094,10178,10885,10091,10095"},
	},
	["DUNGEONS\\The Burning Crusade\\Shattered Halls Quests"] = {
		{ids="9495"},
	},
	["DUNGEONS\\The Burning Crusade\\Tempest Keep Attunement"] = {
		{ids="10883,10884,10885,10886,10888"},
	},
	["DUNGEONS\\The Burning Crusade\\The Arcatraz Quests"] = {
		{ids="10568", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10684,10685,10575", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10683", cond_if=[[rep('The Scryers')>=Neutral]]},
		{ids="10571,10574,10575", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10704,10622,10628,10705,10706,11216,9824,9825,9826,9829,9831,9832"},
	},
	["DUNGEONS\\The Burning Crusade\\The Black Morass Quests"] = {
		{ids="10902", cond_if=[[skill("Alchemy") < 0]]},
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["DUNGEONS\\The Burning Crusade\\The Botanica Quests"] = {
		{ids="10897", cond_if=[[skill("Alchemy") < 0]]},
		{ids="10257,10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10704"},
	},
	["DUNGEONS\\The Burning Crusade\\The Cipher of Damnation"] = {
		{ids="10681,10458,10480,10481,10513,10514,10515,10519,10521,10527,10546,10522,10523,10528,10537,10540,10541,10547,10550,10570,10576,10577,10578,10579,10588"},
	},
	["DUNGEONS\\The Burning Crusade\\The Mechanar Quests"] = {
		{ids="10623,10627,10663,10664,10665"},
	},
	["DUNGEONS\\The Burning Crusade\\The Slave Pens Quests"] = {
		{ids="9738"},
	},
	["DUNGEONS\\The Burning Crusade\\The Steamvault Quests"] = {
		{ids="10623,10627,10663,10664,10666,10667,9763,9764,10885,11216,9824,9825,9826,9829,9831,9832"},
	},
	["DUNGEONS\\The Burning Crusade\\The Underbog Quests"] = {
		{ids="9715,9717,9719,9738"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Ahn'kahet: The Old Kingdom Quests"] = {
		{ids="13187,13204"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Azjol-Nerub Quests"] = {
		{ids="13167,13182"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Drak'Tharon Keep Quests"] = {
		{ids="12208,11984,11989,11990,11991,12007,12042,12802,12068,12238,12484,12029,12037,13129"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Gundrak Quests"] = {
		{ids="12507,12510,12514,12516,12623,12627,12628,12632,12642,12646,12647,12653,12665,12666,12667,12672,12668,12674,12675,12684,12685,12712,12721,12729,12730,13097,13099,13111,13098,13096"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Lightning Quests"] = {
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12996,12997,13061,13062,12886,13064,12915,12922,12956,12924,12966,12967,13009,13050,13051,13010,13011,12975,12976,13057,13005,13035,13047,13108,13109"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Stone Quests"] = {
		{ids="13207"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Culling of Stratholme Quests"] = {
		{ids="13149,13151"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Nexus Quests"] = {
		{ids="11733,11900,11910,11941,11943,11905,11911,13095,11946,11951,11957,11967,11969,11973,11973"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Oculus Quests"] = {
		{ids="13124,13126,13127,13128"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Violet Hold Quests"] = {
		{ids="13158,13159"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Keep Quests"] = {
		{ids="11272,13206,11262"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Pinnacle Quests"] = {
		{ids="13131,13132"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Month"] = {
		{ids="12306"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Year"] = {
		{ids="12306"},
	},
	["EVENTS\\Brewfest\\Achievements\\Direbrewfest"] = {
		{ids="12062"},
	},
	["EVENTS\\Brewfest\\Achievements\\Down With The Dark Iron"] = {
		{ids="12192"},
	},
	["EVENTS\\Brewfest\\Brewfest Dailies"] = {
		{ids="11407,11408,12020,12318,12062"},
	},
	["EVENTS\\Brewfest\\Brewfest Quests"] = {
		{ids="11409,11412,12194,12191,11431,11120,12318,12062"},
	},
	["EVENTS\\Children's Week\\Children's Week Main Questline"] = {
		{ids="172,1800,910,911,915,925,5502"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Chronos Turn-Ins (Elwynn Forest)"] = {
		{ids="7881,7882,7883,7884,7885,7941"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Kerri Hicks Turn-Ins (Elwynn Forest)"] = {
		{ids="7889,7890,7891,7892,7893,7939"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Rinling Turn-Ins (Elwynn Forest)"] = {
		{ids="7894,7895,7896,7897,7898,7942"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Sayge's Fortunes (Elwynn Forest)"] = {
		{ids="7937,7938,7944,7945"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Spawn of Jubjub (Elwynn Forest)"] = {
		{ids="7946"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Yebb Neblegear Turn-Ins (Elwynn Forest)"] = {
		{ids="7899,7900,7901,7902,8222,8223"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Chronos Turn-Ins (Mulgore)"] = {
		{ids="7881,7882,7883,7884,7885,7941"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Kerri Hicks Turn-Ins (Mulgore)"] = {
		{ids="7889,7890,7891,7892,7893,7939"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Rinling Turn-Ins (Mulgore)"] = {
		{ids="7894,7895,7896,7897,7898,7942"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Sayge's Fortunes (Mulgore)"] = {
		{ids="7937,7938,7944,7945"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Spawn of Jubjub (Mulgore)"] = {
		{ids="7946"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Yebb Neblegear Turn-Ins (Mulgore)"] = {
		{ids="7899,7900,7901,7902,8222,8223"},
	},
	["EVENTS\\Feast of Winter Veil\\Feast of Winter Veil Quest"] = {
		{ids="6964,7061,6961,6962,6963,6983,6984,8746"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Hallowed Be Thy Name"] = {
		{ids="12404,12409", cond_if=[[rep("The Aldor") >= Neutral]]},
		{ids="12404,12409", cond_if=[[rep("The Scryers") >= Neutral]]},
		{ids="11357,11361,12155,11219,12139,12155,1657,8322,8409,12368,12363,12402,12373,12365,12364,12370,12369,12371,12376,12380,12387,12385,12384,12382,12397,12396,12374,12375,12383,12398,12379,12399,12401,12386,12367,12362,12381,12378,12400,12377,12366,12361,12388,12389,12391,12395,12392,12390,12403,12393,12406,12394,12407,12408"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Rotten Hallow"] = {
		{ids="1657,8322,8409"},
	},
	["EVENTS\\Hallow's End\\Achievements\\The Savior of Hallow's End"] = {
		{ids="11357,11361,12155,11219,12139,12155"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Trick or Treat!"] = {
		{ids="12366"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Tricks and Treats of Azeroth"] = {
		{ids="12404,12409", cond_if=[[rep("The Aldor") >= Neutral]]},
		{ids="12404,12409", cond_if=[[rep("The Scryers") >= Neutral]]},
		{ids="12368,12363,12402,12373,12365,12364,12370,12369,12371,12376,12380,12387,12385,12384,12382,12397,12396,12374,12375,12383,12398,12379,12399,12401,12386,12367,12362,12381,12378,12400,12377,12366,12361,12388,12389,12391,12395,12392,12390,12403,12393,12406,12394,12407,12408"},
	},
	["EVENTS\\Hallow's End\\Hallow's End Candy Buckets"] = {
		{ids="12404,12409", cond_if=[[rep("The Aldor") >= Neutral]]},
		{ids="12404,12409", cond_if=[[rep("The Scryers") >= Neutral]]},
		{ids="12368,12363,12402,12373,12365,12364,12370,12369,12371,12376,12380,12387,12385,12384,12382,12397,12396,12374,12375,12383,12398,12379,12399,12401,12386,12367,12362,12381,12378,12400,12377,12366,12361,12388,12389,12391,12395,12392,12390,12403,12393,12406,12394,12407,12408"},
	},
	["EVENTS\\Hallow's End\\Hallow's End Daily Quests"] = {
		{ids="11357,11219,12139,12155,11405"},
	},
	["EVENTS\\Hallow's End\\Hallow's End Quests"] = {
		{ids="11220", cond_if=[[level >= 75]]},
		{ids="8312,11357,8359,12366,11361,12155,12361,8358,8360,12367,8354,12368,1657,8322,8409,11220"},
	},
	["EVENTS\\Harvest Festival\\Harvest Festival Quest"] = {
		{ids="8150"},
	},
	["EVENTS\\Love is in the Air\\Gift Giving"] = {
		{ids="8981,8981,8981"},
	},
	["EVENTS\\Love is in the Air\\Love is in the Air Quests"] = {
		{ids="8904,8979,8980,8982,8983,8984,9029"},
	},
	["EVENTS\\Lunar Festival\\Lunar Festival Main Questline"] = {
		{ids="8873,8867,8883,8864,8865,8863,8862"},
	},
	["EVENTS\\Lunar Festival\\Lunar Festival Optimized Elders Path"] = {
		{ids="8714,8722,8652,8648,8645,8650,8688,8643,8642,8866,8653,8651,8683,8636,8649,8646,8675,8647,8716,8674,8680,8717,8686,8673,8678,8679,8685,8719,8654,8681,8671,8684,8724,8682,8677,8670,8720,8672,8726,8723,8725,8721,8718,8715,8676,8635,8713,8619,8644,8727"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Dailies"] = {
		{ids="11954", cond_if=[[level >= 64]]},
		{ids="11917", cond_if=[[level >= 22 and level <= 31]]},
		{ids="11952", cond_if=[[level >= 51 and level <= 59]]},
		{ids="11948", cond_if=[[level >= 43 and level <= 50]]},
		{ids="11947", cond_if=[[level >= 32 and level <= 42]]},
		{ids="11953", cond_if=[[level >= 60 and level <= 63]]},
		{ids="11926,11925"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Quests"] = {
		{ids="11915,11846,11922,11923,11966,11886,11891,12012,11955,11696,11691,11972"},
	},
	["EVENTS\\Midsummer Fire Festival\\The Fires of Azeroth\\Midsummer Fire Festival Bonfires"] = {
		{ids="9339", cond_if=[[haveq(9332,11933,9330,9331) or completedq(9332,11933,9330,9331)]]},
		{ids="11852,11859,11847,11744,11861,11838,11762,11836,11760,11849,11746,11845,11741,11856,11841,11734,11846,11839,11763,11740,9332,11753,11933,11735,11738,11837,11761,11737,11857,11743,11581,11745,9330,11751,11739,11844,11842,11749,11742,9331,11757,11732,11840,11748,11853,11584,11848,11850,11860,11755,11756,11862,11851,11747,11835,11759,11843,11736,11863,11758,11854,11750,11858,11754,11855,11752"},
	},
	["GOLD\\Gathering\\Frostweave Cloth"] = {
		{ids="13272"},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Cloak Quest"] = {
		{ids="8557", cond=[[Warrior]]},
		{ids="8695", cond=[[Paladin]]},
		{ids="8690", cond=[[Shaman]]},
		{ids="8693", cond=[[Rogue]]},
		{ids="8691", cond=[[Mage]]},
		{ids="8692", cond=[[Druid]]},
		{ids="8689", cond=[[Priest]]},
		{ids="8696", cond=[[Hunter]]},
		{ids="8694", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Ring Quest"] = {
		{ids="8556", cond=[[Warrior]]},
		{ids="8703", cond=[[Paladin]]},
		{ids="8698", cond=[[Shaman]]},
		{ids="8701", cond=[[Rogue]]},
		{ids="8699", cond=[[Mage]]},
		{ids="8700", cond=[[Druid]]},
		{ids="8697", cond=[[Priest]]},
		{ids="8704", cond=[[Hunter]]},
		{ids="8702", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Weapon Quest"] = {
		{ids="8558", cond=[[Warrior]]},
		{ids="8711", cond=[[Paladin]]},
		{ids="8706", cond=[[Shaman]]},
		{ids="8709", cond=[[Rogue]]},
		{ids="8707", cond=[[Mage]]},
		{ids="8708", cond=[[Druid]]},
		{ids="8705", cond=[[Priest]]},
		{ids="8712", cond=[[Hunter]]},
		{ids="8710", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Signet Ring of the Bronze Dragonflight"] = {
		{ids="8753,8754,8755,8756", cond_if=[[completedq(8752)]]},
		{ids="8758,8759,8760,8761", cond_if=[[completedq(8757)]]},
		{ids="8766", cond_if=[[completedq(8756)]]},
		{ids="8764", cond_if=[[completedq(8751)]]},
		{ids="8765", cond_if=[[completedq(8761)]]},
		{ids="8748,8749,8750,8751", cond_if=[[completedq(8747)]]},
		{ids="8757,8747,8752"},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Boots Quest"] = {
		{ids="8559", cond=[[Warrior]]},
		{ids="8655", cond=[[Paladin]]},
		{ids="8621", cond=[[Shaman]]},
		{ids="8637", cond=[[Rogue]]},
		{ids="8634", cond=[[Mage]]},
		{ids="8665", cond=[[Druid]]},
		{ids="8596", cond=[[Priest]]},
		{ids="8626", cond=[[Hunter]]},
		{ids="8660", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Chest Quest"] = {
		{ids="8562,8562", cond=[[Warrior]]},
		{ids="8627,8627", cond=[[Paladin]]},
		{ids="8622,8622", cond=[[Shaman]]},
		{ids="8638,8638", cond=[[Rogue]]},
		{ids="8633,8633", cond=[[Mage]]},
		{ids="8666,8666", cond=[[Druid]]},
		{ids="8603,8603", cond=[[Priest]]},
		{ids="8656,8656", cond=[[Hunter]]},
		{ids="8661,8661", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Helm Quest"] = {
		{ids="8561", cond=[[Warrior]]},
		{ids="8628", cond=[[Paladin]]},
		{ids="8623", cond=[[Shaman]]},
		{ids="8639", cond=[[Rogue]]},
		{ids="8632", cond=[[Mage]]},
		{ids="8667", cond=[[Druid]]},
		{ids="8592", cond=[[Priest]]},
		{ids="8657", cond=[[Hunter]]},
		{ids="8662", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Legs Quest"] = {
		{ids="8560", cond=[[Warrior]]},
		{ids="8629", cond=[[Paladin]]},
		{ids="8624", cond=[[Shaman]]},
		{ids="8640", cond=[[Rogue]]},
		{ids="8631", cond=[[Mage]]},
		{ids="8668", cond=[[Druid]]},
		{ids="8593", cond=[[Priest]]},
		{ids="8658", cond=[[Hunter]]},
		{ids="8663", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Shoulder Quest"] = {
		{ids="8544", cond=[[Warrior]]},
		{ids="8630", cond=[[Paladin]]},
		{ids="8602", cond=[[Shaman]]},
		{ids="8641", cond=[[Rogue]]},
		{ids="8625", cond=[[Mage]]},
		{ids="8669", cond=[[Druid]]},
		{ids="8594", cond=[[Priest]]},
		{ids="8659", cond=[[Hunter]]},
		{ids="8664", cond=[[Warlock]]},
	},
	["LEVELING\\Boosted Characters\\Boosted Druid Intro"] = {
		{ids="64047,64049,64051,64053,64217,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Hunter Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Mage Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Priest Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Rogue Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Shaman Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warlock Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warrior Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Cenarion Battlegear"] = {
		{ids="8800,8548,8572,8573,8574"},
	},
	["LEVELING\\Cenarion Field Duty Combat Assignments"] = {
		{ids="8773", cond_if=[[itemcount(21248) >= 1 or haveq(8773)]]},
		{ids="8771", cond_if=[[itemcount(21750) >= 1 or haveq(8771)]]},
		{ids="8501", cond_if=[[itemcount(20941) >= 1 or haveq(8501)]]},
		{ids="8777", cond_if=[[itemcount(21256) >= 1 or haveq(8777)]]},
		{ids="8776", cond_if=[[itemcount(21255) >= 1 or haveq(8776)]]},
		{ids="8775", cond_if=[[itemcount(21253) >= 1 or haveq(8775)]]},
		{ids="8774", cond_if=[[itemcount(21252) >= 1 or haveq(8774)]]},
		{ids="8770", cond_if=[[itemcount(21749) >= 1 or haveq(8770)]]},
		{ids="8687", cond_if=[[itemcount(21251) >= 1 or haveq(8687)]]},
		{ids="8502", cond_if=[[itemcount(20942) >= 1 or haveq(8502)]]},
		{ids="8772", cond_if=[[itemcount(21250) >= 1 or haveq(8772)]]},
		{ids="8539", cond_if=[[itemcount(21249) >= 1 or haveq(8539)]]},
		{ids="8731,8732"},
	},
	["LEVELING\\Cenarion Field Duty Logistics Assignments"] = {
		{ids="8807", cond_if=[[itemcount(21382) >= 1 or haveq(8807)]]},
		{ids="8805", cond_if=[[itemcount(21379) >= 1 or haveq(8805)]]},
		{ids="8809", cond_if=[[itemcount(21381) >= 1 or haveq(8809)]]},
		{ids="8808", cond_if=[[itemcount(21384) >= 1 or haveq(8808)]]},
		{ids="8806", cond_if=[[itemcount(21380) >= 1 or haveq(8806)]]},
		{ids="8810", cond_if=[[itemcount(21385) >= 1 or haveq(8810)]]},
		{ids="8829", cond_if=[[itemcount(21514) >= 1 or haveq(8829)]]},
		{ids="8804", cond_if=[[itemcount(21378) >= 1 or haveq(8804)]]},
		{ids="8786", cond_if=[[itemcount(21261) >= 1 or haveq(8786)]]},
		{ids="8787", cond_if=[[itemcount(21264) >= 1 or haveq(8787)]]},
		{ids="8785", cond_if=[[itemcount(21258) >= 1 or haveq(8785)]]},
		{ids="8731,8732"},
	},
	["LEVELING\\Cenarion Field Duty Tactical Assignments"] = {
		{ids="8738", cond_if=[[itemcount(21166) >= 1 or haveq(8738)]]},
		{ids="8536", cond_if=[[itemcount(21751) >= 1 or haveq(8536)]]},
		{ids="8740", cond_if=[[itemcount(20944) >= 1 or haveq(8740)]]},
		{ids="8498", cond_if=[[itemcount(20943) >= 1 or haveq(8498)]]},
		{ids="8739", cond_if=[[itemcount(21167) >= 1 or haveq(8739)]]},
		{ids="8538", cond_if=[[itemcount(20948) >= 1 or haveq(8538)]]},
		{ids="8537", cond_if=[[itemcount(20945) >= 1 or haveq(8537)]]},
		{ids="8535", cond_if=[[itemcount(20947) >= 1 or haveq(8535)]]},
		{ids="8534", cond_if=[[itemcount(21165) >= 1 or haveq(8534)]]},
		{ids="8737", cond_if=[[itemcount(21245) >= 1 or haveq(8737)]]},
		{ids="8731,8732"},
	},
	["LEVELING\\Class Quests\\Druid Class Quests"] = {
		{ids="5926,5922,5930,5932,6002", cond_if=[[Tauren Druid]]},
		{ids="6126,6127,6128,6129,6130,27,28,30,31,9063,9052,9051,9053", cond_if=[[Druid]]},
	},
	["LEVELING\\Class Quests\\Hunter Class Quests"] = {
		{ids="6061,6087,6088,6089", cond_if=[[Tauren Hunter]]},
		{ids="8153,8231,8232,7632,7633,7636,7635,7635", cond_if=[[Hunter]]},
		{ids="6062,6083,6082,6081", cond_if=[[(Orc Hunter) or (Troll Hunter)]]},
		{ids="8151"},
	},
	["LEVELING\\Class Quests\\Mage Class Quests"] = {
		{ids="1883,1884,1959,1960,1961,1962,1943,1944,1945,1946,1947,1949,1950,1951,1952,1953,1954,1955,1956,1957,1958,2861,2846,7463", cond_if=[[Mage]]},
	},
	["LEVELING\\Class Quests\\Paladin Class Quests"] = {
		{ids="9601,10590,5405,10592,10593,9721,9722,9723,9725,9735,9736,9737"},
		{ids="9678,9681,64319,9684,63866,9685,9690,9686,9691,9692,9707,9710,9712", cond_if=[[BloodElf Paladin]]},
	},
	["LEVELING\\Class Quests\\Priest Class Quests"] = {
		{ids="5652,5643", cond_if=[[Troll Priest]]},
		{ids="5658,5644", cond_if=[[Scourge Priest]]},
	},
	["LEVELING\\Class Quests\\Rogue Class Quests"] = {
		{ids="2460,2458,2478,2479,2480,8233,8234,3503,8235,3421,3503,8236", cond_if=[[Rogue]]},
	},
	["LEVELING\\Class Quests\\Shaman Class Quests"] = {
		{ids="1516,1517,1518", cond_if=[[(Orc Shaman) or (Troll Shaman)]]},
		{ids="1519,1520,1521", cond_if=[[Tauren Shaman]]},
		{ids="2983,1524,1525,1526,1527,1528,1530,1535,1536,1534,220,63,100,96,1531,8410,8412,8413", cond_if=[[Shaman]]},
	},
	["LEVELING\\Class Quests\\Warlock Class Quests"] = {
		{ids="1485,1499,1506,1501,1504", cond_if=[[Orc Warlock]]},
		{ids="1470,1478,1473,1471", cond_if=[[Scourge Warlock]]},
		{ids="1507,1508,1509,1510,1511,1515,1512,1513,2996,1801,1803,1805,1471,3631,4490,7601,7602,8420,8421,8421,8422,7603,7562,7563,7564,7623,7626,7627,7628,7630,7624,7625,7629,7631", cond_if=[[Warlock]]},
	},
	["LEVELING\\Class Quests\\Warrior Class Quests"] = {
		{ids="1718,1719,1791,1712,1714,1713,1792,8417,8423,8424,8425", cond_if=[[Warrior]]},
		{ids="1818,1819,1820,1821", cond_if=[[Scourge Warrior]]},
		{ids="1498,1502,1503", cond_if=[[(Orc Warrior) or (Troll Warrior) or (Tauren Warrior)]]},
		{ids="1505", cond_if=[[Tauren Warrior]]},
		{ids="1505", cond_if=[[(Orc Warrior) or (Troll Warrior)]]},
	},
	["LEVELING\\Classic (12-58)\\Alterac Mountains (37-38)"] = {
		{ids="544,556"},
	},
	["LEVELING\\Classic (12-58)\\Arathi Highlands (30-30)"] = {
		{ids="1531", cond_if=[[Shaman]]},
		{ids="1718,1719", cond_if=[[Warrior]]},
		{ids="655,672,674,675"},
	},
	["LEVELING\\Classic (12-58)\\Arathi Highlands (36-37)"] = {
		{ids="1164,676,671,701,642,651,702,847"},
	},
	["LEVELING\\Classic (12-58)\\Ashenvale (21-21)"] = {
		{ids="6383,6442"},
		{ids="1528,1530,1535,1536,1534", cond_if=[[Shaman]]},
	},
	["LEVELING\\Classic (12-58)\\Ashenvale (25-26)"] = {
		{ids="2460,2458,2478,2479,2480", cond_if=[[Rogue]]},
		{ids="23", cond_if=[[itemcount(16303) > 0]]},
		{ids="24", cond_if=[[itemcount(16304) > 0]]},
		{ids="6641,25,6503,6544,1918,824,6441,216,6462,6482"},
	},
	["LEVELING\\Classic (12-58)\\Azshara (46-47)"] = {
		{ids="5535,5536,3568,232,238,243"},
	},
	["LEVELING\\Classic (12-58)\\Azshara (50-50)"] = {
		{ids="3517,3518,3541,3542,3561,3565,3562,4494,3563,4300,3564,3569,3570,4133,4293,4294"},
	},
	["LEVELING\\Classic (12-58)\\Azshara (54-55)"] = {
		{ids="3601,5534"},
	},
	["LEVELING\\Classic (12-58)\\Badlands (41-42)"] = {
		{ids="705,703,1108,1137,710,713,714,715,1419,1420,2258,711,712,734,777,716,778"},
	},
	["LEVELING\\Classic (12-58)\\Blasted Lands (51-52)"] = {
		{ids="3501", cond_if=[[itemcount(10593) > 0]]},
		{ids="2581,2583,2585,2601,2603"},
	},
	["LEVELING\\Classic (12-58)\\Burning Steppes (54-54)"] = {
		{ids="4061,3821,4726,4296,4022,3822,4808,4062"},
	},
	["LEVELING\\Classic (12-58)\\Desolace (32-34)"] = {
		{ids="2", cond_if=[[itemcount(16305) > 0]]},
		{ids="1146,1431,1432,9534,9535,247,5561,1365,1368,5386,1433,1434,1435,1366,1370,5763,5381,6143,6142,6161,5741,1480,1481,5501,1436,1482,6027,1484"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (34-35)"] = {
		{ids="1268,1269,1251,1321,1180,1112"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (38-39)"] = {
		{ids="1201,11213,1322,11225,1177,1218,11180,1238,1206,11181,11183,1270,1202,1323,9437,1203,1239,1240,11215,11173,11156,11172,11186,11174,11207,11208"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (43-44)"] = {
		{ids="1166,1169,1168,1273,11184,11158,11217,11160,11161,11159,11162,1262,1170,1171"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (48-49)"] = {
		{ids="1172,626,1173"},
	},
	["LEVELING\\Classic (12-58)\\Eastern Plaguelands (57-58)"] = {
		{ids="5542,5543,5544,6022,6042,5149,5152,5241,6021,5281,5211,6026,9141,6164,5742,5781,5845,9136,9126,9124,9131,5846,5049,5050,7492,1004"},
	},
	["LEVELING\\Classic (12-58)\\Felwood (55-55)"] = {
		{ids="8460,8462,5155,5156,4102,4505,4521,8461,8465"},
	},
	["LEVELING\\Classic (12-58)\\Felwood (56-56)"] = {
		{ids="5157,5158,5887"},
	},
	["LEVELING\\Classic (12-58)\\Feralas (45-46)"] = {
		{ids="2973,2975,2987,2862,2822,3121,2978,2863,2974,2980,2979,2902,2903,7730,7731,2976,7732,3002,649,650,3122,7541"},
	},
	["LEVELING\\Classic (12-58)\\Feralas (49-49)"] = {
		{ids="7738", cond_if=[[itemcount(18972) > 0]]},
		{ids="3380,7734,3062,3063,4120,7003,7721"},
	},
	["LEVELING\\Classic (12-58)\\Hillsbrad Foothills (29-30)"] = {
		{ids="493,494", cond_if=[[not Rogue or Shaman]]},
		{ids="501,509,527,567,552,502,553,1361"},
	},
	["LEVELING\\Classic (12-58)\\Searing Gorge (47-48)"] = {
		{ids="4449,4450,3441,3442,7701,7728,7729,7723,7724,7727,7722,4451,3443,3452,3453,3454,3462,3463,3481"},
	},
	["LEVELING\\Classic (12-58)\\Silithus (58-59)"] = {
		{ids="1004,1123,1124,1125,8280,8283,8277,8284,8318,8304,1126,8308,6844,9416,8281,8278,8282,8285,8306,8279,8287,8323,9128,5181,4741,6845,1185"},
	},
	["LEVELING\\Classic (12-58)\\Stonetalon Mountains (15-16)"] = {
		{ids="1062,6548,6629,6523,6401"},
	},
	["LEVELING\\Classic (12-58)\\Stonetalon Mountains (20-21)"] = {
		{ids="1058,6461,6284,1093,1094,6421,6562,1068"},
	},
	["LEVELING\\Classic (12-58)\\Stonetalon Mountains (23-24)"] = {
		{ids="1087,6301,5881,6282,6393,6381,1096"},
	},
	["LEVELING\\Classic (12-58)\\Stonetalon Mountains (26-27)"] = {
		{ids="6283,1196"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (30-31)"] = {
		{ids="338,340", cond_if=[[((itemcount(2734) >= 1) and (itemcount(2735) >= 1) and (itemcount(2738) >= 1) and (itemcount(2740) >= 1) and (not completedq(340)))]]},
		{ids="338,341", cond_if=[[((itemcount(2742) >= 1) and (itemcount(2744) >= 1) and (itemcount(2745) >= 1) and (itemcount(2748) >= 1) and (not completedq(341)))]]},
		{ids="338,339", cond_if=[[((itemcount(2725) >= 1) and (itemcount(2728) >= 1) and (itemcount(2730) >= 1) and (itemcount(2732) >= 1) and (not completedq(339)))]]},
		{ids="338,342", cond_if=[[((itemcount(2749) >= 1) and (itemcount(2750) >= 1) and (itemcount(2751) >= 1) and (not completedq(342)))]]},
		{ids="583,194,185,190,186,187,191,195"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (35-36)"] = {
		{ids="338,340,338,340,338,340", cond_if=[[((itemcount(2734) >= 1) and (itemcount(2735) >= 1) and (itemcount(2738) >= 1) and (itemcount(2740) >= 1) and (not completedq(340)))]]},
		{ids="338,341,338,341,338,341", cond_if=[[((itemcount(2742) >= 1) and (itemcount(2744) >= 1) and (itemcount(2745) >= 1) and (itemcount(2748) >= 1) and (not completedq(341)))]]},
		{ids="338,339,338,339,338,339", cond_if=[[((itemcount(2725) >= 1) and (itemcount(2728) >= 1) and (itemcount(2730) >= 1) and (itemcount(2732) >= 1) and (not completedq(339)))]]},
		{ids="338,342,338,342,338,342", cond_if=[[((itemcount(2749) >= 1) and (itemcount(2750) >= 1) and (itemcount(2751) >= 1) and (not completedq(342)))]]},
		{ids="1181,605,201,189,213,1182,568,570,9436,581,596,629,569,9457,582,192,188,196,193,1183,638"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (39-39)"] = {
		{ids="338,340", cond_if=[[((itemcount(2734) >= 1) and (itemcount(2735) >= 1) and (itemcount(2738) >= 1) and (itemcount(2740) >= 1) and (not completedq(340)))]]},
		{ids="338,341", cond_if=[[((itemcount(2742) >= 1) and (itemcount(2744) >= 1) and (itemcount(2745) >= 1) and (itemcount(2748) >= 1) and (not completedq(341)))]]},
		{ids="338,339", cond_if=[[((itemcount(2725) >= 1) and (itemcount(2728) >= 1) and (itemcount(2730) >= 1) and (itemcount(2732) >= 1) and (not completedq(339)))]]},
		{ids="338,342", cond_if=[[((itemcount(2749) >= 1) and (itemcount(2750) >= 1) and (itemcount(2751) >= 1) and (not completedq(342)))]]},
		{ids="595,606,1116,572,629,1261,571,197,597,607,599,573"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (42-43)"] = {
		{ids="338,340", cond_if=[[((itemcount(2734) >= 1) and (itemcount(2735) >= 1) and (itemcount(2738) >= 1) and (itemcount(2740) >= 1) and (not completedq(340)))]]},
		{ids="338,341", cond_if=[[((itemcount(2742) >= 1) and (itemcount(2744) >= 1) and (itemcount(2745) >= 1) and (itemcount(2748) >= 1) and (not completedq(341)))]]},
		{ids="338,339", cond_if=[[((itemcount(2725) >= 1) and (itemcount(2728) >= 1) and (itemcount(2730) >= 1) and (itemcount(2732) >= 1) and (not completedq(339)))]]},
		{ids="338,342", cond_if=[[((itemcount(2749) >= 1) and (itemcount(2750) >= 1) and (itemcount(2751) >= 1) and (not completedq(342)))]]},
		{ids="604,587,600,621,617,609,576,1117,2864,2872"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (47-47)"] = {
		{ids="608,594,630,624"},
	},
	["LEVELING\\Classic (12-58)\\Swamp of Sorrows (39-40)"] = {
		{ids="1372,1392,1389,698,9440,1424,1418,1429"},
	},
	["LEVELING\\Classic (12-58)\\Swamp of Sorrows (48-48)"] = {
		{ids="2784,2621,625,2622,2623,2801,580"},
	},
	["LEVELING\\Classic (12-58)\\Tanaris (44-45)"] = {
		{ids="2781,2875,1707,1690,992,1118,1188,1190,1194,8365,3520,8366,2873,1691,2874"},
	},
	["LEVELING\\Classic (12-58)\\Tanaris (49-50)"] = {
		{ids="3362,4504,5863,379,2741,2605,82,3444,3161,1560,4324,2606,2641,10,110,113,32"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (12-15)"] = {
		{ids="6126,6127,6128,6129,6130", cond_if=[[Druid]]},
		{ids="6365,6384,6385,6386", cond_if=[[Orc or Troll]]},
		{ids="842,844,870,869,871,5041,867,1492,848,819,845,872,903,887,894,896,895,865,821,891,890,892,888,899,4921,855,850,851"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (16-20)"] = {
		{ids="26,28,30,31", cond_if=[[Druid]]},
		{ids="1507,1508,1509,1510,1511,1515,1512,1513", cond_if=[[Warlock]]},
		{ids="5644", cond_if=[[Scourge Priest]]},
		{ids="5680", cond_if=[[Troll Priest]]},
		{ids="875,881,877,3281,853,878,900,901,902,858,863,6541,876,905,1483,3921,1069,880,1060,868,3261,1489,882,883,822,907,913,1130,6382,5052,1131,1490,1195"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (21-23)"] = {
		{ids="220,63,100,96", cond_if=[[Shaman]]},
		{ids="1095,879,893,884,843,885,846,906"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (24-25)"] = {
		{ids="849"},
	},
	["LEVELING\\Classic (12-58)\\The Hinterlands (50-51)"] = {
		{ids="1444,7840,7815,7816,4502"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (24-25)"] = {
		{ids="4542,4821,4841,5064,4767"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (27-29)"] = {
		{ids="1197,1149,4865,5147,5062,5088,4904,4770,4881,4966,1136"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (31-32)"] = {
		{ids="1145,1362,1110,1111,5762,1104,1105,1176,1175,1178,5361"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (38-38)"] = {
		{ids="1148", cond_if=[[(haveq(1147) or completedq(1147)) or (haveq(1148) or completedq(1148))]]},
		{ids="1205,1147,1114,1106,1115,1186,1187,1184"},
	},
	["LEVELING\\Classic (12-58)\\Un'Goro Crater (52-54)"] = {
		{ids="3884", cond_if=[[itemcount(11116) > 0]]},
		{ids="2661,4496,2662,4289,4290,4243,4503,4501,3882,3883,3881,4145,4244,4245,4291,4301,3844,3845,4292,974,4492,4284,4285,4287,4288,4147,3908,4491,980,4321,3761,3782"},
	},
	["LEVELING\\Classic (12-58)\\Western Plaguelands (56-58)"] = {
		{ids="5094,5096,5503,5021,5023,5228,5098,5229,5230,5231,5232,5058,5059,5060,5233,4984,5234,5235,4985,5236,5238,9443,6004,6023,6025,5049"},
	},
	["LEVELING\\Classic (12-58)\\Winterspring (55-56)"] = {
		{ids="5083", cond_if=[[itemcount(12771) > 0]]},
		{ids="8464,4842,5082,3783,6029,4809,977"},
	},
	["LEVELING\\Classic (12-58)\\Winterspring (59-60)"] = {
		{ids="8798", cond_if=[[skill('Engineering') >= 250]]},
		{ids="5087,5121,4809,4721,4882,4810,4883"},
	},
	["LEVELING\\Extra Zones\\Eastern Plaguelands"] = {
		{ids="5542,5543,5544,6022,6042,5149,5152,5241,6021,5281,5211,6026,9141,6164,5742,5781,5845,9136,9126,9124,9131,5846,5049,5050,7492,1004"},
	},
	["LEVELING\\Extra Zones\\Ghostlands"] = {
		{ids="9329", cond_if=[[not BloodElf]]},
		{ids="9327,9130,9133,9134,9135", cond_if=[[BloodElf]]},
		{ids="9148,9758,9152,9138,9315,9139,9145,9160,9192,9150,9155,9171,9140,9163,9199,9193,9158,9274,9159,9143,9146,9214,9161,9276,9157,9174,9162,9172,9176,9173,9216,9218,9175,9207,9166,9151,9212,9277,9275,9169,9220,9281,9170,9877,9164,9177"},
	},
	["LEVELING\\Extra Zones\\Silithus"] = {
		{ids="1125,8280,8283,8277,8284,8318,8304,1126,8308,6844,9416,8281,8278,8282,8285,8306,8279,8287,8323,9128,5181,4741,6845,1185,8320,8361,8321"},
	},
	["LEVELING\\Extra Zones\\Silverpine Forest"] = {
		{ids="6321,6323,6322,6324", cond_if=[[Scourge]]},
		{ids="435,449,421,477,447,3221,428,437,1359,422,429,430,438,423,1358,478,439,425,440,481,424,482,479,441,264,530,443,460,461,491,444,516,493"},
	},
	["LEVELING\\Extra Zones\\Western Plaguelands"] = {
		{ids="5094,4642,5901,5096,5503,5021,5023,5228,5229,5230,5231,5232,5058,5059,5060,5233,4984,5234,5235,4985,4987,5236,5902,5098,5238,5051,6390,6004,6023,5153,5154,4971,4972,5210,838,964,8276,1123,1124"},
	},
	["LEVELING\\Scepter of the Shifting Sands"] = {
		{ids="8286,8288,8301,8302,8303,8305,8519,8555,8575,8576,8577,8584,8597,8599,8598,8606,8585,8586,8620,8578,8733,8734,8735,8736,8741,8587,8730,8728,8729,8742,8743,8745"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Orgrimmar)"] = {
		{ids="9263,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Silvermoon City)"] = {
		{ids="12816,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Thunder Bluff)"] = {
		{ids="9264,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Undercity)"] = {
		{ids="9265,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Starter Guides (1-12)\\Durotar (1-12) [Orc & Troll Starter]"] = {
		{ids="3086", cond=[[Troll Mage]]},
		{ids="3083", cond=[[Troll Rogue]]},
		{ids="1516,1517,1518,2983,1524,1525,1526,1527", cond_if=[[Shaman]]},
		{ids="5652", cond_if=[[Troll Priest]]},
		{ids="1485,1499", cond_if=[[Orc Warlock]]},
		{ids="3089", cond=[[Orc Shaman]]},
		{ids="3087", cond=[[Orc Hunter]]},
		{ids="792", cond_if=[[not Orc Warlock]]},
		{ids="6062,6083,6082,6081", cond_if=[[Hunter]]},
		{ids="1506,1501,1504", cond_if=[[Warlock]]},
		{ids="3085", cond=[[Troll Priest]]},
		{ids="1505,1498", cond_if=[[Warrior]]},
		{ids="3065", cond=[[Troll Warrior]]},
		{ids="2383", cond=[[Orc Warrior]]},
		{ids="3090", cond=[[Orc Warlock]]},
		{ids="3088", cond=[[Orc Rogue]]},
		{ids="3084", cond=[[Troll Shaman]]},
		{ids="3082", cond=[[Troll Hunter]]},
		{ids="4641,788,789,4402,5441,6394,790,804,794,805,2161,786,808,826,823,818,817,806,784,837,815,791,830,825,831,816,834,835,812,5726,813,828,827,829,809,5727,840"},
	},
	["LEVELING\\Starter Guides (1-12)\\Eversong Woods (1-13) [Blood Elf Starter]"] = {
		{ids="8336,8346,8338", cond_if=[[BloodElf]]},
		{ids="8563,8344,10073,8330,8345,9529,9619", cond_if=[[BloodElf Warlock]]},
		{ids="8328,10068,8330,8345", cond_if=[[BloodElf Mage]]},
		{ids="8564,10072,8330,8345", cond_if=[[BloodElf Priest]]},
		{ids="9392,10071,8330,8345", cond_if=[[BloodElf Rogue]]},
		{ids="9676,10069,8330,8345,9678,9681,64319,9684,63866,9685", cond_if=[[BloodElf Paladin]]},
		{ids="9393,10070,8330,8345,9484,9486,9485,9673", cond_if=[[BloodElf Hunter]]},
		{ids="8325,8326,8327,8334,8335,8347,9704,9705,8350,8472,8468,8463,8895,9352,9119,9035,8486,8482,8884,8887,8885,8886,8480,8491,9254,9358,9258,8892,9252,9062,9064,8483,8475,9066,8487,8488,9255,9253,9395,9067,9076,9144,9359,9147,8888,8889,9394,8891,8894,8890,8476,8477,8479,9360,9363,8473,8474,10166,8490,840"},
	},
	["LEVELING\\Starter Guides (1-12)\\Mulgore (1-12) [Tauren Starter]"] = {
		{ids="3093", cond=[[Tauren Shaman]]},
		{ids="3094", cond=[[Tauren Druid]]},
		{ids="3091", cond=[[Tauren Warrior]]},
		{ids="6061,6087,6088,6089", cond_if=[[Tauren Hunter]]},
		{ids="5926,5922,5930,5932,6002", cond_if=[[Tauren Druid]]},
		{ids="748,754,756,758,759,760,854", cond_if=[[Tauren]]},
		{ids="3092", cond=[[Tauren Hunter]]},
		{ids="1505,1498", cond_if=[[Tauren Warrior]]},
		{ids="1519,1520,1521,2984,1524,1525,1526,1527", cond_if=[[Tauren Shaman]]},
		{ids="747,752,753,750,755,757,780,3376,763,1656,743,745,767,746,771,766,761,772,749,751,773,764,765,861,833,775,744,776,886,860,840"},
	},
	["LEVELING\\Starter Guides (1-12)\\Tirisfal Glades (1-12) [Undead Starter]"] = {
		{ids="3098", cond_if=[[Scourge Mage]]},
		{ids="3097,5658", cond_if=[[Scourge Priest]]},
		{ids="3096", cond_if=[[Scourge Rogue]]},
		{ids="3095,1818,1819,1820", cond_if=[[Scourge Warrior]]},
		{ids="1470,3099,1478,1473,1471", cond_if=[[Scourge Warlock]]},
		{ids="363,364,3901,376,6395,380,3902,381,382,383,8,365,5481,404,5482,367,427,398,358,368,426,354,362,375,590,361,355,370,374,407,359,369,371,360,356,372,492,840"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains (67-68)"] = {
		{ids="9795,10928,10503,10489,10486,10487,10524,10505,10525,10526,10542,10545,10543,10544,10488,10718,10614,10682,10770,10771,10567,10753,10810,10812,10819,10607,10713,10717,10719,10747,10894,10820,10565,10618,10617,10709,10860,10714,10783,10715,10749,10720,10784,10721,10785,10723,10786,10893,10722,10825,10566,10846,10615,10843,10851,10845,10853,10859,10865,10867"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains Group Quests"] = {
		{ids="10718,10614,10709,10714,10783,10715,10749,10720,10721,10785,10723,10724,10742,10810,10812,10819,10820,10821"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula (58-62)"] = {
		{ids="9498", cond_if=[[not BloodElf]]},
		{ids="9499", cond=[[BloodElf]]},
		{ids="9407,10120,10289,10291,10121,10450,10086,10123,10087,10449,10124,10208,10242,10129,10162,10388,10278,10220,10538,9345,10809,10792,10213,10835,10813,10390,10864,10393,10391,10392,10236,9373,10238,10629,10630,10389,9400,10229,10161,9349,10230,9351,9361,9356,10294,10250,10258,9401,9374,9387,9366,9396,9381,9397,10442,9340,10103,9405,9410,9406,10286,9370,9391,9438,9441,9442,9418,9375,9376,10287,9372,10159,9912,10255,10403,10367,10368,10369,9447,9472"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula Group"] = {
		{ids="9407,10120,10289,10450,10449,10242,10538,10835,10864,10838,10813,10834,10136,9466,10132,10134,10349,10351"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Isle of Quel'danas"] = {
		{ids="11550,11526,11488,11517,11534,11490,29685"},
		{ids="11481", cond_if=[[rep ("The Aldor") >= Neutral and completedq(10551)]]},
		{ids="11482", cond_if=[[rep ("The Scryers") >= Neutral and completedq(10552)]]},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Nagrand (65-67)"] = {
		{ids="9882", cond_if=[[rep ('The Consortium') < Friendly]]},
		{ids="10210,10211,10551,10552,9797,9854,9789,9857,9861,9855,9850,9858,10479,9935,9939,9888,9870,9863,9864,9867,9944,9913,9862,9800,9815,9818,9819,9821,9872,9849,9804,9805,10109,9889,9890,9891,9906,9910,9916,9907,9810,10107,9865,9945,9948,9866,9983,9991,9900,9925,9914,9928,9927,9931,9932,9934,9962,9967,9970,9972,9973,9977"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Nagrand Group Quests"] = {
		{ids="10109,10111,9818,9819,9821,9849,9853,9854,9789,9855,9850,9858,9859,9851,9856,9852,10227,10228,10231,10251,10252,9944,9945,9946,9962,9967,9970,9972,9977,9937,9983,9991,9999,10001,10004,10009,10010,10011"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm (68-70)"] = {
		{ids="10313,10243,10263,10245,10299,10321,10246,10322,10328,10431,10380,10381", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10189", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10193,10204,10329,10194,10652,10197,10198,10330,10200,10341,10338,10202,10432", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10241", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10210,10211,10551,10552,10183,10190,10342,10186,10173,10191,10199,10203,10225,10224,10226,10265,10221,10262,10206,10300,10174,10205,10232,10333,10266,10334,10331,10184,10188,10185,10343,10305,10182,10307,10306,10337,10332,10312,10239,10316,10314,10319,10192,10240,10222,10301,10233,10209,10223,10176,10924,10267,10311,10234,10348,10417,10433,10434,10418,10235,10423,10268,10237,10426,10424,10336,10855,10335,10435,10269,10247,10427,10429,10317,10315,10318,10430,10856,10436,10440,10857,10270,10411,10437,10422,10345,10353,10271,10281,10272,10273,10438,10275,10339,10384,10385,10405"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm Group Quests"] = {
		{ids="10341,10202,10432,10193,10329,10194,10652,10197,10198,10330,10200,10338,10365,10264", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10243,10245,10299,10321,10322,10323,10263", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10508,10509,10189", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10407,10410,10409,10507,10309,10261,10701,10256,10265,10262,10205,10266,10267,10268,10269,10275,10276,10184,10312,10316,10314,10319,10320,10333,10234,10235,10237,10247,10248,10270,10271,10281,10272,10273,10274,10290,10293,10339,10384,10385,10405,10406,10408,10437,10438,10439,10310"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Shadowmoon Valley (70-70)"] = {
		{ids="10619,10568,10826", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10673", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10684", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10571,10673", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10807,10824,10683", cond_if=[[rep('The Scryers')>=Neutral]]},
		{ids="10210,10211,10551,10552,11047,10595,10596,10760,10660,10624,10681,10702,10597,10598,10599,10458,10480,10600,10601,10602,10603,10625,10672,10761,10633,10604,10623,10777,10778,10481,10635,10804,10780,10782,10808"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest (63-65)"] = {
		{ids="10210,10037,10211,10551,10552,10554,10325,10021,10553,10412,9968,9971,9951,9978,9979,9987,10862,10039,10868,10000,10027,10018,10034,9993,10112,10917,10847,10201,10023,10849,10041,10043,10839,10852,10896,10878,10848,10840,10842,10880,10881,10030,9990,10003,10008,10013,9995,10448,10791,9997,10447,10006,10887,10861,10913,10922,10873,10877,10914,10227,10031,10228,10920,10915"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest Group Quests"] = {
		{ids="10052,10898,10842,10877,10923,10034,10036,10922,10929,10930,9983,9991,9999,10001,10004,10009"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh (62-63)"] = {
		{ids="9957", cond_if=[[(rep('Cenarion Expedition') >= Friendly) and not completedq(9968)]]},
		{ids="9697", cond_if=[[(rep('Cenarion Expedition') >= Friendly) and not completedq(9701)]]},
		{ids="9747,9802,9895,9716,9778,9728,9774,9770,9769,9773,9752,9788,10096,9894,9718,9720,9771,9775,9899,9772,9828,9731,9785,9898,9846,9845,9814,9820,10117,9841,9911,9701,9739,9743,9919,9702,9708,9816,9903,9904,9847,9822,9709,9808,9806,9842,9823,10118,10105,9724,9732"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh Group Quests"] = {
		{ids="9730,9817,9817,10117,9894,9895,9729"},
	},
	["LEVELING\\Northrend (69-80)\\Borean Tundra (70-72)"] = {
		{ids="11945", cond_if=[[subzone("Kaskala")]]},
		{ids="11585,11596,11598,11606,11611,11608,11602,11614,11574,11888,12486,11615,11634,11616,11618,11636,11642,11655,11660,11643,11644,11664,11651,11652,11656,11661,11662,11613,12471,11619,11620,11686,11676,11688,11690,11703,11705,11709,11711,11716,11714,11717,11719,11720,11721,11724,11722,11916,11890,11684,11881,11674,11887,11893,11685,11895,11896,11906,11899,11907,11909,11894,11695,11706,11628,11675,11677,11678,11683,11687,11689,11630,11633,11640,11641,11647,11654,11659,11949,11950,11961,11968,11864,11866,11876,11869,11865,11868,11878,11870,11879,11871,11872,11605,11612,11587,11576,11582,11590,11646,11648,11663,11671,11679,11680,11681,11682,11607,11617,11609,11623,11610,12728,11733,11900,11910,11918,11912,11941,11943,11936,11914,11946,11951,11957,11967,11624,11591,11702,11627,11649,11571,11559,11560,11561,11562,11563,11564,11565,11566,11569,11570,11629,11631,11635,11639,11637,11638,11593,11594,11592"},
	},
	["LEVELING\\Northrend (69-80)\\Dragonblight (72-74)"] = {
		{ids="11960", cond_if=[[subzone("Moa'ki Harbor")]]},
		{ids="12372", cond_if=[[subzone("Wyrmrest Temple")]]},
		{ids="12791", cond_if=[[not Mage]]},
		{ids="12173", cond=[[Mage]]},
		{ids="12181,12182,12303,12209,12205,12206,12211,12188,12304,12245,12200,12230,12214,12458,12447,11958,11996,12033,11999,11979,11980,11978,11983,12008,12006,12013,12005,12034,12036,12039,12056,12100,12040,12041,12059,12061,12053,12048,12101,12102,12063,12064,12069,12057,12115,12071,12125,12126,12127,12072,12066,12140,12084,12096,12085,11959,12419,12104,12111,12106,12028,12030,12009,12011,12016,12017,12110,12031,12032,12454,12252,12218,12271,12273,12232,12221,12240,12234,12239,12243,12254,12260,12274,12283,12488,12122,12132,12136,12224,12262,12261,12263,12264,12265,12267,12266,12496,12767,12461,12497,12498,12448,12449,12450,12769,12124,12435,12144,12145,12147,12469,12043,12045,12044,12046,12047,12049,12052,12050,12112,12075,12076,12079,12077,12078,12500,13242,13257,12790,12487"},
	},
	["LEVELING\\Northrend (69-80)\\Grizzly Hills (74-75)"] = {
		{ids="12436,12175,12468,12257,12256,12433,12324,12317,12170,12176,12259,12451,12412,12423,12413,12424,12422,12177,12208,12178,11984,11989,11990,11991,12484,12029,12483,12007,12042,12288,12280,12270,12284,12802,12068,12425,12427,12428,12429,12430,12431,12453,12207,12213,12190,12328,12327,12329,12134,12330,12411,12415,12074,12195,12279,12026,12229,12231,12054,12058,12073,11982,12070,11985,12081,12113,12114,12116,12093,12094,12099,12082,12120,12121,12137,12152,12241,12242,12204,12201,12165,12202,12196,12203,12197,12198,12199"},
	},
	["LEVELING\\Northrend (69-80)\\Howling Fjord (69-71)"] = {
		{ids="11167,11227,11270,11221,11253,11168,11254,11170,11295,11229,11230,11232,11233,11241,11234,11304,12566,11282,11283,11285,11303,12481,11271,11311,11275,11281,11312,11350,11297,11313,11314,11315,11351,11256,11316,11319,11428,11352,11257,11258,11259,11260,11261,11263,11265,11287,11296,11286,11317,11397,11298,11301,11323,11415,11266,11417,11398,11399,11422,11268,11264,11433,11324,11453,11504,11279,11305,11424,11306,11307,11182,11280,11308,11309,12482,11423,11310,11507,11508,11456,11457,11458,11509,11510,11434,11469,11455,11464,11511,11512,11519,11567,11466,11467,11473,11459,11476,11479,11480,11471,11527,11529,12117,12118,11530,11568,11572"},
	},
	["LEVELING\\Northrend (69-80)\\Icecrown (79-80)"] = {
		{ids="13283", cond_if=[[subzone("Ymirheim")]]},
		{ids="13105", cond_if=[[DeathKnight]]},
		{ids="12995,13071,13069", cond_if=[[subzone("The Shadow Vault")]]},
		{ids="13365,13357", cond_if=[[zone("Icecrown")]]},
		{ids="13310", cond_if=[[subzone("The Bombardment")]]},
		{ids="12813,12838,12815", cond_if=[[subzone("Death's Rise")]]},
		{ids="12839", cond_if=[[haveq(12838)]]},
		{ids="13104", cond_if=[[not DeathKnight]]},
		{ids="13419,13036,13008,13040,13039,13044,13045,13070,13086,13118,13122,13130,13135,13110,13125,13139,13141,13157,13068,13224,13228,12892,13330,13340,13302,13293,13072,12891,12893,12897,13301,13230,13073,13074,13075,13076,12899,13238,13260,13237,13239,12938,13106,12939,12955,12999,12943,12949,12951,13085,12992,12982,13084,13042,13092,13059,13043,13091,13121,12806,12807,12810,12814,12840,13117,13119,13120,13134,13229,13136,13138,13140,13077,13078,13079,13080,13264,13258,13261,13259,13262,13263,13271,13275,13282,13081,13082,13083,13304,13351,13168,13169,13170,13171,13172,13174,13155,13133,13211,13152,13144,13212,13220,13235,13143,13145,13146,13147,13160,13305,13236,13348,13349,13355,13354,13352,13379,13373,13353,13358,13366,13356,13359,13360,13306,13361,13362,13363,13364"},
	},
	["LEVELING\\Northrend (69-80)\\Sholazar Basin (76-78)"] = {
		{ids="12521,12489,12524,12624,12522,12688,12525,12523,12589,12592,12549,12520,12526,12550,12804,12634,12551,12543,12558,12644,12645,12560,12544,12556,12654,12569,12528,12595,12603,12605,12683,12681,12607,12658,12614,12561,12611,12612,12805,12608,12617,12660,12620,12621,12559,12613,12691,12548,12547,12797,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12578,12699,12803,12671,12546,12580,12579,12581,12689,12695,12582,12692"},
	},
	["LEVELING\\Northrend (69-80)\\The Storm Peaks (78-79)"] = {
		{ids="12833", cond_if=[[subzone("K3")]]},
		{ids="12818,12843,12844,12827,12836,12819,12826,12820,12828,12829,12830,12831,12832,12821,12822,12823,12824,13060,12846,12882,12895,13054,13000,12909,12910,12913,13055,13056,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,12925,12942,12968,13062,12886,13064,12915,12953,12917,12920,12926,12927,13416,12928,12929,13273,12930,12931,12937,12957,12964,12965,12978,12979,12980,12984,12988,12991,12993,12998,13007,12922,12956,13274,13285,12924,13426,12966,12967,13034,13037,13038,13048,13049,13058"},
	},
	["LEVELING\\Northrend (69-80)\\Zul'Drak (75-76)"] = {
		{ids="12637", cond_if=[[completedq(12631)]]},
		{ids="12643", cond_if=[[completedq(12638)]]},
		{ids="12795", cond_if=[[not completedq(12503)]]},
		{ids="12633,12663", cond_if=[[completedq(12238)]]},
		{ids="12649", cond_if=[[completedq(12643)]]},
		{ids="12638", cond_if=[[completedq(12633)]]},
		{ids="12629", cond_if=[[completedq(12637)]]},
		{ids="12648", cond_if=[[completedq(12629)]]},
		{ids="12631,12664", cond_if=[[not completedq(12238)]]},
		{ids="12763,12859,12902,12861,12883,12884,12894,12903,12901,12912,12904,12914,12630,12652,12661,12916,12919,12669,12673,12677,12686,12676,12690,12710,12713,12503,12740,12565,12505,12596,12506,12597,12598,12512,12606,12553,12552,12583,12584,12555,12599,12932,12933,12934,12935,12936,12948,12799,12557,12609,12610,12504,12508,12507,12510,12562,12514,12527,12516,12623,12627,12615,12622,12628,12635,12640,12639,12632,12642,12650,13549,12655,12646,12647,12653,12659,12662,12665,12666,12667,12672,12668,12674,12675,12684,12685,12709,12712,12708,12707,13556"},
	},
	["LEVELING\\Starter Guides (1-12) & Death Knight (55-58)\\Death Knight Starter (55-58)"] = {
		{ids="12746", cond=[[Draenei]]},
		{ids="12743", cond=[[NightElf]]},
		{ids="12750", cond=[[Scourge]]},
		{ids="12748", cond=[[Orc]]},
		{ids="12745", cond=[[Gnome]]},
		{ids="12744", cond=[[Dwarf]]},
		{ids="12747", cond=[[BloodElf]]},
		{ids="12749", cond=[[Troll]]},
		{ids="12742", cond=[[Human]]},
		{ids="12739", cond=[[Tauren]]},
		{ids="12593,12619,12842,12848,12636,12641,12657,12850,12849,12670,12678,12680,12733,12679,12687,12711,12697,12698,12700,12701,12706,12714,12715,12716,12719,12722,12720,12717,12723,12724,12725,12727,12738,12751,12754,12755,12756,12757,12778,12779,12800,12801,13165,13166,13189"},
	},
	["PROFESSIONS\\Tailoring\\Farming Guides\\Frostweave Cloth"] = {
		{ids="13272"},
	},
	["PROFESSIONS\\Blacksmithing\\Blacksmithing (1-450)"] = {
		{ids="7652,7655,7654,7656"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Armorsmith\\Armorsmith Questline"] = {
		{ids="5301,2756,2757,2760,2761,2762,2763,2765,2764,2771,2772,2773,3321"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Axesmith Questline"] = {
		{ids="5306"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Hammersmith Questline"] = {
		{ids="5305"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Swordsmith Questline"] = {
		{ids="5307"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Weaponsmith Questline"] = {
		{ids="5302"},
	},
	["PROFESSIONS\\Cooking\\Cooking (1-450)"] = {
		{ids="8307,8313,13090,12521,12489,12524,12522,12525,12523,12549,12520,12634,12644,12645,13571"},
	},
	["PROFESSIONS\\Cooking\\Cooking + Fishing (1-450)"] = {
		{ids="6607"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnome Engineer Membership Card Renewal"] = {
		{ids="3645"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnomish Engineering Questline"] = {
		{ids="3637,3642,3643"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineer Membership Card Renewal"] = {
		{ids="3644"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineering Questline"] = {
		{ids="3633,3639"},
	},
	["PROFESSIONS\\First Aid\\First Aid (1-450)"] = {
		{ids="13272"},
	},
	["PROFESSIONS\\Fishing\\Fishing (1-450)"] = {
		{ids="6607"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Dragonscale Leatherworking\\Dragonscale Leatherworking Questline"] = {
		{ids="5145"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Elemental Leatherworking\\Elemental Leatherworking Questline"] = {
		{ids="5146"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Tribal Leatherworking\\Tribal Leatherworking Questline"] = {
		{ids="2854,2855,2856,2857,2858,2859,2860,5143"},
	},
	["PROFESSIONS\\Lockpicking\\Lockpicking (1-300)"] = {
		{ids="2379,2382,2381"},
	},
	["PROFESSIONS\\Tailoring\\Tailoring (1-450)"] = {
		{ids="13272,13272"},
	},
	["REPUTATIONS\\The Burning Crusade\\Cenarion Expedition"] = {
		{ids="9802,9784,9875"},
	},
	["REPUTATIONS\\The Burning Crusade\\Keepers of Time"] = {
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["REPUTATIONS\\The Burning Crusade\\Lower City"] = {
		{ids="10917,10918"},
	},
	["REPUTATIONS\\The Burning Crusade\\Netherwing"] = {
		{ids="11099,11100", cond_if=[[rep("The Aldor") >= Friendly]]},
		{ids="11094,11095", cond_if=[[rep("The Scryers") >= Friendly]]},
		{ids="10804,10811,10814,10836,10837,10854,10858,10866,10870,11012,11013,11014,11019,11049,11053,11075,11054,11083,11081,11082,11084,11063,11064,11067,11068,11069,11070,11071,11092,11041,11107,11108,11113,11114,11112,11111,11110,11109"},
	},
	["REPUTATIONS\\The Burning Crusade\\Ogri'la"] = {
		{ids="11102", cond_if=[[raceclass("Druid")]]},
		{ids="11010", cond_if=[[not raceclass("Druid")]]},
		{ids="10984,10983,10995,10996,10997,10998,11000,11022,11009,11025,11058,11030,11061,11062,11119,11065,11059,11078,11079,11091,11026"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sha'tari Skyguard"] = {
		{ids="11102", cond_if=[[raceclass("Druid")]]},
		{ids="11010", cond_if=[[not raceclass("Druid")]]},
		{ids="11096,11098,11093,11004,11005,11021,11024,11028,11056,11029,11885,11006,11074,11073,10984,10983,10995,10996,10997,10998,11000,11022,11009,11025,11058,11030,11062,11119,11065,11059,11078,11026"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sporeggar"] = {
		{ids="9714", cond_if=[[rep('Sporeggar')<Exalted]]},
		{ids="9742", cond_if=[[rep('Sporeggar')<Friendly]]},
		{ids="9739,9743,9919"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Aldor"] = {
		{ids="10210,10211,10551,10554,11038,10325,10653,10021,10420,10020,11038,10241,10313,10243,10245,10299,10321,10246,10322,10328,10431,10323,10380,10381,10407,10410,10409,10587,10619,10568,10816,10571,10637,10640,10574,10575,10669,10668,10641,10646,10649,10691,10651,10654,10421"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Consortium"] = {
		{ids="9913,9914,9882,9900,9925,9883,9886,9893,9892,10265,10262,10205,10266,10267,10311,10417,10348,10418,10423,10268,10310,10424,10269,10430,10436,10440,10275,10270,10422,10411,10339,10437,10384,10385,10405,10406,10425,10345,10353,10438,10439,10408,10290,10276,10335,10336,10855,10856,10857,10970,10971,10972,10308,9892"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Mag'har"] = {
		{ids="9400,9401,9405,9410,9406,9438,9441,9442,9447,10479,9888,9983,9889,9890,9891,9906,9907,9868,9991,9999,10001,10004,10009,10010,10011,10107,9928,9927,9931,9932,9934,10044,10045,10081,10082,10085,10101,10102,10167,10168,10170,10171,10172,10175,10212,9944,9945,9865,9946,9866,9937,10477"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Scryers"] = {
		{ids="10338", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10204,10202,10432,10508", cond_if=[[rep ('The Scryers') >= Friendly]]},
		{ids="10210,10211,10552,10553,10412,10656,10416,11039,10189,10193,10329,10194,10652,10197,10198,10330,10200,10341,10509,10507,10687,10824,10683,10807,10688,10689,10817,10684,10685,10686,10669,10668,10641,10646,10649,10691,10692,10658,10419"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Sha'tar"] = {
		{ids="10568,10571,10574,10575,10622", cond_if=[[rep ('The Aldor') >= Friendly]]},
		{ids="10683,10684,10685,10686,10622", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10210,9983,9888,9889,9890,9891,9906,9907,9868,9991,9999,10001,10004,10009,10010,10011,10107,9928,9927,9931,9932,9934,10044,10045,10081,10082,10085,10101,10102,10167,10168,10227,10228,10231,10251,10252,10253,10877,10873,10920,10921,10926,10923,10883,10884,10885,10886,10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10704,10628,10705,10706,10707,11052,10793,10781"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Champion of the Naaru"] = {
		{ids="10680", cond_if=[[Alliance]]},
		{ids="10681", cond_if=[[Horde]]},
		{ids="10458,10480,10481,10513,10514,10515,10519,10521,10527,10546,10522,10523,10528,10537,10540,10541,10547,10550,10570,10576,10577,10578,10579,10588,10884,10885,10886,10888"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Hand of A'dal"] = {
		{ids="10568,10571,10574,10575,10622", cond_if=[[rep("The Aldor") >= Neutral]]},
		{ids="10683,10684,10685,10686,10622", cond_if=[[rep("The Scryers") >= Neutral]]},
		{ids="10445,10210,10211,10551,10552,10628,10705,10706,10707,10708,10944,10946,10947,10948,10949,10985"},
	},
	["TITLES\\Burning Crusade Titles\\Reputation\\of the Shattered Sun"] = {
		{ids="11549"},
	},
}
ZGV.Quest_Cache_Turnin_Horde = {
	["DAILIES\\The Burning Crusade\\Netherwing\\Netherwing Daily Quests"] = {
		{ids="11077", cond_if=[[haveq(11077) or completedq(11077)]]},
		{ids="11076", cond_if=[[haveq(11076) or completedq(11076)]]},
		{ids="11015,11016,11018,11017", cond_if=[[haveq(11015,11016,11018,11017) or completedq(11015,11016,11018,11017)]]},
		{ids="11086,11097,11101", cond_if=[[haveq(11086,11097,11101) or completedq(11086,11097,11101)]]},
		{ids="11020,11035", cond_if=[[haveq(11020,11035) or completedq(11020,11035)]]},
		{ids="11055", cond_if=[[haveq(11055) or completedq(11055)]]},
	},
	["DAILIES\\The Burning Crusade\\Ogri'la\\Ogri'la Daily Quests"] = {
		{ids="11051", cond_if=[[haveq(11051) or completedq(11051)]]},
		{ids="11023", cond_if=[[haveq(11023) or completedq(11023)]]},
		{ids="11066", cond_if=[[haveq(11066) or completedq(11066)]]},
		{ids="11080", cond_if=[[haveq(11080) or completedq(11080)]]},
	},
	["DAILIES\\The Burning Crusade\\Sha'tari Skyguard\\Sha'tari Skyguard Daily Quests"] = {
		{ids="11008,11085,11023,11066"},
	},
	["DAILIES\\The Burning Crusade\\Shattrath Cooking Dailies"] = {
		{ids="11381,11379,11380,11377", cond_if=[[haveq(11381,11379,11380,11377) or completedq(11381,11379,11380,11377)]]},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 1, Capturing Sanctum)"] = {
		{ids="11496", cond_if=[[haveq(11496) or completedq(11496)]]},
		{ids="11524", cond_if=[[haveq(11524) or completedq(11524)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Activating Portal)"] = {
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11532", cond_if=[[haveq(11532) or completedq(11532)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11513", cond_if=[[haveq(11513) or completedq(11513)]]},
		{ids="11538", cond_if=[[haveq(11538) or completedq(11538)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Portal Activated)"] = {
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11532", cond_if=[[haveq(11532) or completedq(11532)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11538", cond_if=[[haveq(11538) or completedq(11538)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Forge Rebuilt)"] = {
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11539", cond_if=[[haveq(11539) or completedq(11539)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11536,11544", cond_if=[[haveq(11536,11544) or completedq(11536,11544)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11542", cond_if=[[haveq(11542) or completedq(11542)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Rebuilding Forge)"] = {
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11539", cond_if=[[haveq(11539) or completedq(11539)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11535", cond_if=[[haveq(11535) or completedq(11535)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11542", cond_if=[[haveq(11542) or completedq(11542)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Alchemy Lab Built)"] = {
		{ids="11543", cond_if=[[haveq(11543) or completedq(11543)]]},
		{ids="11540", cond_if=[[haveq(11540) or completedq(11540)]]},
		{ids="11541", cond_if=[[haveq(11541) or completedq(11541)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11545", cond_if=[[haveq(11545) or completedq(11545)]]},
		{ids="11521,11546", cond_if=[[haveq(11521,11546) or completedq(11521,11546)]]},
		{ids="11536,11544", cond_if=[[haveq(11536,11544) or completedq(11536,11544)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11545", cond_if=[[readyq(11545)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Fully Built)"] = {
		{ids="11543", cond_if=[[haveq(11543) or completedq(11543)]]},
		{ids="11540", cond_if=[[haveq(11540) or completedq(11540)]]},
		{ids="11541", cond_if=[[haveq(11541) or completedq(11541)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11548", cond_if=[[readyq(11548)]]},
		{ids="11521,11546", cond_if=[[haveq(11521,11546) or completedq(11521,11546)]]},
		{ids="11548", cond_if=[[haveq(11548) or completedq(11548)]]},
		{ids="11536,11544", cond_if=[[haveq(11536,11544) or completedq(11536,11544)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Monument Built)"] = {
		{ids="11543", cond_if=[[haveq(11543) or completedq(11543)]]},
		{ids="11540", cond_if=[[haveq(11540) or completedq(11540)]]},
		{ids="11541", cond_if=[[haveq(11541) or completedq(11541)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11548", cond_if=[[readyq(11548)]]},
		{ids="11548", cond_if=[[haveq(11548) or completedq(11548)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11536,11544", cond_if=[[haveq(11536,11544) or completedq(11536,11544)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11520", cond_if=[[haveq(11520) or completedq(11520)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, No Alchemy Lab or Monument)"] = {
		{ids="11543", cond_if=[[haveq(11543) or completedq(11543)]]},
		{ids="11540", cond_if=[[haveq(11540) or completedq(11540)]]},
		{ids="11541", cond_if=[[haveq(11541) or completedq(11541)]]},
		{ids="11515,11516", cond_if=[[haveq(11515,11516) or completedq(11515,11516)]]},
		{ids="11875", cond_if=[[haveq(11875) or completedq(11875)]]},
		{ids="11533", cond_if=[[haveq(11533) or completedq(11533)]]},
		{ids="11537", cond_if=[[haveq(11537) or completedq(11537)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11545", cond_if=[[haveq(11545) or completedq(11545)]]},
		{ids="11547", cond_if=[[haveq(11547) or completedq(11547)]]},
		{ids="11536,11544", cond_if=[[haveq(11536,11544) or completedq(11536,11544)]]},
		{ids="11514", cond_if=[[haveq(11514) or completedq(11514)]]},
		{ids="11545", cond_if=[[readyq(11545)]]},
		{ids="11877", cond_if=[[haveq(11877) or completedq(11877)]]},
		{ids="11525", cond_if=[[haveq(11525) or completedq(11525)]]},
		{ids="11880", cond_if=[[haveq(11880) or completedq(11880)]]},
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11523", cond_if=[[haveq(11523) or completedq(11523)]]},
		{ids="11520", cond_if=[[haveq(11520) or completedq(11520)]]},
		{ids="11550,11526"},
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Cooking Dailies"] = {
		{ids="13116", cond_if=[[haveq(13116) or completedq(13116)]]},
		{ids="13113", cond_if=[[haveq(13113) or completedq(13113)]]},
		{ids="13115", cond_if=[[haveq(13115) or completedq(13115)]]},
		{ids="13114", cond_if=[[haveq(13114) or completedq(13114)]]},
		{ids="13112", cond_if=[[haveq(13112) or completedq(13112)]]},
		{ids="13089"},
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Fishing Dailies"] = {
		{ids="13830", cond_if=[[haveq(13830) or completedq(13830)]]},
		{ids="13832", cond_if=[[haveq(13832) or completedq(13832)]]},
		{ids="13834", cond_if=[[haveq(13834) or completedq(13834)]]},
		{ids="13836", cond_if=[[haveq(13836) or completedq(13836)]]},
		{ids="13833", cond_if=[[haveq(13833) or completedq(13833)]]},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Death's Rise Dailies"] = {
		{ids="12813", cond_if=[[haveq(12813) or completedq(12813)]]},
		{ids="12815", cond_if=[[haveq(12815) or completedq(12815)]]},
		{ids="12838", cond_if=[[haveq(12838) or completedq(12838)]]},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Orgrim's Hammer Dailies"] = {
		{ids="13261,13357", cond_if=[[haveq(13261,13357) or completedq(13261,13357)]]},
		{ids="13302", cond_if=[[haveq(13302) or completedq(13302)]]},
		{ids="13283", cond_if=[[haveq(13283) or completedq(13283)]]},
		{ids="13353,13365,13276,13281", cond_if=[[haveq(13353,13365,13276,13281) or completedq(13353,13365,13276,13281)]]},
		{ids="13301", cond_if=[[haveq(13301) or completedq(13301)]]},
		{ids="13331", cond_if=[[haveq(13331) or completedq(13331)]]},
		{ids="13310", cond_if=[[haveq(13310) or completedq(13310)]]},
		{ids="13376,13406", cond_if=[[haveq(13376,13406) or completedq(13376,13406)]]},
		{ids="13330", cond_if=[[haveq(13330) or completedq(13330)]]},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Shadowvault Dailies"] = {
		{ids="12995,13069,13071"},
	},
	["DAILIES\\Wrath of the Lich King\\Jewelcrafting Dailies"] = {
		{ids="12960", cond_if=[[haveq(12960) or completedq(12960)]]},
		{ids="12959", cond_if=[[haveq(12959) or completedq(12959)]]},
		{ids="12961", cond_if=[[haveq(12961) or completedq(12961)]]},
		{ids="12963", cond_if=[[haveq(12963) or completedq(12963)]]},
		{ids="12958", cond_if=[[haveq(12958) or completedq(12958)]]},
		{ids="12962", cond_if=[[haveq(12962) or completedq(12962)]]},
		{ids="13041"},
	},
	["DAILIES\\Wrath of the Lich King\\The Kalu'ak Dailies"] = {
		{ids="11504,11507,11508,11509,11469,11472,11945,11960"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\Frenzyheart Tribe Dailies"] = {
		{ids="12732", cond_if=[[haveq(12732) or completedq(12732) or completedq(12732)]]},
		{ids="12758", cond_if=[[haveq(12758) or completedq(12758) or completedq(12758)]]},
		{ids="12734", cond_if=[[haveq(12734) or completedq(12734) or completedq(12734)]]},
		{ids="12703", cond_if=[[haveq(12703) or completedq(12703) or completedq(12703)]]},
		{ids="12741", cond_if=[[haveq(12741) or completedq(12741) or completedq(12741)]]},
		{ids="12760", cond_if=[[haveq(12760) or completedq(12760)]]},
		{ids="12759", cond_if=[[haveq(12759) or completedq(12759) or completedq(12759)]]},
		{ids="12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12654,12573,12574,12575,12576,12577,12578,12580,12579,12581,12692,12702"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\The Oracles Dailies"] = {
		{ids="12705", cond_if=[[haveq(12705) or completedq(12705)]]},
		{ids="12762", cond_if=[[haveq(12762) or completedq(12762)]]},
		{ids="12737", cond_if=[[haveq(12737) or completedq(12737)]]},
		{ids="12736", cond_if=[[haveq(12736) or completedq(12736)]]},
		{ids="12735", cond_if=[[haveq(12735) or completedq(12735)]]},
		{ids="12761", cond_if=[[haveq(12761) or completedq(12761)]]},
		{ids="12726", cond_if=[[haveq(12726) or completedq(12726)]]},
		{ids="12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12654,12573,12574,12575,12576,12577,12578,12580,12579,12581,12695,12704"},
	},
	["DAILIES\\Wrath of the Lich King\\The Sons of Hodir\\The Sons of Hodir Dailies"] = {
		{ids="13001", cond_if=[[not completedq(13001)]]},
		{ids="13046", cond_if=[[haveq(13046) or completedq(13046)]]},
		{ids="13003", cond_if=[[haveq(13003) or completedq(13003)]]},
		{ids="13420", cond_if=[[not completedq(13420)]]},
		{ids="13006,13006", cond_if=[[haveq(13006) or completedq(13006)]]},
		{ids="12981,12981", cond_if=[[haveq(12981) or completedq(12981)]]},
		{ids="12977,12977", cond_if=[[haveq(12977) or completedq(12977)]]},
		{ids="12994", cond_if=[[haveq(12994) or completedq(12994)]]},
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,13062,12886,13064,12922,12956,12915,12966,12967,12924,13009,13050,13051,12975,12976,12985,12987,13011,13010,13057,13005,13035,13047"},
	},
	["DAILIES\\Wrath of the Lich King\\Wyrmrest Accord Dailies"] = {
		{ids="12372", cond_if=[[not completedq(13413)]]},
		{ids="12372", cond_if=[[completedq(13413)]]},
		{ids="11999,12059,12005,12061,12066,12084,12085,12106,12110,12122,12767,12461,12448,12449,12450,12769,12419,12124,12435,11918,11936,11919,13412,13413,11940,13414"},
	},
	["DUNGEONS\\Classic\\Blackfathom Deeps Quests"] = {
		{ids="6564,6563,6565,6921,6922,6561"},
	},
	["DUNGEONS\\Classic\\Blackrock Depths Quests"] = {
		{ids="4133,3441,3442,3443,3452,3453,3454,3462,3463,3481,4324,4022,4061,4062,3801,3802,4123,4136,4024,3906,4134,4081,4063,4201,3907,4082,3981,3982,4001,4002,4003,4004"},
	},
	["DUNGEONS\\Classic\\Dire Maul East Quests"] = {
		{ids="5527,7489,7441,5526"},
	},
	["DUNGEONS\\Classic\\Dire Maul North Quests"] = {
		{ids="5518,7429,7703,7481"},
	},
	["DUNGEONS\\Classic\\Dire Maul North Tribute (58-60)"] = {
		{ids="1193"},
	},
	["DUNGEONS\\Classic\\Dire Maul West Quests"] = {
		{ids="7461,7462"},
	},
	["DUNGEONS\\Classic\\Gnomeregan Quests"] = {
		{ids="2842,2843,2841"},
	},
	["DUNGEONS\\Classic\\Lower Blackrock Spire Quests"] = {
		{ids="3520,3527,4787,3528,5065,4981,4982,4867,4742,4866,4729,4862,4903,4983,4724,4788"},
	},
	["DUNGEONS\\Classic\\Maraudon Quests"] = {
		{ids="7044,7046,7068,7029,7064,7067,7028,7066"},
	},
	["DUNGEONS\\Classic\\Ragefire Chasm Quests"] = {
		{ids="5726,5727,5722,5761,5728,5725,5724,5723"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Blackwing Lair Attunement"] = {
		{ids="7761"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Molten Core Attunement"] = {
		{ids="7848"},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Naxxramas Attunement"] = {
		{ids="9123", cond_if=[[haveq(9123) or completedq(9123)]]},
		{ids="9122", cond_if=[[haveq(9122) or completedq(9122)]]},
		{ids="9121", cond_if=[[haveq(9121) or completedq(9121)]]},
	},
	["DUNGEONS\\Classic\\Raid Attunements\\Onyxia's Lair Attunement"] = {
		{ids="4903,4941,4974,6566,6567,6567,6568,6569,6570,6582,6583,6584,6585,6601,6601,6602,6602"},
	},
	["DUNGEONS\\Classic\\Razorfen Downs Quests"] = {
		{ids="6522,6626,3523,3525,3341,6521"},
	},
	["DUNGEONS\\Classic\\Razorfen Kraul Quests"] = {
		{ids="1144,1221,1102,1109,6522"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Armory Quests"] = {
		{ids="1048"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Cathedral Quests"] = {
		{ids="1048"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Graveyard Quests"] = {
		{ids="1109,1051,1113"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Library Quests"] = {
		{ids="1049", cond=[[Orc]]},
		{ids="1149,1150,1151,1152,1154,6627,1159,1160,1048"},
	},
	["DUNGEONS\\Classic\\Scholomance Quests"] = {
		{ids="4726,4808,4809,4810,4907,4734,4735,5522,5531,5094,5096,5098,838,964,5514,5801,5803,5382,5341,5529,4771,5515,5582,5384,5461,5462,5463,5464,5465,5466"},
	},
	["DUNGEONS\\Classic\\Shadowfang Keep Quests"] = {
		{ids="1098,1014,1013"},
	},
	["DUNGEONS\\Classic\\Stratholme - Live Side Quests"] = {
		{ids="5281,5542,5543,5544,5742,5781,5845,5846,5282,5848,5214,5251,5262"},
	},
	["DUNGEONS\\Classic\\Stratholme - Undead Side Quests"] = {
		{ids="5382,5515,5384,5461,5462,5251,5262,6022,6133,6042,6135,6136,5463,5263,5212,5464,5243,6163,5213"},
	},
	["DUNGEONS\\Classic\\Temple of Atal'Hakkar Quests"] = {
		{ids="3380,3444,3520,3527,1424,1429,4787,1444,4145,4147,3446,3447,3373,1445,1446,3528,4146"},
	},
	["DUNGEONS\\Classic\\Uldaman Quests"] = {
		{ids="2278,2280", cond_if=[[level >=40]]},
		{ids="2258,2283,2284,2318,2338,2202,2339,2418,709,2342,2340,2341"},
	},
	["DUNGEONS\\Classic\\Upper Blackrock Spire Quests"] = {
		{ids="4769,4726,4808,4809,4810,4907,6804,6805,4903,4768,4903,4941,4734,5047,5160,5161,5162,5164,6821,4735,4974,6566,6567,6567,6568,6569,6570,6582,6583,6584,6585,6601,6602,6602"},
	},
	["DUNGEONS\\Classic\\Wailing Caverns Quests"] = {
		{ids="6981", cond_if=[[haveq(6981) or completedq(6981)]]},
		{ids="3366", cond_if=[[haveq(3366) or completedq(3366)]]},
		{ids="886,870,877,880,1489,1490,865,1486,1487,1491,959,914,3369,962"},
	},
	["DUNGEONS\\Classic\\Zul'Farrak Quests"] = {
		{ids="2933,2934,2935,3520,3527,2768,2865,3042,2770,2846,2936"},
	},
	["DUNGEONS\\The Burning Crusade\\Auchenai Crypts Quests"] = {
		{ids="9983", cond_if=[[haveq(9983) or completedq(9983)]]},
		{ids="9400,9401,9405,9410,9406,9438,9441,10227,10228,10231,10251,10252,10253,9888,9889,9890,9891,9906,9991,9999,10001,10004,10009,10010,10011,9907,9872,9868,10107,9928,9927,9931,9932,9934,10044,10045,10081,10082,10085,10101,10102,10167,10168,10164"},
	},
	["DUNGEONS\\The Burning Crusade\\Black Temple Attunement"] = {
		{ids="10568,10571,10574", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10575,10622,10628,10705,10706,10707,10708,10944,10946,10947,10948,10949,10985"},
		{ids="10683,10684,10685", cond_if=[[rep ('The Scryers') >= Neutral]]},
	},
	["DUNGEONS\\The Burning Crusade\\Blood Furnace Quests"] = {
		{ids="9590,9608"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Citadel Attunement"] = {
		{ids="10755,10756,10757,10758"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Ramparts Quests"] = {
		{ids="9407,10120,10289,10291,10121,10123,10124,9588,9572"},
	},
	["DUNGEONS\\The Burning Crusade\\Karazhan Attunement"] = {
		{ids="11216,9824,9825,9826,9829,9831,9832,9836,9837,9838"},
	},
	["DUNGEONS\\The Burning Crusade\\Mana-Tombs Quests"] = {
		{ids="10216,10165,10218,10969,10970,10425,10971,10973,10974,10976,10977"},
	},
	["DUNGEONS\\The Burning Crusade\\Mount Hyjal Attunement"] = {
		{ids="10445"},
	},
	["DUNGEONS\\The Burning Crusade\\Old Hillsbrad Foothills Quests"] = {
		{ids="10279,10277,10282,10283,10284,10285,12513"},
	},
	["DUNGEONS\\The Burning Crusade\\Serpentshrine Cavern Attunement"] = {
		{ids="9644", cond_if=[[haveq(9644) or completedq(9644)]]},
		{ids="9630,9638,9639,9640,9645,9680,9631,9637,10901"},
	},
	["DUNGEONS\\The Burning Crusade\\Sethekk Halls Quests"] = {
		{ids="10180,10097,10098"},
	},
	["DUNGEONS\\The Burning Crusade\\Shadow Labyrinth Quests"] = {
		{ids="10641,10668,10669,10646,10623,10627,10663,10664,11216,9824,9825,9826,9829,10177,10178,10094,10885,10666,10091,10095,9831,10649"},
		{ids="10587,10637,10640", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10687,10688", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10689", cond_if=[[rep ('The Scryers') >= Neutral]]},
	},
	["DUNGEONS\\The Burning Crusade\\Shattered Halls Quests"] = {
		{ids="9495"},
	},
	["DUNGEONS\\The Burning Crusade\\Tempest Keep Attunement"] = {
		{ids="10883,10884,10885,10886,10888"},
	},
	["DUNGEONS\\The Burning Crusade\\The Arcatraz Quests"] = {
		{ids="10568,10571,10574", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10683,10684,10685", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10575,10622,10628,10705,10704,10706,11216,9824,9825,9826,9829,9831,9832"},
	},
	["DUNGEONS\\The Burning Crusade\\The Black Morass Quests"] = {
		{ids="10902", cond_if=[[skill("Alchemy") < 0]]},
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["DUNGEONS\\The Burning Crusade\\The Botanica Quests"] = {
		{ids="10897", cond_if=[[skill("Alchemy") < 0]]},
		{ids="10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10257,10704"},
	},
	["DUNGEONS\\The Burning Crusade\\The Cipher of Damnation"] = {
		{ids="10681,10458,10480,10481,10513,10514,10515,10519,10521,10522,10523,10527,10528,10537,10540,10546,10541,10547,10550,10570,10576,10577,10578,10579,10588"},
	},
	["DUNGEONS\\The Burning Crusade\\The Mechanar Quests"] = {
		{ids="10623,10627,10663,10664,10665"},
	},
	["DUNGEONS\\The Burning Crusade\\The Slave Pens Quests"] = {
		{ids="9738"},
	},
	["DUNGEONS\\The Burning Crusade\\The Steamvault Quests"] = {
		{ids="10623,10627,10663,10664,10666,9763,9764,10885,10667,11216,9824,9825,9826,9829,9831,9832"},
	},
	["DUNGEONS\\The Burning Crusade\\The Underbog Quests"] = {
		{ids="9715,9717,9719,9738"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Ahn'kahet: The Old Kingdom Quests"] = {
		{ids="13187,13204"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Azjol-Nerub Quests"] = {
		{ids="13167,13182"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Drak'Tharon Keep Quests"] = {
		{ids="12208,11984,11989,11990,11991,12007,12042,12802,12068,12484,12029,12238,12037,13129"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Gundrak Quests"] = {
		{ids="12507,12510,12514,12516,12623,12627,12628,12632,12642,12646,12647,12653,12665,12666,12667,12672,12668,12674,12675,12684,12685,12712,12721,12729,12730,13099,13097,13096,13111,13098"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Lightning Quests"] = {
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12996,12997,13061,13062,12886,13064,12922,12915,12956,12966,12967,12967,12924,13009,13050,13051,12975,12976,13010,13057,13005,13035,13047,13108,13109"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Stone Quests"] = {
		{ids="13207"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Culling of Stratholme Quests"] = {
		{ids="13149,13151"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Nexus Quests"] = {
		{ids="11733,11941,11900,11910,11943,11946,11951,11957,11967,11969,13095,11973,11905,11911"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Oculus Quests"] = {
		{ids="13124,13126,13127,13128"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Violet Hold Quests"] = {
		{ids="13158,13159"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Keep Quests"] = {
		{ids="11272,13206,11262"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Pinnacle Quests"] = {
		{ids="13131,13132"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Month"] = {
		{ids="12306"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Year"] = {
		{ids="12306"},
	},
	["EVENTS\\Brewfest\\Achievements\\Direbrewfest"] = {
		{ids="12062"},
	},
	["EVENTS\\Brewfest\\Achievements\\Down With The Dark Iron"] = {
		{ids="12192"},
	},
	["EVENTS\\Brewfest\\Brewfest Dailies"] = {
		{ids="11408", cond_if=[[haveq(11408)]]},
		{ids="11407", cond_if=[[haveq(11407)]]},
		{ids="12020,12318,12062"},
	},
	["EVENTS\\Brewfest\\Brewfest Quests"] = {
		{ids="12194", cond_if=[[haveq(12194) or completedq(12194)]]},
		{ids="11409,11412,12191,11431,11120,12318,12062"},
	},
	["EVENTS\\Children's Week\\Children's Week Main Questline"] = {
		{ids="172,1800,910,911,915,925,5502"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Sayge's Fortunes (Elwynn Forest)"] = {
		{ids="7937,7938,7944,7945"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Sayge's Fortunes (Mulgore)"] = {
		{ids="7937,7938,7944,7945"},
	},
	["EVENTS\\Feast of Winter Veil\\Feast of Winter Veil Quest"] = {
		{ids="6964,7061,6961,6962,6963,6983,6984,8746"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Hallowed Be Thy Name"] = {
		{ids="11219,12139,12155", cond_if=[[haveq(11219,12139,12155) or completedq(11219,12139,12155)]]},
		{ids="12155", cond_if=[[haveq(12155) or completedq(12155)]]},
		{ids="11357,11361,8322,1657,8409"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Rotten Hallow"] = {
		{ids="8322,1657,8409"},
	},
	["EVENTS\\Hallow's End\\Achievements\\The Savior of Hallow's End"] = {
		{ids="11219,12139,12155", cond_if=[[haveq(11219,12139,12155) or completedq(11219,12139,12155)]]},
		{ids="12155", cond_if=[[haveq(12155) or completedq(12155)]]},
		{ids="11357,11361"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Tricks and Treats of Azeroth"] = {
	},
	["EVENTS\\Hallow's End\\Hallow's End Daily Quests"] = {
		{ids="12139", cond_if=[[haveq(12139) or completedq(12139)]]},
		{ids="12155", cond_if=[[haveq(12155) or completedq(12155)]]},
		{ids="11219", cond_if=[[haveq(11219) or completedq(11219)]]},
		{ids="11357,11405"},
	},
	["EVENTS\\Hallow's End\\Hallow's End Quests"] = {
		{ids="12155", cond_if=[[haveq(12155) or completedq(12155)]]},
		{ids="8359,11357,11361,8358,8360,8354,8322,1657,8409,8312,11220"},
	},
	["EVENTS\\Harvest Festival\\Harvest Festival Quest"] = {
		{ids="8150"},
	},
	["EVENTS\\Love is in the Air\\Love is in the Air Quests"] = {
		{ids="8904,8979,8980,8982,8983,8984"},
	},
	["EVENTS\\Lunar Festival\\Lunar Festival Main Questline"] = {
		{ids="8873,8867,8883"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Dailies"] = {
		{ids="11947", cond_if=[[haveq(11947) or completedq(11947)]]},
		{ids="11953", cond_if=[[haveq(11953) or completedq(11953)]]},
		{ids="11917", cond_if=[[haveq(11917) or completedq(11917)]]},
		{ids="11948", cond_if=[[haveq(11948) or completedq(11948)]]},
		{ids="11954", cond_if=[[haveq(11954) or completedq(11954)]]},
		{ids="11952", cond_if=[[haveq(11952) or completedq(11952)]]},
		{ids="11926,11925"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Quests"] = {
		{ids="11915,11922,11923,11886,11891,12012,11966,11955,11696,11691,11972"},
	},
	["EVENTS\\Midsummer Fire Festival\\The Fires of Azeroth\\Midsummer Fire Festival Bonfires"] = {
		{ids="9332,11933,9330,9331", cond_if=[[haveq(9332,11933,9330,9331) or completedq(9332,11933,9330,9331)]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Cloak Quest"] = {
		{ids="8557", cond=[[Warrior]]},
		{ids="8695", cond=[[Paladin]]},
		{ids="8690", cond=[[Shaman]]},
		{ids="8693", cond=[[Rogue]]},
		{ids="8691", cond=[[Mage]]},
		{ids="8692", cond=[[Druid]]},
		{ids="8689", cond=[[Priest]]},
		{ids="8696", cond=[[Hunter]]},
		{ids="8694", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Ring Quest"] = {
		{ids="8556", cond=[[Warrior]]},
		{ids="8703", cond=[[Paladin]]},
		{ids="8698", cond=[[Shaman]]},
		{ids="8701", cond=[[Rogue]]},
		{ids="8699", cond=[[Mage]]},
		{ids="8700", cond=[[Druid]]},
		{ids="8697", cond=[[Priest]]},
		{ids="8704", cond=[[Hunter]]},
		{ids="8702", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Weapon Quest"] = {
		{ids="8558", cond=[[Warrior]]},
		{ids="8711", cond=[[Paladin]]},
		{ids="8706", cond=[[Shaman]]},
		{ids="8709", cond=[[Rogue]]},
		{ids="8707", cond=[[Mage]]},
		{ids="8708", cond=[[Druid]]},
		{ids="8705", cond=[[Priest]]},
		{ids="8712", cond=[[Hunter]]},
		{ids="8710", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Boots Quest"] = {
		{ids="8559", cond=[[Warrior]]},
		{ids="8655", cond=[[Paladin]]},
		{ids="8621", cond=[[Shaman]]},
		{ids="8637", cond=[[Rogue]]},
		{ids="8634", cond=[[Mage]]},
		{ids="8665", cond=[[Druid]]},
		{ids="8596", cond=[[Priest]]},
		{ids="8626", cond=[[Hunter]]},
		{ids="8660", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Helm Quest"] = {
		{ids="8561", cond=[[Warrior]]},
		{ids="8628", cond=[[Paladin]]},
		{ids="8623", cond=[[Shaman]]},
		{ids="8639", cond=[[Rogue]]},
		{ids="8632", cond=[[Mage]]},
		{ids="8667", cond=[[Druid]]},
		{ids="8592", cond=[[Priest]]},
		{ids="8657", cond=[[Hunter]]},
		{ids="8662", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Legs Quest"] = {
		{ids="8560", cond=[[Warrior]]},
		{ids="8629", cond=[[Paladin]]},
		{ids="8624", cond=[[Shaman]]},
		{ids="8640", cond=[[Rogue]]},
		{ids="8631", cond=[[Mage]]},
		{ids="8668", cond=[[Druid]]},
		{ids="8593", cond=[[Priest]]},
		{ids="8658", cond=[[Hunter]]},
		{ids="8663", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Shoulder Quest"] = {
		{ids="8544", cond=[[Warrior]]},
		{ids="8630", cond=[[Paladin]]},
		{ids="8602", cond=[[Shaman]]},
		{ids="8641", cond=[[Rogue]]},
		{ids="8625", cond=[[Mage]]},
		{ids="8669", cond=[[Druid]]},
		{ids="8594", cond=[[Priest]]},
		{ids="8659", cond=[[Hunter]]},
		{ids="8664", cond=[[Warlock]]},
	},
	["LEVELING\\Boosted Characters\\Boosted Druid Intro"] = {
		{ids="64047,64049,64051,64053,64217"},
	},
	["LEVELING\\Boosted Characters\\Boosted Hunter Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Mage Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Priest Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Rogue Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Shaman Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warlock Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warrior Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Cenarion Battlegear"] = {
		{ids="8800,8548,8572,8573,8574"},
	},
	["LEVELING\\Cenarion Field Duty Combat Assignments"] = {
		{ids="8687", cond_if=[[haveq(8687)]]},
		{ids="8771", cond_if=[[haveq(8771)]]},
		{ids="8770", cond_if=[[haveq(8770)]]},
		{ids="8501", cond_if=[[haveq(8501)]]},
		{ids="8773", cond_if=[[haveq(8773)]]},
		{ids="8539", cond_if=[[haveq(8539)]]},
		{ids="8775", cond_if=[[haveq(8775)]]},
		{ids="8777", cond_if=[[haveq(8777)]]},
		{ids="8776", cond_if=[[haveq(8776)]]},
		{ids="8774", cond_if=[[haveq(8774)]]},
		{ids="8772", cond_if=[[haveq(8772)]]},
		{ids="8502", cond_if=[[haveq(8502)]]},
		{ids="8507"},
	},
	["LEVELING\\Cenarion Field Duty Logistics Assignments"] = {
		{ids="8810", cond_if=[[haveq(8810)]]},
		{ids="8829", cond_if=[[haveq(8829)]]},
		{ids="8786,8787", cond_if=[[haveq(8786,8787)]]},
		{ids="8804", cond_if=[[haveq(8804)]]},
		{ids="8808", cond_if=[[haveq(8808)]]},
		{ids="8806,8805", cond_if=[[haveq(8806,8805)]]},
		{ids="8809", cond_if=[[haveq(8809)]]},
		{ids="8807", cond_if=[[haveq(8807)]]},
		{ids="8785", cond_if=[[haveq(8785)]]},
		{ids="8507"},
	},
	["LEVELING\\Cenarion Field Duty Tactical Assignments"] = {
		{ids="8739", cond_if=[[haveq(8739)]]},
		{ids="8537,8535", cond_if=[[haveq(8537,8535)]]},
		{ids="8737,8536", cond_if=[[haveq(8737,8536)]]},
		{ids="8538,8498", cond_if=[[haveq(8538,8498)]]},
		{ids="8534,8738,8740", cond_if=[[haveq(8534,8738,8740)]]},
		{ids="8507"},
	},
	["LEVELING\\Class Quests\\Druid Class Quests"] = {
		{ids="5926,5922,5930,5932,6002", cond_if=[[Tauren Druid]]},
		{ids="6126,6127,6128,6129,6130,27,28,30,31,9063,9052,9051,9053", cond_if=[[Druid]]},
	},
	["LEVELING\\Class Quests\\Hunter Class Quests"] = {
		{ids="6061,6087,6089", cond_if=[[Tauren Hunter]]},
		{ids="6062,6083,6082,6081", cond_if=[[(Orc Hunter) or (Troll Hunter)]]},
		{ids="8151,8153,8231,8232,7632,7636", cond_if=[[Hunter]]},
	},
	["LEVELING\\Class Quests\\Mage Class Quests"] = {
		{ids="1883,1884,1959,1960,1961,1943,1944,1945,1947,1949,1950,1951,1952,1953,1954,1955,1956,1957,2861,2846,7463", cond_if=[[Mage]]},
	},
	["LEVELING\\Class Quests\\Paladin Class Quests"] = {
		{ids="9601,5405,10590,10592,10593,9721,9722,9723,9725,9735,9736,9737"},
		{ids="9678,9681,64319,9684,63866,9685,9690,9686,9691,9692,9707,9710", cond_if=[[BloodElf Paladin]]},
	},
	["LEVELING\\Class Quests\\Priest Class Quests"] = {
		{ids="5652,5643", cond_if=[[Troll Priest]]},
		{ids="5658,5644", cond_if=[[Scourge Priest]]},
	},
	["LEVELING\\Class Quests\\Rogue Class Quests"] = {
		{ids="2460,2458,2478,2479,2480,8233,8234,8235,8236", cond_if=[[Rogue]]},
	},
	["LEVELING\\Class Quests\\Shaman Class Quests"] = {
		{ids="1516,1517,1518", cond_if=[[(Orc Shaman) or (Troll Shaman)]]},
		{ids="1519,1520,1521", cond_if=[[Tauren Shaman]]},
		{ids="2983,1524,1525,1526,1527,1528,1530,1535,1536,1534,220,63,100,96,1531,8410,8412,8413", cond_if=[[Shaman]]},
	},
	["LEVELING\\Class Quests\\Warlock Class Quests"] = {
		{ids="1485,1499,1506,1501,1504", cond_if=[[Orc Warlock]]},
		{ids="1470,1478,1473,1471", cond_if=[[Scourge Warlock]]},
		{ids="1507,1508,1509,1510,1511,1515,1512,1513,2996,1758,1803,1805,1471,3631,4490,7601,8420,8421,7602,8422,7603,7562,7563,7564,7626,7627,7628,7630,7623,7624,7625,7629,7631", cond_if=[[Warlock]]},
	},
	["LEVELING\\Class Quests\\Warrior Class Quests"] = {
		{ids="1718,1719,1791,1712,1713,8417,8423,8424,8425", cond_if=[[Warrior]]},
		{ids="1818,1819,1820,1821", cond_if=[[Scourge Warrior]]},
		{ids="1505,1498,1502,1503", cond_if=[[(Orc Warrior) or (Troll Warrior) or (Tauren Warrior)]]},
	},
	["LEVELING\\Classic (12-58)\\Alterac Mountains (37-38)"] = {
		{ids="553,544,556,1164"},
	},
	["LEVELING\\Classic (12-58)\\Arathi Highlands (30-30)"] = {
		{ids="1531", cond_if=[[Shaman]]},
		{ids="1718,1719", cond_if=[[Warrior]]},
		{ids="655,672,674,675"},
	},
	["LEVELING\\Classic (12-58)\\Arathi Highlands (36-37)"] = {
		{ids="638,642,651,676,671,701,702,847"},
	},
	["LEVELING\\Classic (12-58)\\Ashenvale (21-21)"] = {
		{ids="6382,6562,6442"},
		{ids="1528,1530,1535,1536", cond_if=[[Shaman]]},
	},
	["LEVELING\\Classic (12-58)\\Ashenvale (25-26)"] = {
		{ids="2460,2458,2478,2479,2480", cond_if=[[Rogue]]},
		{ids="6641,25,1918,23,6544,6503,24,6441,824,6482,216,6462"},
	},
	["LEVELING\\Classic (12-58)\\Azshara (46-47)"] = {
		{ids="5535,5536,232,238"},
	},
	["LEVELING\\Classic (12-58)\\Azshara (50-50)"] = {
		{ids="3517,3561,3565,3518,32,3541,3542,3568,3569"},
	},
	["LEVELING\\Classic (12-58)\\Azshara (54-55)"] = {
		{ids="3601,5534,4300"},
	},
	["LEVELING\\Classic (12-58)\\Badlands (41-42)"] = {
		{ids="705,1106,1108,713,714,715,1418,710,711,712,734,716,777,778,2258,1419,703,1420"},
	},
	["LEVELING\\Classic (12-58)\\Blasted Lands (51-52)"] = {
		{ids="3501", cond_if=[[haveq(3501) or completedq(3501)]]},
		{ids="1444,2601,2603,2581,2583,2585"},
	},
	["LEVELING\\Classic (12-58)\\Burning Steppes (54-54)"] = {
		{ids="4324,4022,3821,4726,4296,4061,3822,4062"},
	},
	["LEVELING\\Classic (12-58)\\Desolace (32-34)"] = {
		{ids="1145,1431,2,9534,9535,5561,1362,5361,1432,1433,1365,1368,5386,1435,1480,1434,1481,5741,6161,6027,1482,1484,1366,5501,5381,1370,6143,6142"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (34-35)"] = {
		{ids="1268,1269,1251,1321,1178,1111"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (38-39)"] = {
		{ids="11225,1218,11180,11181,11183,1201,1238,1322,1323,1206,1203,9437,1202,1239,1177,11213,11172,11174,11207,11156,11173,11208,11215,11186,1205,1270"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (43-44)"] = {
		{ids="1273,11184,11158,11217,11160,11161,11159,11162,1261,1166,1169,1168,1170,1171"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (48-49)"] = {
		{ids="625,1172,1173"},
	},
	["LEVELING\\Classic (12-58)\\Eastern Plaguelands (57-58)"] = {
		{ids="5601,5149,6030,5241,6026,9141,5281,6164,5542,5543,5544,5742,6022,6042,5781,6021,5211,9136,9126,9124,9131,5845,5846,5023,5049"},
	},
	["LEVELING\\Classic (12-58)\\Felwood (55-55)"] = {
		{ids="8460,8462,8461"},
	},
	["LEVELING\\Classic (12-58)\\Felwood (56-56)"] = {
		{ids="4521,5155,5156,4102,4505,5157,5158,4120"},
	},
	["LEVELING\\Classic (12-58)\\Feralas (45-46)"] = {
		{ids="2862,2987,2973,2975,2978,2863,2902,2903,2974,2822,7730,7731,2980,2979,7732,649,2976,3121,1262,3002"},
	},
	["LEVELING\\Classic (12-58)\\Feralas (49-49)"] = {
		{ids="7738", cond_if=[[haveq(7738) or completedq(7738)]]},
		{ids="3122,7003,7721,7734,3062,3063"},
	},
	["LEVELING\\Classic (12-58)\\Hillsbrad Foothills (29-30)"] = {
		{ids="494,501,509,552,502,527,567"},
		{ids="493", cond_if=[[haveq(493) or completedq(493)]]},
	},
	["LEVELING\\Classic (12-58)\\Searing Gorge (47-48)"] = {
		{ids="4449,3441,3442,3443,7701,7723,7724,7727,7728,7729,7722,3452,3453,3454,3462,4451,3463,3481"},
	},
	["LEVELING\\Classic (12-58)\\Silithus (58-59)"] = {
		{ids="1004,1123,1124,8276,1125,1126,8280,8277,8318,9416,8308,8281,8278,8284,8304,8285,8279,8323,8282,8287,8283,4642,9128,5210,5181,6844,6845"},
	},
	["LEVELING\\Classic (12-58)\\Stonetalon Mountains (15-16)"] = {
		{ids="6548,6629,6523"},
	},
	["LEVELING\\Classic (12-58)\\Stonetalon Mountains (20-21)"] = {
		{ids="6401", cond_if=[[haveq(6401) or completedq(6401)]]},
		{ids="1060,1483,1093,6284,6461,1062"},
	},
	["LEVELING\\Classic (12-58)\\Stonetalon Mountains (23-24)"] = {
		{ids="6421,6301,1087,1095,1096,1058,1068"},
	},
	["LEVELING\\Classic (12-58)\\Stonetalon Mountains (26-27)"] = {
		{ids="6393,6282,6381,6283,1195"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (30-31)"] = {
		{ids="340", cond_if=[[((itemcount(2734) >= 1) and (itemcount(2735) >= 1) and (itemcount(2738) >= 1) and (itemcount(2740) >= 1) and (not completedq(340)))]]},
		{ids="341", cond_if=[[((itemcount(2742) >= 1) and (itemcount(2744) >= 1) and (itemcount(2745) >= 1) and (itemcount(2748) >= 1) and (not completedq(341)))]]},
		{ids="339", cond_if=[[((itemcount(2725) >= 1) and (itemcount(2728) >= 1) and (itemcount(2730) >= 1) and (itemcount(2732) >= 1) and (not completedq(339)))]]},
		{ids="338", cond_if=[[((itemcount(2756) >= 1) and (itemcount(2757) >= 1) and (itemcount(2758) >= 1) and (itemcount(2759) >= 1) and (not completedq(338)))]]},
		{ids="342", cond_if=[[((itemcount(2749) >= 1) and (itemcount(2750) >= 1) and (itemcount(2751) >= 1) and (not completedq(342)))]]},
		{ids="583,185,186,190,191,194"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (35-36)"] = {
		{ids="340,340,340", cond_if=[[((itemcount(2734) >= 1) and (itemcount(2735) >= 1) and (itemcount(2738) >= 1) and (itemcount(2740) >= 1) and (not completedq(340)))]]},
		{ids="341,341,341", cond_if=[[((itemcount(2742) >= 1) and (itemcount(2744) >= 1) and (itemcount(2745) >= 1) and (itemcount(2748) >= 1) and (not completedq(341)))]]},
		{ids="339,339,339", cond_if=[[((itemcount(2725) >= 1) and (itemcount(2728) >= 1) and (itemcount(2730) >= 1) and (itemcount(2732) >= 1) and (not completedq(339)))]]},
		{ids="338,338,338", cond_if=[[((itemcount(2756) >= 1) and (itemcount(2757) >= 1) and (itemcount(2758) >= 1) and (itemcount(2759) >= 1) and (not completedq(338)))]]},
		{ids="342,342,342", cond_if=[[((itemcount(2749) >= 1) and (itemcount(2750) >= 1) and (itemcount(2751) >= 1) and (not completedq(342)))]]},
		{ids="1180,1181,568,9436,581,596,187,195,5762,5763,188,192,605,189,213,201,1182,569,570,9457,582,629"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (39-39)"] = {
		{ids="340", cond_if=[[((itemcount(2734) >= 1) and (itemcount(2735) >= 1) and (itemcount(2738) >= 1) and (itemcount(2740) >= 1) and (not completedq(340)))]]},
		{ids="341", cond_if=[[((itemcount(2742) >= 1) and (itemcount(2744) >= 1) and (itemcount(2745) >= 1) and (itemcount(2748) >= 1) and (not completedq(341)))]]},
		{ids="339", cond_if=[[((itemcount(2725) >= 1) and (itemcount(2728) >= 1) and (itemcount(2730) >= 1) and (itemcount(2732) >= 1) and (not completedq(339)))]]},
		{ids="338", cond_if=[[((itemcount(2756) >= 1) and (itemcount(2757) >= 1) and (itemcount(2758) >= 1) and (itemcount(2759) >= 1) and (not completedq(338)))]]},
		{ids="342", cond_if=[[((itemcount(2749) >= 1) and (itemcount(2750) >= 1) and (itemcount(2751) >= 1) and (not completedq(342)))]]},
		{ids="1115,1240,572,196,193,595,606,597,607,599,571"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (42-43)"] = {
		{ids="340", cond_if=[[((itemcount(2734) >= 1) and (itemcount(2735) >= 1) and (itemcount(2738) >= 1) and (itemcount(2740) >= 1) and (not completedq(340)))]]},
		{ids="341", cond_if=[[((itemcount(2742) >= 1) and (itemcount(2744) >= 1) and (itemcount(2745) >= 1) and (itemcount(2748) >= 1) and (not completedq(341)))]]},
		{ids="339", cond_if=[[((itemcount(2725) >= 1) and (itemcount(2728) >= 1) and (itemcount(2730) >= 1) and (itemcount(2732) >= 1) and (not completedq(339)))]]},
		{ids="338", cond_if=[[((itemcount(2756) >= 1) and (itemcount(2757) >= 1) and (itemcount(2758) >= 1) and (itemcount(2759) >= 1) and (not completedq(338)))]]},
		{ids="342", cond_if=[[((itemcount(2749) >= 1) and (itemcount(2750) >= 1) and (itemcount(2751) >= 1) and (not completedq(342)))]]},
		{ids="1116,573,197,600,621,587,604,617,609,576"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (47-47)"] = {
		{ids="1118,2874,594,630,608"},
	},
	["LEVELING\\Classic (12-58)\\Swamp of Sorrows (39-40)"] = {
		{ids="1372,1392,698,1389,9440,1424,1184"},
	},
	["LEVELING\\Classic (12-58)\\Swamp of Sorrows (48-48)"] = {
		{ids="2784,624,2621,2622,2623,2801"},
	},
	["LEVELING\\Classic (12-58)\\Tanaris (44-45)"] = {
		{ids="2864,1117,1137,1187,1190,1194,1188,2872,1707,2781,1690,992,8365,2875,8366,2873,1691"},
	},
	["LEVELING\\Classic (12-58)\\Tanaris (49-50)"] = {
		{ids="243,4450,3380,1560,3520,2605,379,2606,82,3362,5863,3161,10,110,113"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (12-15)"] = {
		{ids="6126,6127,6128,6129,6130", cond_if=[[Druid]]},
		{ids="809,6365,6384,6385,6386", cond_if=[[Orc or Troll]]},
		{ids="840,842,844,871,845,1492,819,887,895,890,892,5041,872,855,850"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (16-20)"] = {
		{ids="26,28,30,31", cond_if=[[Druid]]},
		{ids="1507,1508,1509,1510,1511,1515,1512,1513", cond_if=[[Warlock]]},
		{ids="5644", cond_if=[[Scourge Priest]]},
		{ids="5680", cond_if=[[Troll Priest]]},
		{ids="848,867,903,870,869,853,4921,894,900,901,858,875,881,888,902,863,896,865,877,880,851,3921,6541,876,3281,905,3261,883,821,891,882,907,878,5052,913,899,1130,1489,1490"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (21-23)"] = {
		{ids="1534,220,63,100,96", cond_if=[[Shaman]]},
		{ids="1094,1069,843,893,884,885,879,906,868,822"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (24-25)"] = {
		{ids="846,849"},
	},
	["LEVELING\\Classic (12-58)\\The Hinterlands (50-51)"] = {
		{ids="650,1429,626,7840,7815,7816,3563,3562,3564,580"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (24-25)"] = {
		{ids="5881,4542,4841"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (27-29)"] = {
		{ids="1196,1149,4821,1197,4865,5062,5064,5088,4770,4881,4966,4904,5147,4767,1131"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (31-32)"] = {
		{ids="1361,1110,1104,1105,1176,1175"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (38-38)"] = {
		{ids="1436,1136,1146,1112,1114,1183,1186,1147,1148"},
	},
	["LEVELING\\Classic (12-58)\\Un'Goro Crater (52-54)"] = {
		{ids="3884", cond_if=[[haveq(3884) or completedq(3884)]]},
		{ids="2641,4494,2661,2662,3444,4243,4244,4245,4289,4290,3844,4291,4503,4501,3882,3883,3881,3884,4284,4145,3845,4492,4491,4301,4292,974,4285,4287,4288,4321,4504,4496,3761,3782,4502,4147,4133"},
	},
	["LEVELING\\Classic (12-58)\\Western Plaguelands (56-58)"] = {
		{ids="4293,4294,5094,6029,5021,5096,5228,5229,5230,5231,5232,5098,5233,5234,4984,4985,5235,5236,6004,6023,6025,5023,5049,9443"},
	},
	["LEVELING\\Classic (12-58)\\Winterspring (55-56)"] = {
		{ids="8465,980,3908,4808,3783,977,4809,4842,5082,5083,8464"},
	},
	["LEVELING\\Classic (12-58)\\Winterspring (59-60)"] = {
		{ids="8798", cond_if=[[haveq(8798) or completedq(8798)]]},
		{ids="5086,5087,5163,4741,4809,5121,4721,4882,4883,4810"},
	},
	["LEVELING\\Extra Zones\\Eastern Plaguelands"] = {
		{ids="5601,5149,6030,5241,6026,9141,5281,6164,5542,5543,5544,5742,6022,6042,5781,6021,5211,9136,9126,9124,9131,5845,5846,5023,5049"},
	},
	["LEVELING\\Extra Zones\\Ghostlands"] = {
		{ids="9329", cond_if=[[haveq(9329) or completedq(9329)]]},
		{ids="9327", cond_if=[[haveq(9327) or completedq(9327)]]},
		{ids="9130,9133,9134,9135", cond_if=[[BloodElf]]},
		{ids="9148,9149,9758,9138,9315,9139,9152,9150,9155,9160,9158,9145,9143,9146,9157,9174,9161,9274,9162,9172,9149,9163,9173,9175,9192,9171,9216,9218,9140,9159,9212,9276,9166,9277,9214,9275,9169,9176,9207,9151,9281,9220,9877,9193,9199,9164,9170,9177"},
	},
	["LEVELING\\Extra Zones\\Silithus"] = {
		{ids="1124,8276,1125,1126,8280,8277,8318,9416,8308,8281,8278,8284,8304,8285,8279,8323,8282,8287,8283,4642,9128,5210,5181,6844,6845,8320,8361,8321,8306"},
	},
	["LEVELING\\Extra Zones\\Silverpine Forest"] = {
		{ids="445,6321,6323,6322,6324", cond_if=[[Scourge]]},
		{ids="435,449,3221,421,428,429,437,422,447,1359,477,438,430,425,439,478,423,481,482,424,479,440,441,264,460,461,443,530,444,491,516"},
	},
	["LEVELING\\Extra Zones\\Western Plaguelands"] = {
		{ids="4293,4294,5094,6029,5021,5096,5228,5229,5230,5231,5232,5233,5234,4984,4985,5235,5236,5901,5238,5050,5051,5902,6004,6023,5152,5153,5154,4971,4972,6390,5098,838,964,4987,1004,1123,4120,7492"},
	},
	["LEVELING\\Scepter of the Shifting Sands"] = {
		{ids="8286,8288,8301,8302,8303,8305,8519,8555,8575,8576,8599,8597,8598,8584,8585,8606,8577,8733,8734,8735,8736,8586,8578,8587,8620,8741,8730,8728,8729,8743"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Orgrimmar)"] = {
		{ids="9263,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Silvermoon City)"] = {
		{ids="12816,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Thunder Bluff)"] = {
		{ids="9264,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Undercity)"] = {
		{ids="9265,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Starter Guides (1-12)\\Durotar (1-12) [Orc & Troll Starter]"] = {
		{ids="3086", cond_if=[[Troll Mage]]},
		{ids="1505,1498", cond_if=[[Warrior]]},
		{ids="3083", cond_if=[[Troll Rogue]]},
		{ids="1516,1517,1518,2983,1524,1525,1526,1527", cond_if=[[Shaman]]},
		{ids="2383", cond_if=[[Orc Warrior]]},
		{ids="3090,1485,1499", cond_if=[[Orc Warlock]]},
		{ids="3084", cond_if=[[Troll Shaman]]},
		{ids="792", cond_if=[[not Orc Warlock]]},
		{ids="3089", cond_if=[[Orc Shaman]]},
		{ids="6062,6083,6082,6081", cond_if=[[Hunter]]},
		{ids="3082", cond_if=[[Troll Hunter]]},
		{ids="1506,1501,1504", cond_if=[[Warlock]]},
		{ids="3087", cond_if=[[Orc Hunter]]},
		{ids="3088", cond_if=[[Orc Rogue]]},
		{ids="3085,5652", cond_if=[[Troll Priest]]},
		{ids="3065", cond_if=[[Troll Warrior]]},
		{ids="4641,788,4402,5441,790,789,804,6394,794,805,823,2161,784,830,825,791,786,818,808,826,817,815,837,834,835,831,813,812,816,806,828,827,829,5726,5727"},
	},
	["LEVELING\\Starter Guides (1-12)\\Eversong Woods (1-13) [Blood Elf Starter]"] = {
		{ids="8564,10072", cond_if=[[BloodElf Priest]]},
		{ids="9676,10069,9678,9681,64319,9684,63866,9685", cond_if=[[BloodElf Paladin]]},
		{ids="8338", cond_if=[[haveq(8338) or completedq(8338)]]},
		{ids="8346", cond_if=[[haveq(8346) or completedq(8346)]]},
		{ids="8328,10068", cond_if=[[BloodElf Mage]]},
		{ids="8336", cond_if=[[haveq(8336) or completedq(8336)]]},
		{ids="8563,10073,8344,9529,9619", cond_if=[[BloodElf Warlock]]},
		{ids="9392,10071", cond_if=[[BloodElf Rogue]]},
		{ids="9393,10070,9484,9486,9485,9673", cond_if=[[BloodElf Hunter]]},
		{ids="8325,8326,8330,8345,8327,8334,8335,8347,9704,9705,8350,8472,8468,8463,8895,9119,8486,9352,8884,8887,9358,9035,9062,8482,8483,8475,9064,9254,8487,8488,9252,8491,9255,9395,8885,8886,8480,9076,8892,9066,9359,9144,9147,8888,9394,8894,8889,8890,8891,8479,8476,9360,8477,9363,9067,9258,8473,8474,10166,9253,8490"},
	},
	["LEVELING\\Starter Guides (1-12)\\Mulgore (1-12) [Tauren Starter]"] = {
		{ids="3094,5926,5922,5930,5932,6002", cond_if=[[Tauren Druid]]},
		{ids="748,754,756,758,759,760,854", cond_if=[[Tauren]]},
		{ids="3092,6061,6087,6089", cond_if=[[Tauren Hunter]]},
		{ids="3091,1505,1498", cond_if=[[Tauren Warrior]]},
		{ids="3093,1519,1520,1521,2984,1524,1525,1526,1527", cond_if=[[Tauren Shaman]]},
		{ids="752,747,753,755,750,780,3376,757,763,1656,767,761,745,743,771,749,772,766,751,773,833,746,764,765,775,776,744,861,886,860"},
	},
	["LEVELING\\Starter Guides (1-12)\\Tirisfal Glades (1-12) [Undead Starter]"] = {
		{ids="3098", cond_if=[[Scourge Mage]]},
		{ids="3097,5658", cond_if=[[Scourge Priest]]},
		{ids="3096", cond_if=[[Scourge Rogue]]},
		{ids="3099,1470,1478,1473,1471", cond_if=[[Scourge Warlock]]},
		{ids="3095,1818,1819,1820", cond_if=[[Scourge Warrior]]},
		{ids="363,364,376,3901,3902,380,6395,381,382,5481,383,8,367,404,590,354,362,361,375,355,427,365,426,407,398,358,368,5482,374,370,359,360,371,369,492,356,372"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains (67-68)"] = {
		{ids="10928,9795,10486,10503,10524,10525,10542,10545,10543,10544,10487,10526,10489,10505,10718,10488,10810,10812,10770,10771,10753,10567,10682,10717,10713,10719,10819,10820,10614,10709,10714,10783,10715,10749,10720,10784,10721,10785,10894,10893,10607,10747,10722,10825,10723,10786,10565,10618,10617,10566,10846,10843,10851,10860,10845,10853,10859,10865,10615,10867"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains Group Quests"] = {
		{ids="10718,10614,10709,10714,10783,10715,10749,10720,10721,10785,10723,10724,10742,10810,10812,10819,10820,10821"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula (58-62)"] = {
		{ids="9498", cond_if=[[not BloodElf]]},
		{ids="9499", cond=[[BloodElf]]},
		{ids="9407,10120,10289,10291,10121,10086,10450,10123,10124,10449,10208,10129,10162,10242,10809,9345,10538,10087,10388,10835,10393,10390,10391,10392,10236,10238,10629,10630,10864,10213,10220,10229,10161,9351,9349,9361,9356,10278,10230,10813,10250,10294,10792,10258,9400,9401,9405,9410,9374,9366,9381,9340,10389,9406,9438,9441,9418,9375,9396,9370,9397,9391,9376,10286,9373,10442,9372,10255,10403,10367,10368,10369,10159,9442,9447,9387,10287,9472"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula Group"] = {
		{ids="9407,10120,10289,10450,10449,10242,10538,10835,10864,10838,10813,10834,10136,9466,10132,10134,10349,10351"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Isle of Quel'danas"] = {
		{ids="11482", cond_if=[[haveq(11482) or completedq(11482)]]},
		{ids="11517,11534", cond_if=[[haveq(11517,11534) or completedq(11517,11534)]]},
		{ids="11481", cond_if=[[haveq(11481) or completedq(11481)]]},
		{ids="11550,11526,11488,11490,29685"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Nagrand (65-67)"] = {
		{ids="9882", cond_if=[[haveq(9882) or completedq(9882)]]},
		{ids="10210,10211,9854,9789,9857,9797,9861,9870,9818,9819,9872,9821,9800,9804,9858,9850,9855,10109,9888,9889,9890,9891,10479,9910,9906,9805,9907,9916,9864,9944,9945,9948,9865,9983,9991,9913,9914,9900,9925,9863,9866,9867,10107,9928,9927,9931,9932,9935,9939,9934,9849,9810,9815,9862,9962,9967,9970,9972,9973,9977"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Nagrand Group Quests"] = {
		{ids="9983", cond_if=[[haveq(9983) or completedq(9983)]]},
		{ids="10109,10111,9818,9819,9821,9849,9853,9854,9789,9857,9858,9850,9855,9859,9856,9851,10227,10228,10231,10251,10252,9944,9945,9946,9962,9967,9970,9972,9977,9937,9991,9999,10001,10004,10009,10010,10011"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm (68-70)"] = {
		{ids="10241,10243,10313,10245,10299,10246,10321,10328,10322,10431,10380", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10432", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10189,10193,10204,10329,10194,10652,10197,10198,10330,10200,10338,10341,10202", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10381", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10210,10211,10190,10183,10191,10342,10186,10225,10224,10263,10203,10265,10199,10173,10226,10221,10300,10262,10206,10205,10174,10334,10337,10331,10184,10305,10185,10182,10307,10306,10343,10332,10312,10316,10314,10319,10188,10239,10192,10301,10222,10240,10233,10209,10924,10223,10176,10266,10333,10433,10348,10417,10234,10418,10311,10267,10235,10423,10434,10268,10232,10237,10247,10426,10427,10317,10315,10318,10424,10336,10855,10335,10429,10430,10436,10440,10856,10435,10411,10422,10345,10270,10271,10281,10272,10437,10353,10269,10438,10273,10857,10275,10339,10384,10385,10405"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm Group Quests"] = {
		{ids="10341,10202,10189,10193,10329,10194,10652,10197,10198,10330,10200,10338,10365,10264", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10243,10245,10299,10321,10322,10323,10263", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10432,10508", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10407,10410,10409,10509,10507,10309,10261,10701,10256,10265,10262,10205,10266,10267,10268,10269,10275,10276,10184,10312,10316,10314,10319,10320,10333,10234,10235,10237,10247,10248,10270,10271,10281,10272,10273,10274,10290,10293,10339,10384,10385,10405,10406,10408,10437,10438,10439,10310"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Shadowmoon Valley (70-70)"] = {
		{ids="10826", cond_if=[[rep ('The Aldor') >= Neutral]]},
		{ids="10672,10673", cond_if=[[rep('The Scryers') >= Neutral]]},
		{ids="10683,10807,10684", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10619,10568,10571,10672,10673", cond_if=[[rep('The Aldor') >= Neutral]]},
		{ids="10824", cond_if=[[rep('The Scryers')>=Neutral]]},
		{ids="10210,10211,10595,11047,10596,10597,10598,10681,10458,10599,10600,10601,10602,10624,10660,10702,10760,10625,10603,10604,10623,10761,10777,10480,10633,10804,10635,10778,10780,10481,10782,10808"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest (63-65)"] = {
		{ids="10325", cond_if=[[haveq(10325) or completedq(10325)]]},
		{ids="10021", cond_if=[[haveq(10021) or completedq(10021)]]},
		{ids="10412", cond_if=[[haveq(10412) or completedq(10412)]]},
		{ids="10210,10211,10554,10553,9957,9951,9971,9968,9978,9796,10105,10037,9979,10862,9993,10201,10018,10027,10868,10847,10039,10041,10849,10839,10852,10896,10842,10878,10880,10840,10917,10112,10043,10034,10000,10003,10008,9990,9987,10013,9995,10023,10791,10448,9997,10447,10006,10848,10887,10881,10922,10913,10030,10227,10920,10873,10914,10877,10915,10861,10031,10228"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest Group Quests"] = {
		{ids="9983", cond_if=[[haveq(9983) or completedq(9983)]]},
		{ids="10052,10898,10842,10877,10923,10034,10036,10922,10929,10930,9991,9999,10001,10004,10009"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh (62-63)"] = {
		{ids="9697", cond_if=[[haveq(9697) or completedq(9697)]]},
		{ids="10103", cond_if=[[haveq(10103) or completedq(10103)]]},
		{ids="9912,9778,9747,9802,9728,9895,9716,9752,9718,9774,9769,9773,9771,10096,9788,9894,9785,9772,9770,9828,9899,9775,9911,9743,9739,9701,9702,9814,9845,9846,9820,9708,9919,9806,9808,9903,9904,9841,9822,9847,9842,9823,10118,10117,9816,9709,9898,9720,9731,9724,9732"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh Group Quests"] = {
		{ids="9730,10117,9894,9895,9729"},
	},
	["LEVELING\\Northrend (69-80)\\Borean Tundra (70-72)"] = {
		{ids="11945", cond_if=[[haveq(11945) or completedq(11945)]]},
		{ids="11585,11596,11611,11606,11598,11614,11608,11602,11615,11616,11634,11636,11642,11664,11643,11644,11651,11655,11660,11656,11661,11662,11613,12471,11619,11620,11652,11618,11688,11676,11686,11690,11703,11705,11709,11711,11716,11717,11719,11720,11714,11721,11724,11722,11888,11916,11881,11887,11684,11890,11895,11906,11896,11899,11893,11685,11695,11894,11909,11907,11674,11675,11677,11678,11683,11687,11706,11628,11689,11630,11633,11654,11641,11640,11647,11659,11949,11950,11961,11968,11865,11866,11876,11869,11878,11879,11870,11871,11872,11868,11574,11576,11587,11590,11646,11648,11663,11671,11679,11680,11681,11682,11605,11612,11607,11617,11609,11623,11610,11582,11733,11941,11910,11918,11943,11912,11946,11951,11957,11936,11967,11914,11900,12486,11624,11627,11702,11571,11559,11561,11560,11562,11563,11564,11565,11569,11566,11570,11649,11629,11631,11635,11637,11639,11638,11591,11593,11594,11592,12728"},
	},
	["LEVELING\\Northrend (69-80)\\Dragonblight (72-74)"] = {
		{ids="12118", cond_if=[[haveq(12118) or completedq(12118)]]},
		{ids="11979", cond_if=[[haveq(11979) or completedq(11979)]]},
		{ids="12372", cond_if=[[haveq(12372) or completedq(12372)]]},
		{ids="11960", cond_if=[[haveq(11960) or completedq(11960)]]},
		{ids="12791", cond_if=[[not Mage]]},
		{ids="12117", cond_if=[[haveq(12117) or completedq(12117)]]},
		{ids="12173", cond=[[Mage]]},
		{ids="12182", cond_if=[[haveq(12182) or completedq(12182)]]},
		{ids="12181,12206,12304,12205,12211,12188,12209,12303,12033,11996,11980,11978,11983,12006,12013,11999,12008,12034,12040,12005,12059,12041,12036,12039,12100,12101,12056,12063,12064,12057,12048,12053,12115,12071,12061,12069,12125,12072,12066,12140,11958,12096,12102,12104,12126,12084,12085,12111,11959,12028,12011,12016,12009,12017,12106,12030,12031,12032,12454,12214,12245,12200,12252,12271,12273,12230,12218,12234,12240,12232,12239,12254,12260,12274,12283,12243,12458,12419,12110,12221,12127,12132,12136,12447,12262,12261,12263,12264,12265,12267,12224,12122,12767,12266,12496,12497,12461,12448,12449,12450,12769,12124,12435,12144,12145,12469,12044,12045,12043,12046,12049,12047,12052,12050,12112,12075,12076,12077,12078,12079,12147,12498,12500,13242,13257,12790,12488"},
	},
	["LEVELING\\Northrend (69-80)\\Grizzly Hills (74-75)"] = {
		{ids="12487", cond_if=[[haveq(12487) or completedq(12487)]]},
		{ids="12468,12433,12324,12317,12170,12436,12175,12257,12256,12259,12412,12423,12424,12176,12177,12178,12208,11984,11989,11990,12484,11991,12007,12422,12288,12280,12270,12284,12042,12802,12413,12427,12428,12429,12430,12431,12029,12483,12425,12328,12327,12329,12134,12330,12451,12411,12207,12213,12453,12026,12195,12054,12074,11982,12070,11985,12190,12081,12093,12094,12068,12082,12113,12114,12116,12120,12121,12137,12229,12231,12058,12073,12415,12279,12152,12099,12204,12201,12165,12202,12196,12203,12197,12198,12199,12241,12242"},
	},
	["LEVELING\\Northrend (69-80)\\Howling Fjord (69-71)"] = {
		{ids="11270,11227,11167,11253,11168,11254,11170,11221,11229,11230,11232,11233,11234,11241,11295,11282,11283,11285,11303,12481,12566,11275,11312,11313,11281,11350,11311,11314,11315,11316,11319,11351,11271,11428,11256,11258,11257,11259,11261,11260,11352,11287,11286,11297,11317,11323,11296,11415,11298,11398,11301,11422,11397,11399,11266,11265,11263,11417,11433,11268,11264,11453,11324,11304,11305,11306,11182,11279,11307,11308,12482,11423,11309,11424,11504,11507,11456,11457,11508,11509,11434,11510,11464,11466,11455,11473,11459,11476,11479,11480,11469,11519,11527,11458,11471,11467,11529,11530,11511,11512,11567,11280,11310,11568,11572"},
	},
	["LEVELING\\Northrend (69-80)\\Icecrown (79-80)"] = {
		{ids="13353", cond_if=[[haveq(13353) or completedq(13353)]]},
		{ids="12815", cond_if=[[haveq(12815) or completedq(12815)]]},
		{ids="13071", cond_if=[[haveq(13071) or completedq(13071)]]},
		{ids="13069", cond_if=[[haveq(13069) or completedq(13069)]]},
		{ids="13105", cond_if=[[DeathKnight]]},
		{ids="13301", cond_if=[[haveq(13301) or completedq(13301)]]},
		{ids="13330", cond_if=[[haveq(13330) or completedq(13330)]]},
		{ids="12813", cond_if=[[haveq(12813) or completedq(12813)]]},
		{ids="13357", cond_if=[[haveq(13357) or completedq(13357)]]},
		{ids="12995", cond_if=[[haveq(12995) or completedq(12995)]]},
		{ids="13302", cond_if=[[haveq(13302) or completedq(13302)]]},
		{ids="13365", cond_if=[[haveq(13365) or completedq(13365)]]},
		{ids="13261", cond_if=[[haveq(13261) or completedq(13261)]]},
		{ids="13283", cond_if=[[haveq(13283) or completedq(13283)]]},
		{ids="12838", cond_if=[[haveq(12838) or completedq(12838)]]},
		{ids="13310", cond_if=[[haveq(13310) or completedq(13310)]]},
		{ids="13104", cond_if=[[not DeathKnight]]},
		{ids="13036,13039,13040,13008,13044,13045,13070,13086,13130,13135,13118,13122,13110,13125,13139,13141,13157,13419,13224,13068,12892,12891,12893,13340,13293,13072,13073,13074,13075,12897,13228,13230,13260,13238,12899,12938,12955,12939,12949,12951,13085,12943,12999,13092,13059,13042,13043,13091,12992,12982,13084,12806,12807,12810,12839,12814,12840,13106,13117,13119,13120,13134,13136,13076,13077,13078,13079,13237,13229,13239,13258,13259,13262,13263,13271,13275,13080,13081,13082,13264,13282,13168,13169,13170,13171,13172,13174,13121,13133,13138,13140,13211,13152,13144,13212,13220,13235,13155,13143,13145,13146,13147,13160,13304,13305,13236,13348,13351,13379,13373,13352,13354,13355,13359,13358,13349,13366,13356,13360,13361,13306,13362,13083,13363,13364"},
	},
	["LEVELING\\Northrend (69-80)\\Sholazar Basin (76-78)"] = {
		{ids="12695", cond_if=[[haveq(12695) or completedq(12695)]]},
		{ids="12692", cond_if=[[haveq(12692) or completedq(12692)]]},
		{ids="12624,12624,12624", cond_if=[[readyq(12624) or completedq(12624)]]},
		{ids="12521,12489,12524,12688,12522,12523,12525,12589,12520,12549,12526,12624,12550,12804,12634,12644,12592,12551,12543,12544,12645,12560,12654,12556,12558,12569,12595,12603,12605,12683,12607,12614,12681,12658,12803,12561,12611,12612,12805,12608,12617,12660,12620,12621,12559,12691,12613,12548,12547,12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12696,12699,12671,12797,12546,12578,12580,12579,12581"},
	},
	["LEVELING\\Northrend (69-80)\\The Storm Peaks (78-79)"] = {
		{ids="12833", cond_if=[[haveq(12833) or completedq(12833)]]},
		{ids="12818,12819,12826,12827,12836,12831,12829,12830,12820,12828,12832,12821,12823,12822,12824,12843,12844,13060,12895,12909,12910,13054,13055,13056,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,13062,12886,13064,12913,13000,12882,12917,12920,12926,12927,13416,12928,12929,12930,12931,12937,12957,12964,12965,12978,12979,12980,12984,12991,12988,12993,12998,13007,12925,12942,12968,12953,12922,13273,13274,12915,12956,13285,12966,12967,12924,13426,13034,13037,13038,13048,13049,13058"},
	},
	["LEVELING\\Northrend (69-80)\\Zul'Drak (75-76)"] = {
		{ids="12637", cond_if=[[haveq(12637) or completedq(12637)]]},
		{ids="12631", cond_if=[[haveq(12631) or completedq(12631)]]},
		{ids="12663", cond_if=[[haveq(12663) or completedq(12663)]]},
		{ids="12648", cond_if=[[haveq(12648) or completedq(12648)]]},
		{ids="12655", cond_if=[[itemcount(38551) >= 10]]},
		{ids="12795", cond_if=[[not completedq(12503)]]},
		{ids="12664", cond_if=[[haveq(12664) or completedq(12664)]]},
		{ids="12633", cond_if=[[haveq(12633) or completedq(12631)]]},
		{ids="12629", cond_if=[[haveq(12629) or completedq(12629)]]},
		{ids="12649", cond_if=[[haveq(12649) or completedq(12649)]]},
		{ids="12638", cond_if=[[haveq(12638) or completedq(12638)]]},
		{ids="12643", cond_if=[[haveq(12643) or completedq(12643)]]},
		{ids="12763,12902,12859,12861,12883,12894,12904,12901,12912,12903,12884,12630,12652,12914,12916,12661,12673,12669,12686,12677,12690,12710,12676,12713,12919,12565,12503,12740,12598,12512,12606,12552,12553,12583,12555,12932,12933,12934,12935,12936,12948,12557,12799,12609,12610,12505,12504,12508,12584,12506,12507,12597,12562,12510,12599,12596,12514,12527,12516,12623,12615,12627,12622,12628,12632,12635,12642,12655,12646,12647,12640,12639,12650,12653,12665,12666,12667,12672,12668,12674,12675,12684,12685,13549,12662,12659,13556,12708,12707,12709,12712"},
	},
	["LEVELING\\Starter Guides (1-12) & Death Knight (55-58)\\Death Knight Starter (55-58)"] = {
		{ids="12746", cond=[[Draenei]]},
		{ids="28649", cond=[[Worgen]]},
		{ids="12750", cond=[[Scourge]]},
		{ids="12748", cond=[[Orc]]},
		{ids="12745", cond=[[Gnome]]},
		{ids="12744", cond=[[Dwarf]]},
		{ids="12739", cond=[[Tauren]]},
		{ids="28650", cond=[[Goblin]]},
		{ids="12749", cond=[[Troll]]},
		{ids="12747", cond=[[BloodElf]]},
		{ids="12742", cond=[[Human]]},
		{ids="12743", cond=[[NightElf]]},
		{ids="12593,12619,12842,12848,12636,12641,12657,12850,12670,12733,12680,12687,12679,12678,12697,12698,12700,12701,12706,12714,12715,12719,12716,12717,12720,12722,12723,12725,12724,12727,12738,12751,12754,12755,12756,12757,12778,12779,12800,12801,13165,13166,13189"},
	},
	["PROFESSIONS\\Blacksmithing\\Blacksmithing (1-450)"] = {
		{ids="7655,7654,7656"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Armorsmith\\Armorsmith Questline"] = {
		{ids="2756,2757,2760,2761,2762,2763,2765,2764,2771,2772,2773,3321,5283"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Axesmith Questline"] = {
		{ids="5306"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Hammersmith Questline"] = {
		{ids="5305"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Master Swordsmith Questline"] = {
		{ids="5307"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Weaponsmith Questline"] = {
		{ids="5302"},
	},
	["PROFESSIONS\\Cooking\\Cooking (1-450)"] = {
		{ids="8307,8313,13090,12521,12489,12524,12522,12525,12523,12549,12520,12634,12644,12645,13571"},
	},
	["PROFESSIONS\\Cooking\\Cooking + Fishing (1-450)"] = {
		{ids="6607"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnomish Engineering Questline"] = {
		{ids="3637,3642,3643"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineering Questline"] = {
		{ids="3633,3639"},
	},
	["PROFESSIONS\\Fishing\\Fishing (1-450)"] = {
		{ids="6607"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Dragonscale Leatherworking\\Dragonscale Leatherworking Questline"] = {
		{ids="5145"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Elemental Leatherworking\\Elemental Leatherworking Questline"] = {
		{ids="5146"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Tribal Leatherworking\\Tribal Leatherworking Questline"] = {
		{ids="2854,2855,2856,2857,2858,2859,2860,5143"},
	},
	["PROFESSIONS\\Lockpicking\\Lockpicking (1-300)"] = {
		{ids="2379,2382,2381"},
	},
	["REPUTATIONS\\The Burning Crusade\\Cenarion Expedition"] = {
		{ids="9802,9875"},
	},
	["REPUTATIONS\\The Burning Crusade\\Keepers of Time"] = {
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["REPUTATIONS\\The Burning Crusade\\Lower City"] = {
		{ids="10917"},
	},
	["REPUTATIONS\\The Burning Crusade\\Netherwing"] = {
		{ids="11099,11100", cond_if=[[rep("The Aldor") >= Friendly]]},
		{ids="11094,11095", cond_if=[[rep("The Scryers") >= Friendly]]},
		{ids="10804,10811,10814,10836,10837,10854,10858,10866,10870,11013,11014,11049,11053,11075,11083,11081,11082,11054,11084,11064,11067,11068,11069,11070,11071,11092,11041,11107,11108"},
	},
	["REPUTATIONS\\The Burning Crusade\\Ogri'la"] = {
		{ids="11102", cond_if=[[raceclass("Druid")]]},
		{ids="11010", cond_if=[[not raceclass("Druid")]]},
		{ids="10984,10983,10995,10996,10997,10998,11000,11022,11009,11025,11058,11030,11062,11119,11059,11065,11078,11061,11079,11091,11026"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sha'tari Skyguard"] = {
		{ids="11102", cond_if=[[raceclass("Druid")]]},
		{ids="11010", cond_if=[[not raceclass("Druid")]]},
		{ids="11096,11098,11004,11093,11005,11021,11024,11028,11056,11029,11885,11073,10984,10983,10995,10996,10997,10998,11000,11022,11009,11025,11058,11030,11062,11119,11059,11065,11078,11026"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sporeggar"] = {
		{ids="9739,9743,9919"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Aldor"] = {
		{ids="10210,10211,10554,10325,10020,10021,11038,10241,10243,10313,10245,10299,10321,10246,10328,10322,10431,10380,10381,10323,10407,10653,10410,10420,10409,10619,10568,10587,10637,10816,10571,10574,10575,10640,10641,10668,10669,10646,10649,10650,10650"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Consortium"] = {
		{ids="9913,9882,9900,9925,9914,9893,10265,10262,10205,10266,10348,10417,10418,10267,10311,10310,10423,10268,10424,10430,10436,10440,10269,10339,10384,10385,10405,10406,10425,10422,10345,10411,10353,10437,10438,10439,10408,10270,10275,10290,10276,10335,10336,10855,10856,10857,10970,10970,10971,10972"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Mag'har"] = {
		{ids="9983", cond_if=[[haveq(9983) or completedq(9983)]]},
		{ids="9400,9401,9405,9410,9406,9438,9441,9442,9447,9888,9889,9890,10479,9891,9906,9991,9999,10001,10004,10009,10010,10011,9907,9872,9868,10107,9928,9927,9931,9932,9934,10044,10045,10081,10082,10085,10101,10102,10167,10168,10170,10171,10172,10175,10212,9944,9945,9946,9865,9866,9937"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Scryers"] = {
		{ids="10341,10202,10432", cond_if=[[rep ('The Scryers') >= Friendly]]},
		{ids="10210,10211,10553,11039,10189,10193,10204,10329,10194,10652,10197,10198,10330,10200,10338,10508,10509,10507,10824,10687,10688,10807,10683,10684,10685,10686,10640,10641,10668,10669,10646,10649,10691,10692,10412,10656,10416"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Sha'tar"] = {
		{ids="10568,10571,10574,10575", cond_if=[[rep ('The Aldor') >= Friendly]]},
		{ids="9983", cond_if=[[haveq(9983) or completedq(9983)]]},
		{ids="10683,10684,10685,10686", cond_if=[[rep ('The Scryers') >= Neutral]]},
		{ids="10210,9888,9889,9890,9891,9906,9991,9999,10001,10004,10009,10010,10011,9907,9868,10107,9928,9927,9931,9932,9934,10044,10045,10081,10082,10085,10101,10102,10167,10168,10227,10228,10231,10251,10252,10253,10920,10921,10877,10923,10883,10884,10885,10886,10265,10262,10205,10266,10267,10268,10269,10275,10276,10280,10704,10622,10628,10705,10706,10707,10793,10781,11052"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Champion of the Naaru"] = {
		{ids="10680", cond_if=[[Alliance]]},
		{ids="10681", cond_if=[[Horde]]},
		{ids="10458,10480,10481,10513,10514,10515,10519,10521,10522,10527,10528,10537,10540,10546,10547,10550,10570,10576,10577,10578,10523,10541,10579,10588,10884,10885,10886,10888"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Hand of A'dal"] = {
		{ids="10568,10571,10574,10575", cond_if=[[rep("The Aldor") >= Neutral]]},
		{ids="10683,10684,10685,10686", cond_if=[[rep("The Scryers") >= Neutral]]},
		{ids="10210,10211,10622,10628,10705,10706,10707,10708,10944,10946,10947,10948,10949,10985,10445"},
	},
	["TITLES\\Burning Crusade Titles\\Reputation\\of the Shattered Sun"] = {
		{ids="11549"},
	},
}
