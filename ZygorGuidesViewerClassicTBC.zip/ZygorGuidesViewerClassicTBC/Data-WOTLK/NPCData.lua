local name,ZGV=...
ZGV._NPCData={
--|wThis is for tips
--|ccompletedq(12237)
--search //UNLOCK CONDITION, //STABLE, //TEMPORARY	
	["Repair"] = [[
		-- ALLIANCE --
		1287=sA|m1453|x64.07|y68.36|wInside the building -- Stormwind City/0, Marda Weller (Checked 8/24/2022)
		1289=sA|m1453|x64.20|y68.59|wInside the building -- Stormwind City/0, Gunther Weller (Checked 8/24/2022)
		1291=sA|m1453|x62.02|y67.79|wInside the building -- Stormwind City/0, Carla Granger (Checked 8/24/2022)
		1294=sA|m1453|x61.90|y67.18|wInside the building -- Stormwind City/0, Aldric Moore (Checked 8/24/2022)
		1295=sA|m1453|x61.97|y67.47|wInside the building -- Stormwind City/0, Lara Moore (Checked 8/24/2022)
		1297=sA|m1453|x58.71|y68.71|wInside the building -- Stormwind City/0, Lina Stover (Checked 8/24/2022)
		1298=sA|m1453|x58.34|y69.03|wInside the building -- Stormwind City/0, Frederick Stover (Checked 8/24/2022)
		1299=sA|m1453|x58.30|y67.15|wInside the building -- Stormwind City/0, Lisbeth Schneider (Checked 8/24/2022)
		1309=sA|m1453|x51.82|y83.49|wInside the building -- Stormwind City/0, Wynne Larson (Checked 8/24/2022)
		1310=sA|m1453|x52.65|y83.66|wInside the building -- Stormwind City/0, Evan Larson (Checked 8/24/2022)
		1312=sA|m1453|x52.82|y74.86|wInside the building -- Stormwind City/0, Ardwyn Cailen (Checked 8/24/2022)
		1314=sA|m1453|x53.18|y82.04|wInside the building -- Stormwind City/0, Duncan Cullen (Checked 8/24/2022)
		1315=sA|m1453|x53.01|y74.90|wInside the building -- Stormwind City/0, Allan Hafgan (Checked 8/24/2022)
		1319=sA|m1453|x69.18|y57.64|wInside the building -- Stormwind City/0, Bryan Cross (Checked 8/24/2022)
		1320=sA|m1453|x71.86|y61.98|wInside the building -- Stormwind City/0, Seoman Griffith (Checked 8/24/2022)
		1323=sA|m1453|x77.17|y60.98|wInside the building -- Stormwind City/0, Osric Strang (Checked 8/24/2022)
		1324=sA|m1453|x77.21|y57.36|wInside the building -- Stormwind City/0, Heinrich Stone (Checked 8/24/2022)
		1333=sA|m1453|x73.00|y57.45|wInside the building -- Stormwind City/0, Gerik Koen (Checked 8/24/2022)
		1339=sA|m1453|x71.68|y58.18|wInside the building -- Stormwind City/0, Mayda Thane (Checked 8/24/2022)
		1341=sA|m1453|x77.51|y61.29|wInside the building -- Stormwind City/0, Wilhelm Strang (Checked 8/24/2022)
		1348=sA|m1453|x48.12|y55.00|wInside the building -- Stormwind City/0, Gregory Ardus (Checked 8/24/2022)
		1349=sA|m1453|x53.51|y57.56|wInside the building -- Stormwind City/0, Agustus Moulaine (Checked 8/24/2022)
		1350=sA|m1453|x53.20|y57.93|wInside the building -- Stormwind City/0, Theresa Moulaine (Checked 8/24/2022)
		5509=sA|m1453|x59.30|y33.85|wInside the building -- Stormwind City/0, Kathrum Axehand (Checked 8/24/2022)
		5510=sA|m1453|x61.98|y36.44|wInside the building -- Stormwind City/0, Thulman Flintcrag (Checked 8/24/2022)
		5512=sA|m1453|x63.24|y37.56 -- Stormwind City/0, Kaita Deepforge (Checked 8/24/2022)
		--12805=sA|m1453|x73.59|y53.0 -- Stormwind City/0, Officer Areyn (Checked 8/24/2022)
		29288=sA|m1453|x23.27|y36.70|wHe walks around on the deck of the ship -- Stormwind City/0, Engineer Kurtis Paddock (Checked 8/24/2022)
		26394=sA|m1453|x74.28|y67.65|wInside the building -- Stormwind City/0, Captain O'Neal (Checked 8/24/2022)
		26393=sA|m1453|x75.02|y67.77|wInside the building -- Stormwind City/0, Captain Dirgehammer (Checked 8/24/2022)
		12778=sA|m1453|x75.32|y67.43|wInside the building -- Stormwind City/0, Lieutenant Rachel Vaccar (Checked 8/24/2022)
		12784=sA|m1453|x75.42|y67.31|wInside the building -- Stormwind City/0, Lieutenant Jackspring (Checked 8/24/2022)
		12785=sA|m1453|x75.59|y67.09|wInside the building -- Stormwind City/0, Sergeant Major Clate (Checked 8/24/2022)
		27011=sA|m114|x57.83|y66.04 -- Borean Tundra/0, Broff Bombast (Checked 9/20/2022)
		26600=sA|m114|x56.42|y19.76|wWalking around this area -- Borean Tundra/0, Chief Engineer Galpen Rolltie	(Checked 9/20/2022)
		26599=sA|m114|x57.00|y19.80 -- Borean Tundra/0, Willis Wobblewheel (Checked 9/20/2022)
		23735=sA|m117|x59.50|y63.82 -- Howling Fjord/0, Bartleby Armorfist (checked 9/22/2022)
		24052=sA|m117|x61.01|y17.08 -- Howling Fjord/0, Eldrim Mounder (checked 9/22/2022)
		26934=sA|m117|x75.01|y65.19 -- Howling Fjord/0, Everett McGill (checked 9/22/2022)
		23862=sA|m117|x30.69|y41.84 -- Howling Fjord/0, Finlay Fletcher (checked 9/22/2022)
		23908=sA|m117|x29.83|y42.60 -- Howling Fjord/0, Jhet Ironbeard (checked 9/22/2022)
		26901=sA|m117|x60.10|y61.30 -- Howling Fjord/0, Torik (checked 9/22/2022)
		27045=sA|m115|x77.82|y50.73 -- Dragonblight/0, Master Smith Devin Brevig (checked 9/23/2022)
		27055=sA|m115|x29.02|y55.09 -- Dragonblight/0, Sentinel Amberline (checked 9/23/2022)
		27062=sA|m116|x31.38|y59.86 -- Grizzly Hills/0, Brom Armstrong (checked 9/23/2022)
		26229=sA|m116|x59.79|y27.83 -- Grizzly Hills/0, Tiernan Anvilheart (checked 9/23/2022)
		29923=sA|m120|x28.83|y74.92 -- The Storm Peaks/0, Dagni Oregleam (checked 9/26/2022)
		--29252=sA|m116|x16.00|y86.80 -- ??, Jason Riggins //TEMPORARY		
		30345=sA|m118|x55.20|y39.40|wOn the Skybreaker Airship -- Icecrown/0, Chief Engineer Boltwrench (checked 9/27/2022)
		31776=sA|m118|x56.99|y62.57 -- Icecrown/0, Frazzle Geargrinder (checked 9/27/2022)
		
		-- HORDE --
		25274=sH|m114|x41.10|y55.50|wWalking around this area -- Borean Tundra/0, Armorer Orkuruk			(Checked 9/20/2022)
		27067=sH|m114|x49.74|y10.08|wInside the building -- Borean Tundra/0, Drigoth					(Checked 9/20/2022)
		26697=sH|m114|x76.62|y37.18|wInside the building -- Borean Tundra/0, Tewah Chillmane				(Checked 9/20/2022)
		24347=sH|m117|x79.25|y28.91 -- Howling Fjord/0, Alexis Walker (checked 9/22/2022)
		24330=sH|m117|x53.85|y66.94 -- Howling Fjord/0, Orson Locke (checked 9/22/2022)
		24188=sH|m117|x25.94|y24.66 -- Howling Fjord/0, Samuel Rosemond (checked 9/22/2022)
		24028=sH|m117|x48.11|y11.01 -- Howling Fjord/0, Talu Frosthoof (checked 9/22/2022)
		27267=sH|m115|x75.97|y63.26 -- Dragonblight/0, Quartermaster Bartlett (Checked 9/23/2022)
		27019=sH|m115|x36.63|y46.24 -- Dragonblight/0, Siegesmith Gulda (checked 9/23/2022)
		--29253=sH|m116|x16.00|y86.80 -- Grizzly Hills/0, Koloth (checked 9/28/2022) //TEMPORARY
		27037=sH|m116|x22.05|y65.11 -- Grizzly Hills/0, Hidetrader Jun'ik (checked 9/23/2022)
		26707=sH|m116|x65.31|y48.07 -- Grizzly Hills/0, Litoko Icetotem (checked 9/23/2022)
		27134=sH|m116|x23.40|y63.07 -- Grizzly Hills/0, Smith Prigka (checked 9/23/2022)
		29945=sH|m120|x36.37|y48.95 -- The Storm Peaks/0, Marksman Udabu (checked 9/26/2022)
		29969=sH|m120|x67.38|y50.64 -- The Storm Peaks/0, Ontak (checked 9/26/2022)
		31781=sH|m118|x51.94|y57.60 -- Icecrown/0, Blast Thunderbomb (checked 9/27/2022)
		30825=sH|m118|x60.00|y34.59|wOn the Ogrim's Hammer Airship-- Icecrown/0, Chief Engineer Copperclaw (checked 9/27/2022)

		-- NEUTRAL --
		25314=sB|m114|x32.94|y34.40|wInside the building -- Borean Tundra/0, Archmage Berinand (Checked 9/20/2022)
		27188=sB|m114|x77.91|y52.21|wInside the building -- Borean Tundra/0, Tonraq (Checked 9/20/2022)
		27139=sB|m114|x46.52|y32.56|wInside the building -- Borean Tundra/0, Librarian Whitley (Checked 9/20/2022)
		--31805=sB|m115|x44.80|y79.80 -- Borean Tundra/0, Nagojut ON A BOAT THAT MOVES (Checked 9/20/2022)
		27151=sB|m117|x25.65|y57.44 -- Howling Fjord/0, Deniigi (checked 9/22/2022)
		27943=sB|m115|x59.38|y54.95 -- Dragonblight/0, Dalormi (checked 9/23/2022)
		27185=sB|m115|x49.49|y75.38 -- Dragonblight/0, Kuk'uq (checked 9/23/2022)
		--31804=sB|m115|x49.80|y80.30 -- Dragonblight/0, Qatiichii (BOAT)
		26898=sB|m115|x55.04|y23.55 -- Dragonblight/0, Troz (checked 9/23/2022)
		28796=sB|m121|x41.22|y67.83 -- Zul'Drak/0, Arlen Brighthammer (checked 9/26/2022)
		28855=sB|m121|x59.53|y57.04 -- Zul'Drak/0, Ba'kari (checked 9/26/2022)
		29688=sB|m121|x25.23|y63.88 -- Zul'Drak/0, Engineer Reed (checked 9/26/2022)
		28797=sB|m121|x41.37|y67.84 -- Zul'Drak/0, Haley Copperturn (checked 9/26/2022)
		28871=sB|m121|x14.30|y74.18 -- Zul'Drak/0, Scabbard (checked 9/26/2022)
		29014=sB|m119|x55.91|y70.33 -- Sholazar Basin/0, Grakjek (checked 9/26/2022)
		29035=sB|m119|x53.53|y55.89 -- Sholazar Basin/0, Loomee (checked 9/26/2022)
		28040=sB|m119|x27.32|y59.75 -- Sholazar Basin/0, Mardan Thunderhoof (checked 9/26/2022)
		32594=sB|m120|x67.12|y60.97 -- The Storm Peaks/0, Calder (checked 9/26/2022)
		32477=sB|m120|x45.03|y27.50 -- The Storm Peaks/0, Chester Copperpot (checked 9/26/2022)
		29964=sB|m120|x31.38|y38.26|wInside the building -- The Storm Peaks/0, Dargum Hammerdeep (checked 9/26/2022)
		30006=sB|m120|x47.46|y70.45|wInside the building -- The Storm Peaks/0, Warsmith Sigfinna (checked 9/26/2022)
		29907=sB|m120|x40.96|y86.48 -- The Storm Peaks/0, Xark Bolthammer (checked 9/26/2022)
		33599=sB|m118|x71.80|y20.80 -- ??, Brollen Wheatbeard
		30434=sB|m118|x87.25|y75.89 -- Icecrown/0, Durik Bronzebomb (checked 9/27/2022)
		33594=sB|m118|x72.20|y20.80 -- ??, Fizzix Blastbolt
		30436=sB|m118|x86.93|y77.12 -- Icecrown/0, Halig Fireforge (checked 9/27/2022)
		30067=sB|m118|x20.52|y47.77 -- Icecrown/0, Initiate Claget (checekd 9/27/2022)
		31115=sB|m118|x79.60|y72.60 -- Icecrown/0, Quartermaster Vaskess
		--30336=sB|m118|x44.84|y22.69|wInside the building -- Icecrown/0, Runesmith Balehammer NEED UNLOCK CONDITIONS (checked 9/27/2022)

		-- ALLIANCE --
		54=sA|m1429|x41.52|y65.89 -- Elwynn Forest/0, Corina Steele
		74=sA|m1429|x41.36|y65.58 -- Elwynn Forest/0, Kurran Steele
		78=sA|m1429|x47.23|y41.9 -- Elwynn Forest/0, Janos Hammerknuckle
		190=sA|m1429|x47.56|y41.39 -- Elwynn Forest/0, Dermot Johns
		896=sA|m1429|x25.18|y73.88 -- Elwynn Forest/0, Veldan Lightfoot
		959=sA|m1429|x64.69|y69.5 -- Elwynn Forest/0, Morley Eberlein
		1198=sA|m1429|x83.28|y66.08 -- Elwynn Forest/0, Rallic Finn
		1213=sA|m1429|x47.69|y41.41 -- Elwynn Forest/0, Godric Rothgar
		1249=sA|m1429|x25.23|y74.06 -- Elwynn Forest/0, Quartermaster Hudson
		1645=sA|m1429|x25.37|y73.99 -- Elwynn Forest/0, Quartermaster Hicks
		2046=sA|m1429|x41.7|y65.78 -- Elwynn Forest/0, Andrew Krighton
		167=sA|m1432|x34.01|y46.54 -- Loch Modan/0, Morhan Coppertongue
		222=sA|m1432|x42.86|y9.88 -- Loch Modan/0, Nillen Andemar
		954=sA|m1432|x82.65|y64.1 -- Loch Modan/0, Kat Sampson
		1214=sA|m1432|x64.82|y66.04 -- Loch Modan/0, Aldren Cordon
		1362=sA|m1432|x24.13|y18.2 -- Loch Modan/0, Gothor Brumn
		1469=sA|m1432|x35.82|y43.45 -- Loch Modan/0, Vrok Blunderblast
		1686=sA|m1432|x83.15|y63.42 -- Loch Modan/0, Irene Sureshot
		1687=sA|m1432|x83.02|y62.96 -- Loch Modan/0, Cliff Hadin
		225=sA|m1431|x73.6|y50.03 -- Duskwood/0, Gavin Gnarltree
		226=sA|m1431|x73.92|y48.8 -- Duskwood/0, Morg Gnarltree
		228=sA|m1431|x73.03|y44.47 -- Duskwood/0, Avette Fellwood
		789=sA|m1433|x27.08|y45.54 -- Redridge Mountains/0, Kimberly Hiett
		793=sA|m1433|x30.56|y46.46 -- Redridge Mountains/0, Kara Adams
		956=sA|m1433|x30.87|y46.43 -- Redridge Mountains/0, Dorin Songblade
		3088=sA|m1433|x23.83|y41.31 -- Redridge Mountains/0, Henry Chapal
		3097=sA|m1433|x88.25|y71.02 -- Redridge Mountains/0, Bernard Brubaker
		836=sA|m1426|x28.76|y66.37 -- Dun Morogh/0, Durnan Furcutter
		945=sA|m1426|x28.66|y67.73 -- Dun Morogh/0, Rybrad Coldbank
		1104=sA|m1426|x28.79|y67.84 -- Dun Morogh/0, Grundel Harkin
		1238=sA|m1426|x45.18|y51.92 -- Dun Morogh/0, Gamili Frosthide
		1240=sA|m1426|x45.15|y51.75 -- Dun Morogh/0, Boran Ironclink
		1243=sA|m1426|x40.68|y65.12 -- Dun Morogh/0, Hegnar Rumbleshot
		1273=sA|m1426|x45.28|y52.19 -- Dun Morogh/0, Grawn Thromwyn
		1690=sA|m1426|x45.3|y51.53 -- Dun Morogh/0, Thrawn Boltar
		1698=sA|m1426|x68.86|y55.95 -- Dun Morogh/0, Frast Dokner
		3162=sA|m1426|x30.11|y45.27 -- Dun Morogh/0, Burdrak Harglhelm
		3177=sA|m1426|x62.9|y49.88 -- Dun Morogh/0, Turuk Amberstill
		1322=sA|m1443|x67.93|y8.31 -- Desolace/0, Maxton Strang
		1296=sA|m1428|x85.2|y68.39 -- Burning Steppes/0, Felder Stover
		1441=sA|m1437|x11.52|y59.59 -- Wetlands/0, Brak Durnad
		1450=sA|m1437|x11.54|y59.85 -- Wetlands/0, Brahnmar
		1454=sA|m1437|x8.12|y55.84 -- Wetlands/0, Jennabink Powerseam
		1459=sA|m1437|x11.27|y58.42 -- Wetlands/0, Naela Trance
		1461=sA|m1437|x11.33|y59.58 -- Wetlands/0, Murndan Derth
		1462=sA|m1437|x11.11|y58.32 -- Wetlands/0, Edwina Monzor
		2679=sA|m1437|x25.6|y25.8 -- Wetlands/0, Wenna Silkbeard
		1471=sA|m1417|x45.98|y47.71 -- Arathi Highlands/0, Jannos Ironwill
		15127=sA|m1417|x45.96|y45.21 -- Arathi Highlands/0, Samuel Hawke
		1668=sA|m1436|x57.7|y53.93 -- Westfall/0, William MacGregor
		1695=sA|m1444|x89.34|y45.86 -- Feralas/0, Rendow
		7852=sA|m1444|x30.63|y42.7 -- Feralas/0, Pratt McGrubben
		10293=sA|m1444|x30.78|y43.14 -- Feralas/0, Dulciea Frostmoon
		2404=sA|m1424|x32.11|y44.42 -- Hillsbrad Foothills/0, Blacksmith Verringtan
		3543=sA|m1424|x51.21|y56.97 -- Hillsbrad Foothills/0, Robert Aebischer
		3528=sA|m1421|x46.39|y71.87 -- Silverpine Forest/0, Pyrewood Armorer
		3530=sA|m1421|x46.54|y72.39 -- Silverpine Forest/0, Pyrewood Tailor
		3532=sA|m1421|x43.95|y74.09 -- Silverpine Forest/0, Pyrewood Leatherworker
		3588=sA|m1438|x58.71|y39.66 -- Teldrassil/0, Khardan Proudblade
		3589=sA|m1438|x59.3|y41.09 -- Teldrassil/0, Keina
		3590=sA|m1438|x59.45|y41.04 -- Teldrassil/0, Janna Brightmoon
		3591=sA|m1438|x58.98|y39.64 -- Teldrassil/0, Freja Nightwing
		3592=sA|m1438|x58.68|y39.83 -- Teldrassil/0, Andiss
		3609=sA|m1438|x56.3|y59.48 -- Teldrassil/0, Shalomon
		3610=sA|m1438|x55.89|y59.2 -- Teldrassil/0, Jeena Featherbow
		3611=sA|m1438|x56.12|y60.25 -- Teldrassil/0, Brannol Eaglemoon
		3612=sA|m1438|x56.32|y59.58 -- Teldrassil/0, Sinda
		3613=sA|m1438|x56.28|y59.38 -- Teldrassil/0, Meri Ironweave
		4164=sA|m1457|x59.24|y46.36 -- Darnassus/0, Cylania
		4171=sA|m1457|x65.36|y59.74 -- Darnassus/0, Merelyssa
		4172=sA|m1457|x55.67|y89.97 -- Darnassus/0, Anadyia
		4173=sA|m1457|x63.26|y66.26 -- Darnassus/0, Landria
		4175=sA|m1457|x60.66|y72.47 -- Darnassus/0, Vinasia
		4177=sA|m1457|x57.13|y76.98 -- Darnassus/0, Melea
		4180=sA|m1457|x60.6|y72.08 -- Darnassus/0, Ealyshia Dewwhisper
		4203=sA|m1457|x58.76|y44.49 -- Darnassus/0, Ariyell Skyshadow
		4231=sA|m1457|x64.99|y60.21 -- Darnassus/0, Kieran
		4232=sA|m1457|x64.19|y59.07 -- Darnassus/0, Glorandiir
		4233=sA|m1457|x65.19|y60.72 -- Darnassus/0, Mythidan
		4234=sA|m1457|x56.13|y88.9 -- Darnassus/0, Andrus
		4235=sA|m1457|x62.67|y65.58 -- Darnassus/0, Turian
		4236=sA|m1457|x52.9|y80.49 -- Darnassus/0, Cyridan
		4240=sA|m1457|x56.92|y76.33 -- Darnassus/0, Caynrus
		17930=sA|m1943|x49.60|y53.00 -- Azuremyst Isle/0, Nabek
		17929=sA|m1943|x49.60|y52.80 -- Azuremyst Isle/0, Kioni
		17245=sA|m1943|x46.40|y71.00 -- Azuremyst Isle/0, Blacksmith Calypso
		16918=sA|m1943|x80.40|y47.40 -- Azuremyst Isle/0, Jel
		16919=sA|m1943|x79.20|y50.80 -- Azuremyst Isle/0, Mura
		16917=sA|m1943|x80.00|y47.00 -- Azuremyst Isle/0, Aurok
		17667=sA|m1950|x53.40|y56.80 -- Bloodmyst Isle/0, Beega
		16716=sA|m1947|x71.00|y91.40 -- The Exodar/0, Gornii
		16714=sA|m1947|x69.59|y89.60 -- The Exodar/0, Ven
		16753=sA|m1947|x67.14|y95.80 -- The Exodar/0, Gotaan
		16762=sA|m1947|x68.09|y96.40 -- The Exodar/0, Treall
		16765=sA|m1947|x73.30|y84.50 -- The Exodar/0, Ellomin
		16735=sA|m1947|x45.20|y87.40 -- The Exodar/0, Muhaa
		16747=sA|m1947|x70.32|y92.19 -- The Exodar/0, Mahri
		16715=sA|m1947|x47.50|y89.90 -- The Exodar/0, Avelii
		16750=sA|m1947|x67.40|y94.00 -- The Exodar/0, Yil
		16632=sA|m1947|x46.55|y61.57 -- The Exodar/0, Oss
		4183=sA|m1439|x37.57|y40.34 -- Darkshore/0, Naram Longclaw
		4185=sA|m1439|x38.2|y40.42 -- Darkshore/0, Shaldyn
		4186=sA|m1439|x36.99|y41.19 -- Darkshore/0, Mavralyn
		4187=sA|m1439|x37.04|y41.33 -- Darkshore/0, Harlon Thornguard
		6300=sA|m1439|x38.14|y41.1 -- Darkshore/0, Elisa Steelhand
		3951=sA|m1440|x50.27|y67.27 -- Ashenvale/0, Bhaldaran Ravenshade
		3952=sA|m1440|x34.47|y49.51 -- Ashenvale/0, Aeolynn
		3953=sA|m1440|x34.54|y49.9 -- Ashenvale/0, Tandaan Lightmane
		11137=sA|m1440|x35.78|y52.04 -- Ashenvale/0, Xai'ander
		14753=sA|m1440|x61.48|y83.85 -- Ashenvale/0, Illiyana Moonblaze
		17412=sA|m1440|x86.60|y44.20 -- Ashenvale/0, Phaedra
		5102=sA|m1455|x35.75|y65.73 -- Ironforge/0, Dolman Steelfury
		5103=sA|m1455|x35.97|y65.24 -- Ironforge/0, Grenil Steelfury
		5106=sA|m1455|x31.71|y58.27 -- Ironforge/0, Bromiir Ormsen
		5107=sA|m1455|x31.95|y57.92 -- Ironforge/0, Mangorn Flinthammer
		5108=sA|m1455|x32.62|y57.38 -- Ironforge/0, Raena Flinthammer
		5119=sA|m1455|x62.19|y88.16 -- Ironforge/0, Hegnar Swiftaxe
		5120=sA|m1455|x62.36|y88.68 -- Ironforge/0, Brenwyn Wintersteel
		5121=sA|m1455|x62.54|y88.7 -- Ironforge/0, Kelomir Ironhand
		5122=sA|m1455|x71.76|y66.69 -- Ironforge/0, Skolmin Goldfury
		5123=sA|m1455|x72.2|y65.23 -- Ironforge/0, Bretta Goldfury
		5125=sA|m1455|x53.85|y87.89 -- Ironforge/0, Dolkin Craghelm
		5126=sA|m1455|x54.85|y87.4 -- Ironforge/0, Olthran Craghelm
		5129=sA|m1455|x54.7|y87.97 -- Ironforge/0, Lissyphus Finespindle
		5133=sA|m1455|x23.13|y15.93 -- Ironforge/0, Harick Boulderdrum
		5152=sA|m1455|x22.76|y15.91 -- Ironforge/0, Bingus
		5155=sA|m1455|x38.25|y5.15 -- Ironforge/0, Ingrys Stonebrow
		5156=sA|m1455|x38.67|y5.99 -- Ironforge/0, Maeva Snowbraid
		5170=sA|m1455|x44.99|y6.79 -- Ironforge/0, Hjoldir Stoneblade
		4259=sA|m1455|x51.73|y42.78 -- Ironforge/0, Thurgrum Deepforge
		7976=sA|m1455|x61.55|y89.43 -- Ironforge/0, Thalgus Thunderfist
		4886=sA|m1445|x64.62|y50.41 -- Dustwallow Marsh/0, Hans Weston
		4888=sA|m1445|x64.6|y50.07 -- Dustwallow Marsh/0, Marie Holdston
		4889=sA|m1445|x67.5|y47.97 -- Dustwallow Marsh/0, Torq Ironblast
		4890=sA|m1445|x67.39|y47.86 -- Dustwallow Marsh/0, Piter Verance
		4892=sA|m1445|x67.94|y49.89 -- Dustwallow Marsh/0, Jensen Farran
		4188=sA|m1442|x35.59|y7.35 -- Stonetalon Mountains/0, Illyanie
		4257=sA|m1459|x43.41|y15.63 -- ??, Lana Thunderbrew
		13216=sA|m1459|x44.27|y18.24 -- ??, Gaelden Hammersmith
		13217=sA|m1416|x39.44|y81.65 -- Alterac Mountains/0, Thanthaldis Snowgleam
		5508=sA|m1419|x66.08|y17.15 -- Blasted Lands/0, Strumner Flintheel
		11703=sA|m1427|x41.5|y74.96 -- Searing Gorge/0, Graw Cornerstone
		12942=sA|m1422|x43.07|y84.3 -- Western Plaguelands/0, Leonard Porter
		14301=sA|m1447|x12.0|y78.38 -- Azshara/0, Brinna Valanaar
		15315=sA|m1448|x62.4|y25.77 -- Felwood/0, Mylini Frostmoon
		19452=sA|m1944|x88.39|y52.32 -- Hellfire Peninsula/0, Quartermaster Drake
		21209=sA|m1944|x51.20|y59.98 -- Hellfire Peninsula/0, Dumphry
		16823=sA|m1944|x56.77|y63.84 -- Hellfire Peninsula/0, Humphry
		19001=sA|m1944|x23.27|y39.95 -- Hellfire Peninsula/0, Talaara
		19314=sA|m1944|x70.95|y63.25 -- Hellfire Peninsula/0, Supply Officer Shandria
		22227=sA|m1944|x54.67|y63.57 -- Hellfire Peninsula/0, Markus Scylan
		20231=sA|m1944|x78.52|y34.00 -- Hellfire Peninsula/0, Supply Officer Pestle
		18010=sA|m1946|x41.61|y27.28 -- Zangarmarsh/0, Maktu
		19694=sA|m1946|x68.51|y50.21 -- Zangarmarsh/0, Loolruna
		19370=sA|m1948|x36.82|y54.89 -- Shadowmoon Valley/0, Ordinn Thunderfist
		19373=sA|m1948|x36.79|y55.05 -- Shadowmoon Valley/0, Mari Stonehand
		19351=sA|m1948|x36.80|y54.31 -- Shadowmoon Valley/0, Daggle Ironshaper
		19499=sA|m1949|x37.75|y63.80 -- Blade's Edge Mountains/0, Cahill
		21112=sA|m1949|x60.78|y69.07 -- Blade's Edge Mountains/0, Bossi Pentapiston
		19012=sA|m1951|x53.24|y69.84 -- Nagrand/0, Sparik
		21485=sA|m1951|x43.00|y42.60 -- Nagrand/0, Aldraan
		19056=sA|m1952|x56.49|y54.97 -- Terokkar Forest/0, Cecil Meyers
		30241=sA|m127|x74.59|y79.50 -- Crystalsong Forest/0, Lanudal Silverhart
		
		
		-- HORDE --
		3314=sH|m1454|x47.55|y68.38 -- Orgrimmar/0, Urtharo
		3315=sH|m1454|x62.8|y50.43 -- Orgrimmar/0, Tor'phan
		3316=sH|m1454|x62.87|y44.69 -- Orgrimmar/0, Handor
		3317=sH|m1454|x56.51|y73.77 -- Orgrimmar/0, Ollanus
		3319=sH|m1454|x55.97|y72.73 -- Orgrimmar/0, Sana
		3321=sH|m1454|x56.24|y73.21 -- Orgrimmar/0, Morgum
		3322=sH|m1454|x52.14|y62.13 -- Orgrimmar/0, Kaja
		3330=sH|m1454|x44.34|y48.1 -- Orgrimmar/0, Muragus
		3331=sH|m1454|x45.65|y55.96 -- Orgrimmar/0, Kareth
		3349=sH|m1454|x29.73|y74.17 -- Orgrimmar/0, Ukra'nor
		3356=sH|m1454|x82.59|y23.95 -- Orgrimmar/0, Sumi
		3359=sH|m1454|x73.25|y42.25 -- Orgrimmar/0, Kiro
		3360=sH|m1454|x81.47|y18.73 -- Orgrimmar/0, Koru
		3361=sH|m1454|x81.58|y18.86 -- Orgrimmar/0, Shoma
		3409=sH|m1454|x81.15|y18.67 -- Orgrimmar/0, Zendo'jian
		3410=sH|m1454|x78.08|y38.45 -- Orgrimmar/0, Jin'sora
		4043=sH|m1454|x82.29|y18.86 -- Orgrimmar/0, Galthuk
		5812=sH|m1454|x82.58|y23.57 -- Orgrimmar/0, Tumi
		5816=sH|m1454|x44.17|y48.43 -- Orgrimmar/0, Katis
		15528=sH|m1454|x31.20|y74.00 -- Orgrimmar/0, Healer Longrunner
		12799=sH|m1454|x41.46|y68.56 -- Orgrimmar/0, Sergeant Ba'sha
		3159=sH|m1411|x40.46|y68.0 -- Durotar/0, Kzan Thornslash
		3160=sH|m1411|x40.6|y67.8 -- Durotar/0, Huklah
		3161=sH|m1411|x40.47|y67.82 -- Durotar/0, Rarc
		3163=sH|m1411|x52.01|y40.45 -- Durotar/0, Uhgar
		3165=sH|m1411|x52.98|y41.02 -- Durotar/0, Ghrawt
		3166=sH|m1411|x53.11|y40.86 -- Durotar/0, Cutac
		3167=sH|m1411|x51.9|y41.14 -- Durotar/0, Wuark
		10369=sH|m1411|x56.47|y73.11 -- Durotar/0, Trayexir
		980=sH|m1435|x45.08|y50.43 -- Swamp of Sorrows/0, Grimnal
		981=sH|m1435|x45.66|y50.92 -- Swamp of Sorrows/0, Hartash
		984=sH|m1435|x45.06|y51.4 -- Swamp of Sorrows/0, Thralosh
		8176=sH|m1435|x45.46|y51.41 -- Swamp of Sorrows/0, Gharash
		1146=sH|m1434|x32.36|y27.94 -- Stranglethorn Vale/0, Vharr
		1147=sH|m1434|x31.61|y29.18 -- Stranglethorn Vale/0, Hragran
		1381=sH|m1434|x32.57|y27.94 -- Stranglethorn Vale/0, Krakk
		1407=sH|m1418|x2.9|y47.24 -- Badlands/0, Sranda
		2113=sH|m1420|x32.4|y65.66 -- Tirisfal Glades/0, Archibald Kava
		2116=sH|m1420|x32.37|y66.22 -- Tirisfal Glades/0, Blacksmith Rand
		2117=sH|m1420|x32.4|y66.43 -- Tirisfal Glades/0, Harold Raims
		2135=sH|m1420|x60.21|y53.1 -- Tirisfal Glades/0, Abe Winters
		2136=sH|m1420|x60.13|y53.39 -- Tirisfal Glades/0, Oliver Dwor
		2137=sH|m1420|x60.3|y52.81 -- Tirisfal Glades/0, Eliza Callen
		3522=sH|m1420|x52.59|y55.77 -- Tirisfal Glades/0, Constance Brisboise
		2997=sH|m1456|x41.41|y62.36 -- Thunder Bluff/0, Jyn Stonehoof
		2999=sH|m1456|x39.81|y55.64 -- Thunder Bluff/0, Taur Stonehoof
		3015=sH|m1456|x46.99|y45.7 -- Thunder Bluff/0, Kuna Thunderhorn
		3018=sH|m1456|x55.54|y57.07 -- Thunder Bluff/0, Hogor Thunderhoof
		3019=sH|m1456|x54.07|y57.23 -- Thunder Bluff/0, Delgo Ragetotem
		3020=sH|m1456|x53.19|y58.29 -- Thunder Bluff/0, Etu Ragetotem
		3021=sH|m1456|x52.98|y56.63 -- Thunder Bluff/0, Kard Ragetotem
		3022=sH|m1456|x49.62|y48.71 -- Thunder Bluff/0, Sunn Ragetotem
		3023=sH|m1456|x51.59|y55.02 -- Thunder Bluff/0, Sura Wildmane
		3092=sH|m1456|x43.44|y44.33 -- Thunder Bluff/0, Tagain
		3093=sH|m1456|x42.65|y43.51 -- Thunder Bluff/0, Grod
		3095=sH|m1456|x42.75|y44.79 -- Thunder Bluff/0, Fela
		8358=sH|m1456|x45.58|y56.6 -- Thunder Bluff/0, Hewa
		8359=sH|m1456|x45.76|y55.84 -- Thunder Bluff/0, Ahanu
		8360=sH|m1456|x44.96|y56.58 -- Thunder Bluff/0, Elki
		8398=sH|m1456|x52.89|y57.49 -- Thunder Bluff/0, Ohanko
		3073=sH|m1412|x44.06|y77.47 -- Mulgore/0, Marjak Keenblade
		3074=sH|m1412|x44.13|y77.25 -- Mulgore/0, Varia Hardhide
		3075=sH|m1412|x44.2|y77.5 -- Mulgore/0, Bronk Steelrage
		3077=sH|m1412|x45.65|y58.6 -- Mulgore/0, Mahnott Roughwound
		3078=sH|m1412|x45.49|y58.47 -- Mulgore/0, Kennah Hawkseye
		3079=sH|m1412|x45.81|y58.69 -- Mulgore/0, Varg Windwhisper
		3080=sH|m1412|x45.9|y58.73 -- Mulgore/0, Harant Ironbrace
		3343=sH|m1459|x49.67|y82.45 -- Netherstorm, Grelkor
		13218=sH|m1459|x49.32|y82.48 -- Netherstorm, Grunnda Wolfheart
		13219=sH|m1416|x62.83|y59.27 -- Alterac Mountains/0, Jekyll Flandring
		3477=sH|m1413|x51.12|y28.95 -- The Barrens/0, Hraq
		3479=sH|m1413|x51.23|y29.15 -- The Barrens/0, Nargal Deatheye
		3483=sH|m1413|x51.21|y29.04 -- The Barrens/0, Jahan Hawkwing
		3486=sH|m1413|x52.25|y31.85 -- The Barrens/0, Halija Whitestrider
		3488=sH|m1413|x51.11|y29.06 -- The Barrens/0, Uthrok
		3682=sH|m1413|x43.79|y12.21 -- The Barrens/0, Vrang Wildgore
		10380=sH|m1413|x45.11|y59.0 -- The Barrens/0, Sanuye Runetotem
		14754=sH|m1413|x46.65|y8.37 -- The Barrens/0, Kelm Hargunth
		3539=sH|m1424|x60.43|y26.18 -- Hillsbrad Foothills/0, Ott
		3552=sH|m1421|x44.6|y39.11 -- Silverpine Forest/0, Alexandre Lefevre
		3553=sH|m1421|x43.32|y41.34 -- Silverpine Forest/0, Sebastian Meloche
		3554=sH|m1421|x44.79|y39.24 -- Silverpine Forest/0, Andrea Boynton
		9553=sH|m1421|x45.0|y39.29 -- Silverpine Forest/0, Nadia Vernon
		4556=sH|m1458|x61.49|y41.78 -- Undercity/0, Gordon Wendham
		4557=sH|m1458|x61.14|y40.88 -- Undercity/0, Louis Warren
		4558=sH|m1458|x63.82|y37.97 -- Undercity/0, Lauren Newcomb
		4559=sH|m1458|x62.61|y39.7 -- Undercity/0, Timothy Weldon
		4560=sH|m1458|x62.33|y38.67 -- Undercity/0, Walter Ellingson
		4569=sH|m1458|x77.07|y49.39 -- Undercity/0, Charles Seaton
		4570=sH|m1458|x69.45|y27.43 -- Undercity/0, Sydney Upton
		4580=sH|m1458|x71.18|y29.58 -- Undercity/0, Lucille Castleton
		4592=sH|m1458|x77.48|y49.62 -- Undercity/0, Nathaniel Steenwick
		4597=sH|m1458|x61.4|y30.08 -- Undercity/0, Samuel Van Brunt
		4600=sH|m1458|x58.66|y33.06 -- Undercity/0, Geoffrey Hartwell
		4601=sH|m1458|x58.99|y32.58 -- Undercity/0, Francis Eliot
		4602=sH|m1458|x58.81|y32.82 -- Undercity/0, Benijah Fenner
		4603=sH|m1458|x62.71|y26.76 -- Undercity/0, Nicholas Atwood
		4604=sH|m1458|x54.7|y38.75 -- Undercity/0, Abigail Sawyer
		5754=sH|m1458|x69.55|y26.93 -- Undercity/0, Zane Bradford
		5819=sH|m1458|x61.64|y28.94 -- Undercity/0, Mirelle Tremayne
		5820=sH|m1458|x70.33|y58.22 -- Undercity/0, Gillian Moore
		5821=sH|m1458|x70.36|y28.91 -- Undercity/0, Sheldon Von Croy
		4883=sH|m1445|x36.39|y30.84 -- Dustwallow Marsh/0, Krak
		4884=sH|m1445|x36.16|y31.8 -- Dustwallow Marsh/0, Zulrg
		9552=sH|m1445|x35.5|y30.09 -- Dustwallow Marsh/0, Zanara
		6028=sH|m1440|x73.53|y60.3 -- Ashenvale/0, Burkrum
		8159=sH|m1444|x74.7|y42.58 -- Feralas/0, Worb Strongstitch
		9548=sH|m1444|x74.93|y45.7 -- Feralas/0, Cawind Trueaim
		8878=sH|m1443|x55.59|y56.49 -- Desolace/0, Muuran
		12045=sH|m1443|x25.8|y71.01 -- Desolace/0, Hae'Wilani
		9549=sH|m1442|x45.35|y59.1 -- Stonetalon Mountains/0, Borand
		9551=sH|m1441|x44.88|y50.68 -- Thousand Needles/0, Starn
		9555=sH|m1417|x72.52|y33.35 -- Arathi Highlands/0, Mu'uta
		15126=sH|m1417|x73.36|y29.67 -- Arathi Highlands/0, Rutherford Twing
		10361=sH|m1447|x22.22|y51.09 -- Azshara/0, Gruul Darkblade
		10379=sH|m1448|x34.81|y53.15 -- Felwood/0, Altsoba Ragetotem
		14737=sH|m1425|x77.52|y80.35 -- The Hinterlands/0, Smith Slagtree
		16678=sH|m1954|x52.52|y64.42 -- Eversong Woods/0, Rahein
		16626=sH|m1954|x60.90|y86.50 -- Silvermoon City/0, Tynna
		16625=sH|m1954|x61.20|y86.40 -- Silvermoon City/0, Keeli
		16623=sH|m1954|x65.00|y47.80 -- Silvermoon City/0, Zyandrel
		16620=sH|m1954|x86.00|y39.60 -- Silvermoon City/0, Mathaleron
		16693=sH|m1954|x60.20|y86.40 -- Silvermoon City/0, Winthren
		16666=sH|m1954|x52.55|y63.57 -- Eversong Woods/0, Feledis
		16637=sH|m1954|x56.45|y60.50 -- Silvermoon City/0, Welethelon
		16619=sH|m1954|x86.00|y35.20 -- Silvermoon City/0, Celana
		16670=sH|m1954|x79.80|y36.20 -- Silvermoon City/0, Eriden
		16636=sH|m1954|x69.62|y65.64 -- Silvermoon City/0, Zathanna
		16631=sH|m1954|x65.09|y47.60 -- Silvermoon City/0, Andra
		16691=sH|m1954|x55.55|y62.50 -- Silvermoon City/0, Noraelath
		16257=sH|m1941|x48.40|y46.00 -- Eversong Woods/0, Geron
		16258=sH|m1941|x48.60|y46.20 -- Eversong Woods/0, Farsil
		15400=sH|m1941|x59.50|y62.60 -- Eversong Woods/0, Arathel Sunforge
		18926=sH|m1941|x47.00|y47.40 -- Eversong Woods/0, Sleyin
		15292=sH|m1941|x37.60|y18.80 -- Eversong Woods/0, Faraden Thelryn
		15291=sH|m1941|x37.20|y19.20 -- Eversong Woods/0, Jainthess Thelryn
		16263=sH|m1941|x60.00|y62.60 -- Eversong Woods/0, Paelarin
		16260=sH|m1941|x59.40|y62.80 -- Eversong Woods/0, Areyn
		16261=sH|m1941|x43.60|y71.40 -- Eversong Woods/0, Sathiel
		16186=sH|m1941|x47.80|y47.80 -- Eversong Woods/0, Vara
		18426=sH|m1942|x48.40|y33.20 -- Ghostlands/0, Terellia
		17655=sH|m1942|x49.00|y30.40 -- Ghostlands/0, Blacksmith Frances
		16274=sH|m1942|x72.20|y31.80 -- Ghostlands/0, Narina
		16528=sH|m1942|x47.60|y32.20 -- Ghostlands/0, Provisioner Vredigar
		16583=sH|m1944|x53.13|y38.16 -- Hellfire Peninsula/0, Rohok
		19561=sH|m1944|x60.84|y81.61 -- Hellfire Peninsula/0, Hagash the Blind
		18997=sH|m1944|x26.48|y60.07 -- Hellfire Peninsula/0, Fallesh Sunfallow
		19436=sH|m1944|x87.89|y48.30 -- Hellfire Peninsula/0, Supply Master Broog
		19315=sH|m1944|x65.81|y43.56 -- Hellfire Peninsula/0, Supply Officer Isabel
		22225=sH|m1944|x56.81|y37.79 -- Hellfire Peninsula/0, Reagan Mancuso
		21283=sH|m1944|x55.17|y38.79 -- Hellfire Peninsula/0, Megzeg Nukklebust
		19383=sH|m1946|x32.53|y48.10 -- Zangarmarsh/0, Captured Gnome
		18011=sH|m1946|x85.28|y54.76 -- Zangarmarsh/0, Zurai
		19333=sH|m1948|x29.80|y31.26 -- Shadowmoon Valley/0, Grokom Deatheye
		19342=sH|m1948|x29.29|y30.91 -- Shadowmoon Valley/0, Krek Cragcrush
		19339=sH|m1948|x29.92|y31.15 -- Shadowmoon Valley/0, Korthul
		21086=sH|m1949|x75.30|y59.60 -- Blade's Edge Mountains/0, Ruka
		19479=sH|m1949|x51.31|y58.58 -- Blade's Edge Mountains/0, Orgatha
		19473=sH|m1949|x53.10|y59.12 -- Blade's Edge Mountains/0, Raiza
		19011=sH|m1951|x56.08|y37.32 -- Nagrand/0, Osrok the Immovable
		18962=sH|m1952|x49.22|y45.54 -- Terokkar Forest/0, Bar Talet
		30253=sH|m127|x77.80|y49.80 -- Crystalsong Forest/0, Felindel Sunhammer
		32253=sH|m125|x71.30|y31.70 -- Dalaran, Kyunghee
		

		
		-- NEUTRAL --
		1669=sB|m1436|x43.47|y66.75 -- Westfall/0, Defias Profiteer
		2482=sB|m1434|x28.33|y75.46 -- Stranglethorn Vale/0, Zarena Cromwind
		2483=sB|m1434|x35.75|y10.65 -- Stranglethorn Vale/0, Jaquilina Dramet
		2839=sB|m1434|x28.3|y74.55 -- Stranglethorn Vale/0, Haren Kanmae
		2840=sB|m1434|x28.27|y75.21 -- Stranglethorn Vale/0, Kizz Bluntstrike
		2843=sB|m1434|x27.46|y77.54 -- Stranglethorn Vale/0, Jutak
		2844=sB|m1434|x28.96|y75.05 -- Stranglethorn Vale/0, Hurklor
		2845=sB|m1434|x29.04|y74.99 -- Stranglethorn Vale/0, Fargon Mortalak
		2847=sB|m1434|x29.07|y75.48 -- Stranglethorn Vale/0, Jansen Underwood
		2849=sB|m1434|x28.14|y77.56 -- Stranglethorn Vale/0, Qixdi Goodstitch
		14921=sB|m1434|x15.07|y16.0 -- Stranglethorn Vale/0, Rin'wosho the Trader
		3000=sB|m1449|x44.1|y7.19 -- Un'Goro Crater/0, Gibbert
		3053=sB|m1441|x80.39|y77.0 -- Thousand Needles/0, Synge
		3491=sB|m1413|x62.23|y37.47 -- The Barrens/0, Ironzar
		3492=sB|m1413|x62.16|y38.45 -- The Barrens/0, Vexspindle
		3493=sB|m1413|x62.2|y38.41 -- The Barrens/0, Grazlix
		3658=sB|m1413|x61.75|y38.27 -- The Barrens/0, Lizzarik
		3683=sB|m1413|x41.79|y38.69 -- The Barrens/0, Kiknikle
		3684=sB|m1413|x41.77|y38.62 -- The Barrens/0, Pizznukle
		3534=sB|m1421|x46.49|y86.49 -- Silverpine Forest/0, Wallace the Blind
		3536=sB|m1424|x80.14|y38.89 -- Hillsbrad Foothills/0, Kris Legace
		3537=sB|m1424|x55.72|y34.79 -- Hillsbrad Foothills/0, Zixil
		4085=sB|m1442|x62.69|y40.17 -- Stonetalon Mountains/0, Nizzik
		4086=sB|m1442|x58.21|y51.73 -- Stonetalon Mountains/0, Veenix
		5411=sB|m1446|x51.46|y28.81 -- Tanaris/0, Krinkle Goodsteel
		8129=sB|m1446|x50.79|y27.71 -- Tanaris/0, Wrinkle Goodsteel
		8131=sB|m1446|x50.73|y27.53 -- Tanaris/0, Blizrik Buckshot
		20082=sB|m1446|x64.00|y56.40 -- Tanaris/0, Yarley
		4184=sB|m1450|x51.99|y32.89 -- Moonglade/0, Geenia Sunshadow
		12023=sB|m1450|x56.6|y29.94 -- Moonglade/0, Kharedon
		12024=sB|m1450|x51.18|y42.3 -- Moonglade/0, Meliri
		12029=sB|m1450|x53.34|y42.69 -- Moonglade/0, Narianna
		--15909=sB|m80|x54.00|y35.00 -- Moonglade/0,Fariel Starsong MAP?
		8161=sB|m1425|x13.41|y44.14 -- The Hinterlands/0, Harggan
		9179=sB|m1418|x42.46|y52.49 -- Badlands/0, Jazzrik
		10856=sB|m1420|x83.26|y68.14 -- Tirisfal Glades/0, Argent Quartermaster Hasana
		10857=sB|m1422|x42.83|y83.71 -- Western Plaguelands/0, Argent Quartermaster Lightspark
		11278=sB|m1422|x67.99|y77.6 -- Western Plaguelands/0, Magnus Frostwake
		16376=sB|m1423|x81.01|y59.61 -- Eastern Plaguelands/0, Craftsman Wilhelm
		28943=sB|m124|x54.55|y57.52 -- Plaguelands: The Scarlet Enclave/0, Fineous
		28760=sB|m124|x52.80|y35.00 -- Plaguelands: The Scarlet Enclave/0, Hargus the Gimp
		28500=sB|m124|x50.40|y29.20 -- Plaguelands: The Scarlet Enclave/0, Master Siegesmith Corvus
		11182=sB|m1452|x61.62|y37.86 -- Winterspring/0, Nixxrak
		11183=sB|m1452|x61.66|y37.82 -- Winterspring/0, Blixxrak
		11184=sB|m1452|x61.72|y38.02 -- Winterspring/0, Wixxrak
		14624=sB|m1427|x38.8|y28.5 -- Searing Gorge/0, Master Smith Burninate
		15176=sB|m1451|x51.22|y38.85 -- Silithus/0, Vargus
		20112=sB|m1459|x43.19|y50.43 -- Netherstorm/0, Wind Trader Tuluman
		--23159=sB|m339|x61.50|y51.20 -- Black Temple/0, 
		26081=sB|m1426|x17.80|y74.50 -- ??, High Admiral "Shelly" Jorrik
		9544=sB|m1428|x66.00|y22.00 -- Burning Steppes/0, Yuka Screwspigot
		23571=sB|m1445|x42.50|y73.40 -- Dustwallow Marsh/0, Razbo Rustgear
		25046=sB|m1957|x50.60|y40.80 -- Isle of Quel'Danas/0, Smith Hauthaa
		23373=sB|m1946|x51.54|y35.40 -- Zangarmarsh/0, Mortog Steamhead
		17904=sB|m1946|x79.26|y63.67 -- Zangarmarsh/0, Fedryen Swiftspear
		18382=sB|m1946|x17.87|y51.14 -- Zangarmarsh/0, Mycah
		19526=sB|m1948|x63.26|y30.75 -- Shadowmoon Valley/0, Dunaman
		19517=sB|m1948|x55.41|y59.02 -- Shadowmoon Valley/0, Alorra
		23144=sB|m1948|x65.50|y86.45 -- Shadowmoon Valley/0, Gug
		21183=sB|m1948|x53.92|y23.53 -- Shadowmoon Valley/0, Oronok Torn-heart
		19530=sB|m1948|x61.08|y29.69 -- Shadowmoon Valley/0, Darmend
		20917=sB|m1949|x61.59|y38.29 -- Blade's Edge Mountains/0, Zinyen Swiftstrider
		22264=sB|m1949|x29.35|y57.49 -- Blade's Edge Mountains/0, Ogri'la Steelshaper
		18278=sB|m1951|x71.27|y41.32 -- Nagrand/0, Pilot Marsha
		23007=sB|m1951|x30.53|y56.92 -- Nagrand/0, Paulsta'ats
		19879=sB|m1952|x34.60|y66.00 -- Terokkar Forest/0, Horvon the Armorer
		22476=sB|m1952|x30.98|y76.48 -- Terokkar Forest/0, Aundro
		20890=sB|m1952|x37.67|y51.30 -- Terokkar Forest/0, Siflaed Coldhammer
		19575=sB|m1953|x32.65|y66.74 -- Netherstorm/0, Qiff 
		22491=sB|m1953|x66.03|y67.30 -- Netherstorm/0, Kerpow Blastwrench
		20463=sB|m1953|x57.71|y85.19 -- Netherstorm/0, Apprentice Andrethan
		28344=sB|m1953|x32.39|y64.38 -- Netherstorm/0, Blazzle
		19536=sB|m1953|x43.96|y36.66 -- Netherstorm/0, Dealer Jadyan
		19240=sB|m1955|x42.00|y75.20 -- Shattrath City/0, Selanam the Blade
		19236=sB|m1955|x44.50|y76.09 -- Shattrath City/0, Quelama Lightblade
		19238=sB|m1955|x49.50|y79.09 -- Shattrath City/0, Urumir Stavebright
		19239=sB|m1955|x54.55|y82.52 -- Shattrath City/0, Mahir Redstroke
		19662=sB|m1955|x64.00|y71.60 -- Shattrath City/0, Aaron Hollman
		27711=sB|m1955|x28.00|y47.50 -- Shattrath City/0, Technician Halmaha
		20616=sB|m1955|x23.55|y32.40 -- Shattrath City/0, Asuur
		25196=sB|m1955|x41.50|y63.40 -- Shattrath City/0, Archer Delvinar
		25195=sB|m1955|x37.50|y27.80 -- Shattrath City/0, Marksman Bova
		27667=sB|m1955|x48.65|y42.65 -- Shattrath City/0, Anwehu
		19047=sB|m1955|x52.00|y16.40 -- Shattrath City/0, Lissaf
		19043=sB|m1955|x34.44|y19.25 -- Shattrath City/0, Ahemen
		20613=sB|m1955|x43.60|y90.40 -- Shattrath City/0, Arodis Sunblade
		--14371=sB|m9005|x81.80|y25.50 -- Dire Maul/0, 
		28989=sB|m125|x60.50|y52.20 -- Dalaran, Aemara
		28990=sB|m125|x46.67|y27.64 -- Dalaran, Anthony Durain
		29499=sB|m125|x54.00|y61.40 -- Dalaran, Bartram Haller
		29523=sB|m125|x51.00|y71.59 -- Dalaran, Bragund Brightlink
		28722=sB|m125|x39.00|y25.00 -- Dalaran, Bryan Landers
		29476=sB|m125|x59.75|y52.20 -- Dalaran, Dagna Flintlock
		34252=sB|m125|x46.45|y27.60 -- Dalaran, Dubin Clay
		28997=sB|m125|x46.65|y27.57 -- Dalaran, Griselda Hunderland
		29538=sB|m125|x60.55|y11.65 -- Dalaran, Hexil Garrot
		35498=sB|m125|x46.50|y27.00 -- Dalaran, Horace Hunderland
		29496=sB|m125|x54.65|y62.40 -- Dalaran, Kerta the Bold
		28995=sB|m125|x43.50|y50.35 -- Dalaran, Paldesse
		28716=sB|m125|x45.65|y28.57 -- Dalaran, Palja Amboss
		35497=sB|m125|x50.70|y70.59 -- Dalaran, Rafael Langrom
		29494=sB|m125|x49.00|y71.50 -- Dalaran, Shen Kang Cheng
		28991=sB|m125|x54.52|y62.59 -- Dalaran, Valaden Silverblade
		28992=sB|m125|x51.50|y72.27 -- Dalaran, Valerie Langrom
		29497=sB|m125|x55.34|y64.20 -- Dalaran, Walther Whiteford
		35500=sB|m125|x52.20|y72.70 -- Dalaran, Matilda Brightlink
		35496=sB|m125|x43.70|y48.60 -- Dalaran, Rueben Lauren
		--37687=sB|m186|x36.54|y20.55 -- Icecrown Citadel/1,Alchemist Finklestein
		--37688=sB|m186|x38.20|y21.50 -- Icecrown Citadel/1,Crusader Grimtong
		--37696=sB|m186|x37.65|y21.50 -- Icecrown Citadel/1,Crusader Halford
		--38858=sB|m186|x36.20|y20.60 -- Icecrown Citadel/1,Goodman the "Closer"
		--38316=sB|m186|x40.00|y21.50 -- Icecrown Citadel/1,Ormus the Penitent
		--38054=sB|m186|x36.20|y20.60 -- Icecrown Citadel/1,Scott the Merciful
		--33669=sB|m147|x54.00|y87.20 -- Ulduar/1/0,Demolisher Engineer Blastwrench
		--31027=sB|m130|x50.40|y58.39 -- The Culling of Stratholme/1,Leeka Turner
		--31024=sB|m130|x83.60|y59.40 -- The Culling of Stratholme/1/0,Brock Thriss
	]],
	["Auctioneer"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		8670=sA|m1453|x60.84|y71.52|wInside the building -- Stormwind City/0, Auctioneer Chilton (Checked 8/24/2022)
		8719=sA|m1453|x61.18|y71.28|wInside the building -- Stormwind City/0, Auctioneer Fitch (Checked 8/24/2022)
		15659=sA|m1453|x61.15|y70.68|wInside the building -- Stormwind City/0, Auctioneer Jaxon (Checked 8/24/2022)

		8669=sA|m1457|x56.37|y51.82 -- Darnassus/0, Auctioneer Tolon
		8723=sA|m1457|x56.24|y54.03 -- Darnassus/0, Auctioneer Golothas
		15678=sA|m1457|x57.3|y53.56 -- Darnassus/0, Auctioneer Silva'las
		15679=sA|m1457|x55.58|y52.44 -- Darnassus/0, Auctioneer Cazarez
		16707=sA|m1947|x63.50|y58.40 -- The Exodar/0, Eoch
		18349=sA|m1947|x63.20|y58.50 -- The Exodar/0, Iressa
		18348=sA|m1947|x62.80|y58.40 -- The Exodar/0, Fanin
		8671=sA|m1455|x23.77|y71.78 -- Ironforge/0, Auctioneer Buckler
		8720=sA|m1455|x24.16|y74.66 -- Ironforge/0, Auctioneer Redmuse
		9859=sA|m1455|x25.8|y75.55 -- Ironforge/0, Auctioneer Lympkin
		-- HORDE --
		8672=sH|m1458|x67.54|y52.41 -- Undercity/0, Auctioneer Leeka
		8721=sH|m1458|x64.41|y52.41 -- Undercity/0, Auctioneer Epitwee
		15675=sH|m1458|x71.42|y46.68 -- Undercity/0, Auctioneer Stockton
		15676=sH|m1458|x71.5|y41.9 -- Undercity/0, Auctioneer Yarly
		15682=sH|m1458|x67.65|y35.89 -- Undercity/0, Auctioneer Cain
		15683=sH|m1458|x64.39|y35.8 -- Undercity/0, Auctioneer Naxxremis
		15684=sH|m1458|x60.49|y41.75 -- Undercity/0, Auctioneer Tricket
		15686=sH|m1458|x60.46|y46.44 -- Undercity/0, Auctioneer Rhyker
		18761=sH|m1954|x60.40|y61.40 -- Silvermoon City/0, Darise
		16628=sH|m1954|x92.85|y59.50 -- Silvermoon City/0, Caidori
		16629=sH|m1954|x92.70|y57.00 -- Silvermoon City/0, Tandron
		16627=sH|m1954|x92.50|y58.30 -- Silvermoon City/0, Ithillan
		17627=sH|m1954|x59.67|y62.52 -- Silvermoon City/0, Jenath
		17629=sH|m1954|x61.85|y62.52 -- Silvermoon City/0, Feynna
		17628=sH|m1954|x60.60|y63.60 -- Silvermoon City/0, Vynna
		8673=sH|m1454|x55.9|y62.71 -- Orgrimmar/0, Auctioneer Thathung
		8724=sH|m1454|x55.83|y64.81 -- Orgrimmar/0, Auctioneer Wabang
		9856=sH|m1454|x55.25|y61.78 -- Orgrimmar/0, Auctioneer Grimful
		8674=sH|m1456|x40.41|y51.76 -- Thunder Bluff/0, Auctioneer Stampi
		8722=sH|m1456|x38.89|y50.19 -- Thunder Bluff/0, Auctioneer Gullem
		-- NEUTRAL --
		8661=sB|m1446|x51.95|y29.65 -- Tanaris/0, Auctioneer Beardo
		9857=sB|m1452|x61.44|y37.2 -- Winterspring/0, Auctioneer Grizzlin
		9858=sB|m1434|x27.77|y77.04 -- Stranglethorn Vale/0, Auctioneer Kresky
		15677=sB|m1434|x28.42|y75.91 -- Stranglethorn Vale/0, Auctioneer Graves
		15681=sB|m1434|x26.58|y76.34 -- Stranglethorn Vale/0, Auctioneer O'reely
	]],
	["Banker"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		2455=sA|m1453|x64.29|y80.75|wInside the building -- Stormwind City/0, Olivia Burnside (Checked 8/24/2022)
		2456=sA|m1453|x63.87|y81.10|wInside the building -- Stormwind City/0, Newton Burnside (Checked 8/24/2022)
		2457=sA|m1453|x63.44|y81.44|wInside the building -- Stormwind City/0, John Burnside (Checked 8/24/2022)

		2460=sA|m1455|x34.96|y58.41 -- Ironforge/0, Barnum Stonemantle
		2461=sA|m1455|x35.92|y60.14 -- Ironforge/0, Bailey Stonemantle
		5099=sA|m1455|x36.81|y61.86 -- Ironforge/0, Soleil Stonemantle
		4155=sA|m1457|x39.38|y42.43 -- Darnassus/0, Idriana
		4208=sA|m1457|x39.68|y41.53 -- Darnassus/0, Lairn
		4209=sA|m1457|x39.6|y41.98 -- Darnassus/0, Garryeth
		18350=sA|m1947|x45.60|y43.80 -- The Exodar/0, Jaela
		17773=sA|m1947|x45.55|y44.52 -- The Exodar/0, Ossco
		16710=sA|m1947|x45.60|y43.40 -- The Exodar/0, Kellag
		-- HORDE --
		2458=sH|m1458|x65.93|y43.42 -- Undercity/0, Randolph Montague
		2459=sH|m1458|x66.41|y44.06 -- Undercity/0, Mortimer Montague
		2996=sH|m1456|x47.62|y58.58 -- Thunder Bluff/0, Torn
		3309=sH|m1454|x49.58|y69.11 -- Orgrimmar/0, Karus
		3318=sH|m1454|x50.0|y68.57 -- Orgrimmar/0, Koma
		3320=sH|m1454|x49.08|y69.59 -- Orgrimmar/0, Soran
		4549=sH|m1458|x65.96|y44.75 -- Undercity/0, William Montague
		4550=sH|m1458|x65.55|y44.07 -- Undercity/0, Ophelia Montague
		8356=sH|m1456|x47.13|y57.89 -- Thunder Bluff/0, Chesmu
		8357=sH|m1456|x47.2|y59.32 -- Thunder Bluff/0, Atepa
		17632=sH|m1954|x67.40|y79.00 -- Silvermoon City/0, Elana
		17633=sH|m1954|x67.40|y76.60 -- Silvermoon City/0, Hatheon
		17631=sH|m1954|x67.40|y77.80 -- Silvermoon City/0, Ceera
		16615=sH|m1954|x89.00|y43.40 -- Silvermoon City/0, Novia
		16617=sH|m1954|x90.50|y43.20 -- Silvermoon City/0, Daenice
		16616=sH|m1954|x89.80|y43.60 -- Silvermoon City/0, Periel
		19318=sH|m1955|x48.40|y29.20 -- Shattrath City/0, Gromden
		-- NEUTRAL --
		2625=sB|m1434|x26.53|y76.57 -- Stranglethorn Vale/0, Viznik Goldgrubber
		8123=sB|m1434|x26.51|y76.46 -- Stranglethorn Vale/0, Rickle Goldgrubber
		3496=sB|m1413|x62.63|y37.42 -- The Barrens/0, Fuzruckle
		3683=sB|m1413|x41.79|y38.69 -- The Barrens/0, Kiknikle
		8119=sB|m1413|x62.67|y37.39 -- The Barrens/0, Zikkel
		7799=sB|m1446|x52.29|y28.91 -- Tanaris/0, Gimblethorn
		8124=sB|m1446|x52.37|y28.94 -- Tanaris/0, Qizzik
		13917=sB|m1452|x61.45|y36.97 -- Winterspring/0, Izzy Coppergrab
		21733=sB|m1953|x32.81|y68.03 -- Netherstorm/0, Karzo
		28343=sB|m1953|x32.37|y67.18 -- Netherstorm/0, Meeda
		21734=sB|m1953|x32.64|y67.95 -- Netherstorm/0, Zixxy
		21732=sB|m1953|x32.97|y67.94 -- Netherstorm/0, Nandirx
		19246=sB|m1955|x58.90|y61.40 -- Shattrath City/0, Berudan Keysworn
		19034=sB|m1955|x49.40|y28.25 -- Shattrath City/0, Mendorn
		19338=sB|m1955|x59.65|y60.34 -- Shattrath City/0, L'lura Goldspun
		29530=sB|m125|x32.40|y53.40 -- Dalaran, Binzik Goldbook
		28677=sB|m125|x53.55|y15.57 -- Dalaran, Teller Hanners
		29282=sB|m125|x53.40|y15.60 -- ??, Paymaster Alstein
		30608=sB|m125|x42.85|y79.42 -- Dalaran, Paymaster Amadi
		30606=sB|m125|x43.52|y79.59 -- Dalaran, Paymaster Chang
		30604=sB|m125|x44.10|y79.59 -- Dalaran, Teller Almeida
		30605=sB|m125|x43.50|y78.40 -- Dalaran, Teller Gee
		28676=sB|m125|x54.20|y16.20 -- Dalaran, Teller Althiellis
		30607=sB|m125|x42.65|y78.44 -- Dalaran, Teller Plushner
		28675=sB|m125|x52.55|y15.47 -- Dalaran, Teller Rames
	]],
	["Flight master"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		352=sA|m1453|x70.95|y72.51|wInside the building -- Stormwind City/0, Dungar Longdrink (Checked 8/24/2022)
		523=sA|m1436|x56.55|y52.64 -- Westfall/0, Thor
		931=sA|m1433|x30.58|y59.41 -- Redridge Mountains/0, Ariena Stormfeather
		1571=sA|m1437|x9.49|y59.69 -- Wetlands/0, Shellei Brondir
		1572=sA|m1432|x33.93|y50.95 -- Loch Modan/0, Thorgrum Borrelson
		1573=sA|m1455|x55.5|y47.74 -- Ironforge/0, Gryth Thurden
		2299=sA|m1428|x84.33|y68.32 -- Burning Steppes/0, Borgus Stoutarm
		2409=sA|m1431|x77.48|y44.28 -- Duskwood/0, Felicia Maline
		2432=sA|m1424|x49.33|y52.27 -- Hillsbrad Foothills/0, Darla Harris
		2835=sA|m1417|x45.75|y46.11 -- Arathi Highlands/0, Cedrik Prose
		2859=sA|m1434|x27.52|y77.78 -- Stranglethorn Vale/0, Gyll
		24366=sA|m1434|x38.20|y4.00 -- Stranglethorn Vale/0, Nizzle
		2941=sA|m1427|x37.93|y30.86 -- Searing Gorge/0, Lanie Reed
		3838=sA|m1438|x58.39|y94.01 -- Teldrassil/0, Vesprystus
		17555=sA|m1947|x68.59|y63.40 -- The Exodar/0, Stephanos
		17554=sA|m1950|x57.60|y54.00 -- Bloodmyst Isle/0, Laando
		3841=sA|m1439|x36.33|y45.57 -- Darkshore/0, Caylais Moonfeather
		4267=sA|m1440|x34.4|y47.98 -- Ashenvale/0, Daelyshia
		22935=sA|m1440|x85.00|y43.40 -- Ashenvale/0, Suralais Farwind
		4319=sA|m1444|x89.49|y45.85 -- Feralas/0, Thyssiana
		8019=sA|m1444|x30.23|y43.24 -- Feralas/0, Fyldren Moonfeather
		4321=sA|m1445|x67.47|y51.3 -- Dustwallow Marsh/0, Baldruc
		4407=sA|m1442|x36.43|y7.18 -- Stonetalon Mountains/0, Teloren
		7823=sA|m1446|x51.0|y29.34 -- Tanaris/0, Bera Stonehammer
		6706=sA|m1443|x64.65|y10.53 -- Desolace/0, Baritanas Skyriver
		8609=sA|m1419|x65.53|y24.33 -- Blasted Lands/0, Alexandra Constantine
		10897=sA|m1450|x48.1|y67.34 -- Moonglade/0, Sindrayl
		11138=sA|m1452|x62.33|y36.6 -- Winterspring/0, Maethrya
		12577=sA|m1447|x11.9|y77.58 -- Azshara/0, Jarrodenus
		12578=sA|m1448|x62.48|y24.24 -- Felwood/0, Mishellena
		12596=sA|m1422|x42.92|y85.06 -- Western Plaguelands/0, Bibilfaz Featherwhistle
		12617=sA|m1423|x81.63|y59.27 -- Eastern Plaguelands/0, Khaelyn Steelwing
		15177=sA|m1451|x50.58|y34.44 -- Silithus/0, Cloud Skydancer
		18785=sA|m1944|x25.19|y37.23 -- Hellfire Peninsula/0, Kuma
		20234=sA|m1944|x78.41|y34.90 -- Hellfire Peninsula/0, Runetog Wildhammer
		16822=sA|m1944|x54.68|y62.34 -- Hellfire Peninsula/0, Flightmaster Krill Bitterhue
		18931=sA|m1944|x87.36|y52.42 -- Hellfire Peninsula/0, Amish Wildhammer
		22485=sA|m1946|x41.29|y29.00 -- Zangarmarsh/0, Halu
		18788=sA|m1946|x67.83|y51.46 -- Zangarmarsh/0, Munci
		18939=sA|m1948|x37.61|y55.45 -- Shadowmoon Valley/0, Brubeck Stormfoot
		21107=sA|m1949|x61.15|y70.44 -- Blade's Edge Mountains/0, Rip Pedalslam
		18937=sA|m1949|x37.82|y61.40 -- Blade's Edge Mountains/0, Amerun Leafshade
		18789=sA|m1951|x54.20|y75.00 -- Nagrand/0, Furgu
		18809=sA|m1952|x59.45|y55.43 -- Terokkar Forest/0, Furnan Skysoar
		-- HORDE --
		1387=sH|m1434|x32.53|y29.35 -- Stranglethorn Vale/0, Thysta
		2858=sH|m1434|x26.87|y77.09 -- Stranglethorn Vale/0, Gringer
		2226=sH|m1421|x45.62|y42.59 -- Silverpine Forest/0, Karos Razok
		2389=sH|m1424|x60.14|y18.62 -- Hillsbrad Foothills/0, Zarise
		2851=sH|m1417|x73.06|y32.68 -- Arathi Highlands/0, Urda
		2861=sH|m1418|x3.98|y44.78 -- Badlands/0, Gorrik
		2995=sH|m1456|x47.0|y49.83 -- Thunder Bluff/0, Tal
		3305=sH|m1427|x34.83|y30.87 -- Searing Gorge/0, Grisha
		3310=sH|m1454|x45.11|y63.88 -- Orgrimmar/0, Doras
		3615=sH|m1413|x51.5|y30.33 -- The Barrens/0, Devrak
		10378=sH|m1413|x44.44|y59.15 -- The Barrens/0, Omusa Thunderhorn
		4312=sH|m1442|x45.12|y59.84 -- Stonetalon Mountains/0, Tharm
		7824=sH|m1446|x51.6|y25.44 -- Tanaris/0, Bulkrek Ragefist
		4314=sH|m1425|x81.7|y81.75 -- The Hinterlands/0, Gorkas
		4317=sH|m1441|x45.14|y49.1 -- Thousand Needles/0, Nyse
		4551=sH|m1458|x63.25|y48.55 -- Undercity/0, Michael Garrett
		6026=sH|m1435|x46.07|y54.82 -- Swamp of Sorrows/0, Breyk
		6726=sH|m1443|x21.6|y74.13 -- Desolace/0, Thalon
		8020=sH|m1444|x75.44|y44.35 -- Feralas/0, Shyn
		8610=sH|m1447|x21.95|y49.61 -- Azshara/0, Kroum
		11139=sH|m1452|x60.47|y36.3 -- Winterspring/0, Yugrek
		11899=sH|m1445|x35.56|y31.88 -- Dustwallow Marsh/0, Shardi
		11900=sH|m1448|x34.44|y53.96 -- Felwood/0, Brakkar
		11901=sH|m1440|x12.23|y33.8 -- Ashenvale/0, Andruk
		12616=sH|m1440|x73.18|y61.58 -- Ashenvale/0, Vhulgra
		12636=sH|m1423|x80.22|y57.0 -- Eastern Plaguelands/0, Georgia
		12740=sH|m1450|x32.09|y66.6 -- Moonglade/0, Faustron
		13177=sH|m1428|x65.68|y24.22 -- Burning Steppes/0, Vahgruk
		15178=sH|m1451|x48.68|y36.67 -- Silithus/0, Runk Windtamer
		16192=sH|m1941|x54.40|y50.80 -- Eversong Woods/0, Skymistress Gloaming
		16189=sH|m1942|x45.40|y30.50 -- Ghostlands/0, Skymaster Sunwing
		26560=sB|m1957|x48.40|y25.20 -- Isle of Quel'Danas/0, Ohura
		16587=sH|m1944|x56.29|y36.25 -- Hellfire Peninsula/0, Barley
		18930=sH|m1944|x87.35|y48.14 -- Hellfire Peninsula/0, Vlagga Freyfeather
		19558=sH|m1944|x61.65|y81.20 -- Hellfire Peninsula/0, Amilya Airheart
		18942=sH|m1944|x27.80|y59.98 -- Hellfire Peninsula/0, Innalia
		18791=sH|m1946|x33.07|y51.07 -- Zangarmarsh/0, Du'ga
		20762=sH|m1946|x84.77|y55.11 -- Zangarmarsh/0, Gur'zil
		19317=sH|m1948|x30.34|y29.18 -- Shadowmoon Valley/0, Drek'Gol
		18953=sH|m1949|x52.05|y54.12 -- Blade's Edge Mountains/0, Unoke Tenderhoof
		22455=sH|m1949|x76.37|y65.93 -- Blade's Edge Mountains/0, Sky-Master Maxxor
		18808=sH|m1951|x57.19|y35.25 -- Nagrand/0, Gursha
		18807=sH|m1952|x49.19|y43.42 -- Terokkar Forest/0, Kerna
		-- NEUTRAL --
		8018=sB|m1425|x11.07|y46.15 -- The Hinterlands/0, Guthrum Thunderfist
		10583=sB|m1449|x45.23|y5.83 -- Un'Goro Crater/0, Gryfe
		16227=sB|m1413|x63.08|y37.16 -- The Barrens/0, Bragok
		23612=sB|m1445|x42.80|y72.40 -- Dustwallow Marsh/0, Dyslix Silvergrub
		22931=sB|m1448|x51.40|y82.20 -- Felwood/0, Gorrim
		24851=sB|m1942|x74.60|y67.00 -- Ghostlands/0, Kiz Coilspanner
		21766=sB|m1948|x56.32|y57.80 -- Shadowmoon Valley/0, Alieshor
		19581=sB|m1948|x63.33|y30.40 -- Shadowmoon Valley/0, Maddix
		22216=sB|m1949|x61.68|y39.61 -- Blade's Edge Mountains/0, Fhyn Leafshadow
		20515=sB|m1953|x65.20|y66.81 -- Netherstorm/0, Harpax
		19583=sB|m1953|x45.31|y34.87 -- Netherstorm/0, Grennik
		18938=sB|m1953|x33.74|y63.99 -- Netherstorm/0, Krexcil
		18940=sB|m1955|x63.80|y41.00 -- Shattrath City/0, Nutral
	]],
	["Innkeeper"] = [[
		-- ALLIANCE --
		25245=sA|m114|x58.29|y68.05|wInside the building -- Borean Tundra/0, James Deacon (Checked 9/21/2022)
		24057=sA|m117|x60.48|y15.86|wInside the building -- Howling Fjord/0, Christina Daniels (checked 9/22/2022)
		23937=sA|m117|x30.86|y41.46 -- Howling Fjord/0, Innkeeper Celeste Goodhutch (checked 9/22/2022)
		23731=sA|m117|x58.39|y62.45 -- Howling Fjord/0, Innkeeper Hazel Lagras (checked 9/22/2022)
		27042=sA|m115|x77.42|y51.68|wWalking around inside the building -- Dragonblight/0, Illusia Lune (checked 9/23/2022)
		27052=sA|m115|x28.89|y56.09 -- Dragonblight/0, Naohain (checked 9/23/2022)
		27066=sA|m116|x31.97|y60.28|wInside the building -- Grizzly Hills/0, Jennifer Bell (checked 9/23/2022)
		33970=sA|m118|x76.20|y19.50 -- ??, Caris Sunlance
		26375=sA|m116|x59.56|y26.30 -- Grizzly Hills/0, Quartermaster McCarty (checked 9/28/2022)
		
		-- HORDE --
		25278=sH|m114|x41.92,|y54.48|wInside the building -- Borean Tundra/0, Williamson (checked 9/21/2022)
		24149=sH|m117|x52.15|y66.41 -- Howling Fjord/0, Basil Osgood (checked 9/22/2022)
		24342=sH|m117|x79.73|y30.84|wInside the building -- Howling Fjord/0, Timothy Holland (checked 9/22/2022)
		33971=sH|m118|x76.00|y24.00 -- ??, Jarin Dawnglow

		-- NEUTRAL --
		28791=sB|m121|x40.83|y66.25|wInside the building -- Zul'Drak/0, Marissa Everwatch (checked 9/26/2022)

		-- ALLIANCE --
		6740=sA|m1453|x60.38|y75.27|wInside the building -- Stormwind City/0, Innkeeper Allison (Checked 8/24/2022)
		295=sA|m1429|x43.77|y65.8 -- Elwynn Forest/0, Innkeeper Farley
		1247=sA|m1426|x47.37|y52.52 -- Dun Morogh/0, Innkeeper Belm
		1464=sA|m1437|x10.69|y60.95 -- Wetlands/0, Innkeeper Helbrek
		2352=sA|m1424|x51.16|y58.92 -- Hillsbrad Foothills/0, Innkeeper Anderson
		5111=sA|m1455|x18.15|y51.44 -- Ironforge/0, Innkeeper Firebrew
		6272=sA|m1445|x66.58|y45.22 -- Dustwallow Marsh/0, Innkeeper Janene
		6727=sA|m1433|x27.0|y44.82 -- Redridge Mountains/0, Innkeeper Brianna
		6734=sA|m1432|x35.53|y48.4 -- Loch Modan/0, Innkeeper Hearthstove
		6735=sA|m1457|x67.42|y15.64 -- Darnassus/0, Innkeeper Saelienne
		6736=sA|m1438|x55.61|y59.78 -- Teldrassil/0, Innkeeper Keldamyr
		17553=sA|m1950|x55.80|y59.60 -- Bloodmyst Isle/0, Caregiver Topher Loaal
		16553=sA|m1943|x48.40|y49.20 -- Azuremyst Isle/0, Caregiver Chellan
		16739=sA|m1947|x59.55|y19.69 -- The Exodar/0, Caregiver Breel
		6737=sA|m1439|x37.04|y44.12 -- Darkshore/0, Innkeeper Shaussiy
		6738=sA|m1440|x36.98|y49.21 -- Ashenvale/0, Innkeeper Kimlya
		6790=sA|m1431|x73.87|y44.4 -- Duskwood/0, Innkeeper Trelayne
		7736=sA|m1444|x30.96|y43.48 -- Feralas/0, Innkeeper Shyria
		8931=sA|m1436|x52.86|y53.71 -- Westfall/0, Innkeeper Heather
		11103=sA|m1443|x66.27|y6.55 -- Desolace/0, Innkeeper Lyshaerya
		16458=sA|m1442|x35.78|y5.73 -- Stonetalon Mountains/0, Innkeeper Faralia
		16826=sA|m1944|x54.22|y63.60 -- Hellfire Peninsula/0, Sid Limbardi
		18906=sA|m1944|x23.35|y36.36 -- Hellfire Peninsula/0, Caregiver Ophera Windfury
		18251=sA|m1946|x67.14|y49.03 -- Zangarmarsh/0, Caregiver Abidaar
		18908=sA|m1946|x41.85|y26.22 -- Zangarmarsh/0, Innkeeper Kerp
		19352=sA|m1948|x37.06|y58.26 -- Shadowmoon Valley/0, Dreg Cloudsweeper
		19495=sA|m1949|x35.80|y63.88 -- Blade's Edge Mountains/0, Innkeeper Shaunessy
		21110=sA|m1949|x60.98|y68.11 -- Blade's Edge Mountains/0, Fizit "Doc" Clocktock
		18914=sA|m1951|x54.22|y76.10 -- Nagrand/0, Caregiver Isel
		19296=sA|m1952|x56.70|y53.27 -- Terokkar Forest/0, Innkeeper Biribi
		
		
		-- HORDE --
		2388=sH|m1424|x62.77|y19.02 -- Hillsbrad Foothills/0, Innkeeper Shay
		3934=sH|m1413|x51.98|y29.89 -- The Barrens/0, Innkeeper Boorand Plainswind
		7714=sH|m1413|x45.57|y59.03 -- The Barrens/0, Innkeeper Byula
		5688=sH|m1420|x61.7|y52.04 -- Tirisfal Glades/0, Innkeeper Renee
		5814=sH|m1434|x31.48|y29.75 -- Stranglethorn Vale/0, Innkeeper Thulbek
		6739=sH|m1421|x43.17|y41.27 -- Silverpine Forest/0, Innkeeper Bates
		6741=sH|m1458|x67.73|y37.89 -- Undercity/0, Innkeeper Norman
		6746=sH|m1456|x45.81|y64.71 -- Thunder Bluff/0, Innkeeper Pala
		6747=sH|m1412|x46.62|y61.09 -- Mulgore/0, Innkeeper Kauth
		6928=sH|m1411|x51.51|y41.64 -- Durotar/0, Innkeeper Grosk
		6929=sH|m1454|x54.09|y68.4 -- Orgrimmar/0, Innkeeper Gryshka
		6930=sH|m1435|x45.16|y56.66 -- Swamp of Sorrows/0, Innkeeper Karakul
		7731=sH|m1442|x47.46|y62.12 -- Stonetalon Mountains/0, Innkeeper Jayka
		7737=sH|m1444|x74.8|y45.18 -- Feralas/0, Innkeeper Greul
		9356=sH|m1418|x2.81|y45.85 -- Badlands/0, Innkeeper Shul'kar
		9501=sH|m1417|x73.84|y32.46 -- Arathi Highlands/0, Innkeeper Adegwa
		11106=sH|m1443|x24.09|y68.21 -- Desolace/0, Innkeeper Sikewa
		11116=sH|m1441|x46.07|y51.51 -- Thousand Needles/0, Innkeeper Abeqwa
		12196=sH|m1440|x73.99|y60.64 -- Ashenvale/0, Innkeeper Kaylisk
		14731=sH|m1425|x78.14|y81.37 -- The Hinterlands/0, Lard
		24208=sH|m1445|x36.80|y32.20 -- Dustwallow Marsh/0, "Little" Logok
		15433=sH|m1941|x48.00|y47.60 -- Eversong Woods/0, Innkeeper Delaniel
		15397=sH|m1941|x43.60|y71.20 -- Eversong Woods/0, Marniel Amberlight
		16542=sH|m1942|x48.80|y32.20 -- Ghostlands/0, Innkeeper Kalarin
		17630=sH|m1954|x67.59|y72.80 -- Silvermoon City/0, Innkeeper Jovia
		16618=sH|m1954|x79.60|y58.40 -- Silvermoon City/0, Innkeeper Velandra
		16602=sH|m1944|x56.71|y37.47 -- Hellfire Peninsula/0, Floyd Pinkus
		18905=sH|m1944|x26.88|y59.54 -- Hellfire Peninsula/0, Innkeeper Bazil Olof'tazun
		18245=sH|m1946|x30.66|y50.93 -- Zangarmarsh/0, Merajit
		19319=sH|m1948|x30.22|y27.75 -- Shadowmoon Valley/0, Innkeeper Darg Bloodclaw
		19470=sH|m1949|x53.36|y55.41 -- Blade's Edge Mountains/0, Gholah
		21088=sH|m1949|x76.09|y60.31 -- Blade's Edge Mountains/0, Matron Varah
		18913=sH|m1951|x56.73|y34.51 -- Nagrand/0, Matron Tikkit
		18957=sH|m1952|x48.76|y45.05 -- Terokkar Forest/0, Innkeeper Grilka
		
		
		-- NEUTRAL --
		6791=sB|m1413|x62.04|y39.4 -- The Barrens/0, Innkeeper Wiley
		6807=sB|m1434|x27.03|y77.31 -- Stranglethorn Vale/0, Innkeeper Skindle
		7733=sB|m1446|x52.5|y27.91 -- Tanaris/0, Innkeeper Fizzgrimble
		18542=sB|m1446|x66.40|y49.50 -- Tanaris/0, Alexston Chrome
		7744=sB|m1425|x14.14|y41.56 -- The Hinterlands/0, Innkeeper Thulfram
		11118=sB|m1452|x61.35|y38.83 -- Winterspring/0, Innkeeper Vizzie
		15174=sB|m1451|x51.89|y39.16 -- Silithus/0, Calandrath
		16256=sB|m1423|x81.62|y58.07 -- Eastern Plaguelands/0, Jessica Chambers
		25036=sB|m1957|x51.10|y33.59 -- Isle of Quel'Danas/0, Caregiver Inaara
		23995=sB|m1445|x41.80|y74.00 -- Dustwallow Marsh/0, Axle
		18907=sB|m1946|x78.49|y62.94 -- Zangarmarsh/0, Innkeeper Coryth Stoktron
		21744=sB|m1948|x56.32|y59.84 -- Shadowmoon Valley/0, Roldemar
		21746=sB|m1948|x61.12|y28.24 -- Shadowmoon Valley/0, Caretaker Aluuro
		22922=sB|m1949|x62.86|y38.31 -- Blade's Edge Mountains/0, Innkeeper Aelerya
		19531=sB|m1953|x43.36|y36.14 -- Netherstorm/0, Eyonix
		19571=sB|m1953|x31.96|y64.42 -- Netherstorm/0, Innkeeper Remi Dodoso
		19232=sB|m1955|x56.20|y81.59 -- Shattrath City/0, Innkeeper Haelthol
		19046=sB|m1955|x28.00|y49.20 -- Shattrath City/0, Minalei
	]],
	["Stable Master"] = [[
		-- ALLIANCE --
		27068=sA|m116|x32.52|y59.51 -- Grizzly Hills/0, Matthew Ackerman (checked 9/28/2022)
		-- HORDE --
		26044=sH|m114|x40.28|y55.02|wWalking around inisde the building -- Borean Tundra/0, Durkot Wolfbrother
		--24350=sH|m117|x79.06|y30.79 -- Howling Fjord/0, Robert Clarke (Checked //STABLE)
		-- NEUTRAL --

		-- ALLIANCE --
		9977=sA|m1453|x42.57|y64.07 -- Stormwind City/0, Sylista (Checked 8/24/2022)
		11069=sA|m1453|x67.23|y37.74 -- Stormwind City/0, Jenova Stoneshield (Checked 8/24/2022)
		6749=sA|m1429|x42.85|y65.94 -- Elwynn Forest/0, Erma
		9978=sA|m1424|x50.41|y58.8 -- Hillsbrad Foothills/0, Wesley
		9980=sA|m1426|x47.0|y52.65 -- Dun Morogh/0, Shelby Stoneflint
		9982=sA|m1433|x26.8|y46.55 -- Redridge Mountains/0, Penny
		9984=sA|m1455|x69.29|y83.58 -- Ironforge/0, Ulbrek Firehand
		9989=sA|m1432|x34.64|y48.09 -- Loch Modan/0, Lina Hearthstove
		10045=sA|m1436|x52.93|y53.07 -- Westfall/0, Kirk Maxwell
		10046=sA|m1437|x10.52|y59.73 -- Wetlands/0, Bethaine Flinthammer
		10047=sA|m1445|x66.0|y45.5 -- Dustwallow Marsh/0, Michael
		10051=sA|m1438|x56.62|y59.62 -- Teldrassil/0, Seriadne
		10052=sA|m1440|x36.5|y50.36 -- Ashenvale/0, Maluressian
		10056=sA|m1457|x39.26|y10.04 -- Darnassus/0, Alassin
		16764=sA|m1947|x59.80|y24.20 -- The Exodar/0, Arthaid
		17485=sA|m1943|x49.00|y49.80 -- Azuremyst Isle/0, Esbina
		17666=sA|m1950|x55.00|y59.80 -- Bloodmyst Isle/0, Astur
		10059=sA|m1444|x31.46|y43.14 -- Feralas/0, Antarius
		10062=sA|m1431|x74.01|y46.1 -- Duskwood/0, Steven Black
		10085=sA|m1439|x37.4|y44.27 -- Darkshore/0, Jaelysia
		11104=sA|m1443|x65.61|y7.83 -- Desolace/0, Shelgrayn
		13617=sA|m1459|x42.55|y16.82 -- ??, Stormpike Stable Master
		16824=sA|m1944|x54.45|y62.68 -- Hellfire Peninsula/0, Master Sergeant Lorin Thalmerok
		18250=sA|m1946|x67.62|y49.70 -- Zangarmarsh/0, Joraal
		19368=sA|m1948|x37.51|y56.03 -- Shadowmoon Valley/0, Crinn Pathfinder
		22469=sA|m1949|x36.08|y64.52 -- Blade's Edge Mountains/0, Fiskal Shadowsong
		19019=sA|m1951|x55.80|y74.51 -- Nagrand/0, Luftasia
		24905=sA|m1952|x56.79|y53.87 -- Terokkar Forest/0, Leassian
		
		-- HORDE --
		9976=sH|m1417|x73.92|y33.12 -- Arathi Highlands/0, Tharlidun
		9979=sH|m1421|x43.45|y41.17 -- Silverpine Forest/0, Sarah Goode
		9981=sH|m1413|x51.74|y29.66 -- The Barrens/0, Sikwa
		9983=sH|m1413|x45.3|y58.65 -- The Barrens/0, Kelsuwa
		9986=sH|m1444|x74.49|y43.27 -- Feralas/0, Shyrka Wolfrunner
		9987=sH|m1411|x51.99|y41.84 -- Durotar/0, Shoja'my
		9988=sH|m1454|x70.35|y15.01 -- Orgrimmar/0, Xon'cha
		10048=sH|m1442|x47.92|y61.39 -- Stonetalon Mountains/0, Gereck
		10049=sH|m1435|x45.56|y55.15 -- Swamp of Sorrows/0, Hekkru
		10050=sH|m1412|x46.76|y60.35 -- Mulgore/0, Seikwa
		10053=sH|m1458|x67.42|y37.58 -- Undercity/0, Anya Maulray
		10054=sH|m1456|x45.08|y60.22 -- Thunder Bluff/0, Bulrug
		10055=sH|m1420|x60.03|y52.16 -- Tirisfal Glades/0, Morganus
		10057=sH|m1424|x62.3|y19.7 -- Hillsbrad Foothills/0, Theodore Mont Claire
		10058=sH|m1418|x3.65|y47.58 -- Badlands/0, Greth
		11105=sH|m1443|x24.9|y68.66 -- Desolace/0, Aboda
		11117=sH|m1441|x45.77|y51.06 -- Thousand Needles/0, Awenasa
		13616=sH|m1459|x57.16|y82.44 -- ??, Frostwolf Stable Master
		14741=sH|m1425|x79.16|y79.52 -- The Hinterlands/0, Huntsman Markhor
		15131=sH|m1440|x73.37|y61.02 -- Ashenvale/0, Qeeju
		16094=sH|m1434|x31.87|y29.49 -- Stranglethorn Vale/0, Durik
		16185=sH|m1941|x47.50|y47.20 -- Eversong Woods/0, Anathos
		16665=sH|m1942|x48.40|y31.20 -- Ghostlands/0, Paniar
		16656=sH|m1954|x83.20|y30.79 -- Silvermoon City/0, Shalenn
		16586=sH|m1944|x54.37|y41.02 -- Hellfire Peninsula/0, Huntsman Torf Angerhoof
		18244=sH|m1946|x31.74|y49.79 -- Zangarmarsh/0, Khalan
		21336=sH|m1948|x29.20|y29.34 -- Shadowmoon Valley/0, Gedrah
		19476=sH|m1949|x53.53|y53.21 -- Blade's Edge Mountains/0, Lor
		22468=sH|m1949|x75.52|y60.27 -- Blade's Edge Mountains/0, Ogrin
		19018=sH|m1951|x56.75|y40.83 -- Nagrand/0, Wilda Bearmane
		18984=sH|m1952|x49.31|y44.70 -- Terokkar Forest/0, Trag
		
		
		-- NEUTRAL --
		9985=sB|m1446|x52.25|y28.0 -- Tanaris/0, Laziphus
		10060=sB|m1434|x27.29|y77.22 -- Stranglethorn Vale/0, Grimestack
		10061=sB|m1425|x14.4|y45.22 -- The Hinterlands/0, Killium Bouldertoe
		25037=sB|m1957|x50.20|y35.40 -- ??, Seraphina Bloodheart
		10063=sB|m1413|x62.18|y39.2 -- The Barrens/0, Reggifuz
		11119=sB|m1452|x60.38|y37.91 -- Winterspring/0, Azzleby
		15722=sB|m1451|x49.29|y36.44 -- Silithus/0, Squire Leoren Mal'derath
		17896=sB|m1946|x78.73|y64.35 -- Zangarmarsh/0, Kameel Longstride
		23392=sB|m1949|x27.59|y52.51 -- Blade's Edge Mountains/0, Skyguard Stable Master
		24974=sB|m1953|x32.02|y64.80 -- Netherstorm/0, Liza Cutlerflix
		21517=sB|m1955|x55.80|y79.40 -- Shattrath City/0, Ilthuril
		21518=sB|m1955|x28.50|y47.40 -- Shattrath City/0, Oruhe
	]],
	["TrainerAlchemy"] = [[
		-- ALLIANCE --
		26903=sA|m117|x58.35|y62.22 -- Howling Fjord/0, Lanolis Dewdrop (checked 9/22/2022)
		-- HORDE --
		26975=sH|m114|x41.76|y54.22|wUpstairs inside the building -- Borean Tundra/0, Arthur Henslowe (checked 9/21/2022)
		27023=sH|m115|x36.20|y48.83 -- Dragonblight/0, Apothecary Bressa (checked 9/23/2022)
		27029=sH|m115|x76.88|y62.09 -- Dragonblight/0, Apothecary Wormwick (checked 9/28/2022)
		-- NEUTRAL --
		

		-- ALLIANCE --
		5499=sA|m1453|x55.66|y86.09|wInside the building -- Stormwind City/0, Lilyssia Nightbreeze (Checked 8/24/2022)
		1215=sA|m1429|x39.84|y48.23 -- Elwynn Forest/0, Alchemist Mallory
		1470=sA|m1432|x37.06|y49.37 -- Loch Modan/0, Ghak Healtouch
		3603=sA|m1438|x57.63|y60.8 -- Teldrassil/0, Cyndra Kindwhisper
		3964=sA|m1440|x50.85|y67.11 -- Ashenvale/0, Kylanna
		4160=sA|m1457|x54.87|y24.01 -- Darnassus/0, Ainethil
		4900=sA|m1445|x63.93|y47.64 -- Dustwallow Marsh/0, Alchemist Narett
		5177=sA|m1455|x66.61|y55.68 -- Ironforge/0, Tally Berryfizz
		7948=sA|m1444|x32.62|y43.77 -- Feralas/0, Kylanna Windwhisper
		17215=sA|m1943|x48.40|y51.50 -- Azuremyst Isle/0, Daedal
		16723=sA|m1947|x28.20|y61.34 -- The Exodar/0, Lucc
		18802=sA|m1944|x53.80|y65.82 -- Hellfire Peninsula/0, Alchemist Gribble
		
		-- HORDE --
		1386=sH|m1435|x48.52|y55.84 -- Swamp of Sorrows/0, Rogvar
		2132=sH|m1420|x59.43|y52.19 -- Tirisfal Glades/0, Carolai Anise
		2391=sH|m1424|x61.62|y19.18 -- Hillsbrad Foothills/0, Serge Hinott
		3009=sH|m1456|x46.61|y33.17 -- Thunder Bluff/0, Bena Winterhoof
		3184=sH|m1411|x55.4|y73.94 -- Durotar/0, Miao'zan
		3347=sH|m1454|x56.83|y33.03 -- Orgrimmar/0, Yelmak
		4611=sH|m1458|x47.77|y73.34 -- Undercity/0, Doctor Herbert Halsey
		16161=sH|m1941|x38.20|y72.50 -- Eversong Woods/0, Arcanist Sheynathren
		16642=sH|m1954|x55.20|y31.20 -- Silvermoon City/0, Camberon
		16588=sH|m1944|x52.28|y36.46 -- Hellfire Peninsula/0, Apothecary Antonivich
		
		
		
		-- NEUTRAL --
		2837=sB|m1434|x28.04|y77.99 -- Stranglethorn Vale/0, Jaxin Chong
		19052=sB|m1955|x45.70|y21.30 -- Shattrath City/0, Lorokeem
		28703=sB|m125|x41.80|y32.60 -- Dalaran, Linzy Blackbolt
	]],
	["TrainerBlacksmithing"] = [[
		-- ALLIANCE --
		26904=sA|m117|x59.59|y63.79 -- Howling Fjord/0, Rosina Rivet (checked 9/22/2022)
		-- HORDE --
		26564=sH|m115|x36.61|y47.19 -- Dragonblight/0, Borus Ironbender (checked 9/23/2022)
		-- NEUTRAL --
		33591=sB|m118|x71.80|y20.80 -- ??, Rekka the Hammer
		
		-- ALLIANCE --
		5511=sA|m1453|x63.65|y36.96 -- Stormwind City/0, Therum Deepforge (Checked 8/24/2022)
		514=sA|m1429|x41.7|y65.54 -- Elwynn Forest/0, Smith Argus
		1241=sA|m1426|x45.34|y51.93 -- Dun Morogh/0, Tognus Flintfire
		3136=sA|m1431|x74.0|y48.54 -- Duskwood/0, Clarise Gnarltree
		4258=sA|m1455|x52.54|y41.45 -- Ironforge/0, Bengus Deepforge
		6299=sA|m1439|x38.19|y40.93 -- Darkshore/0, Delfrum Flintbeard
		16724=sA|m1947|x60.55|y89.52 -- The Exodar/0, Miall
		17245=sA|m1943|x46.40|y71.00 -- Azuremyst Isle/0, Blacksmith Calypso
		16823=sA|m1944|x56.77|y63.84 -- Hellfire Peninsula/0, Humphry
		
		-- HORDE --
		2998=sH|m1456|x39.38|y55.08 -- Thunder Bluff/0, Karn Stonehoof
		3174=sH|m1411|x52.03|y40.71 -- Durotar/0, Dwukk
		3355=sH|m1454|x82.34|y22.97 -- Orgrimmar/0, Saru Steelfury
		3478=sH|m1413|x51.29|y28.9 -- The Barrens/0, Traugh
		3557=sH|m1421|x43.19|y41.08 -- Silverpine Forest/0, Guillaume Sorouy
		4596=sH|m1458|x61.26|y30.62 -- Undercity/0, James Van Brunt
		15400=sH|m1941|x59.50|y62.60 -- Eversong Woods/0, Arathel Sunforge
		16583=sH|m1944|x53.13|y38.16 -- Hellfire Peninsula/0, Rohok
		19341=sH|m1948|x29.63|y31.53 -- Shadowmoon Valley/0, Grutah
		16669=sH|m1954|x79.40|y39.00 -- Silvermoon City/0, Bemarrin
		
		-- NEUTRAL --
		2836=sB|m1434|x28.99|y75.55 -- Stranglethorn Vale/0, Brikk Keencraft
		28694=sB|m125|x45.20|y28.80 -- Dalaran, Alard Schmied
		29506=sB|m125|x44.50|y29.60 -- Dalaran, Orland Schaeffer
		29505=sB|m125|x76.00|y84.20 -- Dalaran, Imindril Spearsong
		
		--33631=sB|m111|x43.30|y64.79 -- Shattrath City/0,Barien
		33675=sB|m111|x37.6|y31.2 -- Shattrath City/0, Onodo
	]],
	["TrainerCooking"] = [[
		-- ALLIANCE --
		26989=sA|m114|x57.92|y71.54 -- Borean Tundra/0, Rollick MacKreel (Checked 9/21/2022)
		26905=sA|m117|x58.20|y62.05 -- Howling Fjord/0, Brom Brewbaster (checked 9/22/2022)
		-- HORDE --
		26972=sH|m114|x41.98|y54.11|wInside the building -- Borean Tundra/0, Orn Tenderhoof (checked 9/21/2022)
		26953=sH|m117|x78.61|y29.48 -- Howling Fjord/0, Thomas Kolichio (checked 9/22/2022)
		-- NEUTRAL --
		33587=sB|m118|x72.40|y20.80 -- ??, Bethany Cromwell

		-- ALLIANCE --
		5482=sA|m1453|x78.17|y53.09|wInside the building in the back room -- Stormwind City/0, Stephen Ryback (Checked 8/24/2022)
		1430=sA|m1429|x44.36|y65.98 -- Elwynn Forest/0, Tomas
		1355=sA|m1426|x68.37|y54.49 -- Dun Morogh/0, Cook Ghilm
		1699=sA|m1426|x47.67|y52.3 -- Dun Morogh/0, Gremlock Pilsnor
		3087=sA|m1433|x22.78|y43.46 -- Redridge Mountains/0, Crystal Boughman
		4210=sA|m1457|x49.03|y21.24 -- Darnassus/0, Alegorn
		5159=sA|m1455|x60.07|y36.43 -- Ironforge/0, Daryl Riknussun
		6286=sA|m1438|x57.12|y61.29 -- Teldrassil/0, Zarrin
		17246=sA|m1943|x46.80|y70.40 -- Azuremyst Isle/0, "Cookie" McWeaksauce
		16719=sA|m1947|x55.40|y26.75 -- The Exodar/0, Mumman
		18987=sA|m1944|x54.03|y63.56 -- Hellfire Peninsula/0, Gaston
		19369=sA|m1948|x37.21|y58.50 -- Shadowmoon Valley/0, Celie Steelwing
		
		28705=sA|m125|x40.85|y65.44 -- Dalaran, Katherine Lee
		
		-- HORDE --
		1382=sH|m1434|x31.34|y27.97 -- Stranglethorn Vale/0, Mudduk
		3026=sH|m1456|x50.71|y53.11 -- Thunder Bluff/0, Aska Mistrunner
		3067=sH|m1412|x45.4|y58.11 -- Mulgore/0, Pyall Silentstride
		3399=sH|m1454|x57.39|y53.95 -- Orgrimmar/0, Zamja
		4552=sH|m1458|x62.14|y44.91 -- Undercity/0, Eunice Burch
		8306=sH|m1413|x55.28|y31.77 -- The Barrens/0, Duhng
		16277=sH|m1941|x48.60|y47.00 -- Eversong Woods/0, Quarelestra
		16253=sH|m1942|x48.40|y31.00 -- Ghostlands/0, Master Chef Mouldier
		16676=sH|m1954|x69.50|y71.45 -- Silvermoon City/0, Sylann
		18988=sH|m1944|x56.81|y37.38 -- Hellfire Peninsula/0, Baxter
		
		29631=sH|m125|x70.00|y39.00 -- Dalaran, Awilo Lon'gomba
		
		-- NEUTRAL --
		18993=sB|m1946|x78.51|y63.05 -- Zangarmarsh/0, Naka
		19185=sB|m1955|x63.10|y68.40 -- Shattrath City/0, Jack Trapper
	]],
	["TrainerEnchanting"] = [[
		-- ALLIANCE --
		-- HORDE --
		26980=sH|m114|x41.14|y53.94|wUpstairs inside the building -- Borean Tundra/0, Eorain Dawnstrike (checked 9/21/2022)
		-- NEUTRAL --
		33583=sB|m118|x73.00|y20.50 -- ??, Fael Morningsong

		-- ALLIANCE --
		1317=sA|m1453|x52.90|y74.45|wInside the building -- Stormwind City/0, Lucan Cordell (Checked 8/24/2022)
		11072=sA|m1429|x64.92|y70.71 -- Elwynn Forest/0, Kitta Firewind
		3606=sA|m1438|x36.7|y34.16 -- Teldrassil/0, Alanna Raveneye
		4213=sA|m1457|x58.4|y13.12 -- Darnassus/0, Taladan
		16725=sA|m1947|x40.40|y39.14 -- The Exodar/0, Nahogg
		5157=sA|m1455|x59.76|y45.44 -- Ironforge/0, Gimble Thistlefuzz
		7949=sA|m1444|x31.54|y44.25 -- Feralas/0, Xylinnia Starshine
		18773=sA|m1944|x53.63|y66.14 -- Hellfire Peninsula/0, Johan Barnes
		-- HORDE --
		3011=sH|m1456|x44.91|y37.49 -- Thunder Bluff/0, Teg Dawnstrider
		3345=sH|m1454|x53.9|y38.66 -- Orgrimmar/0, Godan
		4616=sH|m1458|x62.47|y61.79 -- Undercity/0, Lavinia Crowe
		5695=sH|m1420|x61.76|y51.56 -- Tirisfal Glades/0, Vance Undergloom
		11074=sH|m1442|x49.17|y57.18 -- Stonetalon Mountains/0, Hgarth
		16160=sH|m1941|x38.20|y72.50 -- Eversong Woods/0, Magistrix Eredania
		16633=sH|m1954|x69.79|y24.35 -- Silvermoon City/0, Sedana
		18753=sH|m1944|x52.34|y35.98 -- Hellfire Peninsula/0, Felannia
		
		-- NEUTRAL --
		19540=sB|m1953|x44.23|y33.66 -- Netherstorm/0, Asarnan
		19252=sB|m1955|x43.50|y92.30 -- Shattrath City/0, High Enchanter Bardolan
		19251=sB|m1955|x43.20|y92.20 -- Shattrath City/0, Enchantress Volali
		33633=sB|m111|x55.6|y74.6 -- Shattrath City/0, Enchantress Andiala
		28693=sB|m125|x39.40|y40.90 -- Dalaran, Enchanter Nalthanis
		
	]],
	["TrainerEngineering"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		5518=sA|m1453|x62.08|y30.31 -- Stormwind City/0, Lilliam Sparkspindle (Checked 8/24/2022)
		1676=sA|m1431|x77.38|y48.82 -- Duskwood/0, Finbus Geargrind
		1702=sA|m1426|x50.17|y50.37 -- Dun Morogh/0, Bronk Guzzlegear
		3290=sA|m1432|x45.91|y13.44 -- Loch Modan/0, Deek Fizzlebizz
		5174=sA|m1455|x68.45|y43.54 -- Ironforge/0, Springspindle Fizzlegear
		7944=sA|m1455|x69.54|y50.32 -- Ironforge/0, Tinkmaster Overspark
		11037=sA|m1439|x38.3|y41.11 -- Darkshore/0, Jenna Lemkenilli
		16726=sA|m1947|x54.00|y91.40 -- The Exodar/0, Ockil
		17222=sA|m1943|x48.50|y50.40 -- Azuremyst Isle/0, Artificer Daelo
		18775=sA|m1944|x55.72|y65.59 -- Hellfire Peninsula/0, Lebowski
		17634=sA|m1946|x68.65|y50.21 -- Zangarmarsh/0, K. Lee Smallfry
		-- HORDE --
		11017=sH|m1454|x76.17|y25.17 -- Orgrimmar/0, Roxxik
		11025=sH|m1411|x52.18|y40.79 -- Durotar/0, Mukdrak
		11031=sH|m1458|x76.12|y74.02 -- Undercity/0, Franklin Lloyd
		16667=sH|m1954|x76.80|y41.00 -- Silvermoon City/0, Danwe
		18752=sH|m1944|x54.78|y38.51 -- Hellfire Peninsula/0, Zebig
		17637=sH|m1946|x34.03|y50.93 -- Zangarmarsh/0, Mack Diver
		-- NEUTRAL --
		3494=sB|m1413|x62.66|y36.31 -- The Barrens/0, Tinkerwiz
		8738=sB|m1413|x62.69|y36.25 -- The Barrens/0, Vazario Linkgrease
		7406=sB|m1434|x28.35|y76.35 -- Stranglethorn Vale/0, Oglethorpe Obnoticus
		8126=sB|m1446|x52.47|y27.32 -- Tanaris/0, Nixx Sprocketspring
		8736=sB|m1446|x52.33|y27.72 -- Tanaris/0, Buzzek Bracketswing
		10993=sB|m1412|x61.85|y31.4 -- Mulgore/0, Twizwick Sprocketgrind
		19576=sB|m1953|x32.48|y66.78 -- Netherstorm/0, Xyrol
	]],
	["TrainerFirst Aid"] = [[
		-- ALLIANCE --
		26992=sA|m114|x57.82|y66.38 -- Borean Tundra/0, Brynna Wilson (Checked 9/21/2022)
		23734=sA|m117|x59.69|y62.07|wWalking around this area -- Howling Fjord/0, Anchorite Yazmina (checked 9/22/2022)
		-- HORDE --
		26956=sH|m117|x79.42|y29.34|wUpstairs inside the building -- Howling Fjord/0, Sally Tompkins (checked 9/22/2022)
		-- NEUTRAL --
		33589=sB|m118|x71.40|y22.50 -- ??, Joseph Wilson

		-- ALLIANCE --
		2327=sA|m1453|x53.01|y44.64|wInside the building -- Stormwind City/0, Shaina Fuller (Checked 8/24/2022)
		2329=sA|m1429|x43.39|y65.54 -- Elwynn Forest/0, Michelle Belle
		2326=sA|m1426|x47.17|y52.61 -- Dun Morogh/0, Thamner Pol
		3181=sA|m1437|x10.81|y61.4 -- Wetlands/0, Fremal Doohickey
		4211=sA|m1457|x51.71|y12.21 -- Darnassus/0, Dannelor
		5150=sA|m1455|x55.08|y58.26 -- Ironforge/0, Nissa Firestone
		6094=sA|m1438|x55.28|y56.81 -- Teldrassil/0, Byancie
		17214=sA|m1943|x48.40|y51.80 -- Azuremyst Isle/0, Anchorite Fateema
		16731=sA|m1947|x39.20|y23.60 -- The Exodar/0, Nus
		17424=sA|m1950|x54.60|y54.00 -- Bloodmyst Isle/0, Anchorite Paetheus
		18990=sA|m1944|x22.33|y39.42 -- Hellfire Peninsula/0, Burko
		
		
		-- HORDE --
		2798=sH|m1456|x29.69|y21.17 -- Thunder Bluff/0, Pand Stonebinder
		3373=sH|m1454|x34.17|y84.57 -- Orgrimmar/0, Arnok
		4591=sH|m1458|x73.15|y55.14 -- Undercity/0, Mary Edras
		5759=sH|m1420|x61.81|y52.82 -- Tirisfal Glades/0, Nurse Neela
		5939=sH|m1412|x46.8|y60.84 -- Mulgore/0, Vira Younghoof
		5943=sH|m1411|x54.17|y41.92 -- Durotar/0, Rawrk
		16272=sH|m1941|x48.55|y47.52 -- Eversong Woods/0, Kanaria
		16662=sH|m1954|x77.60|y71.20 -- Silvermoon City/0, Alestus
		18991=sH|m1944|x26.18|y62.05 -- Hellfire Peninsula/0, Aresella
		19478=sH|m1949|x54.01|y55.10 -- Blade's Edge Mountains/0, Fera Palerunner
		
		-- NEUTRAL --
		22477=sB|m1952|x30.83|y76.11 -- Terokkar Forest/0, Anchorite Ensham
		19184=sB|m1955|x66.65|y13.60 -- Shattrath City/0, Mildred Fletcher
		28706=sB|m125|x37.20|y36.79 -- Dalaran, Olisarra the Kind
		
	]],
	["TrainerFishing"] = [[
		-- ALLIANCE --
		26993=sA|m114|x57.88|y71.64 -- Borean Tundra/0, Old Man Robert (Checked 9/21/2022)
		-- HORDE --
		32474=sH|m114|x41.73|y54.47|wInside the building -- Borean Tundra/0, Fishy Ser'ji (checked)
		-- NEUTRAL --

		-- ALLIANCE --
		5493=sA|m1453|x54.99|y69.64 -- Stormwind City/0, Arnold Leland (Checked 8/24/2022)
		1651=sA|m1429|x47.6|y62.32 -- Elwynn Forest/0, Lee Brown
		1680=sA|m1433|x26.98|y51.13 -- Redridge Mountains/0, Matthew Hooper
		1683=sA|m1432|x40.58|y39.68 -- Loch Modan/0, Warg Deepwater
		1700=sA|m1426|x35.47|y40.22 -- Dun Morogh/0, Paxton Ganter
		2367=sA|m1424|x50.78|y61.03 -- Hillsbrad Foothills/0, Donald Rabonne
		3179=sA|m1437|x8.08|y58.59 -- Wetlands/0, Harold Riggs
		3607=sA|m1438|x55.87|y93.51 -- Teldrassil/0, Androl Oakhand
		4156=sA|m1457|x47.88|y56.65 -- Darnassus/0, Astaia
		5161=sA|m1455|x48.06|y6.91 -- Ironforge/0, Grimnur Stonebrand
		7946=sA|m1444|x32.25|y41.6 -- Feralas/0, Brannock
		17101=sA|m1943|x61.00|y54.20 -- Azuremyst Isle/0, Diktynna
		
		-- HORDE --
		3028=sH|m1456|x56.13|y46.38 -- Thunder Bluff/0, Kah Mistrunner
		3332=sH|m1454|x69.8|y29.21 -- Orgrimmar/0, Lumak
		4573=sH|m1458|x80.69|y31.26 -- Undercity/0, Armand Cromwell
		5690=sH|m1420|x67.16|y50.98 -- Tirisfal Glades/0, Clyde Kellen
		5938=sH|m1412|x44.5|y60.65 -- Mulgore/0, Uthan Stillwater
		5941=sH|m1411|x53.24|y81.59 -- Durotar/0, Lau'Tiki
		12032=sH|m1443|x22.69|y72.42 -- Desolace/0, Lui'Mala
		12961=sH|m1440|x10.82|y33.65 -- Ashenvale/0, Kil'Hiwana
		14740=sH|m1425|x80.33|y81.52 -- The Hinterlands/0, Katoom the Angler
		18018=sH|m1946|x32.25|y49.61 -- Zangarmarsh/0, Zurjaya
		16780=sH|m1954|x76.40|y68.00 -- Silvermoon City/0, Drathen
		
		-- NEUTRAL --
		2834=sB|m1434|x27.46|y77.11 -- Stranglethorn Vale/0, Myizz Luckycatch
		16774=sB|m1947|x31.55|y14.65 -- The Exodar/0, Erett
	]],
	["TrainerHerbalism"] = [[
		-- ALLIANCE --
		26994=sA|m114|x57.84|y71.87 -- Borean Tundra/0, Kirea Moondancer (Checked 9/21/2022)
		-- HORDE --
		26974=sH|m114|x42.03,|y53.62 -- Borean Tundra/0, Tansy Wildmane (checked 9/21/2022)
		-- NEUTRAL --

		-- ALLIANCE --
		5502=sA|m1453|x31.24|y62.82|wInside the building -- Stormwind City/0, Shylamiir (Checked 8/24/2022)
		5566=sA|m1453|x54.28|y84.09 -- Stormwind City/0, Tannysa (Checked 8/24/2022)
		1218=sA|m1429|x39.95|y48.4 -- Elwynn Forest/0, Herbalist Pomeroy
		812=sA|m1433|x21.68|y45.77 -- Redridge Mountains/0, Alma Jainrose
		1458=sA|m1437|x7.98|y55.84 -- Wetlands/0, Telurinon Moonshadow
		1473=sA|m1432|x36.47|y48.54 -- Loch Modan/0, Kali Healtouch
		3604=sA|m1438|x57.72|y60.64 -- Teldrassil/0, Malorne Bladeleaf
		3965=sA|m1440|x50.68|y67.17 -- Ashenvale/0, Cylania Rootstalker
		4204=sA|m1457|x47.94|y68.02 -- Darnassus/0, Firodren Mooncaller
		4898=sA|m1445|x64.0|y47.53 -- Dustwallow Marsh/0, Brant Jasperbloom
		5137=sA|m1455|x55.89|y59.13 -- Ironforge/0, Reyna Stonebranch
		17983=sA|m1943|x48.20|y51.20 -- Azuremyst Isle/0, Heur
		18776=sA|m1944|x53.60|y65.79 -- Hellfire Peninsula/0, Rorelien
		16736=sA|m1947|x27.60|y62.40 -- The Exodar/0, Cemmorhan
		17434=sA|m1950|x53.40|y57.80 -- Bloodmyst Isle/0, Morae
		
		-- HORDE --
		2114=sH|m1420|x59.78|y52.12 -- Tirisfal Glades/0, Faruza
		2390=sH|m1424|x61.71|y19.51 -- Hillsbrad Foothills/0, Aranae Venomblood
		2856=sH|m1434|x32.24|y27.42 -- Stranglethorn Vale/0, Angrun
		3013=sH|m1456|x49.95|y40.4 -- Thunder Bluff/0, Komin Winterhoof
		3185=sH|m1411|x55.44|y75.08 -- Durotar/0, Mishiki
		3404=sH|m1454|x55.61|y39.46 -- Orgrimmar/0, Jandi
		4614=sH|m1458|x54.0|y49.54 -- Undercity/0, Martha Alliestar
		8146=sH|m1444|x75.97|y43.33 -- Feralas/0, Ruw
		16367=sH|m1941|x37.40|y71.80 -- Eversong Woods/0, Botanist Tyniarrel
		18748=sH|m1944|x52.23|y36.26 -- Hellfire Peninsula/0, Ruak Stronghorn
		16644=sH|m1954|x67.34|y18.14 -- Silvermoon City/0, Botanist Nathera
		
		-- NEUTRAL --
		908=sB|m1434|x27.72|y77.86 -- Stranglethorn Vale/0, Flora Silverwind
		12025=sB|m1450|x45.41|y46.96 -- Moonglade/0, Malvor
		33678=sB|m111|x38.2|y30 -- Shattrath City/0, Jijia
		28704=sB|m125|x43.55|y34.59 -- Dalaran, Dorothy Egan
	]],
	["TrainerInscription"] = [[
		-- ALLIANCE --
		30713=sA|m1453|x49.82|y74.82|wInside the building -- Stormwind City/0, Catarina Stanford (Checked 8/24/2022)
		26916=sA|m117|x58.26|y62.46|wUpstairs inside the building -- Howling Fjord/0, Mindri Dinkles
		-- HORDE --
		30706=sH|m1454|x56|y46.2 -- Orgrimmar/0, Jo'mah
		-- NEUTRAL --
		28702=sB|m125|x41.80|y36.80 -- Dalaran, Professor Pallin
		33603=sB|m118|x71.60|y20.80 -- ??, Arthur Denny
	]],
	["TrainerLeatherworking"] = [[
		-- ALLIANCE --
		26911=sA|m117|x59.89|y63.55 -- Howling Fjord/0, Bernadette Dexter (checked 9/22/2022)
		-- HORDE --
		-- NEUTRAL --
		33581=sB|m118|x71.80|y20.80 -- ??, Kul'de

		-- ALLIANCE --
		5564=sA|m1453|x71.68|y62.99|wInside the building -- Stormwind City/0, Simon Tanner (Checked 8/24/2022)
		1632=sA|m1429|x46.38|y62.04 -- Elwynn Forest/0, Adele Fielder
		3605=sA|m1438|x41.87|y49.44 -- Teldrassil/0, Nadyia Maneweaver
		3967=sA|m1440|x35.97|y52.1 -- Ashenvale/0, Aayndia Floralwind
		4212=sA|m1457|x64.42|y21.53 -- Darnassus/0, Telonis
		5127=sA|m1455|x40.23|y33.67 -- Ironforge/0, Fimble Finespindle
		7866=sA|m1447|x37.58|y65.41 -- Azshara/0, Peter Galen
		7868=sA|m1427|x63.55|y75.97 -- Searing Gorge/0, Sarah Tanner
		7870=sA|m1444|x89.41|y46.55 -- Feralas/0, Caryssia Moonhunter
		17442=sA|m1943|x44.80|y23.80 -- Azuremyst Isle/0, Moordo
		18771=sA|m1944|x54.11|y63.97 -- Hellfire Peninsula/0, Brumman
		16728=sA|m1947|x67.20|y74.50 -- The Exodar/0, Akham
		
		-- HORDE --
		1385=sH|m1434|x31.74|y28.89 -- Stranglethorn Vale/0, Brawn
		3007=sH|m1456|x41.5|y42.56 -- Thunder Bluff/0, Una
		3069=sH|m1412|x45.43|y57.86 -- Mulgore/0, Chaw Stronghide
		3365=sH|m1454|x62.8|y44.14 -- Orgrimmar/0, Karolek
		3549=sH|m1420|x65.42|y60.12 -- Tirisfal Glades/0, Shelene Rhobart
		3703=sH|m1413|x44.84|y59.45 -- The Barrens/0, Krulmoo Fullmoon
		4588=sH|m1458|x70.17|y57.42 -- Undercity/0, Arthur Moore
		7867=sH|m1418|x62.7|y57.4 -- Badlands/0, Thorkaf Dragoneye
		7869=sH|m1417|x28.26|y45.08 -- Arathi Highlands/0, Brumn Winterhoof
		7871=sH|m1434|x36.54|y34.08 -- Stranglethorn Vale/0, Se'Jib
		8153=sH|m1443|x55.24|y56.33 -- Desolace/0, Narv Hidecrafter
		11098=sH|m1444|x74.36|y43.11 -- Feralas/0, Hahrana Ironhide
		16278=sH|m1941|x53.60|y51.20 -- Eversong Woods/0, Sathein
		18754=sH|m1944|x56.22|y38.69 -- Hellfire Peninsula/0, Barim Spilthoof
		21087=sH|m1949|x76.88|y65.49 -- Blade's Edge Mountains/0, Grikka
		16688=sH|m1954|x84.73|y80.34 -- Silvermoon City/0, Lynalis
		-- NEUTRAL --
		11097=sB|m1425|x13.38|y43.49 -- The Hinterlands/0, Drakk Stonehand
		19187=sB|m1955|x66.90|y67.50 -- Shattrath City/0, Darmari
		29508=sB|m125|x34.50|y27.25 -- Dalaran, Andellion
		28700=sB|m125|x35.29|y28.75 -- Dalaran, Diane Cannings
		29507=sB|m125|x34.20|y28.00 -- Dalaran, Manfred Staller
		29509=sB|m125|x36.20|y29.80 -- Dalaran, Namha Moonwater
		
	]],
	["TrainerJewelcrafting"] = [[
		-- ALLIANCE --
		-- HORDE --
		26982=sH|m114|x41.63|y53.34|wInside the building -- Borean Tundra/0, Geba'li (checked 9/21/2022)
		-- NEUTRAL --
		33590=sB|m118|x71.40|y20.80 -- ??, Oluros

		-- ALLIANCE --
		18774=sA|m1944|x54.63|y63.68 -- Hellfire Peninsula/0, Tatiana
		19778=sA|m1947|x45.00|y24.60 -- The Exodar/0, Farii
		-- HORDE --
		15501=sH|m1941|x48.40|y47.40 -- Eversong Woods/0, Aleinia
		18751=sH|m1944|x56.78|y37.79 -- Hellfire Peninsula/0, Kalaen
		19775=sH|m1954|x90.50|y73.80 -- Silvermoon City/0, Kalinda
		
		-- NEUTRAL --
		19539=sB|m1953|x44.52|y34.03 -- Netherstorm/0, Jazdalaad
		19063=sB|m1955|x35.59|y20.29 -- Shattrath City/0, Hamanar
		
		--33680=sB|m111|x36.10|y47.30 -- Shattrath City/0,Nemiha
	]],
	["TrainerMining"] = [[
		-- ALLIANCE --
		26999=sA|m114|x57.46|y66.12 -- Borean Tundra/0, Fendrig Redbeard (Checked 9/21/2022)
		-- HORDE --
		26976=sH|m114|x42.58|y53.19|wInside the building -- Borean Tundra/0, Brunna Ironaxe (checked 9/21/2022)
		-- NEUTRAL --

		-- ALLIANCE --
		5513=sA|m1453|x59.28|y37.82|wUpstairs inside the building -- Stormwind City/0, Gelman Stonehand (Checked 8/24/2022)
		1681=sA|m1432|x37.01|y47.8 -- Loch Modan/0, Brock Stoneseeker
		1701=sA|m1426|x69.32|y55.45 -- Dun Morogh/0, Dank Drizzlecut
		3137=sA|m1431|x74.06|y49.63 -- Duskwood/0, Matt Johnson
		4254=sA|m1455|x50.0|y26.29 -- Ironforge/0, Geofram Bouldertoe
		17488=sA|m1943|x48.80|y51.00 -- Azuremyst Isle/0, Dulvi
		18779=sA|m1944|x56.69|y63.85 -- Hellfire Peninsula/0, Hurnak Grimmord
		5392=sA|m1426|x50.0|y50.3 -- Dun Morogh/0, Yarr Hammerstone
		6297=sA|m1439|x38.24|y41.0 -- Darkshore/0, Kurdram Stonehammer
		16752=sA|m1947|x60.20|y88.20 -- The Exodar/0, Muaat
		18804=sA|m1950|x56.20|y54.20 -- Bloodmyst Isle/0, Prospector Nachlan
		
		-- HORDE --
		3001=sH|m1456|x34.36|y57.9 -- Thunder Bluff/0, Brek Stonehoof
		3175=sH|m1411|x51.81|y40.88 -- Durotar/0, Krunn
		3357=sH|m1454|x73.11|y26.08 -- Orgrimmar/0, Makaru
		3555=sH|m1421|x43.4|y40.45 -- Silverpine Forest/0, Johan Focht
		4598=sH|m1458|x56.03|y37.45 -- Undercity/0, Brom Killian
		18747=sH|m1944|x55.44|y37.59 -- Hellfire Peninsula/0, Krugosh
		16663=sH|m1954|x79.00|y42.80 -- Silvermoon City/0, Belil
		
		-- NEUTRAL --
		8128=sB|m1446|x51.07|y28.1 -- Tanaris/0, Pikkle
		28698=sB|m125|x41.20|y25.70 -- Dalaran, Jedidiah Handers
		--33682=sB|m111|x36.00|y48.50 -- Shattrath City/0,Fono
	]],
	["TrainerSkinning"] = [[
		-- ALLIANCE --
		26913=sA|m117|x59.93|y63.70 -- Howling Fjord, Frederic Burrhus (checked 9/28/2022)
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		1292=sA|m1453|x72.14|y62.20|wUpstairs inside the building -- Stormwind City/0, Maris Granger (Checked 8/24/2022)
		6306=sA|m1429|x46.24|y62.24 -- Elwynn Forest/0, Helene Peltskinner
		6287=sA|m1438|x42.09|y49.96 -- Teldrassil/0, Radnaal Maneweaver
		6288=sA|m1440|x49.97|y67.28 -- Ashenvale/0, Jayla
		6291=sA|m1455|x39.86|y32.49 -- Ironforge/0, Balthus Stoneflayer
		6292=sA|m1457|x64.13|y22.26 -- Darnassus/0, Eladriel
		6295=sA|m1433|x88.83|y71.29 -- Redridge Mountains/0, Wilma Ranthal
		17441=sA|m1943|x44.60|y23.40 -- Azuremyst Isle/0, Gurf
		16763=sA|m1947|x65.84|y74.50 -- The Exodar/0, Remere
		18777=sA|m1944|x54.50|y63.16 -- Hellfire Peninsula/0, Jelena Nightsky
		
		-- HORDE --
		6289=sH|m1420|x65.58|y60.03 -- Tirisfal Glades/0, Rand Rhobart
		6290=sH|m1412|x45.47|y57.77 -- Mulgore/0, Yonn Deepcut
		6387=sH|m1413|x45.07|y59.09 -- The Barrens/0, Dranh
		7087=sH|m1458|x70.15|y59.17 -- Undercity/0, Killian Hagey
		7088=sH|m1454|x63.35|y45.41 -- Orgrimmar/0, Thuwd
		7089=sH|m1456|x44.44|y43.15 -- Thunder Bluff/0, Mooranta
		8144=sH|m1444|x74.46|y43.04 -- Feralas/0, Kulleg Stonehorn
		12030=sH|m1443|x23.23|y69.71 -- Desolace/0, Malux
		16273=sH|m1941|x53.80|y51.20 -- Eversong Woods/0, Mathreyn
		16692=sH|m1954|x84.40|y80.20 -- Silvermoon City/0, Tyn
		18755=sH|m1944|x56.27|y38.61 -- Hellfire Peninsula/0, Moorutu
		-- NEUTRAL --
		19180=sB|m1955|x64.22|y65.87 -- Shattrath City/0, Seymour
		28696=sB|m125|x35.50|y28.65 -- Dalaran, Derik Marks
	]],
	["TrainerTailoring"] = [[
		-- ALLIANCE --
		-- HORDE --
		26969=sH|m114|x41.63|y53.46|wUpstairs inside the building -- Borean Tundra/0, Raenah (checked 9/21/2022)
		-- NEUTRAL --
		33580=sB|m118|x73.00|y20.80 -- ??, Dustin Vail

		-- ALLIANCE --
		1346=sA|m1453|x53.07|y81.34|wInside the building -- Stormwind City/0, Georgio Bolero (Checked 8/24/2022)
		--9584=sA|m1453|x40.35|y84.61 -- Stormwind City/0, Jalane Ayrole (Checked 8/24/2022) (Master Shadoweave Tailor, not normal trainer)
		1103=sA|m1429|x79.21|y69.02 -- Elwynn Forest/0, Eldrin
		4159=sA|m1457|x63.4|y22.37 -- Darnassus/0, Me'lynn
		4193=sA|m1439|x38.24|y40.53 -- Darkshore/0, Grondal Moonbreeze
		5153=sA|m1455|x43.14|y29.35 -- Ironforge/0, Jormund Stonebrow
		11052=sA|m1445|x66.17|y51.81 -- Dustwallow Marsh/0, Timothy Worthington
		17487=sA|m1943|x46.40|y70.50 -- Azuremyst Isle/0, Erin Kelly
		16729=sA|m1947|x30.60|y47.80 -- The Exodar/0, Refik
		18772=sA|m1944|x54.63|y63.71 -- Hellfire Peninsula/0, Hama
		-- HORDE --
		2399=sH|m1424|x63.74|y20.78 -- Hillsbrad Foothills/0, Daryl Stack
		3004=sH|m1456|x44.52|y45.35 -- Thunder Bluff/0, Tepa
		3363=sH|m1454|x63.64|y49.92 -- Orgrimmar/0, Magar
		3484=sH|m1413|x52.2|y31.7 -- The Barrens/0, Kil'hala
		3523=sH|m1420|x52.59|y55.52 -- Tirisfal Glades/0, Bowen Brisboise
		3704=sH|m1413|x44.92|y59.39 -- The Barrens/0, Mahani
		4576=sH|m1458|x70.75|y30.69 -- Undercity/0, Josef Gregorian
		4578=sH|m1458|x86.65|y22.08 -- Undercity/0, Josephine Lister
		16366=sH|m1941|x37.40|y71.80 -- Eversong Woods/0, Sempstress Ambershine
		16640=sH|m1954|x57.00|y50.20 -- Silvermoon City/0, Keelen Sheets
		18749=sH|m1944|x56.57|y37.09 -- Hellfire Peninsula/0, Dalinna
		
		-- NEUTRAL --
		2627=sB|m1434|x28.77|y76.84 -- Stranglethorn Vale/0, Grarnik Goodstitch
		28699=sB|m125|x36.72|y33.37 -- Dalaran, Charles Worth
		
	]],
	["Vendor"] = [[
		-- ALLIANCE --
		277=sA|m1453|x60.02|y76.86|wHe walks around inside the building -- Stormwind City/0, Roberto Pupellyverbos (Checked 8/24/2022)
		340=sA|m1453|x77.46|y52.68|wUpstairs inside the building -- Stormwind City/0, Kendor Kabonka (Checked 8/24/2022)
		483=sA|m1453|x66.55|y73.36|wInside the building -- Stormwind City/0, Elaine Trias (Checked 8/24/2022)
		1257=sA|m1453|x62.79|y75.03|wInside the building -- Stormwind City/0, Keldric Boucher (Checked 8/24/2022)
		1275=sA|m1453|x63.10|y74.93|wShe walks around inside the building -- Stormwind City/0, Kyra Boucher (Checked 8/24/2022)
		1285=sA|m1453|x64.83|y72.16|wInside the building -- Stormwind City/0, Thurman Mullby (Checked 8/24/2022)
		1286=sA|m1453|x64.72|y71.25|wInside the building -- Stormwind City/0, Edna Mullby (Checked 8/24/2022)
		1287=sA|m1453|x64.07|y68.36|wInside the building -- Stormwind City/0, Marda Weller (Checked 8/24/2022)
		1289=sA|m1453|x64.20|y68.59|wInside the building -- Stormwind City/0, Gunther Weller (Checked 8/24/2022)
		1291=sA|m1453|x62.02|y67.79|wInside the building -- Stormwind City/0, Carla Granger (Checked 8/24/2022)
		1294=sA|m1453|x61.90|y67.18|wInside the building -- Stormwind City/0, Aldric Moore (Checked 8/24/2022)
		1295=sA|m1453|x61.97|y67.47|wInside the building -- Stormwind City/0, Lara Moore (Checked 8/24/2022)
		1297=sA|m1453|x58.71|y68.71|wInside the building -- Stormwind City/0, Lina Stover (Checked 8/24/2022)
		1298=sA|m1453|x58.34|y69.03|wInside the building -- Stormwind City/0, Frederick Stover (Checked 8/24/2022)
		1299=sA|m1453|x58.30|y67.15|wInside the building -- Stormwind City/0, Lisbeth Schneider (Checked 8/24/2022)
		1301=sA|m1453|x59.92|y77.69|wInside the building -- Stormwind City/0, Julia Gallina (Checked 8/24/2022)
		1302=sA|m1453|x69.24|y71.83|wInside the building -- Stormwind City/0, Bernard Gump (Checked 8/24/2022)
		1303=sA|m1453|x69.34|y71.32|wShe walks around inside the building -- Stormwind City/0, Felicia Gump (Checked 8/24/2022)
		1304=sA|m1453|x42.44|y76.93|wInside the building -- Stormwind City/0, Darian Singh (Checked 8/24/2022)
		1305=sA|m1453|x41.96|y82.71|wInside the building -- Stormwind City/0, Jarel Moor (Checked 8/24/2022)
		1307=sA|m1453|x44.58|y86.25|wInside the building -- Stormwind City/0, Charys Yserian (Checked 8/24/2022)
		1308=sA|m1453|x47.42|y82.46|wInside the building -- Stormwind City/0, Owen Vaughn (Checked 8/24/2022)
		1309=sA|m1453|x51.82|y83.49|wInside the building -- Stormwind City/0, Wynne Larson (Checked 8/24/2022)
		1310=sA|m1453|x52.65|y83.66|wInside the building -- Stormwind City/0, Evan Larson (Checked 8/24/2022)
		1311=sA|m1453|x51.44|y94.11|wInside the building -- Stormwind City/0, Joachim Brenlow (Checked 8/24/2022)
		1312=sA|m1453|x52.82|y74.86|wInside the building -- Stormwind City/0, Ardwyn Cailen (Checked 8/24/2022)
		1313=sA|m1453|x55.89|y85.63|wInside the building -- Stormwind City/0, Maria Lumere (Checked 8/24/2022)
		1314=sA|m1453|x53.18|y82.04|wInside the building -- Stormwind City/0, Duncan Cullen (Checked 8/24/2022)
		1315=sA|m1453|x53.01|y74.90|wInside the building -- Stormwind City/0, Allan Hafgan (Checked 8/24/2022)
		1316=sA|m1453|x51.83|y75.12|wInside the building -- Stormwind City/0, Adair Gilroy (Checked 8/24/2022)
		1318=sA|m1453|x52.80|y74.25|wInside the building -- Stormwind City/0, Jessara Cordell (Checked 8/24/2022)
		1319=sA|m1453|x69.18|y57.64|wInside the building -- Stormwind City/0, Bryan Cross (Checked 8/24/2022)
		1320=sA|m1453|x71.86|y61.98|wInside the building -- Stormwind City/0, Seoman Griffith (Checked 8/24/2022)
		1321=sA|m1453|x71.68|y62.20|wInside the building -- Stormwind City/0, Alyssa Griffith (Checked 8/24/2022)
		1323=sA|m1453|x77.17|y60.98|wInside the building -- Stormwind City/0, Osric Strang (Checked 8/24/2022)
		1324=sA|m1453|x77.21|y57.36|wInside the building -- Stormwind City/0, Heinrich Stone (Checked 8/24/2022)
		1325=sA|m1453|x80.27|y70.07|wInside the building -- Stormwind City/0, Jasper Fel (Checked 8/24/2022)
		1326=sA|m1453|x78.62|y70.85|wInside the building -- Stormwind City/0, Sloan McCoy (Checked 8/24/2022)
		1328=sA|m1453|x76.33|y53.85|wShe walks around inside the building -- Stormwind City/0, Elly Langston (Checked 8/24/2022)
		1333=sA|m1453|x73.00|y57.45|wInside the building -- Stormwind City/0, Gerik Koen (Checked 8/24/2022)
		1339=sA|m1453|x71.68|y58.18|wInside the building -- Stormwind City/0, Mayda Thane (Checked 8/24/2022)
		1341=sA|m1453|x77.51|y61.29|wInside the building -- Stormwind City/0, Wilhelm Strang (Checked 8/24/2022)
		1347=sA|m1453|x53.14|y81.75|wInside the building -- Stormwind City/0, Alexandra Bolero (Checked 8/24/2022)
		1348=sA|m1453|x48.12|y55.00|wInside the building -- Stormwind City/0, Gregory Ardus (Checked 8/24/2022)
		1349=sA|m1453|x53.51|y57.56|wInside the building -- Stormwind City/0, Agustus Moulaine (Checked 8/24/2022)
		1350=sA|m1453|x53.20|y57.93|wInside the building -- Stormwind City/0, Theresa Moulaine (Checked 8/24/2022)
		1351=sA|m1453|x53.33|y45.30|wInside the building -- Stormwind City/0, Brother Cassius (Checked 8/24/2022)
		--3518=sA|m1453|x67.90|y72.17 -- Stormwind City/0, Thomas Miller (Checked 8/24/2022) (Wandering NPC, exclude)
		4981=sA|m1453|x66.35|y73.50|wInside the building -- Stormwind City/0, Ben Trias (Checked 8/24/2022)
		5193=sA|m1453|x63.98|y77.50|wInside the building -- Stormwind City/0, Rebecca Laughlin (Checked 8/24/2022)
		5483=sA|m1453|x78.52|y52.87|wShe walks around inside the back of the building -- Stormwind City/0, Erika Tate (Checked 8/24/2022)
		5494=sA|m1453|x55.09|y69.76 -- Stormwind City/0, Catherine Leland (Checked 8/24/2022)
		5503=sA|m1453|x55.77|y85.29|wInside the building -- Stormwind City/0, Eldraeith (Checked 8/24/2022)
		5509=sA|m1453|x59.30|y33.85|wInside the building -- Stormwind City/0, Kathrum Axehand (Checked 8/24/2022)
		5510=sA|m1453|x61.98|y36.44|wInside the building -- Stormwind City/0, Thulman Flintcrag (Checked 8/24/2022)
		5512=sA|m1453|x63.24|y37.56 -- Stormwind City/0, Kaita Deepforge (Checked 8/24/2022)
		5514=sA|m1453|x59.15|y37.48|wInside the building -- Stormwind City/0, Brooke Stonebraid (Checked 8/24/2022)
		5519=sA|m1453|x62.39|y29.88|wInside the building -- Stormwind City/0, Billibub Cogspinner (Checked 8/24/2022)
		5520=sA|m1453|x39.53|y84.53|wInside the basement of The Slaughtered Lamb|cWarlock -- Stormwind City/0, Spackle Thornberry (Checked 8/24/2022)
		5565=sA|m1453|x71.57|y62.76|wInside the building -- Stormwind City/0, Jillian Tanner (Checked 8/24/2022)
		6740=sA|m1453|x60.38|y75.27|wInside the building -- Stormwind City/0, Innkeeper Allison (Checked 8/24/2022)
		--8666=sA|m1453|x46.27|y55.13 -- Stormwind City/0, Lil Timmy (Checked 8/24/2022) (Limited Spawn)
		--12805=sA|m1453|x73.59|y53.0 -- Stormwind City/0, Officer Areyn (Checked 8/24/2022)
		--14450=sA|m1453|x56.31|y53.98 -- Stormwind City/0, Orphan Matron Nightingale (Checked 8/24/2022) (Only sells during Children's Week)
		--14481=sA|m1453|x61.26|y74.98 -- Stormwind City/0, Emmithue Smails (Checked 8/24/2022) (Only sells during Children's Week)
		12781=sA|m1453|x75.16|y66.56|wInside the building -- Stormwind City/0, Master Sergeant Biggins (Checked 8/24/2022)
		--12783=sA|m1453|x76.08|y65.41 -- Stormwind City/0, Lieutenant Karter (Checked 8/24/2022)
		26394=sA|m1453|x74.28|y67.65|wInside the building -- Stormwind City/0, Captain O'Neal (Checked 8/24/2022)
		26393=sA|m1453|x75.02|y67.77|wInside the building -- Stormwind City/0, Captain Dirgehammer (Checked 8/24/2022)
		12778=sA|m1453|x75.32|y67.43|wInside the building -- Stormwind City/0, Lieutenant Rachel Vaccar (Checked 8/24/2022)
		12785=sA|m1453|x75.59|y67.09|wInside the building -- Stormwind City/0, Sergeant Major Clate (Checked 8/24/2022)
		12784=sA|m1453|x75.42|y67.31|wInside the building -- Stormwind City/0, Lieutenant Jackspring (Checked 8/24/2022)
		29288=sA|m1453|x23.27|y36.70|wHe walks around on the deck of the ship -- Stormwind City/0, Engineer Kurtis Paddock (Checked 8/24/2022)
		29291=sA|m1453|x23.25|y36.56|wOn the deck of the ship -- Stormwind City/0, Galley Chief Paul Kubit (Checked 8/24/2022)
		28347=sA|m1453|x74.36|y58.44|wInside the building -- Stormwind City/0,Miles Sidney (Checked 8/24/2022)
		30730=sA|m1453|x49.57|y74.94|wInside the building -- Stormwind City/0, Stanly McCormick (Checked 8/24/2022)
		8118=sA|m1453|x55.4|y58.4 -- Stormwind City/0, Lillian Singh (Checked 8/24/2022) (Only appears on July 4/September 30)
		13435=sA|m1453|x62.23|y70.28 -- Stormwind City/0, Khole Jinglepocket (Checked 8/24/2022) (Only appears during Winter Veil)
		13436=sA|m1453|x62.59|y70.02 -- Stormwind City/0, Guchie Jinglepocket (Checked 8/24/2022) (Only appears during Winter Veil)
		24054=sA|m117|x62.42|y17.27|wInside the building -- Howling Fjord/0, Balar Rumsbane (checked 9/22/2022)
		23735=sA|m117|x59.50|y63.82 -- Howling Fjord/0, Bartleby Armorfist (checked 9/22/2022)
		24057=sA|m117|x60.48|y15.86|wInside the building -- Howling Fjord/0, Christina Daniels (checked 9/22/2022)
		23737=sA|m117|x58.34|y62.90|wInside the building -- Howling Fjord/0, Coot "The Stranger" Albertson (checked 9/22/2022)
		24052=sA|m117|x61.01|y17.07 -- Howling Fjord/0, Eldrim Mounder (checked 9/22/2022)
		26934=sA|m117|x75.00|y65.19 -- Howling Fjord/0, Everett McGill (checked 9/28/2022)
		24356=sA|m117|x29.74|y42.37 -- Howling Fjord/0, Glen Roberts (checked 9/22/2022)
		26908=sA|m117|x58.33|y62.23|wInside the building -- Howling Fjord/0, Helen Fairchild
		24053=sA|m117|x62.49|y17.23|wInside the building -- Howling Fjord/0, Helga Rumsbane (checked 9/22/2022)
		23937=sA|m117|x30.85|y41.46|wInside the building -- Howling Fjord/0, Innkeeper Celeste Goodhutch (checked 9/22/2022)
		23731=sA|m117|x58.39|y62.45|wInside the building -- Howling Fjord/0, Innkeeper Hazel Lagras (checked 9/22/2022)
		24333=sA|m117|x30.73|y41.55|wInside the building -- Howling Fjord/0, Bartender Jason Goodhutch (checked 9/22/2022)
		23908=sA|m117|x29.83|y42.60 -- Howling Fjord/0, Jhet Ironbeard (checked 9/22/2022)
		32773=sA|m117|x59.64|y63.96 -- Howling Fjord/0, Logistics Officer Brighton (checked 9/22/2022)
		23732=sA|m117|x58.37|y62.92|wInside the building -- Howling Fjord/0, Sorely Twitchblade (checked 9/22/2022)
		23802=sA|m117|x58.31|y62.31|wInside the building -- Howling Fjord/0, Wink Sprinklesprankle (checked 9/22/2022)
		24066=sA|m117|x60.65|y16.06 -- Howling Fjord/0, Artie Grizzlehand (checekd 9/28/2022)	
		--29658=sA|m117|x31.61|y41.36 -- Howling Fjord/0, Chelsea Reese (checked 9/28/2022) //STABLE
		--23733=sA|m117|x58.71|y63.08 -- Howling Fjord/0, Horatio the Stable Boy (checked 9/28/2022) //STABLE		
		26900=sA|m117|x30.97|y41.11|wInside the building -- Howling Fjord/0, Tinky Stabberson (checked 9/28/2022)
		26596=sA|m114|x57.11|y18.72|wInside the building -- Borean Tundra/0, "Charlie" Northtop	(Checked 9/21/2022)
		25248=sA|m114|x58.57|y67.14 -- Borean Tundra/0, "Salty" John Thorpe (Checked 9/21/2022)
		27012=sA|m114|x57.70|y72.32 -- Borean Tundra/0, Beem Goldsprocket (Checked 9/21/2022)
		27011=sA|m114|x57.82|y66.05 -- Borean Tundra/0, Broff Bombast (Checked 9/21/2022)
		--27010=sA|m114|x58.40|y68.50 -- Borean Tundra/0, Celidh Aletracker //STABLE
		26600=sA|m114|x56.40|y19.80|wWalking around this area -- Borean Tundra/0, Chief Engineer Galpen Rolltie	(Checked 
		35131=sA|m114|x58.87|y68.09 -- Borean Tundra/0, Durgan Thunderbeak (Checked 9/21/2022)
		25245=sA|m114|x58.29|y68.05 -- Borean Tundra/0, James Deacon (Checked 9/21/2022)
		32564=sA|m114|x57.72|y66.36 -- Borean Tundra/0, Logistics Officer Silverstone (Checked 9/21/2022)
		24357=sA|m114|x58.27|y68.48 -- Borean Tundra/0, Maethor Skyshadow (Checked 9/21/2022)
		26598=sA|m114|x57.38|y20.40 -- Borean Tundra/0, Mistie Flitterdawn (Checked 9/21/2022)
		26995=sA|m114|x57.56|y71.71 -- Borean Tundra/0, Tink Brightbolt	(Checked 9/21/2022)
		--26597=sA|m114|x57.14|y19.07 -- Borean Tundra/0, Toby "Mother Goose" Ironbolt //STABLE
		26599=sA|m114|x57.07|y19.84 -- Borean Tundra/0, Willis Wobblewheel (Checked 9/21/2022)
		27385=sA|m114|x56.60|y73.00 -- ??, Ronald Anderson
		27051=sA|m115|x29.28|y56.18 -- Dragonblight/0, Doldaen (checked 9/23/2022)
		27038=sA|m115|x77.45|y51.94|wUpstairs inside the building -- Dragonblight/0, Drolfy (checked 9/23/2022)
		27041=sA|m115|x77.56|y51.60|wWalking around inside the building -- Dragonblight/0, Fanny McLumpkins (checked 9/23/2022)
		27042=sA|m115|x77.42|y51.68|wWalking around inside the building -- Dragonblight/0, Illusia Lune (checked 9/23/2022)
		27053=sA|m115|x29.38|y56.02 -- Dragonblight/0, Lanus Longleaf (checked 9/23/2022)
		27039=sA|m115|x77.57|y51.36|wInside the building -- Dragonblight/0, Lexey Brevig (checked 9/23/2022)
		27045=sA|m115|x77.82|y50.73 -- Dragonblight/0, Master Smith Devin Brevig (checked 9/23/2022)
		27054=sA|m115|x28.81|y55.89 -- Dragonblight/0, Modoru (checked 9/23/2022)
		27052=sA|m115|x28.89|y56.09 -- Dragonblight/0, Naohain (checked 9/23/2022)
		27044=sA|m115|x77.44|y52.38|wWalking around inside the building -- Dragonblight/0, Ordal McLumpkins (checked 9/23/2022)
		27057=sA|m115|x29.38|y56.14 -- Dragonblight/0, Saramer Whitewillow (checked 9/23/2022)
		27055=sA|m115|x29.02|y55.09 -- Dragonblight/0, Sentinel Amberline (checked 9/23/2022)
		--27056=sA|m115|x28.87|y55.99 -- Dragonblight/0, Sentinel Sweetspring (checked 9/23/2022) //STABLE
		27043=sA|m115|x77.37|y51.80|wInside the building -- Dragonblight/0, Trixy Trixerton (checked 9/23/2022)
		--29275=sA|m116|x34.60|y54.80 -- Grizzly Hills/0, Aspen Grove Supplier (checked HOSTILE)
		27071=sA|m116|x32.01|y60.43|wInside the building -- Grizzly Hills/0, Benjamin Jacobs (checked 9/23/2022)
		27062=sA|m116|x31.38|y59.86 -- Grizzly Hills/0, Brom Armstrong (checked 9/23/2022)
		27066=sA|m116|x31.97|y60.28|wInside the building -- Grizzly Hills/0, Jennifer Bell (checked 9/23/2022)
		29244=sA|m116|x31.58|y59.83 -- Grizzly Hills/0, Jesse Masters (checked 9/23/2022)
		27070=sA|m116|x31.32|y60.00 -- Grizzly Hills/0, Lisa Philbrook (checked 9/23/2022)
		--26377=sA|m116|x59.09|y26.61 -- Grizzly Hills/0, Squire Percy (checked 9/23/2022) //STABLE
		26229=sA|m116|x59.79|y27.83 -- Grizzly Hills/0, Tiernan Anvilheart (checked 9/23/2022)
		--27760=sA|m116|x13.80|y86.40 -- Grizzly Hills/0, "Grizzly" D. Adams (checked 9/28/2022) //TEMPORARY
		26382=sA|m116|x59.12|y28.12 -- Grizzly Hills/0, Balfour Blackblade (checked 9/28/2022)
		--29252=sA|m116|x16.00|y86.80 -- Grizzly Hills/0, Jason Riggins //TEMPORARY
		26374=sA|m116|x59.80|y28.02 -- Grizzly Hills/0, Maevin Farmoon (checked 9/28/2022)
		--27068=sA|m116|x32.52|y59.51 -- Grizzly Hills/0, Matthew Ackerman (checked 9/28/2022) //STABLE
		26375=sA|m116|x59.56|y26.30 -- Grizzly Hills/0, Quartermaster McCarty (checked 9/28/2022)
		27089=sA|m116|x32.21|y60.17|wUpstairs inside the building -- Grizzly Hills/0, Saffron Reynolds (checked 9/28/2022)
		--29250=sA|m116|x13.80|y84.60 -- Grizzly Hills/0, Tim Street //TEMPORARY
		26388=sA|m116|x59.00|y28.12 -- Grizzly Hills/0, Veira Langdon (checked 9/28/2022)
		27088=sA|m116|x32.00|y60.42|wUpstairs inside the building -- Grizzly Hills/0, Yolanda Haymer (checked 9/28/2022)
		29922=sA|m120|x28.49|y74.54 -- The Storm Peaks/0, Corig the Cunning (checked 9/26/2022)
		29923=sA|m120|x28.83|y74.92 -- The Storm Peaks/0, Dagni Oregleam (checked 9/26/2022)
		29926=sA|m120|x28.71|y74.38 -- The Storm Peaks/0, Gunda Boldhammer (checked 9/26/2022)
		29744=sA|m120|x28.83|y74.07 -- The Storm Peaks/0, Rork Sharpchin (checked 9/26/2022)
		29925=sA|m120|x28.57|y74.71 -- The Storm Peaks/0, Rutner Steelpick (checked 9/26/2022)
		29948=sA|m120|x28.66|y74.38 -- The Storm Peaks/0, Boarmaster Bragh (checked 9/28/2022) //STABLE
		31776=sA|m118|x56.99|y62.57 -- Icecrown/0, Frazzle Geargrinder (checked 9/27/2022)
		30345=sA|m118|x55.20|y39.40|wOn the Skybreaker Airship -- Icecrown/0, Chief Engineer Boltwrench (checked 9/27/2022)
		35573=sA|m118|x75.20|y21.50 -- ??, Arcanist Asarina
		35579=sA|m118|x75.40|y21.50 -- ??, Aspirant Forudir
		35575=sA|m118|x75.20|y21.50 -- ??, Champion Isimode
		33307=sA|m118|x76.40|y19.20 -- ??, Corporal Arthur Flew
		33310=sA|m118|x76.40|y19.40 -- ??, Derrick Brindlebeard
		30346=sA|m118|x55.59|y38.25|wOn the Skybreaker Airship -- ??, Galley Chief Dolinger (checked)
		34881=sA|m118|x76.20|y19.50 -- ??, Hiren Loresong
		33657=sA|m118|x76.20|y19.20 -- ??, Irisee
		35291=sA|m118|x75.80|y20.20 -- ??, Moonbell
		33650=sA|m118|x76.40|y19.60 -- ??, Rillie Spindlenut
		33653=sA|m118|x76.20|y19.20 -- ??, Rook Hawkfist
		35577=sA|m118|x75.40|y21.50 -- ??, Valiant Laradia

		-- HORDE --
		26941=sH|m114|x41.34|y54.60|wInside the building -- Borean Tundra/0, Brokkan Bear-Arms (checked 9/21/2022)
		26720=sH|m114|x76.62|y37.46|wInside the building -- Borean Tundra/0, Danook Stormwhisper (checked 9/21/2022)
		27067=sH|m114|x49.74|y10.08 -- Borean Tundra/0, Drigoth (checked 9/21/2022)
		26968=sH|m114|x41.91|y53.19 -- Borean Tundra/0, Drikka (checked 9/21/2022)
		26044=sH|m114|x40.28|y55.02|wWalking around inisde the building -- Borean Tundra/0, Durkot Wolfbrother (checked 9/21/2022)
		32565=sH|m114|x41.42|y53.69 -- Borean Tundra/0, Gara Skullcrush (checked 9/21/2022)
		26938=sH|m114|x41.03|y54.36|wInside the building -- Borean Tundra/0, Groll (checked 9/21/2022)
		--26721=sH|m114|x77.03|y37.23 -- Borean Tundra/0, Halona Stormwhisper (checked //STABLE
		26977=sH|m114|x41.26|y53.96|wUpstairs inside the building -- Borean Tundra/0, Adelene Sunlance (checked 9/21/2022)
		25274=sH|m114|x41.10|y55.50|wWalking around inside the building -- Borean Tundra/0, Armorer Orkuruk (checked 9/21/2022)	
		27069=sH|m114|x49.67|y10.19|wInside the building -- Borean Tundra/0, Matron Magah (checked 9/21/2022)
		26709=sH|m114|x76.25|y37.18|wInside the building -- Borean Tundra/0, Pahu Frosthoof (checked 9/21/2022)
		25736=sH|m114|x48.96|y10.27 -- Borean Tundra/0, Supply Master Taz'ishi (checked 9/21/2022)
		26697=sH|m114|x76.62|y37.18|wInside the building -- Borean Tundra/0, Tewah Chillmane (Checked 9/22/2022)
		35132=sH|m114|x42.17|y55.40|wOn the roof -- Borean Tundra/0, Tohfo Skyhoof (checked 9/22/2022)
		26718=sH|m114|x76.90|y38.19 -- Borean Tundra/0, Trader Alorn (checked 9/22/2022)
		27063=sH|m114|x49.41|y10.16 -- Borean Tundra/0, Vrok (checked 9/22/2022)
		25278=sH|m114|x41.92,|y54.48|wInside the building -- Borean Tundra/0, Williamson (checked 9/22/2022)
		26945=sH|m114|x41.85|y54.08|wInside the building -- Borean Tundra/0, Zend'li Venomtusk (checked 9/22/2022)
		27058=sH|m114|x48.80|y10.30 -- Borean Tundra/0, Korag Keeneye (checked 9/28/2022)
		27065=sH|m114|x49.79|y10.46 -- Borean Tundra/0, Breka Wolfsister (checked 9/28/2022)
		24347=sH|m117|x79.25|y28.91 -- Howling Fjord/0, Alexis Walker (checked 9/22/2022)
		24291=sH|m117|x46.50|y70.09|wPatrols along this road -- Howling Fjord/0, Anton (checked 9/22/2022)
		24341=sH|m117|x79.49|y30.48 -- Howling Fjord/0, Barnabas Frye (checked 9/22/2022)
		24149=sH|m117|x52.15|y66.41 -- Howling Fjord/0, Basil Osgood (checked 9/22/2022)
		26959=sH|m117|x79.38|y29.29 -- Howling Fjord/0, Booker Kells (checked 9/22/2022)
		24033=sH|m117|x49.50|y10.80 -- Howling Fjord/0, Bori Wintertotem (checked 9/22/2022)
		24343=sH|m117|x78.71|y29.66 -- Howling Fjord/0, Brock Olson (checked 9/22/2022)
		24313=sH|m117|x26.33|y24.39 -- Howling Fjord/0, Celina Summers (checked 9/22/2022)
		24148=sH|m117|x53.54|y66.14 -- Howling Fjord/0, David Marks (checked 9/22/2022)
		33018=sH|m117|x52.00|y66.13|wWalking around inside the building -- Howling Fjord/0, Jennifer Owings (checked 9/22/2022)
		24349=sH|m117|x78.48|y28.44|wInside the building -- Howling Fjord/0, Jessica Evans (checked 9/22/2022)
		--24067=sH|m117|x49.46|y11.07 -- Howling Fjord/0, Mahana Frosthoof (checked 9/22/2022) //STABLE
		24154=sH|m117|x52.04|y66.47 -- Howling Fjord/0, Mary Darrow (checked 9/22/2022)
		33019=sH|m117|x52.03|y66.10|wInside the building -- Howling Fjord/0, Megan Owings (checked 9/22/2022)
		24330=sH|m117|x53.85|y66.94 -- Howling Fjord/0, Orson Locke (checked 9/22/2022)
		24348=sH|m117|x79.50|y30.53 -- Howling Fjord/0, Patrick Hall (checked 9/22/2022)
		24350=sH|m117|x79.06|y30.80 -- Howling Fjord/0, Robert Clarke (checked 9/22/2022)
		24188=sH|m117|x25.94|y24.66 -- Howling Fjord/0, Samuel Rosemond (checked 9/22/2022)
		32774=sH|m117|x79.64|y30.77 -- Howling Fjord/0, Sebastian Crane (checked 9/22/2022)
		26984=sH|m117|x53.82|y65.85|wInside the building -- Howling Fjord/0, Stephan Franks (checked 9/22/2022)
		24141=sH|m117|x51.75|y66.73 -- Howling Fjord/0, Stephen Barone (checked 9/22/2022)
		24028=sH|m117|x48.11|y11.01 -- Howling Fjord/0, Talu Frosthoof (checked 9/28/2022)
		24147=sH|m117|x51.78|y66.89 -- Howling Fjord/0, Tara Cooper (checked 9/22/2022)
		24342=sH|m117|x79.73|y30.84|wInside the building -- Howling Fjord/0, Timothy Holland (checked 9/22/2022)
		26567=sH|m115|x36.40|y47.07 -- Dragonblight/0, Aegalas (checked 9/23/2022)
		27022=sH|m115|x36.24|y46.98 -- Dragonblight/0, Afha (checekd 9/23/2022)
		26569=sH|m115|x36.20|y46.51 -- Dragonblight/0, Alys Vol'tyr (checked 9/23/2022)
		27031=sH|m115|x76.85|y62.15 -- Dragonblight/0, Apothecary Rose (checked 9/23/2022)
		27030=sH|m115|x76.95|y62.10 -- Dragonblight/0, Bradley Towns (checked 9/23/2022)
		28057=sH|m115|x76.80|y62.74 -- Dragonblight/0, Garmin Herzog (checked 9/23/2022)
		27025=sH|m115|x77.16|y62.02 -- Dragonblight/0, Harold Haggler (checked 9/23/2022)
		27032=sH|m115|x77.18|y63.05|wWalking around this area -- Dragonblight/0, Lovely Liddia (checked 9/23/2022)
		27027=sH|m115|x76.87|y63.13|wInside the building -- Dragonblight/0, Mrs. Winterby (checked 9/23/2022)
		27267=sH|m115|x75.97|y63.26 -- Dragonblight/0, Quartermaster Bartlett (Checked 9/23/2022)
		27026=sH|m115|x76.69|y63.12|wInside the building -- Dragonblight/0, Rohesia Werner (checked 9/23/2022)
		27019=sH|m115|x36.63|y46.24 -- Dragonblight/0, Siegesmith Gulda (checked 9/23/2022)
		26504=sH|m115|x37.08|y48.56 -- Dragonblight/0, Soar Hawkfury (checked 9/23/2022)
		27021=sH|m115|x36.50|y46.24 -- Dragonblight/0, Tradesman Kontor (checked 9/23/2022)
		26568=sH|m115|x36.20|y46.83 -- Dragonblight/0, Zebu'tan (checked 9/23/2022)
		27037=sH|m116|x22.05|y65.11 -- Grizzly Hills/0, Hidetrader Jun'ik (checked 9/23/2022)
		26680=sH|m116|x65.42|y46.89|wInside the building -- Grizzly Hills/0, Aiyan Coldwind (checked 9/23/2022)
		27125=sH|m116|x20.79|y64.57|wInside the building -- Grizzly Hills/0, Barracks Master Rhekku (checked 9/23/2022)
		26936=sH|m116|x65.52|y47.80 -- Grizzly Hills/0, Chaska Frosthoof (checked 9/23/2022)
		26939=sH|m116|x64.84|y46.70 -- Grizzly Hills/0, Koro the Wanderer (checked 9/23/2022)
		26707=sH|m116|x65.31|y48.07 -- Grizzly Hills/0, Litoko Icetotem (checked 9/23/2022)
		26868=sH|m116|x22.69|y66.17 -- Grizzly Hills/0, Provisioner Lorkran (checked 9/23/2022)
		--27730=sH|m116|x13.80|y86.20 -- Grizzly Hills/0, Purkom (checked, PVP control)
		27132=sH|m116|x23.00|y62.88 -- Grizzly Hills/0, Sani'i (checked 9/23/2022)
		26950=sH|m116|x64.59|y46.90 -- Grizzly Hills/0, Sanut Swiftspear (checked 9/23/2022)
		27133=sH|m116|x22.56|y62.90|wInside the building -- Grizzly Hills/0, Seer Yagnar (checked 9/23/2022)
		27134=sH|m116|x23.40|y63.07 -- Grizzly Hills/0, Smith Prigka (checked 9/23/2022)
		26944=sH|m116|x65.01|y47.88 -- Grizzly Hills/0, Soulok Stormfury (checked 9/23/2022)
		--29740=sH|m116|x21.65|y64.08 -- Grizzly Hills/0, Craga Ironsting (checked 9/28/2022) //STABLE
		--29253=sH|m116|x16.00|y86.80 -- Grizzly Hills/0, Koloth (checked 9/28/2022) //TEMPORARY
		--29251=sH|m116|x13.80|y84.80 -- Grizzly Hills/0, Kor (checked 9/28/2022) //TEMPORARY
		29947=sH|m120|x37.15|y49.80|wInside the building -- The Storm Peaks/0, Apothecary Maple (checked 9/26/2022)
		29970=sH|m120|x67.66|y49.90 -- The Storm Peaks/0, Danho Farcloud (checked 9/26/2022)
		29968=sH|m120|x66.80|y50.06 -- The Storm Peaks/0, Hapanu Coldwind (checked 9/26/2022)
		29945=sH|m120|x36.37|y48.95 -- The Storm Peaks/0, Marksman Udabu (checked 9/26/2022)
		30472=sH|m120|x36.97|y49.51|wInside the building -- The Storm Peaks/0, Olut Alegut (checked 9/26/2022)
		29969=sH|m120|x67.38|y50.64 -- The Storm Peaks/0, Ontak (checked 9/26/2022)
		29944=sH|m120|x37.13|y49.52|wInside the building -- The Storm Peaks/0, Peon Gakra (checked 9/26/2022)
		29971=sH|m120|x67.61|y50.60|wInside the building -- The Storm Peaks/0, Wabada Whiteflower (checked 9/26/2022)
		--29967=sH|m120|x67.52,|y50.29 -- The Storm Peaks/0, Udoho Icerunner (checked 9/28/2022) //STABLE
		31781=sH|m118|x51.94|y57.60 -- Icecrown/0, Blast Thunderbomb (checked 9/27/2022)
		30825=sH|m118|x60.00|y34.59|wOn the Ogrim's Hammer Airship-- Icecrown/0, Chief Engineer Copperclaw (checked 9/27/2022)
		30827=sH|m118|x60.00|y34.50 -- Icecrown/0, Utamu
		35580=sH|m118|x75.40|y22.00 -- ??, Aspirant Naradiel
		35576=sH|m118|x75.20|y22.00 -- ??, Champion Faesrol		
		33556=sH|m118|x76.20|y24.40 -- ??, Doru Thunderhorn
		33555=sH|m118|x76.40|y24.00 -- ??, Eliza Killian
		33553=sH|m118|x76.40|y24.20 -- ??, Freka Bloodaxe
		35574=sH|m118|x75.20|y22.00 -- ??, Magistrix Iruvia
		33554=sH|m118|x76.00|y24.40 -- ??, Samamba
		35290=sH|m118|x75.59|y23.50 -- ??, Steen Horngrass
		33557=sH|m118|x76.20|y23.80 -- ??, Trellis Morningsun
		35578=sH|m118|x75.40|y22.00 -- ??, Valiant Bressia
		34772=sH|m118|x76.20|y24.00 -- ??, Vasarin Redmorn

		-- NEUTRAL --
		27193=sB|m114|x77.17|y50.40 -- Borean Tundra/0, Alornerk (checked 9/21/2022)
		27137=sB|m114|x46.61|y32.74|wInside the building -- Borean Tundra/0, Apprentice Fraser (checked 9/21/2022)
		27138=sB|m114|x46.74|y32.92|wUpstairs inside the building -- Borean Tundra/0, Apprentice Rosen (checked 9/21/2022)
		25314=sB|m114|x32.94|y34.40|wInside the building -- Borean Tundra/0, Archmage Berinand (checked 9/21/2022)
		27187=sB|m114|x78.39|y49.28 -- Borean Tundra/0, Caregiver Poallu (checked 9/21/2022)
		27291=sB|m114|x46.37|y32.65|wUpstairs inside the building -- Borean Tundra/0, Initiate Mehrtens (checked 9/21/2022)
		27188=sB|m114|x77.92|y52.20|wInside the building -- Borean Tundra/0, Tonraq (checked 9/21/2022)
		27140=sB|m114|x46.34|y32.40|wUpstairs inside the building -- Borean Tundra/0, Librarian Andersen (checked 9/21/2022)
		27147=sB|m114|x46.72|y32.47|wUpstairs inide the building -- Borean Tundra/0, Librarian Erickson (checked 9/21/2022)
		27141=sB|m114|x45.24|y33.95 -- Borean Tundra/0, Librarian Hamilton (checked 9/21/2022)
		27143=sB|m114|x46.55|y33.11|wUpstairs inside the building -- Borean Tundra/0, Librarian Ingram (checked 9/21/2022)
		27142=sB|m114|x46.27|y32.85|wUpstairs inside the building -- Borean Tundra/0, Librarian Jeffers (checked 9/21/2022)
		26110=sB|m114|x33.49|y34.37 -- Borean Tundra/0, Librarian Serrah (checked 9/21/2022)
		27139=sB|m114|x46.52|y32.56 -- Borean Tundra/0, Librarian Whitley (checked 9/21/2022)
		27186=sB|m114|x79.61|y50.61 -- Borean Tundra/0, Oogrooq (checked 9/21/2022)
		27195=sB|m114|x78.02|y51.61 -- Borean Tundra/0, Tarralikitak (checked 9/21/2022)
		27190=sB|m114|x78.20|y52.69 -- Borean Tundra/0, Tupit (checked 9/21/2022)
		--27194=sB|m114|x78.16|y49.05 -- Borean Tundra/0, Trapper Saghani (checked 9/28/2022) //STABLE
		--31805=sB|m115|x44.80|y79.80 -- Borean Tundra/0, Nagojut (ON A BOAT)
		24539=sB|m117|x35.09|y80.94 -- Howling Fjord/0, "Silvermoon" Harry (checked 9/22/2022)
		27149=sB|m117|x25.66|y58.70 -- Howling Fjord/0, Arrluk (checked 9/22/2022)
		27148=sB|m117|x25.39|y59.86|wInside the building -- Howling Fjord/0, Caregiver Iqniq (checked 9/22/2022)
		27151=sB|m117|x25.65|y57.44 -- Howling Fjord/0, Deniigi (checked 9/22/2022)
		27144=sB|m117|x24.72|y59.01 -- Howling Fjord/0, Noatak (checked 9/22/2022)
		31916=sB|m117|x25.53|y58.72 -- Howling Fjord/0, Tanaika (checked 9/22/2022)
		27145=sB|m117|x24.87|y57.71 -- Howling Fjord/0, Tipvigut (checked 9/22/2022)
		--27150=sB|m117|x25.42|y59.04 -- Howling Fjord/0, Trapper Shesh //STABLE (checked 9/22/2022)
		27146=sB|m117|x25.65|y57.07 -- Howling Fjord/0, Uukkarnit (checked 9/22/2022)
		27174=sB|m115|x48.14|y74.76|wInside the building -- Dragonblight/0, Caregiver Mumik (checked 9/23/2022)
		32533=sB|m115|x59.94|y53.02|wAt the top of the building -- Dragonblight/0, Cielstrasza (checked 9/23/2022)
		27943=sB|m115|x59.38|y54.95 -- Dragonblight/0, Dalormi (checked 9/23/2022)
		27950=sB|m115|x59.80|y54.24|wInside the building -- Dragonblight/0, Demestrasz (checked 9/23/2022)
		27935=sB|m115|x60.20|y53.53|wInside the building -- Dragonblight/0, Ferithos (checked 9/23/2022)
		27184=sB|m115|x48.62|y75.48 -- Dragonblight/0, Imnek (checked 9/23/2022)
		27185=sB|m115|x49.49|y75.38 -- Dragonblight/0, Kuk'uq (checked 9/23/2022)
		27940=sB|m115|x59.32|y53.62|wInside the building -- Dragonblight/0, Lethecus (checked 9/23/2022)
		27176=sB|m115|x47.42|y74.60 -- Dragonblight/0, Mystic Makittuq (checked 9/23/2022)		
		27181=sB|m115|x48.51|y75.50 -- Dragonblight/0, Qannik (checked 9/23/2022)
		--31804=sB|m115|x49.80|y80.30 -- Dragonblight/0, Qatiichii (BOAT)
		--27948=sB|m115|x61.46|y53.36 -- Dragonblight/0, Risera (checked 9/23/2022) //STABLE
		32763=sB|m115|x48.47|y75.66 -- Dragonblight/0, Sairuk (checked 9/23/2022)
		27182=sB|m115|x49.51|y75.01 -- Dragonblight/0, Takubvik (checked 9/23/2022)
		27183=sB|m115|x48.42|y74.71 -- Dragonblight/0, Trapper Tikaani (checked 9/23/2022)
		27938=sB|m115|x60.31|y54.85|wInside the building -- Dragonblight/0, Trizormu (checked 9/23/2022)
		26898=sB|m115|x55.04|y23.55 -- Dragonblight/0, Troz (checked 9/23/2022)
		26474=sB|m116|x15.96|y47.79 -- Grizzly Hills/0, Ameenah (checked 9/23/2022)
		--29270=sB|m116|x35.00|y55.00 -- Grizzly Hills/0, Aspen Grove Trader (checked HOSTILE)
		29277=sB|m116|x74.02|y34.09 -- Grizzly Hills/0, Datalore Smallsphere (checked 9/23/2022)
		26484=sB|m116|x69.10|y40.10 -- Grizzly Hills/0, Hugh Glass (checked 9/23/2022)
		28799=sB|m121|x41.05|y67.97 -- Zul'Drak/0, Alanna (checked 9/26/2022)
		28807=sB|m121|x32.22|y75.89 -- Zul'Drak/0, Amarante (checked 9/26/2022)
		30098=sB|m121|x45.73|y56.41|wWalking around this area -- Zul'Drak/0,Amphitheater Vendor (checked 9/26/2022)
		28828=sB|m121|x58.81|y56.65 -- Zul'Drak/0, Ansari (checked 9/26/2022)
		28796=sB|m121|x41.22|y67.83 -- Zul'Drak/0, Arlen Brighthammer (checked 9/26/2022)
		--30039=sB|m121|x59.01|y57.75 -- Zul'Drak/0,Asgari //STABLE (checked 9/26/2022
		28855=sB|m121|x59.53|y57.04 -- Zul'Drak/0, Ba'kari (checked 9/26/2022)
		28811=sB|m121|x32.09|y75.52 -- Zul'Drak/0,Brady Ironcrock (checked 9/26/2022)
		28806=sB|m121|x32|y76 -- Zul'Drak/0, Chad Carter (checked 31.98,76.07)
		28832=sB|m121|x59.32|y57.02 -- Zul'Drak/0, Chin'ika (checked 9/26/2022)
		28798=sB|m121|x40.38|y68.72 -- Zul'Drak/0, Claudia Bloodraven (checked 9/26/2022)
		28827=sB|m121|x59.43|y57.44 -- Zul'Drak/0, Co'man (checked 9/26/2022)
		28870=sB|m121|x14.64|y73.85 -- Zul'Drak/0, Corpsedust (checked 9/26/2022)
		28866=sB|m121|x14.18|y73.32 -- Zul'Drak/0, Corrosion (checked 9/26/2022)
		28869=sB|m121|x14.65|y73.63 -- Zul'Drak/0, Deathdrip (checked 9/26/2022)
		29688=sB|m121|x25.23|y63.88 -- Zul'Drak/0, Engineer Reed (checked 9/26/2022)
		--28790=sB|m121|x40.29|y65.29 -- Zul'Drak/0, Fala Softhoof //STABLE (checked 9/26/2022)
		28589=sB|m121|x19.86|y75.45 -- Zul'Drak/0, Gristlegut (checked 9/26/2022)
		28797=sB|m121|x41.37|y67.84 -- Zul'Drak/0, Haley Copperturn (checked 9/26/2022)
		28794=sB|m121|x40.26|y68.84 -- Zul'Drak/0, Kevin Weaver (checked 9/26/2022)
		28812=sB|m121|x32.28|y75.79 -- Zul'Drak/0, Lapu Stormhorn (checked 9/26/2022)
		28810=sB|m121|x32.20|y75.28 -- Zul'Drak/0,Lessien (checked 9/26/2022)
		28791=sB|m121|x40.83|y66.25|wInside the building -- Zul'Drak/0, Marissa Everwatch (checked 9/26/2022)
		28868=sB|m121|x14.63|y74.04 -- Zul'Drak/0,Mulch (checked 9/26/2022)
		28792=sB|m121|x40.59|y68.69 -- Zul'Drak/0, Noggra (checked 9/26/2022)
		29583=sB|m121|x59.33|y57.30 -- Zul'Drak/0, Pan'ya (checked 9/26/2022)
		28830=sB|m121|x59.88|y56.57 -- Zul'Drak/0, Ra'wiri (checked 9/26/2022)
		28829=sB|m121|x59.56|y57.45|wWalking around this area -- Zul'Drak/0, Saree (checked 9/26/2022)
		28871=sB|m121|x14.30|y74.18 -- Zul'Drak/0, Scabbard (checked 9/26/2022)
		28867=sB|m121|x14.33|y73.27 -- Zul'Drak/0, Spiked (checked 9/26/2022)
		28872=sB|m121|x14.15|y73.95 -- Zul'Drak/0, Squirmworm (checked 9/26/2022)
		28809=sB|m121|x32.28|y75.58 -- Zul'Drak/0, Vincent Huber (checked 9/26/2022)
		28831=sB|m121|x59.24|y57.24|wWalking around this area -- Zul'Drak/0, Yamuna (checked 9/26/2022)
		31910=sB|m119|x54.59|y56.12 -- Sholazar Basin/0, Geen (checked 9/26/2022)
		29014=sB|m119|x55.91|y70.33 -- Sholazar Basin/0, Grakjek (checked 9/26/2022)
		--28047=sB|m119|x27.36|y59.40 -- Sholazar Basin/0, Hadrius Harlowe //STABLE (checked 9/26/2022)
		28046=sB|m119|x26.70|y59.55 -- Sholazar Basin/0, Korg the Cleaver (checked 9/26/2022)
		29035=sB|m119|x53.53|y55.89 -- Sholazar Basin/0, Loomee (checked 9/26/2022)
		28040=sB|m119|x27.32|y59.75 -- Sholazar Basin/0, Mardan Thunderhoof (checked 9/26/2022)
		28038=sB|m119|x26.75|y59.27 -- Sholazar Basin/0, Purser Boulian (checked 9/26/2022)
		29122=sB|m119|x55.01|y69.47 -- Sholazar Basin/0, Rarkag (checked 9/26/2022)
		29015=sB|m119|x55.14|y71.80 -- Sholazar Basin/0, Shaman Partak (checked 9/26/2022)
		29037=sB|m119|x54.05|y55.46 -- Sholazar Basin/0, Soo-jam (checked 9/26/2022)
		29121=sB|m119|x53.90|y57.08 -- Sholazar Basin/0, Soo-yum (checked 9/26/2022)
		31911=sB|m119|x55.14|y69.02 -- Sholazar Basin/0, Tanak (checked 9/26/2022)
		--29959=sB|m120|x30.63|y36.87 -- The Storm Peaks/0, Andurg Slatechest //STABLE (checked 9/26/2022)
		29961=sB|m120|x31.16|y38.15|wInside the building -- The Storm Peaks/0, Brangrimm (checked 9/26/2022)
		32594=sB|m120|x67.12|y60.97 -- The Storm Peaks/0, Calder (checked 9/26/2022)
		32477=sB|m120|x45.03|y27.50 -- The Storm Peaks/0, Chester Copperpot (checked 9/26/2022)
		29964=sB|m120|x31.38|y38.26|wInside the building -- The Storm Peaks/0, Dargum Hammerdeep (checked 9/26/2022)
		30010=sB|m120|x50.04|y69.77|wInside the building -- The Storm Peaks/0, Fylla Ingadottir (checked 9/26/2022)
		29905=sB|m120|x41.30|y85.98|wInside the building -- The Storm Peaks/0, Grillix Bonesaw (checked 9/26/2022)
		29906=sB|m120|x40.96|y86.08 -- The Storm Peaks/0, Heksi (checked 9/26/2022)
		29962=sB|m120|x31.44|y37.70|wInside the building -- The Storm Peaks/0, Horgoru the Collector (checked 9/26/2022)
		32540=sB|m120|x66.16|y61.43 -- The Storm Peaks/0, Lillehoff (checked 9/26/2022)
		30005=sB|m120|x48.86|y65.04|wInside the building -- The Storm Peaks, Lodge-Matron Embla (checked 9/26/2022)
		29963=sB|m120|x30.90|y37.36|wInside the building -- The Storm Peaks/0, Magorn (checked 9/26/2022)
		29909=sB|m120|x40.76|y85.37|wInside the building -- The Storm Peaks/0, Nilika Blastbeaker (checked 9/26/2022)
		29908=sB|m120|x40.73|y85.38|wInside the building -- The Storm Peaks/0, Plip Fatpurse (checked 9/26/2022)
		--31247=sB|m120|x40.74|y84.86 -- The Storm Peaks/0, Roxi Ramrocket COLD WEATHER FLYING (checked 9/26/2022)
		30011=sB|m120|x48.58|y71.24|wInside the building -- The Storm Peaks/0, Sigdis the Trader (checked 9/26/2022)
		32478=sB|m120|x44.97|y27.83 -- The Storm Peaks/0, Slosh (checked 9/26/2022)
		29904=sB|m120|x41.09|y85.91|wInside the building -- The Storm Peaks/0, Smilin' Slirk Brassknob (checked 9/26/2022)
		30006=sB|m120|x47.46|y70.45|wInside the building -- The Storm Peaks/0, Warsmith Sigfinna (checked 9/26/2022)
		29907=sB|m120|x40.96|y86.48 -- The Storm Peaks/0, Xark Bolthammer (checked 9/26/2022)
		33866=sB|m118|x69.60|y19.60 -- ??, Akrittok
		33602=sB|m118|x71.40|y20.80 -- ??, Anuur
		--30306=sB|m118|x42.13|y26.55 -- Icecrown/0, Bileblow //UNLOCK CONDITIONS (checked 9/27/2022)
		35344=sB|m118|x69.60|y22.00 -- ??, Bognar Ironfoot
		30310=sB|m118|x42.50|y25.10 -- Icecrown/0, Boltskull
		33599=sB|m118|x71.80|y20.80 -- ??, Brollen Wheatbeard
		33853=sB|m118|x73.00|y23.00 -- ??, Broxel Goldgrasp
		33600=sB|m118|x71.60|y21.00 -- ??, Cerie Larksong
		34885=sB|m118|x69.40|y23.20 -- ??, Dame Evniki Kapsalis
		32538=sB|m118|x43.40|y20.60 -- Icecrown/0, Duchess Mynx
		30434=sB|m118|x87.25|y75.89 -- Icecrown/0, Durik Bronzebomb (checked 9/27/2022)
		33601=sB|m118|x71.80|y20.80 -- ??, Elka Stormbrew
		33644=sB|m118|x74.80|y20.20 -- ??, Ellia Moondancer
		33598=sB|m118|x71.60|y21.00 -- ??, Fanii
		33594=sB|m118|x72.20|y20.80 -- ??, Fizzix Blastbolt
		30436=sB|m118|x86.93|y77.12 -- Icecrown/0, Halig Fireforge (checked 9/27/2022)
		--30304=sB|m118|x44.25|y22.35 -- Icecrown/0, Imhadria //STABLE (checked 9/27/2022)
		30067=sB|m118|x20.52|y47.77 -- Icecrown/0, Initiate Claget (checekd 9/27/2022)
		30070=sB|m118|x20.45|y47.58 -- Icecrown/0, Initiate Gahark (checked 9/27/2022)
		30069=sB|m118|x20.52|y47.82 -- Icecrown/0, Initiate Roderick (checked 9/27/2022)
		33645=sB|m118|x74.80|y20.20 -- ??, Jenna Thunderbrew
		33871=sB|m118|x73.20|y23.40 -- ??, Julie Osworth
		33597=sB|m118|x73.00|y20.50 -- ??, Liere Morningsong
		33865=sB|m118|x74.80|y23.40 -- ??, Makuli
		--30311=sB|m118|x41.96|y26.09 -- Icecrown/0, Mangled (checked 9/27/2022) //UNLOCK CONDITIONS
		33596=sB|m118|x73.00|y20.80 -- ??, Meline Duskpath
		33595=sB|m118|x72.40|y20.80 -- ??, Mera Mistrunner
		31115=sB|m118|x79.58|y72.73|wInside the building -- Icecrown/0, Quartermaster Vaskess (checked 9/27/2022)
		--30336=sB|m118|x44.84|y22.69|wInside the building -- Icecrown/0, Runesmith Balehammer //UNLOCK CONDITIONS (checked 9/27/2022)
		--30307=sB|m118|x42.06|y25.68 -- Icecrown/0, Sarhule the Risen (checked 9/27/2022) //UNLOCK CONDITIONS
		--30309=sB|m118|x42.52|y25.07 -- Icecrown/0, Shambles (checked 9/27/2022) //UNLOCK CONDITIONS
		30439=sB|m118|x86.69|y76.84 -- Icecrown/0, Sister Colleen Tulley (checked 9/27/2022)
		30438=sB|m118|x87.85|y77.82 -- Icecrown/0, Supply Officer Thalmers (checked 9/27/2022)
		33854=sB|m118|x71.65|y22.50 -- ??, Thomas Partridge
		33868=sB|m118|x71.80|y19.20 -- ??, Tingiyok
		33872=sB|m118|x73.60|y23.40 -- ??, Torgah
		33869=sB|m118|x70.00|y19.50 -- ??, Torngasak
		30431=sB|m118|x87.52|y75.58 -- Icecrown/0, Veteran Crusader Aliocha Segard (checked 9/27/2022)

		-- ALLIANCE --
		54=sA|m1429|x41.52|y65.89 -- Elwynn Forest/0, Corina Steele
		66=sA|m1429|x41.82|y67.16 -- Elwynn Forest/0, Tharynn Bouden
		74=sA|m1429|x41.36|y65.58 -- Elwynn Forest/0, Kurran Steele
		78=sA|m1429|x47.23|y41.9 -- Elwynn Forest/0, Janos Hammerknuckle
		151=sA|m1429|x43.96|y65.91 -- Elwynn Forest/0, Brog Hamfist
		152=sA|m1429|x47.48|y41.56 -- Elwynn Forest/0, Brother Danil
		190=sA|m1429|x47.56|y41.39 -- Elwynn Forest/0, Dermot Johns
		258=sA|m1429|x42.35|y89.37 -- Elwynn Forest/0, Joshua Maclure
		295=sA|m1429|x43.77|y65.8 -- Elwynn Forest/0, Innkeeper Farley
		384=sA|m1429|x84.15|y65.48 -- Elwynn Forest/0, Katie Hunter
		465=sA|m1429|x43.99|y65.68 -- Elwynn Forest/0, Barkeep Dobbins
		844=sA|m1429|x78.12|y72.96 -- Westfall/0, Antonio Perelli
		894=sA|m1429|x33.69|y82.9 -- Elwynn Forest/0, Homer Stonefield
		896=sA|m1429|x25.18|y73.88 -- Elwynn Forest/0, Veldan Lightfoot
		955=sA|m1429|x24.08|y73.19 -- Elwynn Forest/0, Sergeant De Vries
		958=sA|m1429|x64.88|y69.19 -- Elwynn Forest/0, Dawn Brightstar
		959=sA|m1429|x64.69|y69.5 -- Elwynn Forest/0, Morley Eberlein
		1198=sA|m1429|x83.28|y66.08 -- Elwynn Forest/0, Rallic Finn
		1213=sA|m1429|x47.69|y41.41 -- Elwynn Forest/0, Godric Rothgar
		1249=sA|m1429|x25.23|y74.06 -- Elwynn Forest/0, Quartermaster Hudson
		1250=sA|m1429|x83.31|y66.68 -- Elwynn Forest/0, Drake Lindgren
		1645=sA|m1429|x25.37|y73.99 -- Elwynn Forest/0, Quartermaster Hicks
		1650=sA|m1429|x82.94|y63.3 -- Elwynn Forest/0, Terry Palin
		2046=sA|m1429|x41.7|y65.78 -- Elwynn Forest/0, Andrew Krighton
		3935=sA|m1429|x44.23|y65.96 -- Elwynn Forest/0, Toddrick
		3937=sA|m1429|x32.94|y51.32 -- Elwynn Forest/0, Kira Songshine
		6367=sA|m1429|x44.21|y53.43 -- Elwynn Forest/0, Donni Anthania
		6373=sA|m1429|x50.05|y42.68 -- Elwynn Forest/0, Dane Winslow
		6374=sA|m1429|x44.39|y65.98 -- Elwynn Forest/0, Cylina Darkheart
		167=sA|m1432|x34.01|y46.54 -- Loch Modan/0, Morhan Coppertongue
		222=sA|m1432|x42.86|y9.88 -- Loch Modan/0, Nillen Andemar
		225=sA|m1431|x73.6|y50.03 -- Duskwood/0, Gavin Gnarltree
		226=sA|m1431|x73.92|y48.8 -- Duskwood/0, Morg Gnarltree
		227=sA|m1431|x73.64|y45.28 -- Duskwood/0, Mabel Solaj
		228=sA|m1431|x73.03|y44.47 -- Duskwood/0, Avette Fellwood
		233=sA|m1436|x56.04|y31.23 -- Westfall/0, Farmer Saldean
		274=sA|m1431|x73.66|y44.03 -- Duskwood/0, Barkeep Hann
		372=sA|m1432|x37.12|y47.15 -- Loch Modan/0, Karm Ironquill
		491=sA|m1436|x57.0|y47.16 -- Westfall/0, Quartermaster Lewis
		734=sA|m1434|x37.95|y2.98 -- Stranglethorn Vale/0, Corporal Bluth
		777=sA|m1433|x29.12|y47.32 -- Redridge Mountains/0, Amy Davenport
		789=sA|m1433|x27.08|y45.54 -- Redridge Mountains/0, Kimberly Hiett
		790=sA|m1433|x29.89|y47.36 -- Redridge Mountains/0, Karen Taylor
		791=sA|m1433|x28.76|y47.32 -- Redridge Mountains/0, Lindsay Ashlock
		793=sA|m1433|x30.56|y46.46 -- Redridge Mountains/0, Kara Adams
		829=sA|m1426|x30.08|y71.51 -- Dun Morogh/0, Adlin Pridedrift
		836=sA|m1426|x28.76|y66.37 -- Dun Morogh/0, Durnan Furcutter
		843=sA|m1436|x57.63|y54.05 -- Westfall/0, Gina MacGregor
		945=sA|m1426|x28.66|y67.73 -- Dun Morogh/0, Rybrad Coldbank
		954=sA|m1432|x82.65|y64.1 -- Loch Modan/0, Kat Sampson
		956=sA|m1433|x30.87|y46.43 -- Redridge Mountains/0, Dorin Songblade
		960=sA|m1431|x73.8|y45.1 -- Duskwood/0, Gunder Thornbush
		1104=sA|m1426|x28.79|y67.84 -- Dun Morogh/0, Grundel Harkin
		1214=sA|m1432|x64.82|y66.04 -- Loch Modan/0, Aldren Cordon
		1237=sA|m1426|x68.61|y54.64 -- Dun Morogh/0, Kazan Mogosh
		1238=sA|m1426|x45.18|y51.92 -- Dun Morogh/0, Gamili Frosthide
		1240=sA|m1426|x45.15|y51.75 -- Dun Morogh/0, Boran Ironclink
		1243=sA|m1426|x40.68|y65.12 -- Dun Morogh/0, Hegnar Rumbleshot
		1247=sA|m1426|x47.37|y52.52 -- Dun Morogh/0, Innkeeper Belm
		1261=sA|m1426|x63.46|y50.55 -- Dun Morogh/0, Veron Amberstill
		1263=sA|m1426|x63.11|y50.87 -- Dun Morogh/0, Yarlyn Amberstill
		1273=sA|m1426|x45.28|y52.19 -- Dun Morogh/0, Grawn Thromwyn
		1296=sA|m1428|x85.2|y68.39 -- Burning Steppes/0, Felder Stover
		1322=sA|m1443|x67.93|y8.31 -- Desolace/0, Maxton Strang
		1362=sA|m1432|x24.13|y18.2 -- Loch Modan/0, Gothor Brumn
		1441=sA|m1437|x11.52|y59.59 -- Wetlands/0, Brak Durnad
		1448=sA|m1437|x10.74|y56.75 -- Wetlands/0, Neal Allen
		1450=sA|m1437|x11.54|y59.85 -- Wetlands/0, Brahnmar
		1452=sA|m1437|x12.06|y57.98 -- Wetlands/0, Gruham Rumdnul
		1453=sA|m1437|x7.96|y56.34 -- Wetlands/0, Dewin Shimmerdawn
		1454=sA|m1437|x8.12|y55.84 -- Wetlands/0, Jennabink Powerseam
		1456=sA|m1437|x10.37|y60.61 -- Wetlands/0, Kersok Prond
		1457=sA|m1437|x10.49|y60.2 -- Wetlands/0, Samor Festivus
		1459=sA|m1437|x11.27|y58.42 -- Wetlands/0, Naela Trance
		1460=sA|m1437|x8.57|y54.34 -- Wetlands/0, Unger Statforth
		1461=sA|m1437|x11.33|y59.58 -- Wetlands/0, Murndan Derth
		1462=sA|m1437|x11.11|y58.32 -- Wetlands/0, Edwina Monzor
		1463=sA|m1437|x8.34|y56.46 -- Wetlands/0, Falkan Armonis
		1464=sA|m1437|x10.69|y60.95 -- Wetlands/0, Innkeeper Helbrek
		1465=sA|m1432|x35.56|y49.15 -- Loch Modan/0, Drac Roughcut
		1469=sA|m1432|x35.82|y43.45 -- Loch Modan/0, Vrok Blunderblast
		1471=sA|m1417|x45.98|y47.71 -- Arathi Highlands/0, Jannos Ironwill
		1474=sA|m1432|x35.94|y45.87 -- Loch Modan/0, Rann Flamespinner
		1668=sA|m1436|x57.7|y53.93 -- Westfall/0, William MacGregor
		1670=sA|m1436|x57.75|y53.71 -- Westfall/0, Mike Miller
		1671=sA|m1433|x21.07|y46.24 -- Redridge Mountains/0, Lamar Veisilli
		1672=sA|m1431|x75.71|y44.55 -- Duskwood/0, Lohgan Eva
		1673=sA|m1431|x76.28|y45.26 -- Duskwood/0, Alyssa Eva
		1678=sA|m1433|x27.49|y47.83 -- Redridge Mountains/0, Vernon Hale
		1682=sA|m1432|x34.75|y48.61 -- Loch Modan/0, Yanni Stoutheart
		1684=sA|m1432|x40.27|y39.28 -- Loch Modan/0, Khara Deepwater
		1685=sA|m1432|x82.47|y63.35 -- Loch Modan/0, Xandar Goodbeard
		1686=sA|m1432|x83.15|y63.42 -- Loch Modan/0, Irene Sureshot
		1687=sA|m1432|x83.02|y62.96 -- Loch Modan/0, Cliff Hadin
		1690=sA|m1426|x45.3|y51.53 -- Dun Morogh/0, Thrawn Boltar
		1691=sA|m1426|x47.18|y52.4 -- Dun Morogh/0, Kreg Bilmn
		1692=sA|m1426|x46.77|y53.71 -- Dun Morogh/0, Golorn Frostbeard
		1694=sA|m1426|x50.08|y49.41 -- Dun Morogh/0, Loslor Rudge
		1695=sA|m1444|x89.34|y45.86 -- Feralas/0, Rendow
		1697=sA|m1426|x30.45|y46.0 -- Dun Morogh/0, Keeg Gibn
		1698=sA|m1426|x68.86|y55.95 -- Dun Morogh/0, Frast Dokner
		2084=sA|m1452|x51.45|y30.83 -- Winterspring/0, Natheril Raincaller
		2264=sA|m1424|x36.82|y44.25 -- Hillsbrad Foothills/0, Hillsbrad Tailor
		2265=sA|m1424|x31.6|y44.48 -- Hillsbrad Foothills/0, Hillsbrad Apprentice Blacksmith
		2303=sA|m1452|x51.95|y29.28 -- Winterspring/0, Lyranne Feathersong
		2352=sA|m1424|x51.16|y58.92 -- Hillsbrad Foothills/0, Innkeeper Anderson
		2357=sA|m1424|x52.18|y55.47 -- Hillsbrad Foothills/0, Merideth Carlson
		2364=sA|m1424|x51.12|y59.24 -- Hillsbrad Foothills/0, Neema
		2365=sA|m1424|x48.74|y57.2 -- Hillsbrad Foothills/0, Bront Coldcleave
		2366=sA|m1424|x51.56|y58.56 -- Hillsbrad Foothills/0, Barkeep Kelly
		2380=sA|m1424|x50.93|y57.1 -- Hillsbrad Foothills/0, Nandar Branson
		2381=sA|m1424|x48.93|y55.02 -- Hillsbrad Foothills/0, Micha Yance
		2383=sA|m1424|x50.62|y60.94 -- Hillsbrad Foothills/0, Lindea Rabonne
		2404=sA|m1424|x32.11|y44.42 -- Hillsbrad Foothills/0, Blacksmith Verringtan
		2668=sA|m1431|x75.87|y45.55 -- Duskwood/0, Danielle Zipstitch
		2669=sA|m1431|x75.67|y45.56 -- Duskwood/0, Sheri Zipstitch
		2679=sA|m1437|x25.6|y25.8 -- Wetlands/0, Wenna Silkbeard
		2682=sA|m1437|x26.39|y25.75 -- Wetlands/0, Fradd Swiftgear
		2683=sA|m1426|x21.85|y31.85 -- ??, Namdo Bizzfizzle
		2697=sA|m1433|x89.01|y70.86 -- Redridge Mountains/0, Clyde Ranthal
		2803=sA|m1448|x62.32|y25.64 -- Felwood/0, Malygen
		2805=sA|m1417|x26.96|y58.83 -- Arathi Highlands/0, Deneb Walker
		2808=sA|m1417|x46.44|y47.6 -- Arathi Highlands/0, Vikki Lonsav
		2810=sA|m1417|x46.48|y47.41 -- Arathi Highlands/0, Hammon Karwn
		2812=sA|m1417|x46.31|y47.04 -- Arathi Highlands/0, Drovnar Strongbrew
		2814=sA|m1417|x45.54|y47.6 -- Arathi Highlands/0, Narj Deepslice
		2816=sA|m1417|x45.07|y46.82 -- Arathi Highlands/0, Androd Fadran
		2910=sA|m1418|x53.42|y43.39 -- Badlands/0, Prospector Ryedol
		3085=sA|m1433|x26.65|y43.5 -- Redridge Mountains/0, Gloria Femmel
		3086=sA|m1433|x22.84|y44.25 -- Redridge Mountains/0, Gretchen Vogel
		3088=sA|m1433|x23.83|y41.31 -- Redridge Mountains/0, Henry Chapal
		3089=sA|m1433|x26.73|y43.23 -- Redridge Mountains/0, Sherman Femmel
		3090=sA|m1433|x25.1|y41.12 -- Redridge Mountains/0, Gerald Crawley
		3091=sA|m1433|x27.17|y45.54 -- Redridge Mountains/0, Franklin Hamar
		3097=sA|m1433|x88.25|y71.02 -- Redridge Mountains/0, Bernard Brubaker
		3133=sA|m1431|x77.99|y48.32 -- Duskwood/0, Herble Baubbletump
		3135=sA|m1431|x79.47|y44.37 -- Duskwood/0, Malissa
		3138=sA|m1431|x75.82|y48.7 -- Duskwood/0, Scott Carevin
		3162=sA|m1426|x30.11|y45.27 -- Dun Morogh/0, Burdrak Harglhelm
		3177=sA|m1426|x62.9|y49.88 -- Dun Morogh/0, Turuk Amberstill
		3178=sA|m1437|x8.0|y58.32 -- Wetlands/0, Stuart Fleming
		3291=sA|m1432|x25.11|y11.8 -- Loch Modan/0, Greishan Ironstove
		3298=sA|m1428|x84.23|y67.78 -- Burning Steppes/0, Gabrielle Chase
		3528=sA|m1421|x46.39|y71.87 -- Silverpine Forest/0, Pyrewood Armorer
		3530=sA|m1421|x46.54|y72.39 -- Silverpine Forest/0, Pyrewood Tailor
		3532=sA|m1421|x43.95|y74.09 -- Silverpine Forest/0, Pyrewood Leatherworker
		3540=sA|m1424|x49.85|y62.41 -- Hillsbrad Foothills/0, Hal McAllister
		3541=sA|m1424|x49.13|y55.05 -- Hillsbrad Foothills/0, Sarah Raycroft
		3542=sA|m1424|x50.82|y59.02 -- Hillsbrad Foothills/0, Jaysin Lanyda
		3543=sA|m1424|x51.21|y56.97 -- Hillsbrad Foothills/0, Robert Aebischer
		3546=sA|m1419|x63.51|y17.01 -- Blasted Lands/0, Bernie Heisten
		3561=sA|m1457|x32.53|y19.72 -- Darnassus/0, Kyrai
		3562=sA|m1457|x34.7|y76.81 -- Darnassus/0, Alaindia
		3577=sA|m1421|x62.61|y65.05 -- Silverpine Forest/0, Dalaran Brewmaster
		3578=sA|m1421|x62.52|y62.65 -- Silverpine Forest/0, Dalaran Miner
		3587=sA|m1438|x59.52|y40.9 -- Teldrassil/0, Lyrai
		3588=sA|m1438|x58.71|y39.66 -- Teldrassil/0, Khardan Proudblade
		3589=sA|m1438|x59.3|y41.09 -- Teldrassil/0, Keina
		3590=sA|m1438|x59.45|y41.04 -- Teldrassil/0, Janna Brightmoon
		3591=sA|m1438|x58.98|y39.64 -- Teldrassil/0, Freja Nightwing
		3592=sA|m1438|x58.68|y39.83 -- Teldrassil/0, Andiss
		3608=sA|m1438|x55.5|y57.14 -- Teldrassil/0, Aldia
		3609=sA|m1438|x56.3|y59.48 -- Teldrassil/0, Shalomon
		3610=sA|m1438|x55.89|y59.2 -- Teldrassil/0, Jeena Featherbow
		3611=sA|m1438|x56.12|y60.25 -- Teldrassil/0, Brannol Eaglemoon
		3612=sA|m1438|x56.32|y59.58 -- Teldrassil/0, Sinda
		3613=sA|m1438|x56.28|y59.38 -- Teldrassil/0, Meri Ironweave
		3614=sA|m1438|x55.27|y57.15 -- Teldrassil/0, Narret Shadowgrove
		3700=sA|m1444|x30.92|y42.09 -- Feralas/0, Jadenvis Seawatcher
		3779=sA|m1452|x51.56|y29.8 -- Winterspring/0, Syurana
		3948=sA|m1432|x35.32|y49.73 -- Loch Modan/0, Honni Goldenoat
		3951=sA|m1440|x50.27|y67.27 -- Ashenvale/0, Bhaldaran Ravenshade
		3952=sA|m1440|x34.47|y49.51 -- Ashenvale/0, Aeolynn
		3953=sA|m1440|x34.54|y49.9 -- Ashenvale/0, Tandaan Lightmane
		3954=sA|m1440|x35.12|y52.11 -- Ashenvale/0, Dalria
		3955=sA|m1440|x49.48|y67.08 -- Ashenvale/0, Shandrina
		3956=sA|m1440|x50.84|y66.99 -- Ashenvale/0, Harklan Moongrove
		3958=sA|m1440|x34.79|y49.83 -- Ashenvale/0, Lardan
		3959=sA|m1440|x37.14|y49.9 -- Ashenvale/0, Nantar
		3960=sA|m1440|x50.0|y66.64 -- Ashenvale/0, Ulthaan
		3961=sA|m1440|x36.62|y49.97 -- Ashenvale/0, Maliynn
		3962=sA|m1440|x34.84|y50.86 -- Ashenvale/0, Haljan Oakheart
		3969=sA|m1440|x36.49|y49.45 -- Ashenvale/0, Fahran Silentblade
		3970=sA|m1440|x34.98|y48.46 -- Ashenvale/0, Llana
		4084=sA|m1442|x35.48|y6.16 -- Stonetalon Mountains/0, Chylina
		4164=sA|m1457|x59.24|y46.36 -- Darnassus/0, Cylania
		4167=sA|m1457|x33.62|y15.91 -- Darnassus/0, Dendrythis
		4168=sA|m1457|x64.57|y21.58 -- Darnassus/0, Elynna
		4169=sA|m1457|x64.54|y71.65 -- Darnassus/0, Jaeana
		4170=sA|m1457|x64.73|y52.96 -- Darnassus/0, Ellandrieth
		4171=sA|m1457|x65.36|y59.74 -- Darnassus/0, Merelyssa
		4172=sA|m1457|x55.67|y89.97 -- Darnassus/0, Anadyia
		4173=sA|m1457|x63.26|y66.26 -- Darnassus/0, Landria
		4175=sA|m1457|x60.66|y72.47 -- Darnassus/0, Vinasia
		4177=sA|m1457|x57.13|y76.98 -- Darnassus/0, Melea
		4180=sA|m1457|x60.6|y72.08 -- Darnassus/0, Ealyshia Dewwhisper
		4181=sA|m1457|x69.35|y45.01 -- Darnassus/0, Fyrenna
		4182=sA|m1439|x37.44|y40.49 -- Darkshore/0, Dalmond
		4183=sA|m1439|x37.57|y40.34 -- Darkshore/0, Naram Longclaw
		4185=sA|m1439|x38.2|y40.42 -- Darkshore/0, Shaldyn
		4186=sA|m1439|x36.99|y41.19 -- Darkshore/0, Mavralyn
		4187=sA|m1439|x37.04|y41.33 -- Darkshore/0, Harlon Thornguard
		4188=sA|m1442|x35.59|y7.35 -- Stonetalon Mountains/0, Illyanie
		4189=sA|m1439|x38.15|y40.6 -- Darkshore/0, Valdaron
		4190=sA|m1439|x36.9|y44.59 -- Darkshore/0, Kyndri
		4191=sA|m1439|x37.11|y43.61 -- Darkshore/0, Allyndia
		4192=sA|m1439|x36.83|y43.9 -- Darkshore/0, Taldan
		4194=sA|m1439|x43.79|y76.35 -- Darkshore/0, Ullanna
		4195=sA|m1439|x43.68|y76.63 -- Darkshore/0, Tiyani
		4200=sA|m1439|x36.76|y44.28 -- Darkshore/0, Laird
		4203=sA|m1457|x58.76|y44.49 -- Darnassus/0, Ariyell Skyshadow
		4216=sA|m1457|x48.52|y68.99 -- Darnassus/0, Chardryn
		4217=sA|m1457|x35.37|y8.4 -- Darnassus/0, Mathrengyl Bearwalker
		4220=sA|m1457|x33.84|y9.5 -- Darnassus/0, Cyroen
		4221=sA|m1457|x47.46|y57.44 -- Darnassus/0, Talaelar
		4222=sA|m1457|x46.93|y56.99 -- Darnassus/0, Voloren
		4223=sA|m1457|x48.53|y21.59 -- Darnassus/0, Fyldan
		4225=sA|m1457|x63.69|y22.27 -- Darnassus/0, Saenorion
		4226=sA|m1457|x55.84|y24.47 -- Darnassus/0, Ulthir
		4228=sA|m1457|x58.57|y14.72 -- Darnassus/0, Vaean
		4229=sA|m1457|x60.95|y17.67 -- Darnassus/0, Mythrin'dir
		4230=sA|m1457|x65.26|y53.02 -- Darnassus/0, Yldan
		4231=sA|m1457|x64.99|y60.21 -- Darnassus/0, Kieran
		4232=sA|m1457|x64.19|y59.07 -- Darnassus/0, Glorandiir
		4233=sA|m1457|x65.19|y60.72 -- Darnassus/0, Mythidan
		4234=sA|m1457|x56.13|y88.9 -- Darnassus/0, Andrus
		4235=sA|m1457|x62.67|y65.58 -- Darnassus/0, Turian
		4236=sA|m1457|x52.9|y80.49 -- Darnassus/0, Cyridan
		4240=sA|m1457|x56.92|y76.33 -- Darnassus/0, Caynrus
		4241=sA|m1457|x70.67|y45.37 -- Darnassus/0, Mydrannul
		4255=sA|m1459|x43.04|y17.63 -- ??, Brogus Thunderbrew
		4256=sA|m1455|x51.52|y26.31 -- Ironforge/0, Golnir Bouldertoe
		4257=sA|m1459|x43.41|y15.63 -- ??, Lana Thunderbrew
		4259=sA|m1455|x51.73|y42.78 -- Ironforge/0, Thurgrum Deepforge
		4265=sA|m1438|x57.18|y61.26 -- Teldrassil/0, Nyoma
		4266=sA|m1438|x55.38|y57.19 -- Teldrassil/0, Danlyia
		4305=sA|m1436|x36.22|y90.18 -- Westfall/0, Kriggon Talsone
		4307=sA|m1439|x36.97|y56.35 -- Darkshore/0, Heldan Galesong
		4730=sA|m1457|x38.27|y15.36 -- Darnassus/0, Lelanai
		4885=sA|m1445|x65.19|y51.49 -- Dustwallow Marsh/0, Gregor MacVince
		4886=sA|m1445|x64.62|y50.41 -- Dustwallow Marsh/0, Hans Weston
		4888=sA|m1445|x64.6|y50.07 -- Dustwallow Marsh/0, Marie Holdston
		4889=sA|m1445|x67.5|y47.97 -- Dustwallow Marsh/0, Torq Ironblast
		4890=sA|m1445|x67.39|y47.86 -- Dustwallow Marsh/0, Piter Verance
		4891=sA|m1445|x68.17|y47.34 -- Dustwallow Marsh/0, Dwane Wertle
		4892=sA|m1445|x67.94|y49.89 -- Dustwallow Marsh/0, Jensen Farran
		4893=sA|m1445|x66.67|y45.21 -- Dustwallow Marsh/0, Bartender Lillian
		4894=sA|m1445|x66.89|y45.25 -- Dustwallow Marsh/0, Craig Nollward
		4896=sA|m1445|x67.45|y51.71 -- Dustwallow Marsh/0, Charity Mipsy
		4897=sA|m1445|x66.43|y51.46 -- Dustwallow Marsh/0, Helenia Olden
		4899=sA|m1445|x64.07|y47.67 -- Dustwallow Marsh/0, Uma Bartulm
		4963=sA|m1437|x10.59|y60.76 -- Wetlands/0, Mikhail
		5049=sA|m1455|x36.3|y85.46 -- Ironforge/0, Lyesa Steelbrow
		5100=sA|m1455|x38.14|y73.69 -- Ironforge/0, Fillius Fizzlespinner
		5101=sA|m1455|x39.23|y74.46 -- Ironforge/0, Bryllia Ironbrand
		5102=sA|m1455|x35.75|y65.73 -- Ironforge/0, Dolman Steelfury
		5103=sA|m1455|x35.97|y65.24 -- Ironforge/0, Grenil Steelfury
		5106=sA|m1455|x31.71|y58.27 -- Ironforge/0, Bromiir Ormsen
		5107=sA|m1455|x31.95|y57.92 -- Ironforge/0, Mangorn Flinthammer
		5108=sA|m1455|x32.62|y57.38 -- Ironforge/0, Raena Flinthammer
		5109=sA|m1455|x29.6|y67.45 -- Ironforge/0, Myra Tyrngaarde
		5110=sA|m1455|x19.19|y56.1 -- Ironforge/0, Barim Jurgenstaad
		5111=sA|m1455|x18.15|y51.44 -- Ironforge/0, Innkeeper Firebrew
		5112=sA|m1455|x18.63|y51.76 -- Ironforge/0, Gwenna Firebrew
		5119=sA|m1455|x62.19|y88.16 -- Ironforge/0, Hegnar Swiftaxe
		5120=sA|m1455|x62.36|y88.68 -- Ironforge/0, Brenwyn Wintersteel
		5121=sA|m1455|x62.54|y88.7 -- Ironforge/0, Kelomir Ironhand
		5122=sA|m1455|x71.76|y66.69 -- Ironforge/0, Skolmin Goldfury
		5123=sA|m1455|x72.2|y65.23 -- Ironforge/0, Bretta Goldfury
		5124=sA|m1455|x57.65|y78.76 -- Ironforge/0, Sognar Cliffbeard
		5125=sA|m1455|x53.85|y87.89 -- Ironforge/0, Dolkin Craghelm
		5126=sA|m1455|x54.85|y87.4 -- Ironforge/0, Olthran Craghelm
		5128=sA|m1455|x39.61|y34.48 -- Ironforge/0, Bombus Finespindle
		5129=sA|m1455|x54.7|y87.97 -- Ironforge/0, Lissyphus Finespindle
		5132=sA|m1455|x38.02|y74.74 -- Ironforge/0, Pithwick
		5133=sA|m1455|x23.13|y15.93 -- Ironforge/0, Harick Boulderdrum
		5134=sA|m1459|x43.08|y17.48 -- ??, Jonivera Farmountain
		5135=sA|m1459|x42.82|y16.88 -- ??, Svalbrad Farmountain
		5138=sA|m1455|x55.07|y59.5 -- Ironforge/0, Gwina Stonebranch
		5139=sA|m1459|x42.79|y16.55 -- ??, Kurdrum Barleybeard
		5140=sA|m1455|x72.24|y75.79 -- Ironforge/0, Edris Barleybeard
		5151=sA|m1455|x31.32|y27.79 -- Ironforge/0, Ginny Longberry
		5152=sA|m1455|x22.76|y15.91 -- Ironforge/0, Bingus
		5154=sA|m1455|x42.93|y28.3 -- Ironforge/0, Poranna Snowbraid
		5155=sA|m1455|x38.25|y5.15 -- Ironforge/0, Ingrys Stonebrow
		5156=sA|m1455|x38.67|y5.99 -- Ironforge/0, Maeva Snowbraid
		5158=sA|m1455|x61.03|y43.99 -- Ironforge/0, Tilli Thistlefuzz
		5160=sA|m1455|x59.88|y37.37 -- Ironforge/0, Emrul Riknussun
		5162=sA|m1455|x48.17|y6.51 -- Ironforge/0, Tansy Puddlefizz
		5163=sA|m1455|x46.4|y26.87 -- Ironforge/0, Burbik Gearspanner
		5169=sA|m1455|x52.95|y13.71 -- Ironforge/0, Tynnus Venomsprout
		5170=sA|m1455|x44.99|y6.79 -- Ironforge/0, Hjoldir Stoneblade
		5175=sA|m1455|x67.84|y42.49 -- Ironforge/0, Gearcutter Cogspinner
		5178=sA|m1455|x66.23|y54.51 -- Ironforge/0, Soolie Berryfizz
		5191=sA|m1457|x70.4|y23.39 -- Darnassus/0, Shalumon
		5508=sA|m1419|x66.08|y17.15 -- Blasted Lands/0, Strumner Flintheel
		5569=sA|m1455|x73.77|y53.48 -- Ironforge/0, Fizzlebang Booms
		5570=sA|m1455|x72.52|y76.94 -- Ironforge/0, Bruuk Barleybeard
		5620=sA|m1433|x26.71|y43.91 -- Redridge Mountains/0, Bartender Wental
		5848=sA|m1413|x49.6|y84.31 -- The Barrens/0, Malgin Barleybrew
		6091=sA|m1438|x59.6|y40.69 -- Teldrassil/0, Dellylah
		6272=sA|m1445|x66.58|y45.22 -- Dustwallow Marsh/0, Innkeeper Janene
		6298=sA|m1439|x38.22|y41.19 -- Darkshore/0, Thelgrum Stonehammer
		6300=sA|m1439|x38.14|y41.1 -- Darkshore/0, Elisa Steelhand
		6301=sA|m1439|x38.1|y41.16 -- Darkshore/0, Gorbold Steelhand
		6328=sA|m1426|x47.28|y53.67 -- Dun Morogh/0, Dannie Fizzwizzle
		6376=sA|m1426|x28.8|y66.16 -- Dun Morogh/0, Wren Darkspring
		6382=sA|m1455|x52.69|y6.07 -- Ironforge/0, Jubahl Corpseseeker
		6576=sA|m1444|x88.95|y45.95 -- Feralas/0, Brienna Starglow
		6727=sA|m1433|x27.0|y44.82 -- Redridge Mountains/0, Innkeeper Brianna
		6731=sA|m1440|x18.22|y60.04 -- Ashenvale/0, Harlown Darkweave
		6734=sA|m1432|x35.53|y48.4 -- Loch Modan/0, Innkeeper Hearthstove
		6735=sA|m1457|x67.42|y15.64 -- Darnassus/0, Innkeeper Saelienne
		6736=sA|m1438|x55.61|y59.78 -- Teldrassil/0, Innkeeper Keldamyr
		6737=sA|m1439|x37.04|y44.12 -- Darkshore/0, Innkeeper Shaussiy
		6738=sA|m1440|x36.98|y49.21 -- Ashenvale/0, Innkeeper Kimlya
		6790=sA|m1431|x73.87|y44.4 -- Duskwood/0, Innkeeper Trelayne
		7736=sA|m1444|x30.96|y43.48 -- Feralas/0, Innkeeper Shyria
		7852=sA|m1444|x30.63|y42.7 -- Feralas/0, Pratt McGrubben
		7879=sA|m1444|x32.44|y43.78 -- Feralas/0, Quintis Jonespyre
		7941=sA|m1444|x31.04|y43.11 -- Feralas/0, Mardrack Greenwell
		7942=sA|m1444|x30.64|y43.43 -- Feralas/0, Faralorn
		7943=sA|m1444|x31.02|y46.25 -- Feralas/0, Harklane
		7945=sA|m1444|x31.08|y46.14 -- Feralas/0, Savanne
		7947=sA|m1444|x31.3|y43.45 -- Feralas/0, Vivianna
		7955=sA|m1426|x49.12|y47.95 -- Dun Morogh/0, Milli Featherwhistle
		7976=sA|m1455|x61.55|y89.43 -- Ironforge/0, Thalgus Thunderfist
		7978=sA|m1455|x26.84|y27.74 -- Ironforge/0, Bimble Longberry
		8150=sA|m1443|x66.19|y6.57 -- Desolace/0, Janet Hommers
		8157=sA|m1444|x32.67|y44.02 -- Feralas/0, Logannas
		8178=sA|m1419|x66.86|y18.23 -- Blasted Lands/0, Nina Lightbrew
		8508=sA|m1426|x31.53|y44.65 -- Dun Morogh/0, Gretta Ganter
		8665=sA|m1457|x69.63|y45.89 -- Darnassus/0, Shylenai
		8681=sA|m1455|x43.36|y29.3 -- Ironforge/0, Outfitter Eric
		8931=sA|m1436|x52.86|y53.71 -- Westfall/0, Innkeeper Heather
		8934=sA|m1436|x52.22|y52.82 -- Westfall/0, Christopher Hewen
		9099=sA|m1455|x49.31|y31.1 -- Ironforge/0, Sraaz
		10118=sA|m1438|x56.25|y92.44 -- Teldrassil/0, Nessa Shadowsong
		10216=sA|m1439|x36.09|y44.93 -- Darkshore/0, Gubber Blump
		10293=sA|m1444|x30.78|y43.14 -- Feralas/0, Dulciea Frostmoon
		10618=sA|m1452|x49.94|y9.84 -- Winterspring/0, Rivern Frostwind
		11056=sA|m1422|x42.66|y83.77 -- Western Plaguelands/0, Alchemist Arbington
		11103=sA|m1443|x66.27|y6.55 -- Desolace/0, Innkeeper Lyshaerya
		11137=sA|m1440|x35.78|y52.04 -- Ashenvale/0, Xai'ander
		11703=sA|m1427|x41.5|y74.96 -- Searing Gorge/0, Graw Cornerstone
		12096=sA|m1459|x43.12|y17.62 -- ??, Stormpike Quartermaster
		12942=sA|m1422|x43.07|y84.3 -- Western Plaguelands/0, Leonard Porter
		12960=sA|m1443|x66.61|y6.97 -- Desolace/0, Christi Galvanis
		13216=sA|m1459|x44.27|y18.24 -- ??, Gaelden Hammersmith
		13217=sA|m1416|x39.44|y81.65 -- Alterac Mountains/0, Thanthaldis Snowgleam
		14301=sA|m1447|x12.0|y78.38 -- Azshara/0, Brinna Valanaar
		14753=sA|m1440|x61.48|y83.85 -- Ashenvale/0, Illiyana Moonblaze
		15011=sA|m1426|x52.6|y36.02 -- Dun Morogh/0, Wagner Hammerstrike
		15127=sA|m1417|x45.96|y45.21 -- Arathi Highlands/0, Samuel Hawke
		15315=sA|m1448|x62.4|y25.77 -- Felwood/0, Mylini Frostmoon
		15353=sA|m1455|x34.09|y66.22 -- Ironforge/0, Katrina Shimmerstar
		16458=sA|m1442|x35.78|y5.73 -- Stonetalon Mountains/0, Innkeeper Faralia
		23510=sA|m1426|x56.50|y37.00 -- Dun Morogh/0, Thunderbrew Apprentice
		23482=sA|m1426|x56.00|y38.00 -- Dun Morogh/0, Barleybrew Apprentice
		23481=sA|m1426|x56.00|y36.40 -- Dun Morogh/0, Keiran Donoghue
		23710=sA|m1426|x46.00|y60.20 -- Dun Morogh/0, Belbi Quikswitch
		24468=sA|m1426|x45.80|y60.20 -- Dun Morogh/0, Pol Amberstill
		23521=sA|m1426|x46.00|y60.20 -- Dun Morogh/0, Anne Summers
		23522=sA|m1426|x55.50|y38.00 -- Dun Morogh/0, Arlen Lochlan
		23525=sA|m1426|x55.20|y37.50 -- Dun Morogh/0, Brother Cartwright
		24834=sA|m1437|x1.60|y59.00 -- ??, Galley Chief Grace
		17412=sA|m1440|x86.60|y44.20 -- Ashenvale/0, Phaedra
		23896=sA|m1445|x69.20|y51.80 -- Dustwallow Marsh/0, "Dirty" Michael Crowe
		14522=sA|m1448|x36.10|y44.50 -- Felwood/0, Ur'dan
		27478=sA|m1455|x19.55|y52.89 -- Ironforge/0, Larkin Thunderbrew
		26123=sA|m1455|x64.55|y26.47 -- Teldrassil/0, Midsummer Supplier
		16920=sA|m1943|x79.20|y51.00 -- Azuremyst Isle/0, Ryosh
		16918=sA|m1943|x80.40|y47.40 -- Azuremyst Isle/0, Jel
		16919=sA|m1943|x79.20|y50.80 -- Azuremyst Isle/0, Mura
		16917=sA|m1943|x80.00|y47.00 -- Azuremyst Isle/0, Aurok
		17222=sA|m1943|x48.50|y50.40 -- Azuremyst Isle/0, Artificer Daelo
		17930=sA|m1943|x49.60|y53.00 -- Azuremyst Isle/0, Nabek
		16553=sA|m1943|x48.40|y49.20 -- Azuremyst Isle/0, Caregiver Chellan
		17446=sA|m1943|x46.80|y22.00 -- Azuremyst Isle/0, Parkat Steelfur
		17929=sA|m1943|x49.60|y52.80 -- Azuremyst Isle/0, Kioni
		17101=sA|m1943|x61.00|y54.20 -- Azuremyst Isle/0, Diktynna
		18810=sA|m1943|x48.00|y52.00 -- Azuremyst Isle/0, Otonambusi
		17486=sA|m1943|x48.60|y52.20 -- Azuremyst Isle/0, Ziz
		17489=sA|m1943|x46.20|y71.00 -- Azuremyst Isle/0, Logan Daniel
		17490=sA|m1943|x44.00|y21.20 -- Azuremyst Isle/0, Ergh of the Stillpine
		17246=sA|m1943|x46.80|y70.40 -- Azuremyst Isle/0, "Cookie" McWeaksauce
		17245=sA|m1943|x46.40|y71.00 -- Azuremyst Isle/0, Blacksmith Calypso
		17657=sA|m1944|x56.70|y62.64 -- Hellfire Peninsula/0, Logistics Officer Ulrike
		16823=sA|m1944|x56.77|y63.84 -- Hellfire Peninsula/0, Humphry
		16826=sA|m1944|x54.22|y63.60 -- Hellfire Peninsula/0, Sid Limbardi
		16829=sA|m1944|x53.86|y65.74 -- Hellfire Peninsula/0, Magus Zabraxis
		18772=sA|m1944|x54.63|y63.71 -- Hellfire Peninsula/0, Hama
		18773=sA|m1944|x53.63|y66.14 -- Hellfire Peninsula/0, Johan Barnes
		18771=sA|m1944|x54.11|y63.97 -- Hellfire Peninsula/0, Brumman
		18774=sA|m1944|x54.63|y63.68 -- Hellfire Peninsula/0, Tatiana
		18775=sA|m1944|x55.72|y65.59 -- Hellfire Peninsula/0, Lebowski
		18987=sA|m1944|x54.03|y63.56 -- Hellfire Peninsula/0, Gaston
		18990=sA|m1944|x22.33|y39.42 -- Hellfire Peninsula/0, Burko
		19001=sA|m1944|x23.27|y39.95 -- Hellfire Peninsula/0, Talaara
		19004=sA|m1944|x24.40|y38.77 -- Hellfire Peninsula/0, Vodesiin
		19314=sA|m1944|x70.95|y63.25 -- Hellfire Peninsula/0, Supply Officer Shandria
		20231=sA|m1944|x78.52|y34.00 -- Hellfire Peninsula/0, Supply Officer Pestle
		16798=sA|m1944|x24.15|y40.25 -- Hellfire Peninsula/0, Provisioner Anir
		22227=sA|m1944|x54.67|y63.57 -- Hellfire Peninsula/0, Markus Scylan
		19451=sA|m1944|x87.62|y53.55 -- Hellfire Peninsula/0, Quartermaster Gorman
		19452=sA|m1944|x88.39|y52.32 -- Hellfire Peninsula/0, Quartermaster Drake
		18802=sA|m1944|x53.80|y65.82 -- Hellfire Peninsula/0, Alchemist Gribble
		18906=sA|m1944|x23.35|y36.36 -- Hellfire Peninsula/0, Caregiver Ophera Windfury
		18266=sA|m1944|x56.33|y62.85 -- Hellfire Peninsula/0, Warrant Officer Tracy Proudwell
		20028=sA|m1946|x42.33|y27.91 -- Zangarmarsh/0, Doba
		18010=sA|m1946|x41.61|y27.29 -- Zangarmarsh/0, Maktu
		18019=sA|m1946|x41.22|y28.67 -- Zangarmarsh/0, Timothy Daniels
		19694=sA|m1946|x68.51|y50.21 -- Zangarmarsh/0, Loolruna
		18009=sA|m1946|x40.85|y28.65 -- Zangarmarsh/0, Puluu
		18005=sA|m1946|x67.81|y47.91 -- Zangarmarsh/0, Haalrun
		18006=sA|m1946|x67.64|y47.87 -- Zangarmarsh/0, Noraani
		18251=sA|m1946|x67.14|y49.03 -- Zangarmarsh/0, Caregiver Abidaar
		18581=sA|m1946|x64.55|y46.57 -- Zangarmarsh/0, Alliance Field Scout
		18908=sA|m1946|x41.85|y26.22 -- Zangarmarsh/0, Innkeeper Kerp
		19722=sA|m1946|x40.52|y28.26 -- Zangarmarsh/0, Muheru the Weaver
		16705=sA|m1947|x27.60|y63.00 -- The Exodar/0, Altaa
		16706=sA|m1947|x44.20|y61.70 -- The Exodar/0, Musal
		16718=sA|m1947|x54.55|y26.52 -- The Exodar/0, Phea
		16716=sA|m1947|x71.00|y91.40 -- The Exodar/0, Gornii
		16714=sA|m1947|x69.59|y89.60 -- The Exodar/0, Ven
		16713=sA|m1947|x61.00|y88.40 -- The Exodar/0, Arras
		16708=sA|m1947|x28.80|y21.00 -- The Exodar/0, Dekin
		16729=sA|m1947|x30.60|y47.80 -- The Exodar/0, Refik
		16722=sA|m1947|x39.99|y39.42 -- The Exodar/0, Egomis
		16735=sA|m1947|x45.20|y87.40 -- The Exodar/0, Muhaa
		16732=sA|m1947|x52.80|y46.00 -- The Exodar/0, Onnis
		16739=sA|m1947|x59.55|y19.69 -- The Exodar/0, Caregiver Breel
		16753=sA|m1947|x67.14|y95.80 -- The Exodar/0, Gotaan
		16751=sA|m1947|x60.43|y88.64 -- The Exodar/0, Merran
		17512=sA|m1947|x45.60|y25.00 -- The Exodar/0, Arred
		16768=sA|m1947|x56.60|y50.00 -- The Exodar/0, Nurguni
		16767=sA|m1947|x64.55|y68.52 -- The Exodar/0, Neii
		16765=sA|m1947|x73.30|y84.50 -- The Exodar/0, Ellomin
		16762=sA|m1947|x68.09|y96.40 -- The Exodar/0, Treall
		16709=sA|m1947|x53.40|y46.80 -- The Exodar/0, Cuzi
		20121=sA|m1947|x52.47|y84.19 -- The Exodar/0, Fingin
		17584=sA|m1947|x81.40|y51.59 -- The Exodar/0, Torallius the Pack Handler
		21019=sA|m1947|x30.63|y34.44 -- The Exodar/0, Sixx
		19374=sA|m1948|x36.18|y55.47 -- Shadowmoon Valley/0, Salle Sunforge
		19371=sA|m1948|x37.03|y58.50 -- Shadowmoon Valley/0, Dalin Stouthammer
		19370=sA|m1948|x36.82|y54.89 -- Shadowmoon Valley/0, Ordinn Thunderfist
		19372=sA|m1948|x36.81|y56.18 -- Shadowmoon Valley/0, Oran Blusterbrew
		19373=sA|m1948|x36.79|y55.05 -- Shadowmoon Valley/0, Mari Stonehand
		19352=sA|m1948|x37.06|y58.26 -- Shadowmoon Valley/0, Dreg Cloudsweeper
		19351=sA|m1948|x36.80|y54.31 -- Shadowmoon Valley/0, Daggle Ironshaper
		20510=sA|m1948|x37.61|y56.06 -- Shadowmoon Valley/0, Brunn Flamebeard
		21112=sA|m1949|x60.78|y69.06 -- Blade's Edge Mountains/0, Bossi Pentapiston
		21113=sA|m1949|x61.26|y68.89 -- Blade's Edge Mountains/0, Sassa Weldwell
		21110=sA|m1949|x60.98|y68.11 -- Blade's Edge Mountains/0, Fizit "Doc" Clocktock
		21111=sA|m1949|x61.25|y68.99 -- Blade's Edge Mountains/0, Bembil Knockhammer
		19495=sA|m1949|x35.80|y63.88 -- Blade's Edge Mountains/0, Innkeeper Shaunessy
		19497=sA|m1949|x38.23|y64.80 -- Blade's Edge Mountains/0, Caoileann
		19498=sA|m1949|x37.76|y66.02 -- Blade's Edge Mountains/0, Tanaide
		19499=sA|m1949|x37.75|y63.80 -- Blade's Edge Mountains/0, Cahill
		18427=sA|m1950|x53.40|y56.40 -- Bloodmyst Isle/0, Fazu
		17553=sA|m1950|x55.80|y59.60 -- Bloodmyst Isle/0, Caregiver Topher Loaal
		17421=sA|m1950|x42.00|y21.20 -- Bloodmyst Isle/0, Clopper Wizbang
		21145=sA|m1950|x63.20|y87.20 -- Bloodmyst Isle/0, Little Azimi
		18811=sA|m1950|x55.20|y58.20 -- Bloodmyst Isle/0, Meriaad
		17667=sA|m1950|x53.40|y56.80 -- Bloodmyst Isle/0, Beega
		20096=sA|m1951|x56.21|y73.33 -- Nagrand/0, Uriku
		19014=sA|m1951|x55.27|y69.48 -- Nagrand/0, Ogir
		19017=sA|m1951|x53.26|y71.88 -- Nagrand/0, Borto
		19012=sA|m1951|x53.24|y69.84 -- Nagrand/0, Sparik
		18822=sA|m1951|x41.20|y44.20 -- Nagrand/0, Quartermaster Davian Vaclav
		19021=sA|m1951|x55.28|y70.52 -- Nagrand/0, Nancila
		21485=sA|m1951|x43.00|y42.60 -- Nagrand/0, Aldraan
		21488=sA|m1951|x41.60|y43.60 -- Nagrand/0, Banro
		21487=sA|m1951|x42.00|y43.00 -- Nagrand/0, Cendrii
		18914=sA|m1951|x54.22|y76.10 -- Nagrand/0, Caregiver Isel
		20240=sA|m1951|x54.54|y75.15 -- Nagrand/0, Trader Narasu
		19773=sA|m1952|x56.02|y53.63 -- Terokkar Forest/0, Spirit Sage Zran
		19296=sA|m1952|x56.70|y53.27 -- Terokkar Forest/0, Innkeeper Biribi
		19038=sA|m1952|x55.73|y53.04 -- Terokkar Forest/0, Supply Officer Mills
		19042=sA|m1952|x57.74|y53.37 -- Terokkar Forest/0, Leeli Longhaggle
		19053=sA|m1952|x57.75|y53.48 -- Terokkar Forest/0, Fabian Lanzonelli
		19056=sA|m1952|x56.49|y54.97 -- Terokkar Forest/0, Cecil Meyers
		21655=sA|m1955|x62.35|y68.65 -- Shattrath City/0, Nakodu
		--9676=sA|m9006|x64.40|y68.20
		--35338=sA|m89|x61.65|y48.35 -- Darnassus/0,Bountiful Barrel
		--34681=sA|m89|x61.67|y48.84 -- Darnassus/0,Ikaneba Summerset
		30731=sA|m89|x58.8|y14.4 -- Darnassus/0, Illianna Moonscribe		
				
		30255=sA|m127|x74.60|y79.00 -- ??, Aniduria
		30241=sA|m127|x74.59|y79.50 -- Crystalsong Forest/0, Lanudal Silverhart
		30244=sA|m127|x75.00|y78.80 -- ??, Miura Brightweaver
		30257=sA|m127|x74.30|y79.50 -- ??, Scout Yribria
		31579=sA|m125|x37.54|y54.75 -- Dalaran, Arcanist Adurin
		33964=sA|m125|x38.50|y53.90 -- ??, Arcanist Firael
		35494=sA|m125|x37.69|y54.65 -- ??, Arcanist Miluria
		37942=sA|m125|x38.61|y53.60 -- ??, Arcanist Uovril
		32426=sA|m125|x37.40|y75.40 -- Dalaran, Coira Longrifle
		31032=sA|m125|x40.85|y65.34 -- Dalaran, Derek Odds
		28682=sA|m125|x42.00|y64.50 -- Dalaran, Inzi Charmlight
		32413=sA|m125|x44.50|y61.90 -- Dalaran, Isirami Fairwind
		32424=sA|m125|x38.40|y75.60 -- Dalaran, Laire Brewgold
		32416=sA|m125|x42.71|y64.44 -- Dalaran, Stefen Cotter
		31580=sA|m125|x37.00|y55.00 -- Dalaran, Arcanist Ivrenne
		
		35101=sA|m100|x54.2|y62.6 -- Hellfire Peninsula/0, Grunda Bronzewing
		30734=sA|m100|x54|y65.4 -- Hellfire Peninsula/0, Jezebel Bican		
		--35337=sA|m37|x34.00|y51.50 -- Elwynn Forest/0/0,Bountiful Barrel
		--34682=sA|m37|x34.00|y51.50 -- Elwynn Forest/0/0,Wilmina Holbeck
		30733=sA|m87|x60.2|y44.2 -- Ironforge/0, Thargen Heavyquill
		27812=sA|m87|x19|y52.8 -- Ironforge/0, Brew Vendor
		27819=sA|m87|x18.89|y52.2 -- Ironforge/0, Brew Vendor
		--27814=sA|m87|x19.00|y51.80 -- Ironforge/0,Brew Vendor
		27820=sA|m87|x18.7|y52.5 -- Ironforge/0, Brew Vendor
		--27813=sA|m87|x18.70|y51.50 -- Ironforge/0,Brew Vendor
		27806=sA|m87|x18.8|y51.8 -- Ironforge/0, Brew Vendor
		--27815=sA|m87|x18.80|y51.80 -- Ironforge/0,Brew Vendor
		--37674=sA|m87|x33.00|y65.00 -- Ironforge/0,Lovely Merchant
		15898=sA|m87|x29.55|y14.52 -- Ironforge/0, Lunar Festival Vendor
		--34783=sA|m103|x75.00|y57.40 -- The Exodar/0,Ranisa Whitebough
		--30732=sA|m103|x39.69|y39.29 -- The Exodar/0,Sessoh
		
		--35340=sA|m27|x59.80|y34.20 -- Dun Morogh/0/0,Bountiful Barrel
		--34645=sA|m27|x59.80|y34.20 -- Dun Morogh/0/0,Elizabeth Barker Winslow
		--32836=sA|m27|x54.00|y50.80 -- Dun Morogh/0/0,Noblegarden Vendor
		32294=sA|m123|x51.60|y17.50 -- ??, Knight Dameron
		39172=sA|m123|x51.60|y17.50 -- ??, Marshal Magruder
		30489=sA|m123|x48.80|y17.50 -- ??, Morgan Day
		31051=sA|m123|x48.50|y21.00 -- ??, Sorceress Kaylana

		-- HORDE --
		980=sH|m1435|x45.08|y50.43 -- Swamp of Sorrows/0, Grimnal
		981=sH|m1435|x45.66|y50.92 -- Swamp of Sorrows/0, Hartash
		982=sH|m1435|x46.52|y54.28 -- Swamp of Sorrows/0, Thultash
		983=sH|m1435|x45.77|y52.82 -- Swamp of Sorrows/0, Thultazor
		984=sH|m1435|x45.06|y51.4 -- Swamp of Sorrows/0, Thralosh
		989=sH|m1435|x44.77|y56.63 -- Swamp of Sorrows/0, Banalash
		1146=sH|m1434|x32.36|y27.94 -- Stranglethorn Vale/0, Vharr
		1147=sH|m1434|x31.61|y29.18 -- Stranglethorn Vale/0, Hragran
		1148=sH|m1434|x32.7|y29.23 -- Stranglethorn Vale/0, Nerrist
		1149=sH|m1434|x31.55|y27.95 -- Stranglethorn Vale/0, Uthok
		1381=sH|m1434|x32.57|y27.94 -- Stranglethorn Vale/0, Krakk
		1407=sH|m1418|x2.9|y47.24 -- Badlands/0, Sranda
		2113=sH|m1420|x32.4|y65.66 -- Tirisfal Glades/0, Archibald Kava
		2115=sH|m1420|x32.28|y65.44 -- Tirisfal Glades/0, Joshua Kien
		2116=sH|m1420|x32.37|y66.22 -- Tirisfal Glades/0, Blacksmith Rand
		2117=sH|m1420|x32.4|y66.43 -- Tirisfal Glades/0, Harold Raims
		2118=sH|m1420|x61.02|y52.37 -- Tirisfal Glades/0, Abigail Shiel
		2134=sH|m1420|x61.16|y52.6 -- Tirisfal Glades/0, Mrs. Winters
		2135=sH|m1420|x60.21|y53.1 -- Tirisfal Glades/0, Abe Winters
		2136=sH|m1420|x60.13|y53.39 -- Tirisfal Glades/0, Oliver Dwor
		2137=sH|m1420|x60.3|y52.81 -- Tirisfal Glades/0, Eliza Callen
		2140=sH|m1421|x43.97|y39.89 -- Silverpine Forest/0, Edwin Harly
		2225=sH|m1459|x50.07|y82.14 -- ??, Zora Guthrek
		2388=sH|m1424|x62.77|y19.02 -- Hillsbrad Foothills/0, Innkeeper Shay
		2393=sH|m1424|x62.29|y19.04 -- Hillsbrad Foothills/0, Christoph Jeffcoat
		2394=sH|m1424|x61.9|y20.98 -- Hillsbrad Foothills/0, Mallen Swain
		2397=sH|m1424|x63.08|y19.4 -- Hillsbrad Foothills/0, Derak Nightfall
		2401=sH|m1424|x62.55|y19.91 -- Hillsbrad Foothills/0, Kayren Soothallow
		2698=sH|m1424|x92.01|y38.22 -- Hillsbrad Foothills/0, George Candarte
		2806=sH|m1448|x34.75|y53.22 -- Felwood/0, Bale
		2819=sH|m1417|x74.85|y34.57 -- Arathi Highlands/0, Tunkk
		2820=sH|m1417|x74.11|y32.37 -- Arathi Highlands/0, Graud
		2821=sH|m1417|x74.08|y32.73 -- Arathi Highlands/0, Keena
		2908=sH|m1418|x3.12|y45.93 -- Badlands/0, Grawl
		2997=sH|m1456|x41.41|y62.36 -- Thunder Bluff/0, Jyn Stonehoof
		2999=sH|m1456|x39.81|y55.64 -- Thunder Bluff/0, Taur Stonehoof
		3002=sH|m1456|x34.34|y56.55 -- Thunder Bluff/0, Kurm Stonehoof
		3003=sH|m1456|x41.43|y53.19 -- Thunder Bluff/0, Fyr Mistrunner
		3005=sH|m1456|x43.8|y45.11 -- Thunder Bluff/0, Mahu
		3010=sH|m1456|x47.41|y33.74 -- Thunder Bluff/0, Mani Winterhoof
		3012=sH|m1456|x44.98|y38.75 -- Thunder Bluff/0, Nata Dawnstrider
		3014=sH|m1456|x49.56|y39.57 -- Thunder Bluff/0, Nida Winterhoof
		3015=sH|m1456|x46.99|y45.7 -- Thunder Bluff/0, Kuna Thunderhorn
		3016=sH|m1456|x49.05|y34.23 -- Thunder Bluff/0, Tand
		3017=sH|m1456|x47.33|y42.49 -- Thunder Bluff/0, Nan Mistrunner
		3018=sH|m1456|x55.54|y57.07 -- Thunder Bluff/0, Hogor Thunderhoof
		3019=sH|m1456|x54.07|y57.23 -- Thunder Bluff/0, Delgo Ragetotem
		3020=sH|m1456|x53.19|y58.29 -- Thunder Bluff/0, Etu Ragetotem
		3021=sH|m1456|x52.98|y56.63 -- Thunder Bluff/0, Kard Ragetotem
		3022=sH|m1456|x49.62|y48.71 -- Thunder Bluff/0, Sunn Ragetotem
		3023=sH|m1456|x51.59|y55.02 -- Thunder Bluff/0, Sura Wildmane
		3025=sH|m1456|x52.3|y47.78 -- Thunder Bluff/0, Kaga Mistrunner
		3027=sH|m1456|x50.98|y52.45 -- Thunder Bluff/0, Naal Mistrunner
		3029=sH|m1456|x55.78|y47.02 -- Thunder Bluff/0, Sewa Mistrunner
		3044=sH|m1456|x25.31|y15.26 -- Thunder Bluff/0, Miles Welsh
		3072=sH|m1412|x45.29|y76.51 -- Mulgore/0, Kawnie Softbreeze
		3073=sH|m1412|x44.06|y77.47 -- Mulgore/0, Marjak Keenblade
		3074=sH|m1412|x44.13|y77.25 -- Mulgore/0, Varia Hardhide
		3075=sH|m1412|x44.2|y77.5 -- Mulgore/0, Bronk Steelrage
		3076=sH|m1412|x45.86|y57.66 -- Mulgore/0, Moorat Longstride
		3077=sH|m1412|x45.65|y58.6 -- Mulgore/0, Mahnott Roughwound
		3078=sH|m1412|x45.49|y58.47 -- Mulgore/0, Kennah Hawkseye
		3079=sH|m1412|x45.81|y58.69 -- Mulgore/0, Varg Windwhisper
		3080=sH|m1412|x45.9|y58.73 -- Mulgore/0, Harant Ironbrace
		3081=sH|m1412|x46.17|y58.18 -- Mulgore/0, Wunna Darkmane
		3092=sH|m1456|x43.44|y44.33 -- Thunder Bluff/0, Tagain
		3093=sH|m1456|x42.65|y43.51 -- Thunder Bluff/0, Grod
		3095=sH|m1456|x42.75|y44.79 -- Thunder Bluff/0, Fela
		3158=sH|m1411|x42.58|y67.34 -- Durotar/0, Duokna
		3159=sH|m1411|x40.46|y68.0 -- Durotar/0, Kzan Thornslash
		3160=sH|m1411|x40.6|y67.8 -- Durotar/0, Huklah
		3161=sH|m1411|x40.47|y67.82 -- Durotar/0, Rarc
		3163=sH|m1411|x52.01|y40.45 -- Durotar/0, Uhgar
		3164=sH|m1411|x54.39|y42.17 -- Durotar/0, Jark
		3165=sH|m1411|x52.98|y41.02 -- Durotar/0, Ghrawt
		3166=sH|m1411|x53.11|y40.86 -- Durotar/0, Cutac
		3167=sH|m1411|x51.9|y41.14 -- Durotar/0, Wuark
		3168=sH|m1411|x52.97|y41.97 -- Durotar/0, Flakk
		3186=sH|m1411|x56.29|y73.4 -- Durotar/0, K'waii
		3187=sH|m1411|x56.4|y73.78 -- Durotar/0, Tai'tasi
		3312=sH|m1454|x44.67|y70.01 -- Orgrimmar/0, Olvia
		3313=sH|m1454|x48.12|y80.53 -- Orgrimmar/0, Trak'gen
		3314=sH|m1454|x47.55|y68.38 -- Orgrimmar/0, Urtharo
		3315=sH|m1454|x62.8|y50.43 -- Orgrimmar/0, Tor'phan
		3316=sH|m1454|x62.87|y44.69 -- Orgrimmar/0, Handor
		3317=sH|m1454|x56.51|y73.77 -- Orgrimmar/0, Ollanus
		3319=sH|m1454|x55.97|y72.73 -- Orgrimmar/0, Sana
		3321=sH|m1454|x56.24|y73.21 -- Orgrimmar/0, Morgum
		3322=sH|m1454|x52.14|y62.13 -- Orgrimmar/0, Kaja
		3323=sH|m1454|x45.44|y56.54 -- Orgrimmar/0, Horthus
		3329=sH|m1454|x48.96|y54.21 -- Orgrimmar/0, Kor'jus
		3330=sH|m1454|x44.34|y48.1 -- Orgrimmar/0, Muragus
		3331=sH|m1454|x45.65|y55.96 -- Orgrimmar/0, Kareth
		3333=sH|m1454|x69.99|y29.76 -- Orgrimmar/0, Shankys
		3334=sH|m1454|x42.08|y49.47 -- Orgrimmar/0, Rekkul
		3335=sH|m1454|x45.99|y45.68 -- Orgrimmar/0, Hagrus
		3342=sH|m1454|x37.41|y52.32 -- Orgrimmar/0, Shan'ti
		3343=sH|m1459|x49.67|y82.45 -- ??, Grelkor
		3346=sH|m1454|x53.87|y38.01 -- Orgrimmar/0, Kithas
		3348=sH|m1454|x56.05|y34.11 -- Orgrimmar/0, Kor'geld
		3349=sH|m1454|x29.73|y74.17 -- Orgrimmar/0, Ukra'nor
		3350=sH|m1454|x46.06|y40.86 -- Orgrimmar/0, Asoran
		3351=sH|m1454|x45.73|y40.94 -- Orgrimmar/0, Magenius
		3356=sH|m1454|x82.59|y23.95 -- Orgrimmar/0, Sumi
		3358=sH|m1454|x73.31|y26.59 -- Orgrimmar/0, Gorina
		3359=sH|m1454|x73.25|y42.25 -- Orgrimmar/0, Kiro
		3360=sH|m1454|x81.47|y18.73 -- Orgrimmar/0, Koru
		3361=sH|m1454|x81.58|y18.86 -- Orgrimmar/0, Shoma
		3362=sH|m1454|x69.38|y12.24 -- Orgrimmar/0, Ogunaro Wolfrunner
		3364=sH|m1454|x63.08|y51.44 -- Orgrimmar/0, Borya
		3366=sH|m1454|x63.04|y45.52 -- Orgrimmar/0, Tamar
		3367=sH|m1454|x60.59|y48.92 -- Orgrimmar/0, Felika
		3368=sH|m1454|x57.2|y53.32 -- Orgrimmar/0, Borstan
		3369=sH|m1454|x58.81|y52.73 -- Orgrimmar/0, Gotri
		3400=sH|m1454|x57.56|y52.89 -- Orgrimmar/0, Xen'to
		3405=sH|m1454|x54.97|y39.44 -- Orgrimmar/0, Zeal'aya
		3409=sH|m1454|x81.15|y18.67 -- Orgrimmar/0, Zendo'jian
		3410=sH|m1454|x78.08|y38.45 -- Orgrimmar/0, Jin'sora
		3411=sH|m1442|x73.58|y95.35 -- Stonetalon Mountains/0, Denni'ka
		3413=sH|m1454|x75.49|y25.36 -- Orgrimmar/0, Sovik
		3477=sH|m1413|x51.12|y28.95 -- The Barrens/0, Hraq
		3479=sH|m1413|x51.23|y29.15 -- The Barrens/0, Nargal Deatheye
		3480=sH|m1413|x52.37|y30.54 -- The Barrens/0, Moorane Hearthgrain
		3481=sH|m1413|x51.66|y29.94 -- The Barrens/0, Barg
		3482=sH|m1413|x51.68|y30.03 -- The Barrens/0, Tari'qa
		3483=sH|m1413|x51.21|y29.04 -- The Barrens/0, Jahan Hawkwing
		3485=sH|m1413|x52.24|y31.69 -- The Barrens/0, Wrahk
		3486=sH|m1413|x52.25|y31.85 -- The Barrens/0, Halija Whitestrider
		3487=sH|m1413|x52.26|y32.02 -- The Barrens/0, Kalyimah Stormcloud
		3488=sH|m1413|x51.11|y29.06 -- The Barrens/0, Uthrok
		3489=sH|m1413|x52.62|y29.84 -- The Barrens/0, Zargh
		3490=sH|m1413|x51.39|y30.2 -- The Barrens/0, Hula'mahi
		3500=sH|m1444|x74.63|y44.91 -- Feralas/0, Tarhus
		3522=sH|m1420|x52.59|y55.77 -- Tirisfal Glades/0, Constance Brisboise
		3539=sH|m1424|x60.43|y26.18 -- Hillsbrad Foothills/0, Ott
		3544=sH|m1424|x61.48|y20.07 -- Hillsbrad Foothills/0, Jason Lemieux
		3547=sH|m1420|x59.52|y51.62 -- Tirisfal Glades/0, Hamlin Atkins
		3548=sH|m1420|x61.76|y50.02 -- Tirisfal Glades/0, Selina Weston
		3550=sH|m1420|x65.85|y59.63 -- Tirisfal Glades/0, Martine Tramblay
		3551=sH|m1421|x42.9|y41.8 -- Silverpine Forest/0, Patrice Dwyer
		3552=sH|m1421|x44.6|y39.11 -- Silverpine Forest/0, Alexandre Lefevre
		3553=sH|m1421|x43.32|y41.34 -- Silverpine Forest/0, Sebastian Meloche
		3554=sH|m1421|x44.79|y39.24 -- Silverpine Forest/0, Andrea Boynton
		3556=sH|m1421|x43.22|y40.66 -- Silverpine Forest/0, Andrew Hilbert
		3621=sH|m1447|x21.81|y52.1 -- Azshara/0, Kurll
		3625=sH|m1459|x49.87|y82.14 -- ??, Rarck
		3682=sH|m1413|x43.79|y12.21 -- The Barrens/0, Vrang Wildgore
		3685=sH|m1412|x47.49|y58.59 -- Mulgore/0, Harb Clawhoof
		3689=sH|m1441|x21.06|y31.86 -- Thousand Needles/0, Laer Stepperunner
		3705=sH|m1413|x44.74|y59.42 -- The Barrens/0, Gahroot
		3708=sH|m1428|x65.7|y23.91 -- Burning Steppes/0, Gruna
		3881=sH|m1411|x51.12|y42.62 -- Durotar/0, Grimtak
		3882=sH|m1411|x42.64|y67.19 -- Durotar/0, Zlagk
		3883=sH|m1412|x44.64|y77.89 -- Mulgore/0, Moodan Sungrain
		3884=sH|m1412|x47.63|y61.49 -- Mulgore/0, Jhawna Oatwind
		3933=sH|m1411|x55.62|y73.61 -- Durotar/0, Hai'zan
		3934=sH|m1413|x51.98|y29.89 -- The Barrens/0, Innkeeper Boorand Plainswind
		4043=sH|m1454|x82.29|y18.86 -- Orgrimmar/0, Galthuk
		4082=sH|m1442|x45.87|y58.66 -- Stonetalon Mountains/0, Grawnal
		4083=sH|m1442|x47.61|y61.59 -- Stonetalon Mountains/0, Jeeda
		4553=sH|m1458|x62.3|y43.09 -- Undercity/0, Ronald Burch
		4554=sH|m1458|x63.52|y39.94 -- Undercity/0, Tawny Grisette
		4555=sH|m1458|x69.16|y48.92 -- Undercity/0, Eleanor Rusk
		4556=sH|m1458|x61.49|y41.78 -- Undercity/0, Gordon Wendham
		4557=sH|m1458|x61.14|y40.88 -- Undercity/0, Louis Warren
		4558=sH|m1458|x63.82|y37.97 -- Undercity/0, Lauren Newcomb
		4559=sH|m1458|x62.61|y39.7 -- Undercity/0, Timothy Weldon
		4560=sH|m1458|x62.33|y38.67 -- Undercity/0, Walter Ellingson
		4561=sH|m1458|x64.04|y37.37 -- Undercity/0, Daniel Bartlett
		4562=sH|m1458|x69.69|y39.05 -- Undercity/0, Thomas Mordan
		4569=sH|m1458|x77.07|y49.39 -- Undercity/0, Charles Seaton
		4570=sH|m1458|x69.45|y27.43 -- Undercity/0, Sydney Upton
		4571=sH|m1458|x76.62|y29.3 -- Undercity/0, Morley Bates
		4574=sH|m1458|x81.03|y30.75 -- Undercity/0, Lizbeth Cromwell
		4575=sH|m1458|x82.77|y15.83 -- Undercity/0, Hannah Akeley
		4577=sH|m1458|x70.58|y30.14 -- Undercity/0, Millie Gregorian
		4580=sH|m1458|x71.18|y29.58 -- Undercity/0, Lucille Castleton
		4581=sH|m1458|x77.41|y39.26 -- Undercity/0, Salazar Bloch
		4585=sH|m1458|x75.2|y51.17 -- Undercity/0, Ezekiel Graves
		4587=sH|m1458|x75.48|y74.34 -- Undercity/0, Elizabeth Van Talen
		4589=sH|m1458|x70.06|y58.44 -- Undercity/0, Joseph Moore
		4590=sH|m1458|x69.24|y61.21 -- Undercity/0, Jonathan Chambers
		4592=sH|m1458|x77.48|y49.62 -- Undercity/0, Nathaniel Steenwick
		4597=sH|m1458|x61.4|y30.08 -- Undercity/0, Samuel Van Brunt
		4599=sH|m1458|x56.71|y36.93 -- Undercity/0, Sarah Killian
		4600=sH|m1458|x58.66|y33.06 -- Undercity/0, Geoffrey Hartwell
		4601=sH|m1458|x58.99|y32.58 -- Undercity/0, Francis Eliot
		4602=sH|m1458|x58.81|y32.82 -- Undercity/0, Benijah Fenner
		4603=sH|m1458|x62.71|y26.76 -- Undercity/0, Nicholas Atwood
		4604=sH|m1458|x54.7|y38.75 -- Undercity/0, Abigail Sawyer
		4610=sH|m1458|x51.71|y74.66 -- Undercity/0, Algernon
		4615=sH|m1458|x54.72|y48.92 -- Undercity/0, Katrina Alliestar
		4617=sH|m1458|x62.38|y60.98 -- Undercity/0, Thaddeus Webb
		4731=sH|m1420|x59.86|y52.68 -- Tirisfal Glades/0, Zachariah Post
		4775=sH|m1458|x64.12|y50.56 -- Undercity/0, Felicia Doan
		4875=sH|m1441|x45.43|y51.16 -- Thousand Needles/0, Turhaw
		4876=sH|m1441|x45.91|y51.47 -- Thousand Needles/0, Jawn Highmesa
		4877=sH|m1441|x46.2|y51.5 -- Thousand Needles/0, Jandia
		4878=sH|m1441|x45.14|y50.78 -- Thousand Needles/0, Montarr
		4879=sH|m1445|x36.7|y30.97 -- Dustwallow Marsh/0, Ogg'marr
		4883=sH|m1445|x36.39|y30.84 -- Dustwallow Marsh/0, Krak
		4884=sH|m1445|x36.16|y31.8 -- Dustwallow Marsh/0, Zulrg
		4954=sH|m1417|x74.18|y33.95 -- Arathi Highlands/0, Uttnar
		5052=sH|m1458|x69.81|y44.28 -- Undercity/0, Edward Remington
		5188=sH|m1454|x43.76|y74.24 -- Orgrimmar/0, Garyl
		5189=sH|m1456|x37.67|y63.25 -- Thunder Bluff/0, Thrumn
		5190=sH|m1458|x69.32|y44.81 -- Undercity/0, Merill Pleasance
		5611=sH|m1454|x54.64|y67.67 -- Orgrimmar/0, Barkeep Morag
		5688=sH|m1420|x61.7|y52.04 -- Tirisfal Glades/0, Innkeeper Renee
		5748=sH|m1421|x33.0|y17.84 -- Silverpine Forest/0, Killian Sanatha
		5749=sH|m1420|x30.81|y66.41 -- Tirisfal Glades/0, Kayla Smithe
		5750=sH|m1420|x61.55|y52.6 -- Tirisfal Glades/0, Gina Lang
		5753=sH|m1458|x85.7|y16.08 -- Undercity/0, Martha Strain
		5754=sH|m1458|x69.55|y26.93 -- Undercity/0, Zane Bradford
		5757=sH|m1421|x43.01|y50.81 -- Silverpine Forest/0, Lilly
		5758=sH|m1421|x53.88|y82.21 -- Silverpine Forest/0, Leo Sarn
		5812=sH|m1454|x82.58|y23.57 -- Orgrimmar/0, Tumi
		5814=sH|m1434|x31.48|y29.75 -- Stranglethorn Vale/0, Innkeeper Thulbek
		5815=sH|m1454|x47.52|y46.71 -- Orgrimmar/0, Kurgul
		5816=sH|m1454|x44.17|y48.43 -- Orgrimmar/0, Katis
		5817=sH|m1454|x47.9|y80.34 -- Orgrimmar/0, Shimra
		5819=sH|m1458|x61.64|y28.94 -- Undercity/0, Mirelle Tremayne
		5820=sH|m1458|x70.33|y58.22 -- Undercity/0, Gillian Moore
		5821=sH|m1458|x70.36|y28.91 -- Undercity/0, Sheldon Von Croy
		5870=sH|m1442|x46.22|y58.36 -- Stonetalon Mountains/0, Krond
		5871=sH|m1413|x51.95|y29.68 -- The Barrens/0, Larhka
		5886=sH|m1421|x44.04|y39.77 -- Silverpine Forest/0, Gwyn Farrow
		5940=sH|m1412|x47.51|y55.05 -- Mulgore/0, Harn Longcast
		5942=sH|m1411|x56.06|y73.38 -- Durotar/0, Zansoa
		5944=sH|m1413|x45.0|y59.33 -- The Barrens/0, Yonada
		6027=sH|m1411|x54.7|y41.5 -- Durotar/0, Kitha
		6028=sH|m1440|x73.53|y60.3 -- Ashenvale/0, Burkrum
		6574=sH|m1417|x72.68|y36.45 -- Arathi Highlands/0, Jun'ha
		6567=sH|m1445|x35.14|y30.83 -- Dustwallow Marsh/0, Ghok'kah
		6739=sH|m1421|x43.17|y41.27 -- Silverpine Forest/0, Innkeeper Bates
		6741=sH|m1458|x67.73|y37.89 -- Undercity/0, Innkeeper Norman
		6746=sH|m1456|x45.81|y64.71 -- Thunder Bluff/0, Innkeeper Pala
		6747=sH|m1412|x46.62|y61.09 -- Mulgore/0, Innkeeper Kauth
		6776=sH|m1412|x46.65|y60.7 -- Mulgore/0, Magrin Rivermane
		6928=sH|m1411|x51.51|y41.64 -- Durotar/0, Innkeeper Grosk
		6929=sH|m1454|x54.09|y68.4 -- Orgrimmar/0, Innkeeper Gryshka
		6930=sH|m1435|x45.16|y56.66 -- Swamp of Sorrows/0, Innkeeper Karakul
		7231=sH|m1454|x81.94|y18.01 -- Orgrimmar/0, Kelgruk Bloodaxe
		7485=sH|m1434|x32.19|y29.27 -- Stranglethorn Vale/0, Nargatt
		7683=sH|m1458|x58.61|y54.68 -- Undercity/0, Alessandro Luca
		7714=sH|m1413|x45.57|y59.03 -- The Barrens/0, Innkeeper Byula
		7731=sH|m1442|x47.46|y62.12 -- Stonetalon Mountains/0, Innkeeper Jayka
		7737=sH|m1444|x74.8|y45.18 -- Feralas/0, Innkeeper Greul
		7854=sH|m1444|x74.43|y42.9 -- Feralas/0, Jangdor Swiftstrider
		7952=sH|m1411|x55.22|y75.64 -- Durotar/0, Zjolnir
		8122=sH|m1454|x51.08|y82.08 -- Orgrimmar/0, Kizzak Sparks
		8143=sH|m1444|x75.5|y43.88 -- Feralas/0, Loorana
		8145=sH|m1444|x74.49|y42.72 -- Feralas/0, Sheendra Tallgrass
		8152=sH|m1443|x51.2|y53.26 -- Desolace/0, Harnor
		8158=sH|m1444|x76.05|y43.28 -- Feralas/0, Bronk
		8159=sH|m1444|x74.7|y42.58 -- Feralas/0, Worb Strongstitch
		8176=sH|m1435|x45.46|y51.41 -- Swamp of Sorrows/0, Gharash
		8177=sH|m1435|x45.38|y56.87 -- Swamp of Sorrows/0, Rartar
		8307=sH|m1413|x55.15|y32.08 -- The Barrens/0, Tarban Hearthgrain
		8358=sH|m1456|x45.58|y56.6 -- Thunder Bluff/0, Hewa
		8359=sH|m1456|x45.76|y55.84 -- Thunder Bluff/0, Ahanu
		8360=sH|m1456|x44.96|y56.58 -- Thunder Bluff/0, Elki
		8361=sH|m1456|x36.38|y54.85 -- Thunder Bluff/0, Chepi
		8362=sH|m1456|x38.91|y64.69 -- Thunder Bluff/0, Kuruk
		8363=sH|m1456|x40.64|y63.99 -- Thunder Bluff/0, Shadi Mistrunner
		8364=sH|m1456|x39.3|y64.26 -- Thunder Bluff/0, Pakwa
		8398=sH|m1456|x52.89|y57.49 -- Thunder Bluff/0, Ohanko
		8401=sH|m1456|x61.98|y58.36 -- Thunder Bluff/0, Halpa
		8403=sH|m1458|x67.59|y44.16 -- Undercity/0, Jeremiah Payson
		8404=sH|m1454|x33.81|y79.84 -- Orgrimmar/0, Xan'tish
		8878=sH|m1443|x55.59|y56.49 -- Desolace/0, Muuran
		9087=sH|m1456|x71.06|y34.18 -- Thunder Bluff/0, Bashana Runetotem
		9356=sH|m1418|x2.81|y45.85 -- Badlands/0, Innkeeper Shul'kar
		9501=sH|m1417|x73.84|y32.46 -- Arathi Highlands/0, Innkeeper Adegwa
		9548=sH|m1444|x74.93|y45.7 -- Feralas/0, Cawind Trueaim
		9549=sH|m1442|x45.35|y59.1 -- Stonetalon Mountains/0, Borand
		9551=sH|m1441|x44.88|y50.68 -- Thousand Needles/0, Starn
		9552=sH|m1445|x35.5|y30.09 -- Dustwallow Marsh/0, Zanara
		9553=sH|m1421|x45.0|y39.29 -- Silverpine Forest/0, Nadia Vernon
		9555=sH|m1417|x72.52|y33.35 -- Arathi Highlands/0, Mu'uta
		9636=sH|m1443|x50.97|y53.55 -- Desolace/0, Kireena
		10361=sH|m1447|x22.22|y51.09 -- Azshara/0, Gruul Darkblade
		10364=sH|m1459|x48.36|y80.32 -- ??, Yaelika Farclaw
		10367=sH|m1459|x48.53|y80.47 -- ??, Shrye Ragefist
		10369=sH|m1411|x56.47|y73.11 -- Durotar/0, Trayexir
		10379=sH|m1448|x34.81|y53.15 -- Felwood/0, Altsoba Ragetotem
		10380=sH|m1413|x45.11|y59.0 -- The Barrens/0, Sanuye Runetotem
		11057=sH|m1420|x83.28|y69.23 -- Tirisfal Glades/0, Apothecary Dithers
		11106=sH|m1443|x24.09|y68.21 -- Desolace/0, Innkeeper Sikewa
		11116=sH|m1441|x46.07|y51.51 -- Thousand Needles/0, Innkeeper Abeqwa
		12027=sH|m1443|x24.92|y71.84 -- Desolace/0, Tukk
		12028=sH|m1443|x23.08|y71.6 -- Desolace/0, Lah'Mawhani
		12031=sH|m1443|x22.64|y71.96 -- Desolace/0, Mai'Lahii
		12033=sH|m1443|x26.16|y69.64 -- Desolace/0, Wulan
		12043=sH|m1442|x45.38|y59.33 -- Stonetalon Mountains/0, Kulwia
		12045=sH|m1443|x25.8|y71.01 -- Desolace/0, Hae'Wilani
		12097=sH|m1459|x46.62|y84.21 -- ??, Frostwolf Quartermaster
		12196=sH|m1440|x73.99|y60.64 -- Ashenvale/0, Innkeeper Kaylisk
		12384=sH|m1423|x14.44|y33.48 -- Eastern Plaguelands/0, Augustus the Touched
		12776=sH|m1411|x40.56|y68.43 -- Durotar/0, Hraug
		12799=sH|m1454|x41.46|y68.56 -- Orgrimmar/0, Sergeant Ba'sha
		12807=sH|m1435|x48.57|y55.26 -- Swamp of Sorrows/0, Greshka
		12943=sH|m1420|x83.3|y69.72 -- Tirisfal Glades/0, Werg Thickblade
		12962=sH|m1440|x11.7|y34.09 -- Ashenvale/0, Wik'Tar
		13218=sH|m1459|x49.32|y82.48 -- ??, Grunnda Wolfheart
		13219=sH|m1416|x62.83|y59.27 -- Alterac Mountains/0, Jekyll Flandring
		13476=sH|m1445|x36.48|y30.35 -- Dustwallow Marsh/0, Balai Lok'Wein
		14480=sH|m1454|x50.64|y65.62 -- Orgrimmar/0, Alowicious Czervik
		14731=sH|m1425|x78.14|y81.37 -- The Hinterlands/0, Lard
		14737=sH|m1425|x77.52|y80.35 -- The Hinterlands/0, Smith Slagtree
		14738=sH|m1425|x79.38|y79.08 -- The Hinterlands/0, Otho Moji'ko
		14739=sH|m1425|x78.8|y78.24 -- The Hinterlands/0, Mystic Yayo'jin
		14740=sH|m1425|x80.33|y81.52 -- The Hinterlands/0, Katoom the Angler
		14754=sH|m1413|x46.65|y8.37 -- The Barrens/0, Kelm Hargunth
		15012=sH|m1411|x46.1|y13.76 -- Durotar/0, Javnir Nashak
		15126=sH|m1417|x73.36|y29.67 -- Arathi Highlands/0, Rutherford Twing
		15354=sH|m1454|x53.63|y65.85 -- Orgrimmar/0, Rachelle Gothena
		17598=sH|m1425|x76.85|y81.4 -- The Hinterlands/0, Renn'az
		23604=sH|m1411|x40.20|y17.50 -- Durotar/0, Agnes Farwithers
		23605=sH|m1411|x41.40|y17.64 -- Durotar/0, Bron
		23606=sH|m1411|x41.50|y17.89 -- Durotar/0, Suntouched Apprentice
		23603=sH|m1411|x41.30|y18.00 -- Durotar/0, Uta Roughdough
		24495=sH|m1411|x40.40|y17.80 -- Durotar/0, Blix Fixwidget
		24510=sH|m1411|x42.55|y17.60 -- Durotar/0, Driz Tumblequick
		24208=sH|m1445|x36.80|y32.20 -- Dustwallow Marsh/0, "Little" Logok
		12793=sH|m1454|x38.10|y72.15 -- Orgrimmar/0, Brave Stonehide
		12796=sH|m1454|x41.80|y72.50 -- Orgrimmar/0, Raider Bork
		12794=sH|m1454|x38.50|y72.65 -- Orgrimmar/0, Stone Guard Zarg
		12795=sH|m1454|x38.20|y72.50 -- Orgrimmar/0, First Sergeant Hola'mahi
		27489=sH|m1454|x50.55|y73.52 -- Orgrimmar/0, Ray'ma
		13431=sH|m1456|x43.80|y58.50 -- Thunder Bluff/0, Whulwert Copperpinch
		24501=sH|m1456|x29.10|y62.40 -- Durotar/0, Drohn's Distillery Apprentice
		26124=sH|m1458|x67.80|y11.20 -- Undercity/0, Midsummer Merchant
		23533=sH|m1458|x67.59|y8.10 -- Durotar/0, T'chali's Voodoo Brewery Apprentice
		16259=sH|m1941|x48.20|y47.20 -- Eversong Woods/0, Sheri
		18929=sH|m1941|x47.40|y45.40 -- Eversong Woods/0, Kyrenna
		18926=sH|m1941|x47.00|y47.40 -- Eversong Woods/0, Sleyin
		15287=sH|m1941|x38.60|y20.40 -- Eversong Woods/0, Shara Sunwing
		16257=sH|m1941|x48.40|y46.00 -- Eversong Woods/0, Geron
		16258=sH|m1941|x48.60|y46.20 -- Eversong Woods/0, Farsil
		15292=sH|m1941|x37.60|y18.80 -- Eversong Woods/0, Faraden Thelryn
		15291=sH|m1941|x37.20|y19.20 -- Eversong Woods/0, Jainthess Thelryn
		18947=sH|m1941|x41.80|y52.80 -- Eversong Woods/0, Solanin
		18951=sH|m1941|x55.40|y54.00 -- Eversong Woods/0, Erilia
		18954=sH|m1941|x36.40|y67.00 -- Eversong Woods/0, Sailor Melinan
		16367=sH|m1941|x37.40|y71.80 -- Eversong Woods/0, Botanist Tyniarrel
		16366=sH|m1941|x37.40|y71.80 -- Eversong Woods/0, Sempstress Ambershine
		16186=sH|m1941|x47.80|y47.80 -- Eversong Woods/0, Vara
		18277=sH|m1941|x53.80|y51.20 -- Eversong Woods/0, Kinamisa
		15433=sH|m1941|x48.00|y47.60 -- Eversong Woods/0, Innkeeper Delaniel
		15400=sH|m1941|x59.50|y62.60 -- Eversong Woods/0, Arathel Sunforge
		16443=sH|m1941|x60.40|y62.40 -- Eversong Woods/0, Zalene Firstlight
		16444=sH|m1941|x44.00|y70.40 -- Eversong Woods/0, Halis Dawnstrider
		15397=sH|m1941|x43.60|y71.20 -- Eversong Woods/0, Marniel Amberlight
		16267=sH|m1941|x48.20|y47.80 -- Eversong Woods/0, Daestra
		16264=sH|m1941|x61.00|y54.60 -- Eversong Woods/0, Winaestra
		16262=sH|m1941|x49.00|y47.00 -- Eversong Woods/0, Landraelanis
		16263=sH|m1941|x60.00|y62.60 -- Eversong Woods/0, Paelarin
		16260=sH|m1941|x59.40|y62.80 -- Eversong Woods/0, Areyn
		16261=sH|m1941|x43.60|y71.40 -- Eversong Woods/0, Sathiel
		16860=sH|m1941|x44.80|y71.80 -- Eversong Woods/0, Jilanne
		17655=sH|m1942|x49.00|y30.40 -- Ghostlands/0, Blacksmith Frances
		17656=sH|m1942|x72.20|y32.20 -- Ghostlands/0, Heron Skygaze
		16253=sH|m1942|x48.40|y31.00 -- Ghostlands/0, Master Chef Mouldier
		16224=sH|m1942|x47.20|y28.60 -- Ghostlands/0, Rathis Tomber
		18426=sH|m1942|x48.40|y33.20 -- Ghostlands/0, Terellia
		16542=sH|m1942|x48.80|y32.20 -- Ghostlands/0, Innkeeper Kalarin
		16528=sH|m1942|x47.60|y32.20 -- Ghostlands/0, Provisioner Vredigar
		16187=sH|m1942|x47.20|y29.00 -- Ghostlands/0, Quartermaster Lymel
		16274=sH|m1942|x72.20|y31.80 -- Ghostlands/0, Narina
		16268=sH|m1942|x47.00|y34.20 -- Ghostlands/0, Eralan
		19560=sH|m1944|x61.42|y81.97 -- Hellfire Peninsula/0, Lukra
		19561=sH|m1944|x60.84|y81.61 -- Hellfire Peninsula/0, Hagash the Blind
		19836=sH|m1944|x61.12|y81.40 -- Hellfire Peninsula/0, Mixie Farshot
		16585=sH|m1944|x54.61|y41.21 -- Hellfire Peninsula/0, Cookie One-Eye
		16583=sH|m1944|x53.13|y38.16 -- Hellfire Peninsula/0, Rohok
		18988=sH|m1944|x56.81|y37.38 -- Hellfire Peninsula/0, Baxter
		18749=sH|m1944|x56.57|y37.09 -- Hellfire Peninsula/0, Dalinna
		18997=sH|m1944|x26.48|y60.07 -- Hellfire Peninsula/0, Fallesh Sunfallow
		18991=sH|m1944|x26.18|y62.05 -- Hellfire Peninsula/0, Aresella
		18998=sH|m1944|x28.06|y61.14 -- Hellfire Peninsula/0, Lursa Sunfallow
		18751=sH|m1944|x56.78|y37.79 -- Hellfire Peninsula/0, Kalaen
		18752=sH|m1944|x54.78|y38.51 -- Hellfire Peninsula/0, Zebig
		18753=sH|m1944|x52.34|y35.98 -- Hellfire Peninsula/0, Felannia
		18754=sH|m1944|x56.22|y38.69 -- Hellfire Peninsula/0, Barim Spilthoof
		19315=sH|m1944|x65.81|y43.56 -- Hellfire Peninsula/0, Supply Officer Isabel
		19562=sH|m1944|x61.61|y81.94 -- Hellfire Peninsula/0, Peon Bolgar
		22225=sH|m1944|x56.81|y37.79 -- Hellfire Peninsula/0, Reagan Mancuso
		17585=sH|m1944|x54.90|y37.81 -- Hellfire Peninsula/0, Quartermaster Urgronn
		16588=sH|m1944|x52.28|y36.46 -- Hellfire Peninsula/0, Apothecary Antonivich
		19559=sH|m1944|x61.74|y81.32 -- Hellfire Peninsula/0, Mondul
		17277=sH|m1944|x28.24|y60.84 -- Hellfire Peninsula/0, Provisioner Valine
		18905=sH|m1944|x26.88|y59.54 -- Hellfire Peninsula/0, Innkeeper Bazil Olof'tazun
		19436=sH|m1944|x87.89|y48.30 -- Hellfire Peninsula/0, Supply Master Broog
		19435=sH|m1944|x88.25|y47.09 -- Hellfire Peninsula/0, Dark Cleric Malod
		16602=sH|m1944|x56.71|y37.47 -- Hellfire Peninsula/0, Floyd Pinkus
		18267=sH|m1944|x55.96|y39.20 -- Hellfire Peninsula/0, Battlecryer Blackeye
		19383=sH|m1946|x32.53|y48.10 -- Zangarmarsh/0, Captured Gnome
		18564=sH|m1946|x32.95|y48.89 -- Zangarmarsh/0, Horde Field Scout
		18011=sH|m1946|x85.28|y54.75 -- Zangarmarsh/0, Zurai
		18017=sH|m1946|x32.38|y51.96 -- Zangarmarsh/0, Seer Janidi
		18018=sH|m1946|x32.25|y49.61 -- Zangarmarsh/0, Zurjaya
		18015=sH|m1946|x31.63|y49.20 -- Zangarmarsh/0, Gambarinka
		18243=sH|m1946|x85.76|y54.01 -- Zangarmarsh/0, Lorti
		18245=sH|m1946|x30.66|y50.93 -- Zangarmarsh/0, Merajit
		19345=sH|m1948|x29.48|y26.18 -- Shadowmoon Valley/0, Kalara
		19348=sH|m1948|x28.18|y27.04 -- Shadowmoon Valley/0, Targrom
		19342=sH|m1948|x29.29|y30.91 -- Shadowmoon Valley/0, Krek Cragcrush
		19343=sH|m1948|x29.26|y26.07 -- Shadowmoon Valley/0, Trop Rendlimb
		19339=sH|m1948|x29.92|y31.15 -- Shadowmoon Valley/0, Korthul
		19333=sH|m1948|x29.80|y31.26 -- Shadowmoon Valley/0, Grokom Deatheye
		20494=sH|m1948|x29.08|y29.47 -- Shadowmoon Valley/0, Dama Wildmane
		19837=sH|m1949|x51.08|y57.81 -- Blade's Edge Mountains/0, Daga Ramba
		21085=sH|m1949|x76.57|y65.64 -- Blade's Edge Mountains/0, Ragar
		21082=sH|m1949|x74.53|y61.41 -- Blade's Edge Mountains/0, Krugash
		21083=sH|m1949|x76.07|y61.79 -- Blade's Edge Mountains/0, Erool
		21086=sH|m1949|x75.30|y59.60 -- Blade's Edge Mountains/0, Ruka
		21088=sH|m1949|x76.09|y60.31 -- Blade's Edge Mountains/0, Matron Varah
		19479=sH|m1949|x51.31|y58.58 -- Blade's Edge Mountains/0, Orgatha
		19474=sH|m1949|x51.36|y57.51 -- Blade's Edge Mountains/0, Karnaze
		19472=sH|m1949|x52.05|y57.13 -- Blade's Edge Mountains/0, Threlc
		19473=sH|m1949|x53.10|y59.12 -- Blade's Edge Mountains/0, Raiza
		19470=sH|m1949|x53.36|y55.41 -- Blade's Edge Mountains/0, Gholah
		19471=sH|m1949|x53.20|y54.48 -- Blade's Edge Mountains/0, Old Orok
		19450=sH|m1949|x52.90|y53.61 -- Blade's Edge Mountains/0, Pol Snowhoof
		21084=sH|m1949|x75.96|y60.14 -- Blade's Edge Mountains/0, Braagor
		21474=sH|m1951|x42.79|y42.54 -- Nagrand/0, Coreiel
		20097=sH|m1951|x58.13|y35.67 -- Nagrand/0, Nula the Butcher
		19020=sH|m1951|x55.52|y35.95 -- Nagrand/0, Matron Qualia
		19015=sH|m1951|x55.84|y37.46 -- Nagrand/0, Mathar G'ochar
		19011=sH|m1951|x56.08|y37.32 -- Nagrand/0, Osrok the Immovable
		19013=sH|m1951|x55.00|y35.74 -- Nagrand/0, Vanteg
		18821=sH|m1951|x41.20|y44.25 -- Nagrand/0, Quartermaster Jaffrey Noreliqe
		21484=sH|m1951|x42.07|y42.98 -- Nagrand/0, Embelar
		21483=sH|m1951|x41.59|y43.92 -- Nagrand/0, Tasaldan
		18913=sH|m1951|x56.73|y34.51 -- Nagrand/0, Matron Tikkit
		20241=sH|m1951|x53.46|y37.01 -- Nagrand/0, Provisioner Nasela
		18957=sH|m1952|x48.76|y45.05 -- Terokkar Forest/0, Innkeeper Grilka
		18959=sH|m1952|x50.15|y45.58 -- Terokkar Forest/0, Dod'ss
		18962=sH|m1952|x49.22|y45.54 -- Terokkar Forest/0, Bar Talet
		18960=sH|m1952|x48.74|y46.04 -- Terokkar Forest/0, Rungor
		19772=sH|m1952|x49.84|y46.57 -- Terokkar Forest/0, Spirit Sage Gartok
		16677=sH|m1954|x69.25|y70.84 -- Silvermoon City/0, Quelis
		16678=sH|m1954|x52.52|y64.42 -- Eversong Woods/0, Rahein
		16670=sH|m1954|x79.80|y36.20 -- Silvermoon City/0, Eriden
		16666=sH|m1954|x52.55|y63.57 -- Eversong Woods/0, Feledis
		16664=sH|m1954|x78.59|y42.50 -- Silvermoon City/0, Zelan
		16650=sH|m1954|x61.59|y52.60 -- Silvermoon City/0, Bithrus
		17630=sH|m1954|x67.59|y72.80 -- Silvermoon City/0, Innkeeper Jovia
		16649=sH|m1954|x74.19|y44.65 -- Silvermoon City/0, Torian
		16693=sH|m1954|x60.20|y86.40 -- Silvermoon City/0, Winthren
		16691=sH|m1954|x55.55|y62.50 -- Silvermoon City/0, Noraelath
		16690=sH|m1954|x65.40|y47.40 -- Silvermoon City/0, Rathin
		16641=sH|m1954|x67.00|y18.40 -- Silvermoon City/0, Melaris
		18347=sH|m1954|x77.00|y68.60 -- Silvermoon City/0, Olirea
		23011=sH|m1954|x63.55|y78.74 -- Silvermoon City/0, Morshelz Copperpinch
		23012=sH|m1954|x54.40|y46.40 -- Silvermoon City/0, Hotoppik Copperpinch
		16689=sH|m1954|x84.50|y78.80 -- Silvermoon City/0, Zaralda
		16683=sH|m1954|x80.20|y51.00 -- Silvermoon City/0, Darlia
		16782=sH|m1954|x75.60|y39.40 -- Silvermoon City/0, Yatheon
		16638=sH|m1954|x55.60|y51.20 -- Silvermoon City/0, Deynna
		16635=sH|m1954|x69.84|y24.60 -- Silvermoon City/0, Lyna
		16637=sH|m1954|x56.45|y60.50 -- Silvermoon City/0, Welethelon
		16636=sH|m1954|x69.62|y65.64 -- Silvermoon City/0, Zathanna
		16631=sH|m1954|x65.09|y47.60 -- Silvermoon City/0, Andra
		16626=sH|m1954|x60.90|y86.50 -- Silvermoon City/0, Tynna
		16624=sH|m1954|x90.80|y73.50 -- Silvermoon City/0, Gelanthis
		16625=sH|m1954|x61.20|y86.40 -- Silvermoon City/0, Keeli
		16191=sH|m1954|x54.20|y70.80 -- Silvermoon City/0, Sathren Azuredawn
		16623=sH|m1954|x65.00|y47.80 -- Silvermoon City/0, Zyandrel
		16620=sH|m1954|x86.00|y39.60 -- Silvermoon City/0, Mathaleron
		16442=sH|m1954|x79.55|y58.50 -- Silvermoon City/0, Vinemaster Suntouched
		16619=sH|m1954|x86.00|y35.20 -- Silvermoon City/0, Celana
		16618=sH|m1954|x79.60|y58.40 -- Silvermoon City/0, Innkeeper Velandra
		16613=sH|m1954|x64.60|y64.60 -- Silvermoon City/0, Parnis
		16612=sH|m1954|x69.20|y66.60 -- Silvermoon City/0, Velanni
		16611=sH|m1954|x54.40|y71.80 -- Silvermoon City/0, Zalle
		16610=sH|m1954|x78.50|y84.55 -- Silvermoon City/0, Kredis
		
		30239=sH|m127|x78.20|y50.00 -- ??, Alanura Firecloud
		30253=sH|m127|x77.80|y49.80 -- Crystalsong Forest/0, Felindel Sunhammer
		30254=sH|m127|x78.59|y48.50 -- ??, Marisalira
		30256=sH|m127|x77.40|y49.60 -- ??, Scout Ordimbral
		32415=sH|m125|x71.20|y32.40 -- Dalaran, Hamaka
		32253=sH|m125|x71.30|y31.70 -- Dalaran, Kyunghee
		37941=sH|m125|x65.52|y23.44 -- ??, Magister Arlan
		31581=sH|m125|x65.69|y23.50 -- Dalaran, Magister Brasael
		33963=sH|m125|x64.60|y24.60 -- ??, Magister Sarien
		31582=sH|m125|x65.40|y22.70 -- Dalaran, Magistrix Lambriesse
		35495=sH|m125|x64.50|y24.55 -- ??, Magistrix Vesara
		32412=sH|m125|x71.00|y33.40 -- Dalaran, Mato
		32420=sH|m125|x65.40|y32.00 -- Dalaran, Mimbihi
		31031=sH|m125|x70.00|y38.50 -- Dalaran, Misensi
		31557=sH|m125|x64.55|y32.52 -- Dalaran, Uda the Beast
		32419=sH|m125|x66.59|y33.60 -- Dalaran, Umbiwa
		--35341=sH|m90|x64.20|y9.80 -- Undercity/0,Bountiful Barrel		
		
		27816=sH|m1454|x37.8|y85.4 -- Orgrimmar/0, Brew Vendor
		27810=sH|m1454|x19.39|y52.2 -- Ironforge/0, Brew Vendor
		
		35099=sH|m100|x54.2|y41.6 -- Hellfire Peninsula/0, Bana Wildmane
		30735=sH|m100|x52.4|y36 -- Hellfire Peninsula/0, Kul Inkspiller
		--35343=sH|m88|x30.60|y63.30 -- Thunder Bluff/0,Bountiful Barrel
		--34684=sH|m88|x30.55|y63.45 -- Thunder Bluff/0,Laha Farplain
		30724=sH|m88|x28.7|y20.39 -- Thunder Bluff/0, Mertle Murkpen
		
		--32837=sH|m18|x61.40|y53.00 -- Tirisfal Glades/0/0,Noblegarden Merchant
		33996=sH|m18|x60.4|y53.2 -- Tirisfal Glades/0, William Saldean
		--30729=sH|m90|x61.50|y57.45 -- Undercity/0,Ickabod Pimlen
		--34683=sH|m90|x64.20|y11.00 -- Undercity/0,Rose Standish
		30723=sH|m1454|x56|y46.2 -- Orgrimmar/0, Xantili
		--35342=sH|m1|x46.50|y13.80 -- Durotar/0/0,Bountiful Barrel
		--34685=sH|m1|x46.50|y13.80 -- Durotar/0/0,Dalni Tallgrass
		30727=sH|m110|x69.6|y23.6 -- Silvermoon City/0, Lelorian
		
		--34787=sH|m94|x56.20|y52.80 -- Eversong Woods/0,John Rigsdale
		39173=sH|m123|x51.80|y17.40 -- ??, Champion Ros'slai
		31101=sH|m123|x21.80|y35.20 -- ??, Hoodoo Master Fu'jin
		32296=sH|m123|x51.60|y17.50 -- ??, Stone Guard Mukar

		-- NEUTRAL --
		14860=sB|m1429|x41.69|y69.55 -- Terokkar Forest/0, Flik
		14844=sB|m1429|x42.00|y70.00 -- Terokkar Forest/0, Sylannia
		14845=sB|m1429|x42.00|y70.00 -- Terokkar Forest/0, Stamp Thunderhorn
		14846=sB|m1429|x41.20|y69.80 -- Terokkar Forest/0, Lhara
		14847=sB|m1429|x41.20|y69.80 -- Terokkar Forest/0, Professor Thaddeus Paleo
		1669=sB|m1436|x43.47|y66.75 -- Westfall/0, Defias Profiteer
		2480=sB|m1416|x38.23|y38.86 -- Alterac Mountains/0, Bro'kin
		2481=sB|m1431|x18.03|y54.35 -- Duskwood/0, Bliztik
		2482=sB|m1434|x28.33|y75.46 -- Stranglethorn Vale/0, Zarena Cromwind
		2483=sB|m1434|x35.75|y10.65 -- Stranglethorn Vale/0, Jaquilina Dramet
		2622=sB|m1434|x28.4|y76.83 -- Stranglethorn Vale/0, Sly Garrett
		2626=sB|m1434|x27.41|y77.16 -- Stranglethorn Vale/0, Old Man Heming
		2663=sB|m1434|x28.13|y74.42 -- Stranglethorn Vale/0, Narkk
		2664=sB|m1434|x28.23|y74.33 -- Stranglethorn Vale/0, Kelsey Yance
		2670=sB|m1434|x28.7|y76.88 -- Stranglethorn Vale/0, Xizk Goodstitch
		2672=sB|m1434|x27.0|y82.47 -- Stranglethorn Vale/0, Cowardly Crosby
		2684=sB|m1416|x47.3|y35.16 -- Alterac Mountains/0, Rizz Loosebolt
		2685=sB|m1434|x28.5|y75.12 -- Stranglethorn Vale/0, Mazk Snipeshot
		2687=sB|m1434|x50.97|y35.2 -- Stranglethorn Vale/0, Gnaz Blunderflame
		2688=sB|m1425|x34.32|y37.76 -- The Hinterlands/0, Ruppo Zipcoil
		2699=sB|m1434|x28.48|y76.04 -- Stranglethorn Vale/0, Rikqiz
		2832=sB|m1434|x27.03|y77.17 -- Stranglethorn Vale/0, Nixxrax Fillamug
		2834=sB|m1434|x27.46|y77.11 -- Stranglethorn Vale/0, Myizz Luckycatch
		2838=sB|m1434|x28.36|y76.66 -- Stranglethorn Vale/0, Crazk Sparks
		2839=sB|m1434|x28.3|y74.55 -- Stranglethorn Vale/0, Haren Kanmae
		2840=sB|m1434|x28.27|y75.21 -- Stranglethorn Vale/0, Kizz Bluntstrike
		2842=sB|m1434|x28.0|y76.98 -- Stranglethorn Vale/0, Wigcik
		2843=sB|m1434|x27.46|y77.54 -- Stranglethorn Vale/0, Jutak
		2844=sB|m1434|x28.96|y75.05 -- Stranglethorn Vale/0, Hurklor
		2845=sB|m1434|x29.04|y74.99 -- Stranglethorn Vale/0, Fargon Mortalak
		2846=sB|m1434|x28.24|y77.54 -- Stranglethorn Vale/0, Blixrez Goodstitch
		2847=sB|m1434|x29.07|y75.48 -- Stranglethorn Vale/0, Jansen Underwood
		2848=sB|m1434|x28.13|y78.1 -- Stranglethorn Vale/0, Glyx Brewright
		2849=sB|m1434|x28.14|y77.56 -- Stranglethorn Vale/0, Qixdi Goodstitch
		3000=sB|m1449|x44.1|y7.19 -- Un'Goro Crater/0, Gibbert
		3053=sB|m1441|x80.39|y77.0 -- Thousand Needles/0, Synge
		3096=sB|m1433|x74.46|y79.51 -- Redridge Mountains/0, Captured Servant of Azora
		3134=sB|m1431|x81.82|y19.76 -- Duskwood/0, Kzixx
		3180=sB|m1437|x46.55|y18.36 -- Wetlands/0, Dark Iron Entrepreneur
		3491=sB|m1413|x62.23|y37.47 -- The Barrens/0, Ironzar
		3492=sB|m1413|x62.16|y38.45 -- The Barrens/0, Vexspindle
		3493=sB|m1413|x62.2|y38.41 -- The Barrens/0, Grazlix
		3495=sB|m1413|x62.64|y36.26 -- The Barrens/0, Gagsprocket
		3497=sB|m1413|x62.76|y38.24 -- The Barrens/0, Kilxx
		3498=sB|m1413|x61.92|y38.79 -- The Barrens/0, Jazzik
		3499=sB|m1413|x61.92|y38.69 -- The Barrens/0, Ranik
		3534=sB|m1421|x46.49|y86.49 -- Silverpine Forest/0, Wallace the Blind
		3536=sB|m1424|x80.14|y38.89 -- Hillsbrad Foothills/0, Kris Legace
		3537=sB|m1424|x55.72|y34.79 -- Hillsbrad Foothills/0, Zixil
		3572=sB|m1413|x61.99|y39.14 -- The Barrens/0, Zizzek
		3658=sB|m1413|x61.75|y38.27 -- The Barrens/0, Lizzarik
		3683=sB|m1413|x41.79|y38.69 -- The Barrens/0, Kiknikle
		3684=sB|m1413|x41.77|y38.62 -- The Barrens/0, Pizznukle
		4085=sB|m1442|x62.69|y40.17 -- Stonetalon Mountains/0, Nizzik
		4086=sB|m1442|x58.21|y51.73 -- Stonetalon Mountains/0, Veenix
		4184=sB|m1450|x51.99|y32.89 -- Moonglade/0, Geenia Sunshadow
		4453=sB|m1441|x78.14|y77.12 -- Thousand Needles/0, Wizzle Brassbolts
		4782=sB|m1425|x14.36|y42.3 -- The Hinterlands/0, Truk Wildbeard
		5411=sB|m1446|x51.46|y28.81 -- Tanaris/0, Krinkle Goodsteel
		5594=sB|m1446|x50.88|y26.96 -- Tanaris/0, Alchemist Pestlezugg
		5783=sB|m1413|x45.89|y35.69 -- ??, Kalldan Felmoon
		6495=sB|m1441|x80.44|y76.46 -- Thousand Needles/0, Riznek
		6496=sB|m1441|x77.31|y77.01 -- Thousand Needles/0, Brivelthwerp
		6548=sB|m1441|x78.29|y75.69 -- Thousand Needles/0, Magus Tirth
		6568=sB|m1446|x51.01|y27.35 -- Tanaris/0, Vizzklick
		6730=sB|m1441|x77.67|y77.9 -- Thousand Needles/0, Jinky Twizzlefixxit
		6777=sB|m1416|x85.95|y79.96 -- Alterac Mountains/0, Zan Shivsproket
		6779=sB|m1416|x86.12|y79.57 -- Alterac Mountains/0, Smudge Thunderwood
		6791=sB|m1413|x62.04|y39.4 -- The Barrens/0, Innkeeper Wiley
		6807=sB|m1434|x27.03|y77.31 -- Stranglethorn Vale/0, Innkeeper Skindle
		7564=sB|m1446|x51.8|y28.66 -- Tanaris/0, Marin Noggenfogger
		7733=sB|m1446|x52.5|y27.91 -- Tanaris/0, Innkeeper Fizzgrimble
		7744=sB|m1425|x14.14|y41.56 -- The Hinterlands/0, Innkeeper Thulfram
		7772=sB|m1444|x49.46|y19.83 -- Feralas/0, Kalin Windflight
		7775=sB|m1444|x45.11|y25.56 -- Feralas/0, Gregan Brewspewer
		7940=sB|m1450|x51.46|y33.25 -- Moonglade/0, Darnall
		8116=sB|m1434|x27.61|y77.66 -- Stranglethorn Vale/0, Ziggle Sparks
		8117=sB|m1455|x31.49|y61.98 -- Ironforge/0, Wizbang Booms
		8121=sB|m1413|x61.72|y38.34 -- The Barrens/0, Jaxxil Sparks
		8125=sB|m1446|x52.63|y28.11 -- Tanaris/0, Dirge Quikcleave
		8129=sB|m1446|x50.79|y27.71 -- Tanaris/0, Wrinkle Goodsteel
		8131=sB|m1446|x50.73|y27.53 -- Tanaris/0, Blizrik Buckshot
		8137=sB|m1446|x66.63|y22.07 -- Tanaris/0, Gikkix
		8139=sB|m1446|x67.0|y21.98 -- Tanaris/0, Jabbey
		8160=sB|m1425|x13.29|y43.37 -- The Hinterlands/0, Nioma
		8161=sB|m1425|x13.41|y44.14 -- The Hinterlands/0, Harggan
		8305=sB|m1437|x50.2|y37.73 -- Wetlands/0, Kixxle
		8678=sB|m1447|x45.27|y90.94 -- Azshara/0, Jubie Gadgetspring
		8679=sB|m1434|x51.05|y35.23 -- Stranglethorn Vale/0, Knaz Blunderflame
		9179=sB|m1418|x42.46|y52.49 -- Badlands/0, Jazzrik
		10856=sB|m1420|x83.26|y68.14 -- Tirisfal Glades/0, Argent Quartermaster Hasana
		10857=sB|m1422|x42.83|y83.71 -- Western Plaguelands/0, Argent Quartermaster Lightspark
		11038=sB|m1423|x79.54|y63.85 -- Eastern Plaguelands/0, Caretaker Alen
		11118=sB|m1452|x61.35|y38.83 -- Winterspring/0, Innkeeper Vizzie
		11182=sB|m1452|x61.62|y37.86 -- Winterspring/0, Nixxrak
		11183=sB|m1452|x61.66|y37.82 -- Winterspring/0, Blixxrak
		11184=sB|m1452|x61.72|y38.02 -- Winterspring/0, Wixxrak
		11185=sB|m1452|x60.8|y38.6 -- Winterspring/0, Xizzer Fizzbolt
		11186=sB|m1452|x61.78|y38.59 -- Winterspring/0, Lunnix Sprocketslip
		11187=sB|m1452|x61.32|y39.16 -- Winterspring/0, Himmik
		11188=sB|m1452|x60.75|y37.77 -- Winterspring/0, Evie Whirlbrew
		11189=sB|m1452|x61.2|y37.21 -- Winterspring/0, Qia
		11278=sB|m1422|x67.99|y77.6 -- Western Plaguelands/0, Magnus Frostwake
		11287=sB|m1422|x69.58|y79.68 -- Western Plaguelands/0, Baker Masterson
		11536=sB|m1423|x81.62|y59.99 -- Eastern Plaguelands/0, Quartermaster Miranda Breechlock
		11555=sB|m1448|x65.18|y2.67 -- Felwood/0, Gorn One Eye
		11557=sB|m1448|x65.69|y2.8 -- Felwood/0, Meilosh
		11874=sB|m1435|x26.45|y31.47 -- Swamp of Sorrows/0, Masat T'andr
		12019=sB|m1450|x48.87|y39.16 -- Moonglade/0, Dargon
		12021=sB|m1450|x45.19|y34.74 -- Moonglade/0, Daeolyn Summerleaf
		12022=sB|m1450|x48.24|y40.13 -- Moonglade/0, Lorelae Wintersong
		12023=sB|m1450|x56.6|y29.94 -- Moonglade/0, Kharedon
		12024=sB|m1450|x51.18|y42.3 -- Moonglade/0, Meliri
		12026=sB|m1450|x44.51|y33.88 -- Moonglade/0, My'lanna
		12029=sB|m1450|x53.34|y42.69 -- Moonglade/0, Narianna
		12245=sB|m1443|x62.02|y38.81 -- Desolace/0, Vendor-Tron 1000
		12919=sB|m1445|x58.54|y60.21 -- Dustwallow Marsh/0, Nat Pagle
		12941=sB|m1423|x80.59|y57.57 -- Eastern Plaguelands/0, Jase Farlane
		12956=sB|m1451|x82.0|y17.73 -- Silithus/0, Zannok Hidepiercer
		12957=sB|m1447|x45.2|y90.84 -- Azshara/0, Blimo Gadgetspring
		12958=sB|m1425|x34.45|y38.58 -- The Hinterlands/0, Gigget Zipcoil
		12959=sB|m1449|x43.27|y7.73 -- Un'Goro Crater/0, Nergal
		13418=sB|m1454|x53.33|y66.48 -- Orgrimmar/0, Kaymard Copperpinch
		13420=sB|m1454|x53.2|y65.89 -- Orgrimmar/0, Penney Copperpinch
		13429=sB|m1458|x68.24|y38.85 -- Undercity/0, Nardstrum Copperpinch
		13430=sB|m1458|x68.14|y38.6 -- Undercity/0, Jaycrue Copperpinch
		13432=sB|m1456|x39.04|y61.06 -- Thunder Bluff/0, Seersa Copperpinch
		13433=sB|m1455|x33.69|y67.23 -- Ironforge/0, Wulmort Jinglepocket
		13434=sB|m1455|x33.6|y67.68 -- Ironforge/0, Macey Jinglepocket
		14437=sB|m1428|x12.43|y31.63 -- Burning Steppes/0, Gorzeeki Wildeyes
		14624=sB|m1427|x38.8|y28.5 -- Searing Gorge/0, Master Smith Burninate
		14637=sB|m1444|x44.81|y43.42 -- Feralas/0, Zorbin Fandazzle
		14921=sB|m1434|x15.07|y16.0 -- Stranglethorn Vale/0, Rin'wosho the Trader
		14961=sB|m1416|x40.05|y80.15 -- Alterac Mountains/0, Mirvyna Jinglepocket
		14962=sB|m1416|x62.0|y58.56 -- Alterac Mountains/0, Dillord Copperpinch
		14963=sB|m1440|x62.07|y82.84 -- Ashenvale/0, Gapp Jinglepocket
		14964=sB|m1413|x46.73|y8.31 -- The Barrens/0, Hecht Copperpinch
		15124=sB|m1417|x46.47|y45.33 -- Arathi Highlands/0, Targot Jinglepocket
		15125=sB|m1417|x74.2|y29.28 -- Arathi Highlands/0, Kosco Copperpinch
		15165=sB|m1446|x66.55|y22.26 -- Tanaris/0, Haughty Modiste
		15174=sB|m1451|x51.89|y39.16 -- Silithus/0, Calandrath
		15175=sB|m1451|x48.66|y37.0 -- Silithus/0, Khur Hornstriker
		15176=sB|m1451|x51.22|y38.85 -- Silithus/0, Vargus
		15179=sB|m1451|x49.87|y36.33 -- Silithus/0, Mishta
		15293=sB|m1451|x62.57|y49.78 -- Silithus/0, Aendel Windspear
		15419=sB|m1451|x51.96|y39.69 -- Silithus/0, Kania
		15864=sB|m1450|x53.65|y35.25 -- Moonglade/0, Valadar Starsong
		15909=sB|m1450|x53.79|y35.32 -- Moonglade/0, Fariel Starsong
		16015=sB|m1452|x58.87|y78.39 -- Winterspring/0, Vi'el
		16256=sB|m1423|x81.62|y58.07 -- Eastern Plaguelands/0, Jessica Chambers
		16376=sB|m1423|x81.01|y59.61 -- Eastern Plaguelands/0, Craftsman Wilhelm
		16543=sB|m1451|x52.51|y38.64 -- Silithus/0, Garon Hutchins
		20112=sB|m1459|x43.19|y50.43 -- Netherstorm/0, Wind Trader Tuluman
		--23159=sB|m339|x61.50|y51.20 -- Black Temple/0, 
		--23157=sB|m339|x61.70|y49.59 -- Black Temple/0, 
		23535=sB|m1413|x68.00|y67.80 -- The Barrens/0, Matero Zeshuwal
		23511=sB|m1426|x55.50|y36.60 -- Dun Morogh/0, Gordok Brew Apprentice
		26081=sB|m1426|x17.80|y74.50 -- ??, High Admiral "Shelly" Jorrik
		9544=sB|m1428|x66.00|y22.00 -- Burning Steppes/0, Yuka Screwspigot
		18255=sB|m1430|x47.00|y75.40 -- Deadwind Pass/0, Apprentice Darius
		24935=sB|m1434|x36.80|y52.40 -- Tirisfal Glades/0, Vend-O-Tron D-Luxe
		24934=sB|m1434|x36.80|y52.60 -- ??, Snack-O-Matic IV
		12246=sB|m1443|x40.50|y79.20 -- Desolace/0, Super-Seller 680
		23995=sB|m1445|x41.80|y74.00 -- Dustwallow Marsh/0, Axle
		23573=sB|m1445|x41.80|y73.00 -- Dustwallow Marsh/0, Krixil Slogswitch
		23571=sB|m1445|x42.50|y73.40 -- Dustwallow Marsh/0, Razbo Rustgear
		20082=sB|m1446|x64.00|y56.40 -- Tanaris/0, Yarley
		20081=sB|m1446|x63.80|y57.50 -- Tanaris/0, Bortega
		20080=sB|m1446|x63.80|y57.80 -- Tanaris/0, Galgrom
		18542=sB|m1446|x66.40|y49.50 -- Tanaris/0, Alexston Chrome
		21643=sB|m1446|x63.60|y57.60 -- Tanaris/0, Alurmi
		20130=sB|m1446|x58.40|y54.20 -- Tanaris/0, Andormu
		19932=sB|m1446|x57.60|y59.00 -- Tanaris/0, Andormu
		27816=sB|m1454|x50.55|y73.44 -- Orgrimmar/0, Brew Vendor
		27811=sB|m1454|x50.50|y73.30 -- Ironforge/0, Brew Vendor
		27810=sB|m1454|x50.65|y73.52 -- Ironforge/0, Brew Vendor
		27815=sB|m1455|x18.80|y51.80 -- ??, Brew Vendor
		27814=sB|m1455|x19.00|y51.80 -- ??, Brew Vendor
		27817=sB|m1455|x18.80|y51.80 -- Ironforge/0, Brew Vendor
		27813=sB|m1455|x18.70|y51.50 -- ??, Brew Vendor
		27812=sB|m1455|x18.70|y51.59 -- Ironforge/0, Brew Vendor
		27818=sB|m1455|x18.80|y51.80 -- Ironforge/0, Brew Vendor
		27806=sB|m1455|x19.00|y51.80 -- Ironforge/0, Brew Vendor
		27820=sB|m1455|x19.00|y52.00 -- Ironforge/0, Brew Vendor
		27819=sB|m1455|x19.00|y51.80 -- Ironforge/0, Brew Vendor
		15898=sB|m1455|x29.55|y14.49 -- Ironforge/0, Lunar Festival Vendor
		18382=sB|m1946|x17.86|y51.14 -- Zangarmarsh/0, Mycah
		18993=sB|m1946|x78.51|y63.05 -- Zangarmarsh/0, Naka
		23373=sB|m1946|x51.54|y35.40 -- Zangarmarsh/0, Mortog Steamhead
		17904=sB|m1946|x79.26|y63.67 -- Zangarmarsh/0, Fedryen Swiftspear
		18911=sB|m1946|x78.05|y66.09 -- Zangarmarsh/0, Juno Dufrain
		18907=sB|m1946|x78.49|y62.94 -- Zangarmarsh/0, Innkeeper Coryth Stoktron
		21172=sB|m1946|x79.52|y63.79 -- Zangarmarsh/0, Sarinei Whitestar
		16715=sB|m1947|x47.50|y89.90 -- The Exodar/0, Avelii
		16657=sB|m1947|x53.00|y90.00 -- The Exodar/0, Feera
		16748=sB|m1947|x66.40|y74.00 -- The Exodar/0, Haferet
		23010=sB|m1947|x55.45|y48.85 -- The Exodar/0, Wolgren Jinglepocket
		16750=sB|m1947|x67.40|y94.00 -- The Exodar/0, Yil
		16757=sB|m1947|x39.09|y12.60 -- The Exodar/0, Bildine
		23009=sB|m1947|x55.45|y48.49 -- ??, Bessbi Jinglepocket
		16766=sB|m1947|x53.50|y68.39 -- The Exodar/0, Issca
		16632=sB|m1947|x46.55|y61.57 -- The Exodar/0, Oss
		16747=sB|m1947|x70.32|y92.19 -- The Exodar/0, Mahri
		--23489=sB|m1948|x65.60|y86.00 --Not visible -- Shadowmoon Valley/0, 
		19625=sB|m1948|x55.39|y59.24 -- Shadowmoon Valley/0, Alorya
		21746=sB|m1948|x61.12|y28.24 -- Shadowmoon Valley/0, Caretaker Aluuro
		19649=sB|m1948|x61.06|y28.00 -- Shadowmoon Valley/0, Dorni
		21183=sB|m1948|x53.92|y23.53 -- Shadowmoon Valley/0, Oronok Torn-heart
		19517=sB|m1948|x55.41|y59.02 -- Shadowmoon Valley/0, Alorra
		19518=sB|m1948|x55.87|y58.41 -- Shadowmoon Valley/0, Feranin
		19532=sB|m1948|x61.63|y28.65 -- Shadowmoon Valley/0, Dearny
		19530=sB|m1948|x61.08|y29.69 -- Shadowmoon Valley/0, Darmend
		--23145=sB|m1948|x65.80|y85.80 --Not visible -- Shadowmoon Valley/0, 
		--23144=sB|m1948|x65.50|y86.45 --Not visible -- Shadowmoon Valley/0, 
		--23143=sB|m1948|x66.20|y87.00 --Not visible -- Shadowmoon Valley/0, 
		19528=sB|m1948|x62.50|y28.23 -- Shadowmoon Valley/0, Nanomah
		19526=sB|m1948|x63.26|y30.75 -- Shadowmoon Valley/0, Dunaman
		19520=sB|m1948|x55.51|y59.31 -- Shadowmoon Valley/0, Lelagar
		19521=sB|m1948|x55.93|y58.16 -- Shadowmoon Valley/0, Arrond
		21744=sB|m1948|x56.32|y59.84 -- Shadowmoon Valley/0, Roldemar
		22264=sB|m1949|x29.35|y57.49 -- Blade's Edge Mountains/0, Ogri'la Steelshaper
		22266=sB|m1949|x27.82|y58.23 -- Blade's Edge Mountains/0, Ogri'la Grubgiver
		20250=sB|m1949|x62.81|y38.94 -- Blade's Edge Mountains/0, Rashere Pridehoof
		22270=sB|m1949|x27.83|y58.49 -- Blade's Edge Mountains/0, Ogri'la Merchant
		22271=sB|m1949|x28.75|y56.73 -- Blade's Edge Mountains/0, Ogri'la Trader
		20915=sB|m1949|x62.28|y40.43 -- Blade's Edge Mountains/0, Noko Moonwhisper
		20917=sB|m1949|x61.59|y38.29 -- Blade's Edge Mountains/0, Zinyen Swiftstrider
		20916=sB|m1949|x62.48|y40.34 -- Blade's Edge Mountains/0, Xerintha Ravenoak
		--23244=sB|m1949|x54.40|y10.80 --Not visible -- Blade's Edge Mountains/0, 
		--23245=sB|m1949|x54.40|y10.80 --Not visible -- Blade's Edge Mountains/0, 
		--23243=sB|m1949|x54.40|y10.80 --Not visible -- Blade's Edge Mountains/0, 
		23208=sB|m1949|x27.33|y52.58 -- Blade's Edge Mountains/0, Skyguard Pyrotechnician
		23110=sB|m1949|x27.87|y57.62 -- Blade's Edge Mountains/0, Ogri'la Keg King
		23112=sB|m1949|x29.15|y58.00 -- Blade's Edge Mountains/0, Mingo
		23428=sB|m1949|x28.07|y58.73 -- Blade's Edge Mountains/0, Jho'nass
		20249=sB|m1949|x61.13|y39.36 -- Blade's Edge Mountains/0, Cymbre Starsong
		23007=sB|m1951|x30.53|y56.92 -- Nagrand/0, Paulsta'ats
		18278=sB|m1951|x71.20|y41.20 -- Nagrand/0, Pilot Marsha
		19718=sB|m1952|x39.73|y70.09 -- Terokkar Forest/0, Provisioner Tsaalt
		22476=sB|m1952|x30.97|y76.48 -- Terokkar Forest/0, Aundro
		20890=sB|m1952|x37.64|y51.23 -- Terokkar Forest/0, Siflaed Coldhammer
		20891=sB|m1952|x37.61|y51.10 -- Terokkar Forest/0, Skraa
		20892=sB|m1952|x37.66|y51.16 -- Terokkar Forest/0, Ruogo
		20893=sB|m1952|x37.72|y51.22 -- Terokkar Forest/0, Morula
		23363=sB|m1952|x67.01|y79.66 -- Terokkar Forest/0, Sahaak
		23367=sB|m1952|x64.30|y66.24 -- Terokkar Forest/0, Grella
		19879=sB|m1952|x34.60|y66.00 -- Terokkar Forest/0, Horvon the Armorer
		19679=sB|m1952|x39.23|y58.82 -- Terokkar Forest/0, "Slim"
		20986=sB|m1952|x39.45|y70.05 -- Terokkar Forest/0, Dealer Tariq
		19573=sB|m1953|x32.51|y63.10 -- Netherstorm/0, Dash
		19572=sB|m1953|x32.77|y64.11 -- Netherstorm/0, Gant
		22479=sB|m1953|x66.39|y67.30 -- Netherstorm/0, Sab'aoth
		22491=sB|m1953|x66.03|y67.30 -- Netherstorm/0, Kerpow Blastwrench
		20463=sB|m1953|x57.71|y85.19 -- Netherstorm/0, Apprentice Andrethan
		19575=sB|m1953|x32.65|y66.75 -- Netherstorm/0, Qiff 
		19574=sB|m1953|x33.13|y67.32 -- Netherstorm/0, Kizzie
		20092=sB|m1953|x58.35|y31.26 -- Netherstorm/0, Dealer Hazzin
		20278=sB|m1953|x33.19|y64.20 -- Netherstorm/0, Vixton Pinchwhistle
		28344=sB|m1953|x32.39|y64.38 -- Netherstorm/0, Blazzle
		19617=sB|m1953|x32.27|y63.92 -- Netherstorm/0, Boots
		23396=sB|m1953|x33.00|y64.00 -- Netherstorm/0, Krixel Pinchwhistle
		20980=sB|m1953|x43.52|y35.27 -- Netherstorm/0, Dealer Rashaad
		19533=sB|m1953|x43.94|y34.52 -- Netherstorm/0, Dealer Aljaan
		19531=sB|m1953|x43.36|y36.14 -- Netherstorm/0, Eyonix
		19537=sB|m1953|x44.12|y34.08 -- Netherstorm/0, Dealer Malij
		19536=sB|m1953|x43.96|y36.67 -- Netherstorm/0, Dealer Jadyan
		19535=sB|m1953|x43.87|y35.24 -- Netherstorm/0, Dealer Zijaad
		19534=sB|m1953|x43.33|y35.09 -- Netherstorm/0, Dealer Digriz
		19539=sB|m1953|x44.52|y34.04 -- Netherstorm/0, Jazdalaad
		19538=sB|m1953|x44.56|y33.73 -- Netherstorm/0, Dealer Senzik
		20194=sB|m1953|x46.73|y56.64 -- Netherstorm/0, Dealer Dunar
		20989=sB|m1953|x43.25|y34.99 -- Netherstorm/0, Dealer Sadaqat
		20981=sB|m1953|x44.99|y36.52 -- Netherstorm/0, Dealer Najeeb
		19540=sB|m1953|x44.23|y33.66 -- Netherstorm/0, Asarnan
		20242=sB|m1953|x43.64|y34.30 -- Netherstorm/0, Karaaz
		22213=sB|m1955|x66.55|y68.54 -- Shattrath City/0, Gidge Spellweaver
		21432=sB|m1955|x51.20|y40.80 -- Shattrath City/0, Almaador
		23263=sB|m1955|x60.90|y69.50 -- Shattrath City/0, Brendan Turner
		27711=sB|m1955|x28.00|y47.50 -- Shattrath City/0, Technician Halmaha
		23064=sB|m1955|x43.00|y64.80 -- Shattrath City/0, Eebee Jinglepocket
		23065=sB|m1955|x43.80|y66.80 -- Shattrath City/0, Olnayvi Copperpinch
		23484=sB|m1955|x47.75|y26.40 -- Shattrath City/0, Haldor the Compulsive
		23483=sB|m1955|x60.52|y63.52 -- Shattrath City/0, Arcanist Xorith
		19331=sB|m1955|x60.45|y63.85 -- Shattrath City/0, Quartermaster Enuril
		19330=sB|m1955|x54.50|y82.55 -- Shattrath City/0, Lisrythe Bloodwatch
		19245=sB|m1955|x43.00|y97.20 -- Shattrath City/0, Vinemaster Alamaro
		19244=sB|m1955|x56.50|y79.65 -- Shattrath City/0, Trader Endernor
		19240=sB|m1955|x42.00|y75.20 -- Shattrath City/0, Selanam the Blade
		19243=sB|m1955|x51.80|y80.40 -- Shattrath City/0, Nalama the Merchant
		19321=sB|m1955|x47.80|y25.50 -- Shattrath City/0, Quartermaster Endarin
		18756=sB|m1955|x75.50|y30.70 -- Shattrath City/0, Haris Pilton
		20613=sB|m1955|x43.60|y90.40 -- Shattrath City/0, Arodis Sunblade
		20616=sB|m1955|x23.55|y32.40 -- Shattrath City/0, Asuur
		25196=sB|m1955|x41.50|y63.40 -- Shattrath City/0, Archer Delvinar
		25195=sB|m1955|x37.50|y27.80 -- Shattrath City/0, Marksman Bova
		23699=sB|m1955|x70.00|y55.00 -- Shattrath City/0, Kevin Browning
		19065=sB|m1955|x35.50|y19.80 -- Shattrath City/0, Inessera
		19664=sB|m1955|x61.40|y69.40 -- Shattrath City/0, Muffin Man Moser
		19663=sB|m1955|x63.20|y70.50 -- Shattrath City/0, Madame Ruby
		19662=sB|m1955|x64.00|y71.60 -- Shattrath City/0, Aaron Hollman
		19661=sB|m1955|x64.65|y69.50 -- Shattrath City/0, Viggz Shinesparked
		18525=sB|m1955|x50.50|y43.20 -- Shattrath City/0, G'eras
		19074=sB|m1955|x46.00|y20.20 -- Shattrath City/0, Skreah
		19213=sB|m1955|x66.00|y68.30 -- Shattrath City/0, Eiin
		19678=sB|m1955|x64.50|y70.20 -- Shattrath City/0, Fantei
		20808=sB|m1955|x59.80|y63.70 -- Shattrath City/0, Scribe Veredis
		20807=sB|m1955|x48.00|y24.60 -- Shattrath City/0, Scribe Saalyn
		27666=sB|m1955|x48.65|y41.50 -- Shattrath City/0, Ontuvo
		27667=sB|m1955|x48.65|y42.65 -- Shattrath City/0, Anwehu
		19195=sB|m1955|x63.55|y68.59 -- Shattrath City/0, Jim Saltit
		19194=sB|m1955|x66.60|y64.20 -- Shattrath City/0, Ernie Packwell
		19197=sB|m1955|x61.90|y70.50 -- Shattrath City/0, Eral
		19196=sB|m1955|x67.20|y67.50 -- Shattrath City/0, Cro Threadstrong
		19049=sB|m1955|x45.50|y19.50 -- Shattrath City/0, Karokka
		19047=sB|m1955|x52.00|y16.40 -- Shattrath City/0, Lissaf
		19045=sB|m1955|x58.20|y15.70 -- Shattrath City/0, Oloraak
		19043=sB|m1955|x34.44|y19.25 -- Shattrath City/0, Ahemen
		19227=sB|m1955|x65.65|y68.69 -- Shattrath City/0, Griftah
		19223=sB|m1955|x64.00|y68.60 -- Shattrath City/0, Granny Smith
		19182=sB|m1955|x75.00|y33.50 -- Shattrath City/0, Shaarubo
		19186=sB|m1955|x74.80|y32.20 -- Shattrath City/0, Kylene
		19050=sB|m1955|x27.40|y49.80 -- Shattrath City/0, Garul
		19232=sB|m1955|x56.20|y81.59 -- Shattrath City/0, Innkeeper Haelthol
		19234=sB|m1955|x44.20|y97.60 -- Shattrath City/0, Yurial Soulwater
		19236=sB|m1955|x44.50|y76.09 -- Shattrath City/0, Quelama Lightblade
		19238=sB|m1955|x49.50|y79.09 -- Shattrath City/0, Urumir Stavebright
		19239=sB|m1955|x54.55|y82.52 -- Shattrath City/0, Mahir Redstroke
		19235=sB|m1955|x43.90|y97.50 -- Shattrath City/0, Amshesha Stilldark
		18484=sB|m1955|x72.40|y30.80 -- Shattrath City/0, Wind Trader Lathrai
		22208=sB|m1955|x66.40|y69.20 -- Shattrath City/0, Nasmara Moonsong
		21905=sB|m1955|x44.65|y91.60 -- Shattrath City/0, Veynna Dawnstar
		21906=sB|m1955|x24.70|y27.40 -- Shattrath City/0, Kelara
		22212=sB|m1955|x66.50|y68.25 -- Shattrath City/0, Andrion Darkspinner
		25950=sB|m1957|x51.40|y32.50 -- Isle of Quel'Danas/0, Shaani
		25043=sB|m1957|x51.80|y34.20 -- ??, Sereth Duskbringer
		25046=sB|m1957|x50.60|y40.80 -- Isle of Quel'Danas/0, Smith Hauthaa
		25976=sB|m1957|x50.20|y28.50 -- Isle of Quel'Danas/0, Theremis
		25977=sB|m1957|x50.20|y28.20 -- Isle of Quel'Danas/0, Yrma
		24975=sB|m1957|x51.40|y32.50 -- Isle of Quel'Danas/0, Mar'nah
		26089=sB|m1957|x50.00|y39.80 -- ??, Kayri
		26092=sB|m1957|x49.40|y39.80 -- ??, Soryn
		26090=sB|m1957|x49.60|y40.40 -- ??, Karynna
		26091=sB|m1957|x50.00|y40.00 -- ??, Olus
		25039=sB|m1957|x51.20|y32.60 -- Isle of Quel'Danas/0, Kaalif
		25035=sB|m1957|x49.80|y39.60 -- ??, Tyrael Flamekissed
		25034=sB|m1957|x47.20|y35.00 -- Isle of Quel'Danas/0, Tradesman Portanuus
		25036=sB|m1957|x51.10|y33.59 -- Isle of Quel'Danas/0, Caregiver Inaara
		25032=sB|m1957|x47.20|y30.60 -- Isle of Quel'Danas/0, Eldara Dawnrunner
		--12944=sB|m9002|x50.50|y59.00
		--14322=sB|m9005|x61.20|y69.20 -- Dire Maul/0, 
		--14371=sB|m9005|x81.80|y25.50 -- Dire Maul/0, 
		29587=sB|m23|x84|y49.8 -- Eastern Plaguelands/0, Dread Commander Thalanor		
		
		35826=sB|m127|x34.00|y35.50 -- ??, Kaye Toogie
		28692=sB|m125|x53.00|y69.80 -- Dalaran, "Red" Jack Findle
		28989=sB|m125|x60.50|y52.20 -- Dalaran, Aemara
		28993=sB|m125|x56.85|y53.27 -- Dalaran, Aerith Primrose
		29512=sB|m125|x36.54|y33.64 -- Dalaran, Ainderu Summerleaf
		29532=sB|m125|x34.70|y56.09 -- Dalaran, Ajay Green
		29535=sB|m125|x62.50|y13.09 -- Dalaran, Alchemist Cinesra
		32631=sB|m125|x23.60|y38.20 -- Dalaran, Alfred Copperworth
		28687=sB|m125|x50.00|y39.40 -- Dalaran, Amisi Azuregaze
		29628=sB|m125|x37.00|y37.50 -- Dalaran, Angelique Butler
		28707=sB|m125|x41.65|y62.80 -- Dalaran, Angelo Pescatore
		28990=sB|m125|x46.67|y27.64 -- Dalaran, Anthony Durain
		29547=sB|m125|x42.59|y55.50 -- Dalaran, Applebough
		32287=sB|m125|x25.55|y47.64 -- Dalaran, Archmage Alvareaux
		29049=sB|m125|x48.48|y38.21 -- Dalaran, Arille Azuregaze
		29499=sB|m125|x54.00|y61.40 -- Dalaran, Bartram Haller
		30885=sB|m125|x59.55|y57.50 -- Dalaran, Blazik Fireclaw
		32515=sB|m125|x36.59|y29.65 -- Dalaran, Braeg Stoutbeard
		29523=sB|m125|x51.00|y71.59 -- Dalaran, Bragund Brightlink
		28951=sB|m125|x58.52|y39.52 -- Dalaran, Breanni
		28722=sB|m125|x39.00|y25.00 -- Dalaran, Bryan Landers
		29702=sB|m125|x44.65|y46.35 -- Dalaran, Chameli Banaphash
		32337=sB|m125|x53.80|y32.40 -- Dalaran, Christi Stockton
		29716=sB|m125|x44.50|y46.10 -- Dalaran, Clockwork Assistant
		29476=sB|m125|x59.75|y52.20 -- Dalaran, Dagna Flintlock
		29537=sB|m125|x63.59|y16.20 -- Dalaran, Darahir
		29528=sB|m125|x49.20|y54.30 -- Dalaran, Debbi Moore
		28726=sB|m125|x36.50|y33.57 -- Dalaran, Dominique Stefano
		28728=sB|m125|x41.00|y25.30 -- Dalaran, Dorian Fines
		34252=sB|m125|x46.45|y27.60 -- Dalaran, Dubin Clay
		28727=sB|m125|x43.62|y34.59 -- Dalaran, Edward Egan
		28776=sB|m125|x51.67|y55.44 -- Dalaran, Elizabeth Ross
		28715=sB|m125|x38.60|y55.90 -- Dalaran, Endora Moorehead
		29715=sB|m125|x52.82|y34.78 -- Dalaran, Fialla Sweetberry
		28997=sB|m125|x46.65|y27.57 -- Dalaran, Griselda Hunderland
		29636=sB|m125|x37.70|y55.40 -- Dalaran, Hagatha Moorehead
		32172=sB|m125|x39.85|y34.49 -- Dalaran, Harold Winston
		29538=sB|m125|x60.55|y11.65 -- Dalaran, Hexil Garrot
		35498=sB|m125|x46.50|y27.00 -- Dalaran, Horace Hunderland
		28714=sB|m125|x39.54|y41.32 -- Dalaran, Ildine Sorrowspear
		29478=sB|m125|x44.34|y45.79 -- Dalaran, Jepetto Joybuzz
		33027=sB|m125|x41.80|y36.50 -- Dalaran, Jessica Sellers
		29491=sB|m125|x44.40|y49.00 -- Dalaran, Karandonna
		29496=sB|m125|x54.65|y62.40 -- Dalaran, Kerta the Bold
		29511=sB|m125|x36.50|y33.10 -- Dalaran, Lalla Brightweave
		28723=sB|m125|x41.80|y36.80 -- Dalaran, Larana Drome
		29510=sB|m125|x34.57|y34.29 -- Dalaran, Linna Bruder
		29714=sB|m125|x54.50|y30.29 -- Dalaran, Lucian Trias
		32216=sB|m125|x57.20|y41.59 -- Dalaran, Mei Francis
		28685=sB|m125|x35.40|y55.00 -- Dalaran, Narisa Redgold
		32334=sB|m125|x45.80|y39.20 -- Dalaran, Nixi Fireclaw
		29495=sB|m125|x44.65|y48.70 -- Dalaran, Norvin Alderman
		29527=sB|m125|x51.70|y54.85 -- Dalaran, Orton Bennet
		28995=sB|m125|x43.50|y50.35 -- Dalaran, Paldesse
		28716=sB|m125|x45.65|y28.57 -- Dalaran, Palja Amboss
		28725=sB|m125|x41.80|y31.60 -- Dalaran, Patricia Egan
		35497=sB|m125|x50.70|y70.59 -- Dalaran, Rafael Langrom
		28718=sB|m125|x36.57|y29.28 -- Dalaran, Ranid Glowergold
		32403=sB|m125|x48.20|y39.62 -- Dalaran, Sandra Bartan
		33026=sB|m125|x44.50|y45.40 -- Dalaran, Sarah Brady
		29703=sB|m125|x45.00|y47.60 -- Dalaran, Sheddle Glossgleam
		29494=sB|m125|x49.00|y71.50 -- Dalaran, Shen Kang Cheng
		28691=sB|m125|x52.65|y69.50 -- Dalaran, Susana Averoy
		28690=sB|m125|x59.55|y37.62 -- Dalaran, Tassia Whisperglen
		28721=sB|m125|x40.50|y34.54 -- Dalaran, Tiffany Cartier
		28701=sB|m125|x40.50|y35.10 -- Dalaran, Timothy Jones
		28991=sB|m125|x54.52|y62.59 -- Dalaran, Valaden Silverblade
		28992=sB|m125|x51.50|y72.27 -- Dalaran, Valerie Langrom
		32514=sB|m125|x38.79|y40.59 -- Dalaran, Vanessa Sellers
		29497=sB|m125|x55.34|y64.20 -- Dalaran, Walther Whiteford
		28994=sB|m125|x49.10|y72.80 -- Dalaran, Abra Cadabra
		29261=sB|m125|x44.50|y56.40 -- Dalaran, Windle Sparkshine
		29548=sB|m125|x51.20|y29.10 -- Dalaran, Aimee
		40160=sB|m125|x40.00|y28.30 -- ??, Frozo the Renowned
		28742=sB|m125|x30.40|y43.80 -- Dalaran, Marcia Chase
		35500=sB|m125|x52.20|y72.70 -- Dalaran, Matilda Brightlink
		35496=sB|m125|x43.70|y48.60 -- Dalaran, Rueben Lauren
		--37687=sB|m186|x36.54|y20.55 -- Icecrown Citadel/1,Alchemist Finklestein
		--37688=sB|m186|x38.20|y21.50 -- Icecrown Citadel/1,Crusader Grimtong
		--37696=sB|m186|x37.65|y21.50 -- Icecrown Citadel/1,Crusader Halford
		--38858=sB|m186|x36.20|y20.60 -- Icecrown Citadel/1,Goodman the "Closer"
		--38316=sB|m186|x40.00|y21.50 -- Icecrown Citadel/1,Ormus the Penitent
		--38054=sB|m186|x36.20|y20.60 -- Icecrown Citadel/1,Scott the Merciful
		
		15909=sB|m80|x53.7|y35.5 -- Moonglade/0, Fariel Starsong
		15864=sB|m80|x53.5|y35.29 -- Moonglade/0, Valadar Starsong
		29203=sB|m124|x48.60|y32.60 -- Plaguelands: The Scarlet Enclave/0, Alchemist Karloff
		29205=sB|m124|x48.00|y32.00 -- Plaguelands: The Scarlet Enclave/0, Corpulous
		29208=sB|m124|x48.20|y32.50 -- Plaguelands: The Scarlet Enclave/0, Fester
		28943=sB|m124|x54.55|y57.52 -- Plaguelands: The Scarlet Enclave/0, Fineous
		29207=sB|m124|x48.40|y33.00 -- Plaguelands: The Scarlet Enclave/0, Gangrenus
		28760=sB|m124|x52.80|y35.00 -- Plaguelands: The Scarlet Enclave/0, Hargus the Gimp
		28500=sB|m124|x50.40|y29.20 -- Plaguelands: The Scarlet Enclave/0, Master Siegesmith Corvus
		28512=sB|m124|x48.80|y32.20 -- ??, Quartermaster Ozorg
		--33630=sB|m111|x38.44|y71.69 -- Shattrath City/0,Aelthin
		33674=sB|m111|x38.6|y30 -- Shattrath City/0, Alchemist Kanhu
		--33631=sB|m111|x43.30|y64.79 -- Shattrath City/0,Barien
		--33639=sB|m111|x38.20|y71.40 -- Shattrath City/0,Botanist Alaenra
		--33635=sB|m111|x41.65|y63.40 -- Shattrath City/0,Daenril
		33683=sB|m111|x37.2|y27.2 -- Shattrath City/0, Dremm
		33633=sB|m111|x55.6|y74.6 -- Shattrath City/0, Enchantress Andiala
		--33634=sB|m111|x43.40|y64.90 -- Shattrath City/0,Engineer Sinbei
		--33682=sB|m111|x36.00|y48.50 -- Shattrath City/0,Fono
		33640=sB|m111|x58.6|y75.2 -- Shattrath City/0, Hanlir
		--33641=sB|m111|x40.80|y63.40 -- Shattrath City/0,Irduil
		33678=sB|m111|x38.2|y30 -- Shattrath City/0, Jijia
		33637=sB|m111|x58|y74.8 -- Shattrath City/0, Kirembri Silvermane
		33681=sB|m111|x37.5|y27.7 -- Shattrath City/0, Korim
		--33636=sB|m111|x41.65|y63.52 -- Shattrath City/0,Miralisse
		--33680=sB|m111|x36.10|y47.30 -- Shattrath City/0,Nemiha
		33675=sB|m111|x37.6|y31.2 -- Shattrath City/0, Onodo
		--33679=sB|m111|x36.20|y44.20 -- Shattrath City/0,Recorder Lidio
		33638=sB|m111|x56|y74.2 -- Shattrath City/0, Scribe Lanloer
		33677=sB|m111|x37.6|y31.8 -- Shattrath City/0, Technician Mihila
		33684=sB|m111|x37.6|y27.2 -- Shattrath City/0, Weaver Aoa
		--33676=sB|m111|x36.40|y44.50 -- Shattrath City/0,Zurii
		--31022=sB|m130|x61.50|y35.04 -- The Culling of Stratholme/1,George Goodman
		--31027=sB|m130|x50.40|y58.39 -- The Culling of Stratholme/1,Leeka Turner
		--31024=sB|m130|x83.60|y59.40 -- The Culling of Stratholme/1/0,Brock Thriss
		--31017=sB|m130|x85.55|y60.55 -- The Culling of Stratholme/1/0,Mal Corricks
		--33669=sB|m147|x54.00|y87.20 -- Ulduar/1/0,Demolisher Engineer Blastwrench
		--34382=sB|m27|x61.00|y36.80 -- Dun Morogh/0/0,Chapman
	]],
	["VendorFood"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		277=sA|m1453|x60.02|y76.86|wHe walks around inside the building -- Stormwind City/0, Roberto Pupellyverbos (Checked 8/24/2022)
		483=sA|m1453|x66.55|y73.36|wInside the building -- Stormwind City/0, Elaine Trias (Checked 8/24/2022)
		1301=sA|m1453|x59.92|y77.69|wInside the building -- Stormwind City/0, Julia Gallina (Checked 8/24/2022)
		1305=sA|m1453|x41.96|y82.71|wInside the building -- Stormwind City/0, Jarel Moor (Checked 8/24/2022)
		1311=sA|m1453|x51.44|y94.11|wInside the building -- Stormwind City/0, Joachim Brenlow (Checked 8/24/2022)
		1328=sA|m1453|x76.33|y53.85|wShe walks around inside the building -- Stormwind City/0, Elly Langston (Checked 8/24/2022)
		--3518=sA|m1453|x67.90|y72.17 -- Stormwind City/0, Thomas Miller (Checked 8/24/2022) (Wandering NPC, exclude)
		4981=sA|m1453|x66.35|y73.50|wInside the building -- Stormwind City/0, Ben Trias (Checked 8/24/2022)
		6740=sA|m1453|x60.38|y75.27|wInside the building -- Stormwind City/0, Innkeeper Allison (Checked 8/24/2022)
		295=sA|m1429|x43.77|y65.8 -- Elwynn Forest/0, Innkeeper Farley
		465=sA|m1429|x43.99|y65.68 -- Elwynn Forest/0, Barkeep Dobbins
		955=sA|m1429|x24.08|y73.19 -- Elwynn Forest/0, Sergeant De Vries
		3935=sA|m1429|x44.23|y65.96 -- Elwynn Forest/0, Toddrick
		3937=sA|m1429|x32.94|y51.32 -- Elwynn Forest/0, Kira Songshine
		233=sA|m1436|x56.04|y31.23 -- Westfall/0, Farmer Saldean
		274=sA|m1431|x73.66|y44.03 -- Duskwood/0, Barkeep Hann
		734=sA|m1434|x37.95|y2.98 -- Stranglethorn Vale/0, Corporal Bluth
		1247=sA|m1426|x47.37|y52.52 -- Dun Morogh/0, Innkeeper Belm
		1464=sA|m1437|x10.69|y60.95 -- Wetlands/0, Innkeeper Helbrek
		1670=sA|m1436|x57.75|y53.71 -- Westfall/0, Mike Miller
		1671=sA|m1433|x21.07|y46.24 -- Redridge Mountains/0, Lamar Veisilli
		1678=sA|m1433|x27.49|y47.83 -- Redridge Mountains/0, Vernon Hale
		1684=sA|m1432|x40.27|y39.28 -- Loch Modan/0, Khara Deepwater
		2303=sA|m1452|x51.95|y29.28 -- Winterspring/0, Lyranne Feathersong
		2352=sA|m1424|x51.16|y58.92 -- Hillsbrad Foothills/0, Innkeeper Anderson
		2364=sA|m1424|x51.12|y59.24 -- Hillsbrad Foothills/0, Neema
		2365=sA|m1424|x48.74|y57.2 -- Hillsbrad Foothills/0, Bront Coldcleave
		2366=sA|m1424|x51.56|y58.56 -- Hillsbrad Foothills/0, Barkeep Kelly
		2803=sA|m1448|x62.32|y25.64 -- Felwood/0, Malygen
		2814=sA|m1417|x45.54|y47.6 -- Arathi Highlands/0, Narj Deepslice
		3086=sA|m1433|x22.84|y44.25 -- Redridge Mountains/0, Gretchen Vogel
		3089=sA|m1433|x26.73|y43.23 -- Redridge Mountains/0, Sherman Femmel
		3138=sA|m1431|x75.82|y48.7 -- Duskwood/0, Scott Carevin
		3178=sA|m1437|x8.0|y58.32 -- Wetlands/0, Stuart Fleming
		3298=sA|m1428|x84.23|y67.78 -- Burning Steppes/0, Gabrielle Chase
		3540=sA|m1424|x49.85|y62.41 -- Hillsbrad Foothills/0, Hal McAllister
		3546=sA|m1419|x63.51|y17.01 -- Blasted Lands/0, Bernie Heisten
		3577=sA|m1421|x62.61|y65.05 -- Silverpine Forest/0, Dalaran Brewmaster
		3948=sA|m1432|x35.32|y49.73 -- Loch Modan/0, Honni Goldenoat
		3959=sA|m1440|x37.14|y49.9 -- Ashenvale/0, Nantar
		3960=sA|m1440|x50.0|y66.64 -- Ashenvale/0, Ulthaan
		3961=sA|m1440|x36.62|y49.97 -- Ashenvale/0, Maliynn
		4084=sA|m1442|x35.48|y6.16 -- Stonetalon Mountains/0, Chylina
		4167=sA|m1457|x33.62|y15.91 -- Darnassus/0, Dendrythis
		4169=sA|m1457|x64.54|y71.65 -- Darnassus/0, Jaeana
		4181=sA|m1457|x69.35|y45.01 -- Darnassus/0, Fyrenna
		4190=sA|m1439|x36.9|y44.59 -- Darkshore/0, Kyndri
		4191=sA|m1439|x37.11|y43.61 -- Darkshore/0, Allyndia
		4192=sA|m1439|x36.83|y43.9 -- Darkshore/0, Taldan
		4195=sA|m1439|x43.68|y76.63 -- Darkshore/0, Tiyani
		4200=sA|m1439|x36.76|y44.28 -- Darkshore/0, Laird
		4221=sA|m1457|x47.46|y57.44 -- Darnassus/0, Talaelar
		4255=sA|m1459|x43.04|y17.63 -- ??, Brogus Thunderbrew
		4266=sA|m1438|x55.38|y57.19 -- Teldrassil/0, Danlyia
		4305=sA|m1436|x36.22|y90.18 -- Westfall/0, Kriggon Talsone
		4307=sA|m1439|x36.97|y56.35 -- Darkshore/0, Heldan Galesong
		4891=sA|m1445|x68.17|y47.34 -- Dustwallow Marsh/0, Dwane Wertle
		4893=sA|m1445|x66.67|y45.21 -- Dustwallow Marsh/0, Bartender Lillian
		4894=sA|m1445|x66.89|y45.25 -- Dustwallow Marsh/0, Craig Nollward
		5109=sA|m1455|x29.6|y67.45 -- Ironforge/0, Myra Tyrngaarde
		5111=sA|m1455|x18.15|y51.44 -- Ironforge/0, Innkeeper Firebrew
		5112=sA|m1455|x18.63|y51.76 -- Ironforge/0, Gwenna Firebrew
		5124=sA|m1455|x57.65|y78.76 -- Ironforge/0, Sognar Cliffbeard
		5140=sA|m1455|x72.24|y75.79 -- Ironforge/0, Edris Barleybeard
		5570=sA|m1455|x72.52|y76.94 -- Ironforge/0, Bruuk Barleybeard
		5620=sA|m1433|x26.71|y43.91 -- Redridge Mountains/0, Bartender Wental
		6091=sA|m1438|x59.6|y40.69 -- Teldrassil/0, Dellylah
		6272=sA|m1445|x66.58|y45.22 -- Dustwallow Marsh/0, Innkeeper Janene
		6727=sA|m1433|x27.0|y44.82 -- Redridge Mountains/0, Innkeeper Brianna
		6734=sA|m1432|x35.53|y48.4 -- Loch Modan/0, Innkeeper Hearthstove
		6735=sA|m1457|x67.42|y15.64 -- Darnassus/0, Innkeeper Saelienne
		6736=sA|m1438|x55.61|y59.78 -- Teldrassil/0, Innkeeper Keldamyr
		6737=sA|m1439|x37.04|y44.12 -- Darkshore/0, Innkeeper Shaussiy
		6738=sA|m1440|x36.98|y49.21 -- Ashenvale/0, Innkeeper Kimlya
		6790=sA|m1431|x73.87|y44.4 -- Duskwood/0, Innkeeper Trelayne
		7736=sA|m1444|x30.96|y43.48 -- Feralas/0, Innkeeper Shyria
		7941=sA|m1444|x31.04|y43.11 -- Feralas/0, Mardrack Greenwell
		7943=sA|m1444|x31.02|y46.25 -- Feralas/0, Harklane
		7978=sA|m1455|x26.84|y27.74 -- Ironforge/0, Bimble Longberry
		8150=sA|m1443|x66.19|y6.57 -- Desolace/0, Janet Hommers
		8931=sA|m1436|x52.86|y53.71 -- Westfall/0, Innkeeper Heather
		9099=sA|m1455|x49.31|y31.1 -- Ironforge/0, Sraaz
		11103=sA|m1443|x66.27|y6.55 -- Desolace/0, Innkeeper Lyshaerya
		12096=sA|m1459|x43.12|y17.62 -- ??, Stormpike Quartermaster
		16458=sA|m1442|x35.78|y5.73 -- Stonetalon Mountains/0, Innkeeper Faralia
		23481=sA|m1426|x56.00|y36.40 -- Dun Morogh/0, Keiran Donoghue
		23525=sA|m1426|x55.20|y37.50 -- Dun Morogh/0, Brother Cartwright
		23521=sA|m1426|x46.00|y60.20 -- Dun Morogh/0, Anne Summers
		23522=sA|m1426|x55.50|y38.00 -- Dun Morogh/0, Arlen Lochlan
		24834=sA|m1437|x1.60|y59.00 -- ??, Galley Chief Grace
		23896=sA|m1445|x69.20|y51.80 -- Dustwallow Marsh/0, "Dirty" Michael Crowe
		19451=sA|m1944|x87.62|y53.55 -- Hellfire Peninsula/0, Quartermaster Gorman
		18251=sA|m1946|x67.14|y49.03 -- Zangarmarsh/0, Caregiver Abidaar
		18908=sA|m1946|x41.85|y26.22 -- Zangarmarsh/0, Innkeeper Kerp
		19352=sA|m1948|x37.06|y58.26 -- Shadowmoon Valley/0, Dreg Cloudsweeper
		19495=sA|m1949|x35.80|y63.88 -- Blade's Edge Mountains/0, Innkeeper Shaunessy
		21110=sA|m1949|x60.98|y68.11 -- Blade's Edge Mountains/0, Fizit "Doc" Clocktock
		21487=sA|m1951|x42.00|y43.00 -- Nagrand/0, Cendrii
		18914=sA|m1951|x54.22|y76.10 -- Nagrand/0, Caregiver Isel
		19296=sA|m1952|x56.70|y53.27 -- Terokkar Forest/0, Innkeeper Biribi
		19038=sA|m1952|x55.73|y53.04 -- Terokkar Forest/0, Supply Officer Mills
		-- HORDE --
		982=sH|m1435|x46.52|y54.28 -- Swamp of Sorrows/0, Thultash
		2388=sH|m1424|x62.77|y19.02 -- Hillsbrad Foothills/0, Innkeeper Shay
		2806=sH|m1448|x34.75|y53.22 -- Felwood/0, Bale
		3003=sH|m1456|x41.43|y53.19 -- Thunder Bluff/0, Fyr Mistrunner
		3017=sH|m1456|x47.33|y42.49 -- Thunder Bluff/0, Nan Mistrunner
		3025=sH|m1456|x52.3|y47.78 -- Thunder Bluff/0, Kaga Mistrunner
		3312=sH|m1454|x44.67|y70.01 -- Orgrimmar/0, Olvia
		3329=sH|m1454|x48.96|y54.21 -- Orgrimmar/0, Kor'jus
		3342=sH|m1454|x37.41|y52.32 -- Orgrimmar/0, Shan'ti
		3368=sH|m1454|x57.2|y53.32 -- Orgrimmar/0, Borstan
		3411=sH|m1442|x73.58|y95.35 -- Stonetalon Mountains/0, Denni'ka
		3480=sH|m1413|x52.37|y30.54 -- The Barrens/0, Moorane Hearthgrain
		3489=sH|m1413|x52.62|y29.84 -- The Barrens/0, Zargh
		3544=sH|m1424|x61.48|y20.07 -- Hillsbrad Foothills/0, Jason Lemieux
		3547=sH|m1420|x59.52|y51.62 -- Tirisfal Glades/0, Hamlin Atkins
		3621=sH|m1447|x21.81|y52.1 -- Azshara/0, Kurll
		3689=sH|m1441|x21.06|y31.86 -- Thousand Needles/0, Laer Stepperunner
		3705=sH|m1413|x44.74|y59.42 -- The Barrens/0, Gahroot
		3708=sH|m1428|x65.7|y23.91 -- Burning Steppes/0, Gruna
		3881=sH|m1411|x51.12|y42.62 -- Durotar/0, Grimtak
		3882=sH|m1411|x42.64|y67.19 -- Durotar/0, Zlagk
		3883=sH|m1412|x44.64|y77.89 -- Mulgore/0, Moodan Sungrain
		3884=sH|m1412|x47.63|y61.49 -- Mulgore/0, Jhawna Oatwind
		3933=sH|m1411|x55.62|y73.61 -- Durotar/0, Hai'zan
		3934=sH|m1413|x51.98|y29.89 -- The Barrens/0, Innkeeper Boorand Plainswind
		4554=sH|m1458|x63.52|y39.94 -- Undercity/0, Tawny Grisette
		4555=sH|m1458|x69.16|y48.92 -- Undercity/0, Eleanor Rusk
		4571=sH|m1458|x76.62|y29.3 -- Undercity/0, Morley Bates
		4875=sH|m1441|x45.43|y51.16 -- Thousand Needles/0, Turhaw
		4879=sH|m1445|x36.7|y30.97 -- Dustwallow Marsh/0, Ogg'marr
		4954=sH|m1417|x74.18|y33.95 -- Arathi Highlands/0, Uttnar
		5611=sH|m1454|x54.64|y67.67 -- Orgrimmar/0, Barkeep Morag
		5688=sH|m1420|x61.7|y52.04 -- Tirisfal Glades/0, Innkeeper Renee
		5814=sH|m1434|x31.48|y29.75 -- Stranglethorn Vale/0, Innkeeper Thulbek
		5870=sH|m1442|x46.22|y58.36 -- Stonetalon Mountains/0, Krond
		5871=sH|m1413|x51.95|y29.68 -- The Barrens/0, Larhka
		5886=sH|m1421|x44.04|y39.77 -- Silverpine Forest/0, Gwyn Farrow
		6739=sH|m1421|x43.17|y41.27 -- Silverpine Forest/0, Innkeeper Bates
		6741=sH|m1458|x67.73|y37.89 -- Undercity/0, Innkeeper Norman
		6746=sH|m1456|x45.81|y64.71 -- Thunder Bluff/0, Innkeeper Pala
		6747=sH|m1412|x46.62|y61.09 -- Mulgore/0, Innkeeper Kauth
		6928=sH|m1411|x51.51|y41.64 -- Durotar/0, Innkeeper Grosk
		6929=sH|m1454|x54.09|y68.4 -- Orgrimmar/0, Innkeeper Gryshka
		6930=sH|m1435|x45.16|y56.66 -- Swamp of Sorrows/0, Innkeeper Karakul
		7485=sH|m1434|x32.19|y29.27 -- Stranglethorn Vale/0, Nargatt
		7714=sH|m1413|x45.57|y59.03 -- The Barrens/0, Innkeeper Byula
		7731=sH|m1442|x47.46|y62.12 -- Stonetalon Mountains/0, Innkeeper Jayka
		7737=sH|m1444|x74.8|y45.18 -- Feralas/0, Innkeeper Greul
		8143=sH|m1444|x75.5|y43.88 -- Feralas/0, Loorana
		8152=sH|m1443|x51.2|y53.26 -- Desolace/0, Harnor
		8307=sH|m1413|x55.15|y32.08 -- The Barrens/0, Tarban Hearthgrain
		9356=sH|m1418|x2.81|y45.85 -- Badlands/0, Innkeeper Shul'kar
		9501=sH|m1417|x73.84|y32.46 -- Arathi Highlands/0, Innkeeper Adegwa
		10367=sH|m1459|x48.53|y80.47 -- ??, Shrye Ragefist
		11106=sH|m1443|x24.09|y68.21 -- Desolace/0, Innkeeper Sikewa
		11116=sH|m1441|x46.07|y51.51 -- Thousand Needles/0, Innkeeper Abeqwa
		12097=sH|m1459|x46.62|y84.21 -- ??, Frostwolf Quartermaster
		12196=sH|m1440|x73.99|y60.64 -- Ashenvale/0, Innkeeper Kaylisk
		12962=sH|m1440|x11.7|y34.09 -- Ashenvale/0, Wik'Tar
		14731=sH|m1425|x78.14|y81.37 -- The Hinterlands/0, Lard
		24208=sH|m1445|x36.80|y32.20 -- Dustwallow Marsh/0, "Little" Logok
		15433=sH|m1941|x48.00|y47.60 -- Eversong Woods/0, Innkeeper Delaniel
		16602=sH|m1944|x56.71|y37.47 -- Hellfire Peninsula/0, Floyd Pinkus
		19315=sH|m1944|x65.81|y43.56 -- Hellfire Peninsula/0, Supply Officer Isabel
		17277=sH|m1944|x28.24|y60.84 -- Hellfire Peninsula/0, Provisioner Valine
		18905=sH|m1944|x26.88|y59.54 -- Hellfire Peninsula/0, Innkeeper Bazil Olof'tazun
		16585=sH|m1944|x54.61|y41.21 -- Hellfire Peninsula/0, Cookie One-Eye
		19559=sH|m1944|x61.74|y81.32 -- Hellfire Peninsula/0, Mondul
		19435=sH|m1944|x88.25|y47.09 -- Hellfire Peninsula/0, Dark Cleric Malod
		18245=sH|m1946|x30.66|y50.93 -- Zangarmarsh/0, Merajit
		21088=sH|m1949|x76.09|y60.31 -- Blade's Edge Mountains/0, Matron Varah
		21084=sH|m1949|x75.96|y60.14 -- Blade's Edge Mountains/0, Braagor
		18913=sH|m1951|x56.73|y34.51 -- Nagrand/0, Matron Tikkit
		20097=sH|m1951|x58.13|y35.67 -- Nagrand/0, Nula the Butcher
		18957=sH|m1952|x48.76|y45.05 -- Terokkar Forest/0, Innkeeper Grilka
		17630=sH|m1954|x67.59|y72.80 -- Silvermoon City/0, Innkeeper Jovia
		16618=sH|m1954|x79.60|y58.40 -- Silvermoon City/0, Innkeeper Velandra
		16442=sH|m1954|x79.55|y58.50 -- Silvermoon City/0, Vinemaster Suntouched
		-- NEUTRAL --
		14844=sB|m1429|x42.00|y70.00 -- Terokkar Forest/0, Sylannia
		14845=sB|m1429|x42.00|y70.00 -- Terokkar Forest/0, Stamp Thunderhorn
		2832=sB|m1434|x27.03|y77.17 -- Stranglethorn Vale/0, Nixxrax Fillamug
		2842=sB|m1434|x28.0|y76.98 -- Stranglethorn Vale/0, Wigcik
		3497=sB|m1413|x62.76|y38.24 -- The Barrens/0, Kilxx
		4782=sB|m1425|x14.36|y42.3 -- The Hinterlands/0, Truk Wildbeard
		6495=sB|m1441|x80.44|y76.46 -- Thousand Needles/0, Riznek
		6496=sB|m1441|x77.31|y77.01 -- Thousand Needles/0, Brivelthwerp
		6791=sB|m1413|x62.04|y39.4 -- The Barrens/0, Innkeeper Wiley
		6807=sB|m1434|x27.03|y77.31 -- Stranglethorn Vale/0, Innkeeper Skindle
		7733=sB|m1446|x52.5|y27.91 -- Tanaris/0, Innkeeper Fizzgrimble
		7744=sB|m1425|x14.14|y41.56 -- The Hinterlands/0, Innkeeper Thulfram
		8125=sB|m1446|x52.63|y28.11 -- Tanaris/0, Dirge Quikcleave
		8137=sB|m1446|x66.63|y22.07 -- Tanaris/0, Gikkix
		11038=sB|m1423|x79.54|y63.85 -- Eastern Plaguelands/0, Caretaker Alen
		11118=sB|m1452|x61.35|y38.83 -- Winterspring/0, Innkeeper Vizzie
		11187=sB|m1452|x61.32|y39.16 -- Winterspring/0, Himmik
		12019=sB|m1450|x48.87|y39.16 -- Moonglade/0, Dargon
		12026=sB|m1450|x44.51|y33.88 -- Moonglade/0, My'lanna
		12959=sB|m1449|x43.27|y7.73 -- Un'Goro Crater/0, Nergal
		14624=sB|m1427|x38.8|y28.5 -- Searing Gorge/0, Master Smith Burninate
		14961=sB|m1416|x40.05|y80.15 -- Alterac Mountains/0, Mirvyna Jinglepocket
		14962=sB|m1416|x62.0|y58.56 -- Alterac Mountains/0, Dillord Copperpinch
		14963=sB|m1440|x62.07|y82.84 -- Ashenvale/0, Gapp Jinglepocket
		14964=sB|m1413|x46.73|y8.31 -- The Barrens/0, Hecht Copperpinch
		15124=sB|m1417|x46.47|y45.33 -- Arathi Highlands/0, Targot Jinglepocket
		15125=sB|m1417|x74.2|y29.28 -- Arathi Highlands/0, Kosco Copperpinch
		15174=sB|m1451|x51.89|y39.16 -- Silithus/0, Calandrath
		16256=sB|m1423|x81.62|y58.07 -- Eastern Plaguelands/0, Jessica Chambers
		24934=sB|m1434|x36.80|y52.60 -- ??, Snack-O-Matic IV
		23995=sB|m1445|x41.80|y74.00 -- Dustwallow Marsh/0, Axle
		23573=sB|m1445|x41.80|y73.00 -- Dustwallow Marsh/0, Krixil Slogswitch
		20080=sB|m1446|x63.80|y57.80 -- Tanaris/0, Galgrom
		21746=sB|m1948|x61.12|y28.24 -- Shadowmoon Valley/0, Caretaker Aluuro
		21744=sB|m1948|x56.32|y59.84 -- Shadowmoon Valley/0, Roldemar
		19518=sB|m1948|x55.87|y58.41 -- Shadowmoon Valley/0, Feranin
		--23143=sB|m1948|x66.20|y87.00 --Not visible -- Shadowmoon Valley/0, 
		19528=sB|m1948|x62.50|y28.23 -- Shadowmoon Valley/0, Nanomah
		22266=sB|m1949|x27.82|y58.23 -- Blade's Edge Mountains/0, Ogri'la Grubgiver
		23110=sB|m1949|x27.87|y57.62 -- Blade's Edge Mountains/0, Ogri'la Keg King
		19718=sB|m1952|x39.73|y70.09 -- Terokkar Forest/0, Provisioner Tsaalt
		20986=sB|m1952|x39.45|y70.05 -- Terokkar Forest/0, Dealer Tariq
		19679=sB|m1952|x39.23|y58.82 -- Terokkar Forest/0, "Slim"
		20893=sB|m1952|x37.72|y51.22 -- Terokkar Forest/0, Morula
		19572=sB|m1953|x32.77|y64.11 -- Netherstorm/0, Gant
		19617=sB|m1953|x32.27|y63.92 -- Netherstorm/0, Boots
		19531=sB|m1953|x43.36|y36.14 -- Netherstorm/0, Eyonix
		23699=sB|m1955|x70.00|y55.00 -- Shattrath City/0, Kevin Browning
		23263=sB|m1955|x60.90|y69.50 -- Shattrath City/0, Brendan Turner
		19664=sB|m1955|x61.40|y69.40 -- Shattrath City/0, Muffin Man Moser
		19045=sB|m1955|x58.20|y15.70 -- Shattrath City/0, Oloraak
		19182=sB|m1955|x75.00|y33.50 -- Shattrath City/0, Shaarubo
		19186=sB|m1955|x74.80|y32.20 -- Shattrath City/0, Kylene
		19050=sB|m1955|x27.40|y49.80 -- Shattrath City/0, Garul
		19223=sB|m1955|x64.00|y68.60 -- Shattrath City/0, Granny Smith
		19232=sB|m1955|x56.20|y81.59 -- Shattrath City/0, Innkeeper Haelthol
	]],
	["VendorPoison"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		1457=sA|m1437|x10.49|y60.2 -- Wetlands/0, Samor Festivus
		3090=sA|m1433|x25.1|y41.12 -- Redridge Mountains/0, Gerald Crawley
		3135=sA|m1431|x79.47|y44.37 -- Duskwood/0, Malissa
		3542=sA|m1424|x50.82|y59.02 -- Hillsbrad Foothills/0, Jaysin Lanyda
		3561=sA|m1457|x32.53|y19.72 -- Darnassus/0, Kyrai
		3969=sA|m1440|x36.49|y49.45 -- Ashenvale/0, Fahran Silentblade
		5139=sA|m1459|x42.79|y16.55 -- ??, Kurdrum Barleybeard
		5169=sA|m1455|x52.95|y13.71 -- Ironforge/0, Tynnus Venomsprout
		12096=sA|m1459|x43.12|y17.62 -- ??, Stormpike Quartermaster
		18019=sA|m1946|x41.22|y28.67 -- Zangarmarsh/0, Timothy Daniels
		19014=sA|m1951|x55.27|y69.48 -- Nagrand/0, Ogir
		-- HORDE --
		3334=sH|m1454|x42.08|y49.47 -- Orgrimmar/0, Rekkul
		3490=sH|m1413|x51.39|y30.2 -- The Barrens/0, Hula'mahi
		3551=sH|m1421|x42.9|y41.8 -- Silverpine Forest/0, Patrice Dwyer
		4585=sH|m1458|x75.2|y51.17 -- Undercity/0, Ezekiel Graves
		10364=sH|m1459|x48.36|y80.32 -- ??, Yaelika Farclaw
		12097=sH|m1459|x46.62|y84.21 -- ??, Frostwolf Quartermaster
		16588=sH|m1944|x52.28|y36.46 -- Hellfire Peninsula/0, Apothecary Antonivich
		19013=sH|m1951|x55.00|y35.74 -- Nagrand/0, Vanteg
		16683=sH|m1954|x80.20|y51.00 -- Silvermoon City/0, Darlia
		-- NEUTRAL --
		2622=sB|m1434|x28.4|y76.83 -- Stranglethorn Vale/0, Sly Garrett
		6779=sB|m1416|x86.12|y79.57 -- Alterac Mountains/0, Smudge Thunderwood
		15175=sB|m1451|x48.66|y37.0 -- Silithus/0, Khur Hornstriker
		20081=sB|m1446|x63.80|y57.50 -- Tanaris/0, Bortega
		--23145=sB|m1948|x65.80|y85.80 --Not visible -- Shadowmoon Valley/0, 
		20986=sB|m1952|x39.45|y70.05 -- Terokkar Forest/0, Dealer Tariq
		19679=sB|m1952|x39.23|y58.82 -- Terokkar Forest/0, "Slim"
		20194=sB|m1953|x46.73|y56.64 -- Netherstorm/0, Dealer Dunar
		22479=sB|m1953|x66.39|y67.30 -- Netherstorm/0, Sab'aoth
		19239=sB|m1955|x54.55|y82.52 -- Shattrath City/0, Mahir Redstroke
		19049=sB|m1955|x45.50|y19.50 -- Shattrath City/0, Karokka
		25043=sB|m1957|x51.80|y34.20 -- ??, Sereth Duskbringer
	]],
	["VendorReagent"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		1257=sA|m1453|x62.79|y75.03|wInside the building -- Stormwind City/0, Keldric Boucher (Checked 8/24/2022)
		1275=sA|m1453|x63.10|y74.93|wShe walks around inside the building -- Stormwind City/0, Kyra Boucher (Checked 8/24/2022)
		1307=sA|m1453|x44.58|y86.25|wInside the building -- Stormwind City/0, Charys Yserian (Checked 8/24/2022)
		1308=sA|m1453|x47.42|y82.46|wInside the building -- Stormwind City/0, Owen Vaughn (Checked 8/24/2022)
		958=sA|m1429|x64.88|y69.19 -- Elwynn Forest/0, Dawn Brightstar
		1463=sA|m1437|x8.34|y56.46 -- Wetlands/0, Falkan Armonis
		1673=sA|m1431|x76.28|y45.26 -- Duskwood/0, Alyssa Eva
		2805=sA|m1417|x26.96|y58.83 -- Arathi Highlands/0, Deneb Walker
		3542=sA|m1424|x50.82|y59.02 -- Hillsbrad Foothills/0, Jaysin Lanyda
		3562=sA|m1457|x34.7|y76.81 -- Darnassus/0, Alaindia
		3700=sA|m1444|x30.92|y42.09 -- Feralas/0, Jadenvis Seawatcher
		3970=sA|m1440|x34.98|y48.46 -- Ashenvale/0, Llana
		4220=sA|m1457|x33.84|y9.5 -- Darnassus/0, Cyroen
		5110=sA|m1455|x19.19|y56.1 -- Ironforge/0, Barim Jurgenstaad
		5139=sA|m1459|x42.79|y16.55 -- ??, Kurdrum Barleybeard
		5151=sA|m1455|x31.32|y27.79 -- Ironforge/0, Ginny Longberry
		12096=sA|m1459|x43.12|y17.62 -- ??, Stormpike Quartermaster
		18019=sA|m1946|x41.22|y28.67 -- Zangarmarsh/0, Timothy Daniels
		19014=sA|m1951|x55.27|y69.48 -- Nagrand/0, Ogir
		-- HORDE --
		983=sH|m1435|x45.77|y52.82 -- Swamp of Sorrows/0, Thultazor
		3323=sH|m1454|x45.44|y56.54 -- Orgrimmar/0, Horthus
		3335=sH|m1454|x45.99|y45.68 -- Orgrimmar/0, Hagrus
		3351=sH|m1454|x45.73|y40.94 -- Orgrimmar/0, Magenius
		3490=sH|m1413|x51.39|y30.2 -- The Barrens/0, Hula'mahi
		3500=sH|m1444|x74.63|y44.91 -- Feralas/0, Tarhus
		4083=sH|m1442|x47.61|y61.59 -- Stonetalon Mountains/0, Jeeda
		4562=sH|m1458|x69.69|y39.05 -- Undercity/0, Thomas Mordan
		4575=sH|m1458|x82.77|y15.83 -- Undercity/0, Hannah Akeley
		4878=sH|m1441|x45.14|y50.78 -- Thousand Needles/0, Montarr
		8361=sH|m1456|x36.38|y54.85 -- Thunder Bluff/0, Chepi
		10364=sH|m1459|x48.36|y80.32 -- ??, Yaelika Farclaw
		12097=sH|m1459|x46.62|y84.21 -- ??, Frostwolf Quartermaster
		13476=sH|m1445|x36.48|y30.35 -- Dustwallow Marsh/0, Balai Lok'Wein
		14739=sH|m1425|x78.8|y78.24 -- The Hinterlands/0, Mystic Yayo'jin
		16588=sH|m1944|x52.28|y36.46 -- Hellfire Peninsula/0, Apothecary Antonivich
		18998=sH|m1944|x28.06|y61.14 -- Hellfire Peninsula/0, Lursa Sunfallow
		18243=sH|m1946|x85.76|y54.01 -- Zangarmarsh/0, Lorti
		18017=sH|m1946|x32.38|y51.96 -- Zangarmarsh/0, Seer Janidi
		19013=sH|m1951|x55.00|y35.74 -- Nagrand/0, Vanteg
		16612=sH|m1954|x69.20|y66.60 -- Silvermoon City/0, Velanni
		-- NEUTRAL --
		15175=sB|m1451|x48.66|y37.0 -- Silithus/0, Khur Hornstriker
		16015=sB|m1452|x58.87|y78.39 -- Winterspring/0, Vi'el
		--23157=sB|m339|x61.70|y49.59 -- Black Temple/0, 
		24935=sB|m1434|x36.80|y52.40 -- Tirisfal Glades/0, Vend-O-Tron D-Luxe
		20081=sB|m1446|x63.80|y57.50 -- Tanaris/0, Bortega
		--23145=sB|m1948|x65.80|y85.80 --Not visible -- Shadowmoon Valley/0, 
		23112=sB|m1949|x29.15|y58.00 -- Blade's Edge Mountains/0, Mingo
		19718=sB|m1952|x39.73|y70.09 -- Terokkar Forest/0, Provisioner Tsaalt
		19679=sB|m1952|x39.23|y58.82 -- Terokkar Forest/0, "Slim"
		20092=sB|m1953|x58.35|y31.26 -- Netherstorm/0, Dealer Hazzin
		22479=sB|m1953|x66.39|y67.30 -- Netherstorm/0, Sab'aoth
		19535=sB|m1953|x43.87|y35.24 -- Netherstorm/0, Dealer Zijaad
		19678=sB|m1955|x64.50|y70.20 -- Shattrath City/0, Fantei
		25039=sB|m1957|x51.20|y32.60 -- Isle of Quel'Danas/0, Kaalif
	]],
	["VendorBullets"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		1285=sA|m1453|x64.83|y72.16|wInside the building -- Stormwind City/0, Thurman Mullby (Checked 8/24/2022)
		5510=sA|m1453|x61.98|y36.44|wInside the building -- Stormwind City/0, Thulman Flintcrag (Checked 8/24/2022)
		151=sA|m1429|x43.96|y65.91 -- Elwynn Forest/0, Brog Hamfist
		227=sA|m1431|x73.64|y45.28 -- Duskwood/0, Mabel Solaj
		491=sA|m1436|x57.0|y47.16 -- Westfall/0, Quartermaster Lewis
		791=sA|m1433|x28.76|y47.32 -- Redridge Mountains/0, Lindsay Ashlock
		1452=sA|m1437|x12.06|y57.98 -- Wetlands/0, Gruham Rumdnul
		1461=sA|m1437|x11.33|y59.58 -- Wetlands/0, Murndan Derth
		1469=sA|m1432|x35.82|y43.45 -- Loch Modan/0, Vrok Blunderblast
		1682=sA|m1432|x34.75|y48.61 -- Loch Modan/0, Yanni Stoutheart
		1686=sA|m1432|x83.15|y63.42 -- Loch Modan/0, Irene Sureshot
		1691=sA|m1426|x47.18|y52.4 -- Dun Morogh/0, Kreg Bilmn
		2084=sA|m1452|x51.45|y30.83 -- Winterspring/0, Natheril Raincaller
		2803=sA|m1448|x62.32|y25.64 -- Felwood/0, Malygen
		2808=sA|m1417|x46.44|y47.6 -- Arathi Highlands/0, Vikki Lonsav
		3088=sA|m1433|x23.83|y41.31 -- Redridge Mountains/0, Henry Chapal
		3541=sA|m1424|x49.13|y55.05 -- Hillsbrad Foothills/0, Sarah Raycroft
		3587=sA|m1438|x59.52|y40.9 -- Teldrassil/0, Lyrai
		3608=sA|m1438|x55.5|y57.14 -- Teldrassil/0, Aldia
		3962=sA|m1440|x34.84|y50.86 -- Ashenvale/0, Haljan Oakheart
		4084=sA|m1442|x35.48|y6.16 -- Stonetalon Mountains/0, Chylina
		4170=sA|m1457|x64.73|y52.96 -- Darnassus/0, Ellandrieth
		4182=sA|m1439|x37.44|y40.49 -- Darkshore/0, Dalmond
		4241=sA|m1457|x70.67|y45.37 -- Darnassus/0, Mydrannul
		4889=sA|m1445|x67.5|y47.97 -- Dustwallow Marsh/0, Torq Ironblast
		4896=sA|m1445|x67.45|y51.71 -- Dustwallow Marsh/0, Charity Mipsy
		5101=sA|m1455|x39.23|y74.46 -- Ironforge/0, Bryllia Ironbrand
		5123=sA|m1455|x72.2|y65.23 -- Ironforge/0, Bretta Goldfury
		5134=sA|m1459|x43.08|y17.48 -- ??, Jonivera Farmountain
		7942=sA|m1444|x30.64|y43.43 -- Feralas/0, Faralorn
		12960=sA|m1443|x66.61|y6.97 -- Desolace/0, Christi Galvanis
		19452=sA|m1944|x88.39|y52.32 -- Hellfire Peninsula/0, Quartermaster Drake
		19351=sA|m1948|x36.80|y54.31 -- Shadowmoon Valley/0, Daggle Ironshaper
		19374=sA|m1948|x36.18|y55.47 -- Shadowmoon Valley/0, Salle Sunforge
		19498=sA|m1949|x37.76|y66.02 -- Blade's Edge Mountains/0, Tanaide
		21111=sA|m1949|x61.25|y68.99 -- Blade's Edge Mountains/0, Bembil Knockhammer
		21488=sA|m1951|x41.60|y43.60 -- Nagrand/0, Banro
		19021=sA|m1951|x55.28|y70.52 -- Nagrand/0, Nancila
		19053=sA|m1952|x57.75|y53.48 -- Terokkar Forest/0, Fabian Lanzonelli
		-- HORDE --
		1149=sH|m1434|x31.55|y27.95 -- Stranglethorn Vale/0, Uthok
		2115=sH|m1420|x32.28|y65.44 -- Tirisfal Glades/0, Joshua Kien
		2134=sH|m1420|x61.16|y52.6 -- Tirisfal Glades/0, Mrs. Winters
		2140=sH|m1421|x43.97|y39.89 -- Silverpine Forest/0, Edwin Harly
		2401=sH|m1424|x62.55|y19.91 -- Hillsbrad Foothills/0, Kayren Soothallow
		2806=sH|m1448|x34.75|y53.22 -- Felwood/0, Bale
		2820=sH|m1417|x74.11|y32.37 -- Arathi Highlands/0, Graud
		2908=sH|m1418|x3.12|y45.93 -- Badlands/0, Grawl
		3018=sH|m1456|x55.54|y57.07 -- Thunder Bluff/0, Hogor Thunderhoof
		3072=sH|m1412|x45.29|y76.51 -- Mulgore/0, Kawnie Softbreeze
		3076=sH|m1412|x45.86|y57.66 -- Mulgore/0, Moorat Longstride
		3078=sH|m1412|x45.49|y58.47 -- Mulgore/0, Kennah Hawkseye
		3158=sH|m1411|x42.58|y67.34 -- Durotar/0, Duokna
		3164=sH|m1411|x54.39|y42.17 -- Durotar/0, Jark
		3186=sH|m1411|x56.29|y73.4 -- Durotar/0, K'waii
		3313=sH|m1454|x48.12|y80.53 -- Orgrimmar/0, Trak'gen
		3322=sH|m1454|x52.14|y62.13 -- Orgrimmar/0, Kaja
		3350=sH|m1454|x46.06|y40.86 -- Orgrimmar/0, Asoran
		3481=sH|m1413|x51.66|y29.94 -- The Barrens/0, Barg
		3625=sH|m1459|x49.87|y82.14 -- ??, Rarck
		4082=sH|m1442|x45.87|y58.66 -- Stonetalon Mountains/0, Grawnal
		4555=sH|m1458|x69.16|y48.92 -- Undercity/0, Eleanor Rusk
		4603=sH|m1458|x62.71|y26.76 -- Undercity/0, Nicholas Atwood
		4876=sH|m1441|x45.91|y51.47 -- Thousand Needles/0, Jawn Highmesa
		8362=sH|m1456|x38.91|y64.69 -- Thunder Bluff/0, Kuruk
		9548=sH|m1444|x74.93|y45.7 -- Feralas/0, Cawind Trueaim
		12027=sH|m1443|x24.92|y71.84 -- Desolace/0, Tukk
		16602=sH|m1944|x56.71|y37.47 -- Hellfire Peninsula/0, Floyd Pinkus
		19315=sH|m1944|x65.81|y43.56 -- Hellfire Peninsula/0, Supply Officer Isabel
		19560=sH|m1944|x61.42|y81.97 -- Hellfire Peninsula/0, Lukra
		19436=sH|m1944|x87.89|y48.30 -- Hellfire Peninsula/0, Supply Master Broog
		18011=sH|m1946|x85.28|y54.75 -- Zangarmarsh/0, Zurai
		21082=sH|m1949|x74.53|y61.41 -- Blade's Edge Mountains/0, Krugash
		19020=sH|m1951|x55.52|y35.95 -- Nagrand/0, Matron Qualia
		18959=sH|m1952|x50.15|y45.58 -- Terokkar Forest/0, Dod'ss
		-- NEUTRAL --
		3053=sB|m1441|x80.39|y77.0 -- Thousand Needles/0, Synge
		3498=sB|m1413|x61.92|y38.79 -- The Barrens/0, Jazzik
		8131=sB|m1446|x50.73|y27.53 -- Tanaris/0, Blizrik Buckshot
		8139=sB|m1446|x67.0|y21.98 -- Tanaris/0, Jabbey
		11038=sB|m1423|x79.54|y63.85 -- Eastern Plaguelands/0, Caretaker Alen
		11184=sB|m1452|x61.72|y38.02 -- Winterspring/0, Wixxrak
		11555=sB|m1448|x65.18|y2.67 -- Felwood/0, Gorn One Eye
		12021=sB|m1450|x45.19|y34.74 -- Moonglade/0, Daeolyn Summerleaf
		12959=sB|m1449|x43.27|y7.73 -- Un'Goro Crater/0, Nergal
		14624=sB|m1427|x38.8|y28.5 -- Searing Gorge/0, Master Smith Burninate
		15174=sB|m1451|x51.89|y39.16 -- Silithus/0, Calandrath
		12246=sB|m1443|x40.50|y79.20 -- Desolace/0, Super-Seller 680
		20080=sB|m1446|x63.80|y57.80 -- Tanaris/0, Galgrom
		21172=sB|m1946|x79.52|y63.79 -- Zangarmarsh/0, Sarinei Whitestar
		19649=sB|m1948|x61.06|y28.00 -- Shadowmoon Valley/0, Dorni
		--23143=sB|m1948|x66.20|y87.00 --Not visible -- Shadowmoon Valley/0, 
		19625=sB|m1948|x55.39|y59.24 -- Shadowmoon Valley/0, Alorya
		22270=sB|m1949|x27.83|y58.49 -- Blade's Edge Mountains/0, Ogri'la Merchant
		20892=sB|m1952|x37.66|y51.16 -- Terokkar Forest/0, Ruogo
		20194=sB|m1953|x46.73|y56.64 -- Netherstorm/0, Dealer Dunar
		19574=sB|m1953|x33.13|y67.32 -- Netherstorm/0, Kizzie
		19534=sB|m1953|x43.33|y35.09 -- Netherstorm/0, Dealer Digriz
		20092=sB|m1953|x58.35|y31.26 -- Netherstorm/0, Dealer Hazzin
		19197=sB|m1955|x61.90|y70.50 -- Shattrath City/0, Eral
		19243=sB|m1955|x51.80|y80.40 -- Shattrath City/0, Nalama the Merchant
		25035=sB|m1957|x49.80|y39.60 -- ??, Tyrael Flamekissed
	]],
	["VendorArrows"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		1285=sA|m1453|x64.83|y72.16|wInside the building -- Stormwind City/0, Thurman Mullby (Checked 8/24/2022)
		1297=sA|m1453|x58.71|y68.71|wInside the building -- Stormwind City/0, Lina Stover (Checked 8/24/2022)
		1298=sA|m1453|x58.34|y69.03|wInside the building -- Stormwind City/0, Frederick Stover (Checked 8/24/2022)
		151=sA|m1429|x43.96|y65.91 -- Elwynn Forest/0, Brog Hamfist
		227=sA|m1431|x73.64|y45.28 -- Duskwood/0, Mabel Solaj
		228=sA|m1431|x73.03|y44.47 -- Duskwood/0, Avette Fellwood
		491=sA|m1436|x57.0|y47.16 -- Westfall/0, Quartermaster Lewis
		789=sA|m1433|x27.08|y45.54 -- Redridge Mountains/0, Kimberly Hiett
		791=sA|m1433|x28.76|y47.32 -- Redridge Mountains/0, Lindsay Ashlock
		1452=sA|m1437|x12.06|y57.98 -- Wetlands/0, Gruham Rumdnul
		1459=sA|m1437|x11.27|y58.42 -- Wetlands/0, Naela Trance
		1462=sA|m1437|x11.11|y58.32 -- Wetlands/0, Edwina Monzor
		1668=sA|m1436|x57.7|y53.93 -- Westfall/0, William MacGregor
		1682=sA|m1432|x34.75|y48.61 -- Loch Modan/0, Yanni Stoutheart
		1691=sA|m1426|x47.18|y52.4 -- Dun Morogh/0, Kreg Bilmn
		2084=sA|m1452|x51.45|y30.83 -- Winterspring/0, Natheril Raincaller
		2803=sA|m1448|x62.32|y25.64 -- Felwood/0, Malygen
		2808=sA|m1417|x46.44|y47.6 -- Arathi Highlands/0, Vikki Lonsav
		3541=sA|m1424|x49.13|y55.05 -- Hillsbrad Foothills/0, Sarah Raycroft
		3587=sA|m1438|x59.52|y40.9 -- Teldrassil/0, Lyrai
		3589=sA|m1438|x59.3|y41.09 -- Teldrassil/0, Keina
		3608=sA|m1438|x55.5|y57.14 -- Teldrassil/0, Aldia
		3610=sA|m1438|x55.89|y59.2 -- Teldrassil/0, Jeena Featherbow
		3951=sA|m1440|x50.27|y67.27 -- Ashenvale/0, Bhaldaran Ravenshade
		3962=sA|m1440|x34.84|y50.86 -- Ashenvale/0, Haljan Oakheart
		4084=sA|m1442|x35.48|y6.16 -- Stonetalon Mountains/0, Chylina
		4170=sA|m1457|x64.73|y52.96 -- Darnassus/0, Ellandrieth
		4173=sA|m1457|x63.26|y66.26 -- Darnassus/0, Landria
		4182=sA|m1439|x37.44|y40.49 -- Darkshore/0, Dalmond
		4241=sA|m1457|x70.67|y45.37 -- Darnassus/0, Mydrannul
		4892=sA|m1445|x67.94|y49.89 -- Dustwallow Marsh/0, Jensen Farran
		4896=sA|m1445|x67.45|y51.71 -- Dustwallow Marsh/0, Charity Mipsy
		5101=sA|m1455|x39.23|y74.46 -- Ironforge/0, Bryllia Ironbrand
		5122=sA|m1455|x71.76|y66.69 -- Ironforge/0, Skolmin Goldfury
		5134=sA|m1459|x43.08|y17.48 -- ??, Jonivera Farmountain
		7942=sA|m1444|x30.64|y43.43 -- Feralas/0, Faralorn
		7976=sA|m1455|x61.55|y89.43 -- Ironforge/0, Thalgus Thunderfist
		12960=sA|m1443|x66.61|y6.97 -- Desolace/0, Christi Galvanis
		14301=sA|m1447|x12.0|y78.38 -- Azshara/0, Brinna Valanaar
		19452=sA|m1944|x88.39|y52.32 -- Hellfire Peninsula/0, Quartermaster Drake
		19351=sA|m1948|x36.80|y54.31 -- Shadowmoon Valley/0, Daggle Ironshaper
		19374=sA|m1948|x36.18|y55.47 -- Shadowmoon Valley/0, Salle Sunforge
		19498=sA|m1949|x37.76|y66.02 -- Blade's Edge Mountains/0, Tanaide
		21111=sA|m1949|x61.25|y68.99 -- Blade's Edge Mountains/0, Bembil Knockhammer
		21488=sA|m1951|x41.60|y43.60 -- Nagrand/0, Banro
		19021=sA|m1951|x55.28|y70.52 -- Nagrand/0, Nancila
		19053=sA|m1952|x57.75|y53.48 -- Terokkar Forest/0, Fabian Lanzonelli
		-- HORDE --
		1149=sH|m1434|x31.55|y27.95 -- Stranglethorn Vale/0, Uthok
		2115=sH|m1420|x32.28|y65.44 -- Tirisfal Glades/0, Joshua Kien
		2134=sH|m1420|x61.16|y52.6 -- Tirisfal Glades/0, Mrs. Winters
		2140=sH|m1421|x43.97|y39.89 -- Silverpine Forest/0, Edwin Harly
		2401=sH|m1424|x62.55|y19.91 -- Hillsbrad Foothills/0, Kayren Soothallow
		2806=sH|m1448|x34.75|y53.22 -- Felwood/0, Bale
		2820=sH|m1417|x74.11|y32.37 -- Arathi Highlands/0, Graud
		2908=sH|m1418|x3.12|y45.93 -- Badlands/0, Grawl
		3015=sH|m1456|x46.99|y45.7 -- Thunder Bluff/0, Kuna Thunderhorn
		3072=sH|m1412|x45.29|y76.51 -- Mulgore/0, Kawnie Softbreeze
		3076=sH|m1412|x45.86|y57.66 -- Mulgore/0, Moorat Longstride
		3158=sH|m1411|x42.58|y67.34 -- Durotar/0, Duokna
		3164=sH|m1411|x54.39|y42.17 -- Durotar/0, Jark
		3186=sH|m1411|x56.29|y73.4 -- Durotar/0, K'waii
		3313=sH|m1454|x48.12|y80.53 -- Orgrimmar/0, Trak'gen
		3350=sH|m1454|x46.06|y40.86 -- Orgrimmar/0, Asoran
		3410=sH|m1454|x78.08|y38.45 -- Orgrimmar/0, Jin'sora
		3481=sH|m1413|x51.66|y29.94 -- The Barrens/0, Barg
		3488=sH|m1413|x51.11|y29.06 -- The Barrens/0, Uthrok
		3625=sH|m1459|x49.87|y82.14 -- ??, Rarck
		4082=sH|m1442|x45.87|y58.66 -- Stonetalon Mountains/0, Grawnal
		4555=sH|m1458|x69.16|y48.92 -- Undercity/0, Eleanor Rusk
		4604=sH|m1458|x54.7|y38.75 -- Undercity/0, Abigail Sawyer
		4876=sH|m1441|x45.91|y51.47 -- Thousand Needles/0, Jawn Highmesa
		6028=sH|m1440|x73.53|y60.3 -- Ashenvale/0, Burkrum
		8362=sH|m1456|x38.91|y64.69 -- Thunder Bluff/0, Kuruk
		9549=sH|m1442|x45.35|y59.1 -- Stonetalon Mountains/0, Borand
		9551=sH|m1441|x44.88|y50.68 -- Thousand Needles/0, Starn
		9552=sH|m1445|x35.5|y30.09 -- Dustwallow Marsh/0, Zanara
		9553=sH|m1421|x45.0|y39.29 -- Silverpine Forest/0, Nadia Vernon
		9555=sH|m1417|x72.52|y33.35 -- Arathi Highlands/0, Mu'uta
		12027=sH|m1443|x24.92|y71.84 -- Desolace/0, Tukk
		17598=sH|m1425|x76.85|y81.4 -- The Hinterlands/0, Renn'az
		16274=sH|m1942|x72.20|y31.80 -- Ghostlands/0, Narina
		16602=sH|m1944|x56.71|y37.47 -- Hellfire Peninsula/0, Floyd Pinkus
		19315=sH|m1944|x65.81|y43.56 -- Hellfire Peninsula/0, Supply Officer Isabel
		19560=sH|m1944|x61.42|y81.97 -- Hellfire Peninsula/0, Lukra
		19561=sH|m1944|x60.84|y81.61 -- Hellfire Peninsula/0, Hagash the Blind
		19436=sH|m1944|x87.89|y48.30 -- Hellfire Peninsula/0, Supply Master Broog
		18011=sH|m1946|x85.28|y54.75 -- Zangarmarsh/0, Zurai
		21082=sH|m1949|x74.53|y61.41 -- Blade's Edge Mountains/0, Krugash
		19020=sH|m1951|x55.52|y35.95 -- Nagrand/0, Matron Qualia
		18959=sH|m1952|x50.15|y45.58 -- Terokkar Forest/0, Dod'ss
		-- NEUTRAL --
		2839=sB|m1434|x28.3|y74.55 -- Stranglethorn Vale/0, Haren Kanmae
		3498=sB|m1413|x61.92|y38.79 -- The Barrens/0, Jazzik
		8139=sB|m1446|x67.0|y21.98 -- Tanaris/0, Jabbey
		11038=sB|m1423|x79.54|y63.85 -- Eastern Plaguelands/0, Caretaker Alen
		11555=sB|m1448|x65.18|y2.67 -- Felwood/0, Gorn One Eye
		12021=sB|m1450|x45.19|y34.74 -- Moonglade/0, Daeolyn Summerleaf
		12029=sB|m1450|x53.34|y42.69 -- Moonglade/0, Narianna
		12959=sB|m1449|x43.27|y7.73 -- Un'Goro Crater/0, Nergal
		14624=sB|m1427|x38.8|y28.5 -- Searing Gorge/0, Master Smith Burninate
		15174=sB|m1451|x51.89|y39.16 -- Silithus/0, Calandrath
		12246=sB|m1443|x40.50|y79.20 -- Desolace/0, Super-Seller 680
		20080=sB|m1446|x63.80|y57.80 -- Tanaris/0, Galgrom
		21172=sB|m1946|x79.52|y63.79 -- Zangarmarsh/0, Sarinei Whitestar
		19649=sB|m1948|x61.06|y28.00 -- Shadowmoon Valley/0, Dorni
		19625=sB|m1948|x55.39|y59.24 -- Shadowmoon Valley/0, Alorya
		--23143=sB|m1948|x66.20|y87.00 --Not visible -- Shadowmoon Valley/0, 
		22270=sB|m1949|x27.83|y58.49 -- Blade's Edge Mountains/0, Ogri'la Merchant
		20892=sB|m1952|x37.66|y51.16 -- Terokkar Forest/0, Ruogo
		20194=sB|m1953|x46.73|y56.64 -- Netherstorm/0, Dealer Dunar
		19574=sB|m1953|x33.13|y67.32 -- Netherstorm/0, Kizzie
		19534=sB|m1953|x43.33|y35.09 -- Netherstorm/0, Dealer Digriz
		20092=sB|m1953|x58.35|y31.26 -- Netherstorm/0, Dealer Hazzin
		19197=sB|m1955|x61.90|y70.50 -- Shattrath City/0, Eral
		19243=sB|m1955|x51.80|y80.40 -- Shattrath City/0, Nalama the Merchant
		25035=sB|m1957|x49.80|y39.60 -- ??, Tyrael Flamekissed
	]],
	["ClassDeathknight"] = [[

	]],
	["ClassDruid"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		5504=sA|m1453|x35.84|y67.35 -- Stormwind City/0, Sheldras Moontree (Checked 8/24/2022)
		5505=sA|m1453|x36.11|y64.41 -- Stormwind City/0, Theridran (Checked 8/24/2022)
		5506=sA|m1453|x34.44|y65.19 -- Stormwind City/0, Maldryn (Checked 8/24/2022)
		3597=sA|m1438|x58.62|y40.28 -- Teldrassil/0, Mardant Strongoak
		3602=sA|m1438|x55.94|y61.56 -- Teldrassil/0, Kal
		4217=sA|m1457|x35.37|y8.4 -- Darnassus/0, Mathrengyl Bearwalker
		4218=sA|m1457|x34.76|y7.36 -- Darnassus/0, Denatharion
		4219=sA|m1457|x33.51|y8.34 -- Darnassus/0, Fylerian Nightwing
		9465=sA|m1448|x61.90|y24.50 -- Felwood/0, Golhine the Hooded
		16721=sA|m1943|x24.40|y54.40 -- Azuremyst Isle/0, Shalannius
		-- HORDE --
		3033=sH|m1456|x76.47|y27.22 -- Thunder Bluff/0, Turak Runetotem
		3034=sH|m1456|x77.14|y27.01 -- Thunder Bluff/0, Sheal Runetotem
		3036=sH|m1456|x77.14|y29.81 -- Thunder Bluff/0, Kym Wildmane
		3060=sH|m1412|x45.09|y75.93 -- Mulgore/0, Gart Mistrunner
		3064=sH|m1412|x48.47|y59.64 -- Mulgore/0, Gennia Runetotem
		8142=sH|m1444|x75.98|y42.28 -- Feralas/0, Jannos Lighthoof
		16655=sH|m1954|x71.50|y56.52 -- Silvermoon City/0, Harene Plainwalker
		-- NEUTRAL --
		12042=sB|m1450|x52.52|y40.56 -- Moonglade/0, Loganaar
	]],
	["ClassHunter"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		5515=sA|m1453|x67.32|y36.18|wInside the building -- Stormwind City/0, Einris Brightspear (Checked 8/24/2022)
		5516=sA|m1453|x67.58|y35.75|wInside the building -- Stormwind City/0, Ulfir Ironbeard (Checked 8/24/2022)
		--5517=sA|m1453|x67.99|y36.01|wUpstairs inside the building -- Stormwind City/0, Thorfin Stoneshield (Checked 8/24/2022) (Upstair, no need to use this one)
		895=sA|m1426|x29.17|y67.45 -- Dun Morogh/0, Thorgas Grimson
		1231=sA|m1426|x45.81|y53.03 -- Dun Morogh/0, Grif Wildheart
		3596=sA|m1438|x58.65|y40.44 -- Teldrassil/0, Ayanna Everstride
		3601=sA|m1438|x56.67|y59.48 -- Teldrassil/0, Dazalar
		3963=sA|m1440|x50.13|y67.94 -- Ashenvale/0, Danlaar Nightstride
		4138=sA|m1457|x39.72|y5.38 -- Darnassus/0, Jeen'ra Nightrunner
		4146=sA|m1457|x40.37|y8.54 -- Darnassus/0, Jocaste
		4205=sA|m1457|x42.2|y7.26 -- Darnassus/0, Dorion
		5115=sA|m1455|x70.96|y89.8 -- Ironforge/0, Daera Brightspear
		5116=sA|m1455|x70.88|y83.61 -- Ironforge/0, Olmin Burningbeard
		5117=sA|m1455|x69.87|y82.89 -- Ironforge/0, Regnus Thundergranite
		5501=sA|m1448|x61.89|y23.58 -- Felwood/0, Kaerbrus
		8308=sA|m1440|x18.01|y59.83 -- Ashenvale/0, Alenndaar Lapidaar
		10930=sA|m1432|x82.39|y62.39 -- Loch Modan/0, Dargh Trueaim
		17110=sA|m1943|x49.80|y51.80 -- Azuremyst Isle/0, Acteon
		17122=sA|m1947|x47.20|y88.50 -- The Exodar/0, Vord
		17505=sA|m1947|x46.55|y88.50 -- The Exodar/0, Killac
		16738=sA|m1947|x47.20|y87.40 -- The Exodar/0, Deremiis
		-- HORDE --
		987=sH|m1435|x47.26|y53.42 -- Swamp of Sorrows/0, Ogromm
		1404=sH|m1434|x31.23|y28.68 -- Stranglethorn Vale/0, Kragg
		3038=sH|m1456|x58.48|y88.32 -- Thunder Bluff/0, Kary Thunderhorn
		3039=sH|m1456|x57.29|y89.78 -- Thunder Bluff/0, Holt Thunderhorn
		3040=sH|m1456|x59.12|y86.87 -- Thunder Bluff/0, Urek Thunderhorn
		3061=sH|m1412|x44.25|y75.69 -- Mulgore/0, Lanka Farshot
		3065=sH|m1412|x47.81|y55.68 -- Mulgore/0, Yaw Sharpmane
		3154=sH|m1411|x42.83|y69.32 -- Durotar/0, Jen'shan
		3171=sH|m1411|x51.84|y43.48 -- Durotar/0, Thotar
		3352=sH|m1454|x66.04|y18.52 -- Orgrimmar/0, Ormak Grimshot
		3406=sH|m1454|x67.24|y20.19 -- Orgrimmar/0, Xor'juul
		3407=sH|m1454|x67.95|y17.8 -- Orgrimmar/0, Sian'dur
		16270=sH|m1941|x48.20|y46.00 -- Eversong Woods/0, Hannovia
		16672=sH|m1954|x82.37|y26.02 -- Silvermoon City/0, Tana
		16673=sH|m1954|x84.39|y26.02 -- Silvermoon City/0, Oninath
		16674=sH|m1954|x84.40|y28.01 -- Silvermoon City/0, Zandine
		-- NEUTRAL --

	]],
	["ClassHunter pets"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		2879=sA|m1453|x67.32|y36.81|wInside the building -- Stormwind City/0, Karrina Mekenda (Checked 8/24/2022)
		543=sA|m1448|x62.2|y24.37 -- Felwood/0, Nalesette Wildbringer
		2878=sA|m1426|x46.68|y53.99 -- Dun Morogh/0, Peria Lamenur
		3306=sA|m1438|x56.78|y59.78 -- Teldrassil/0, Keldas
		3545=sA|m1432|x82.22|y62.83 -- Loch Modan/0, Claude Erksine
		-- HORDE --
		3620=sH|m1411|x52.02|y43.54 -- Durotar/0, Harruk
		3622=sH|m1435|x47.35|y52.88 -- Swamp of Sorrows/0, Grokor
		3624=sH|m1434|x31.11|y28.93 -- Stranglethorn Vale/0, Zudd
		3688=sH|m1412|x47.7|y55.72 -- Mulgore/0, Reban Freerunner
		3698=sA|m1440|x17.97|y60.03 -- Ashenvale/0, Bolyun
		4320=sA|m1440|x49.72|y66.97 -- Ashenvale/0, Caelyb
		10086=sH|m1456|x54.08|y83.99 -- Thunder Bluff/0, Hesuwa Thunderhorn
		10088=sH|m1454|x66.31|y14.81 -- Orgrimmar/0, Xao'tsu
		10089=sA|m1457|x42.47|y9.16 -- Darnassus/0, Silvaria
		10090=sA|m1455|x70.86|y85.83 -- Ironforge/0, Belia Thundergranite
		17484=sA|m1943|x50.00|y52.00 -- Azuremyst Isle/0, Buruk
		16675=sH|m1954|x82.75|y27.95 -- Silvermoon City/0, Halthenis
		-- NEUTRAL --

	]],
	["ClassMage"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		331=sA|m1453|x49.22|y87.72|wThrough the portal inside the tower -- Stormwind City/0, Maginor Dumas (Checked 8/24/2022)
		5497=sA|m1453|x49.49|y85.82|wThrough the portal inside the tower -- Stormwind City/0, Jennea Cannon (Checked 8/24/2022)
		5498=sA|m1453|x48.21|y87.29|wThrough the portal inside the tower -- Stormwind City/0, Elsharin (Checked 8/24/2022)
		--2485=sA|m1453|x50.38|y85.99|wThrough the portal inside the tower -- Stormwind City/0, Larimaine Purdue (Checked 8/24/2022) (Portal Trainer)
		198=sA|m1429|x49.66|y39.4 -- Elwynn Forest/0, Khelden Bremen
		328=sA|m1429|x43.24|y66.19 -- Elwynn Forest/0, Zaldimar Wefhellt
		--944=sA|m1426|x28.7|y66.36 -- very limited -- Dun Morogh/0, 
		1228=sA|m1426|x47.49|y52.07 -- Dun Morogh/0, Magis Sparkmantle
		--2489=sA|m1455|x25.49|y7.06 -- only portals -- Ironforge/0, 
		--4165=sA|m1457|x40.59|y82.13 -- only portals -- Darnassus/0, 
		5144=sA|m1455|x27.24|y8.29 -- Ironforge/0, Bink
		5145=sA|m1455|x26.29|y6.76 -- Ironforge/0, Juli Stormkettle
		5146=sA|m1455|x25.92|y6.17 -- Ironforge/0, Nittlebur Sparkfizzle
		7312=sA|m1455|x27.16|y8.57 -- Ironforge/0, Dink
		27703=sA|m1445|x66.00|y49.00 -- Dustwallow Marsh/0, Ysuria
		27704=sA|m1445|x66.00|y49.40 -- Dustwallow Marsh/0, Horace Alder
		17481=sA|m1943|x49.80|y50.00 -- Azuremyst Isle/0, Semid
		16500=sA|m1943|x79.58|y48.76 -- Azuremyst Isle/0, Valaatu
		16749=sA|m1947|x47.30|y61.50 -- The Exodar/0, Edirah
		17513=sA|m1947|x46.40|y62.60 -- The Exodar/0, Harnan
		17514=sA|m1947|x45.80|y64.20 -- The Exodar/0, Bati
		-- HORDE --
		--2124=sH|m1420|x30.93|y66.06 -- very limited -- Tirisfal Glades/0, 
		2128=sH|m1420|x61.96|y52.47 -- Tirisfal Glades/0, Cain Firesong
		--2492=sH|m1458|x84.19|y15.58 -- only portals -- Undercity/0, 
		3047=sH|m1456|x22.76|y14.53 -- Thunder Bluff/0, Archmage Shymm
		3048=sH|m1456|x25.7|y14.19 -- Thunder Bluff/0, Ursyn Ghull
		3049=sH|m1456|x25.17|y20.96 -- Thunder Bluff/0, Thurston Xane
		4566=sH|m1458|x85.02|y14.02 -- Undercity/0, Kaelystia Hatebringer
		4567=sH|m1458|x85.44|y13.5 -- Undercity/0, Pierce Shackleton
		4568=sH|m1458|x85.13|y10.02 -- Undercity/0, Anastasia Hartwell
		5880=sH|m1411|x56.3|y75.1 -- Durotar/0, Un'Thuwa
		5882=sH|m1454|x38.35|y85.55 -- Orgrimmar/0, Pephredo
		5883=sH|m1454|x38.78|y85.67 -- Orgrimmar/0, Enyo
		--5884=sH|m1411|x42.5|y69.03 -- very limited -- Durotar/0, 
		5885=sH|m1454|x38.44|y86.13 -- Orgrimmar/0, Deino
		--5957=sH|m1456|x22.49|y16.9 -- only portals -- Thunder Bluff/0, 
		--5958=sH|m1454|x38.68|y85.4 -- only portals -- Orgrimmar/0, 
		7311=sH|m1454|x39.16|y86.27 -- Orgrimmar/0, Uthel'nay
		27705=sH|m1435|x47.80|y55.20 -- Swamp of Sorrows/0, Lorrin Foxfire
		15279=sH|m1941|x39.20|y21.40 -- Eversong Woods/0, Julia Sunstriker
		16269=sH|m1941|x48.00|y48.00 -- Eversong Woods/0, Garridel
		16654=sH|m1954|x57.90|y20.30 -- Silvermoon City/0, Narinth
		16653=sH|m1954|x58.85|y19.57 -- Silvermoon City/0, Inethven
		16652=sH|m1954|x58.40|y18.45 -- Silvermoon City/0, Quithas
		16651=sH|m1954|x57.60|y19.80 -- Silvermoon City/0, Zaedana
		-- NEUTRAL --
		16755=sB|m1947|x46.00|y62.80 -- The Exodar/0, Lunaraa
		20791=sB|m1955|x58.30|y47.00 -- Shattrath City/0, Iorioa
		19340=sB|m1955|x43.20|y93.20 -- Shattrath City/0, Mi'irku Farstep
	]],
	["ClassPaladin"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		928=sA|m1453|x48.41|y50.17|wInside the building -- Stormwind City/0, Lord Grayson Shadowbreaker (Checked 8/24/2022)
		5491=sA|m1453|x49.61|y49.91|wInside the building -- Stormwind City/0, Arthur the Faithful (Checked 8/24/2022)
		5492=sA|m1453|x48.50|y49.13|wInside the building -- Stormwind City/0, Katherine the Pure (Checked 8/24/2022)
		925=sA|m1429|x50.43|y42.12 -- Elwynn Forest/0, Brother Sammuel
		927=sA|m1429|x41.09|y66.03 -- Elwynn Forest/0, Brother Wilhelm
		926=sA|m1426|x28.83|y68.33 -- Dun Morogh/0, Bromos Grummner
		1232=sA|m1426|x47.59|y52.07 -- Dun Morogh/0, Azar Stronghammer
		5147=sA|m1455|x23.7|y5.09 -- Ironforge/0, Valgar Highforge
		5148=sA|m1455|x24.54|y4.47 -- Ironforge/0, Beldruk Doombrow
		5149=sA|m1455|x23.13|y6.14 -- Ironforge/0, Brandur Ironhammer
		8140=sA|m1445|x67.39|y47.41 -- Dustwallow Marsh/0, Brother Karman
		16501=sA|m1943|x79.60|y48.20 -- Azuremyst Isle/0, Aurelon
		17483=sA|m1943|x48.40|y49.40 -- Azuremyst Isle/0, Tullas
		17121=sA|m1947|x39.20|y82.60 -- The Exodar/0, Kavaan
		17509=sA|m1947|x38.44|y81.59 -- The Exodar/0, Jol
		16761=sA|m1947|x39.00|y83.80 -- The Exodar/0, Baatun
		17844=sA|m1950|x55.50|y55.30 -- Bloodmyst Isle/0, Vindicator Aesom
		-- HORDE --
		23128=sH|m1454|x32.33|y35.80 -- Orgrimmar/0, Master Pyreanor
		20406=sH|m1458|x58.00|y89.80 -- Undercity/0, Champion Cyssa Dawnrose
		16275=sH|m1941|x48.40|y46.40 -- Eversong Woods/0, Noellene
		15280=sH|m1941|x39.40|y20.60 -- Eversong Woods/0, Jesthenis Sunstriker
		16680=sH|m1954|x91.20|y37.20 -- Silvermoon City/0, Ithelis
		16681=sH|m1954|x92.10|y37.29 -- Silvermoon City/0, Champion Bachi
		16679=sH|m1954|x91.20|y38.00 -- Silvermoon City/0, Osselan
		-- NEUTRAL --

	]],
	["ClassPriest"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		376=sA|m1453|x49.52|y44.56|wInside the building -- Stormwind City/0, High Priestess Laurena (Checked 8/24/2022)
		--5484=sA|m1453|x52.27|y47.64|wHe walks around inside the building -- Stormwind City/0, Brother Benjamin (Checked 8/24/2022) (Walks around)
		5489=sA|m1453|x49.46|y45.16|wInside the building -- Stormwind City/0, Brother Joshua (Checked 8/24/2022)
		11397=sA|m1453|x35.68|y63.20 -- Stormwind City/0, Nara Meideros (Checked 8/24/2022)
		375=sA|m1429|x49.8|y39.48 -- Elwynn Forest/0, Priestess Anetta
		377=sA|m1429|x43.28|y65.72 -- Elwynn Forest/0, Priestess Josetta
		837=sA|m1426|x28.59|y66.38 -- Dun Morogh/0, Branstock Khalder
		1226=sA|m1426|x47.34|y52.18 -- Dun Morogh/0, Maxan Anvol
		3595=sA|m1438|x59.17|y40.43 -- Teldrassil/0, Shanda
		3600=sA|m1438|x55.56|y56.74 -- Teldrassil/0, Laurna Morninglight
		4090=sA|m1457|x38.33|y80.95 -- Darnassus/0, Astarii Starseeker
		4091=sA|m1457|x37.89|y82.73 -- Darnassus/0, Jandria
		4092=sA|m1457|x40.34|y88.68 -- Darnassus/0, Lariia
		5141=sA|m1455|x24.08|y8.41 -- Ironforge/0, Theodrus Frostbeard
		5142=sA|m1455|x24.42|y9.17 -- Ironforge/0, Braenna Flintcrag
		5143=sA|m1455|x25.2|y10.75 -- Ironforge/0, Toldren Deepiron
		11401=sA|m1457|x39.52|y81.19 -- Darnassus/0, Priestess Alathea
		11406=sA|m1455|x24.72|y8.15 -- Ironforge/0, High Priest Rohan
		16502=sA|m1943|x80.13|y48.77 -- Azuremyst Isle/0, Zalduun
		17482=sA|m1943|x48.50|y49.20 -- Azuremyst Isle/0, Guvan
		-- HORDE --
		2123=sH|m1420|x31.1|y66.03 -- Tirisfal Glades/0, Dark Cleric Duesten
		2129=sH|m1420|x61.57|y52.19 -- Tirisfal Glades/0, Dark Cleric Beryl
		3044=sH|m1456|x25.31|y15.26 -- Thunder Bluff/0, Miles Welsh
		3045=sH|m1456|x24.55|y22.57 -- Thunder Bluff/0, Malakai Cross
		3046=sH|m1456|x25.63|y20.69 -- Thunder Bluff/0, Father Cobb
		3706=sH|m1411|x54.25|y42.93 -- Durotar/0, Tai'jin
		3707=sH|m1411|x42.36|y68.81 -- Durotar/0, Ken'jai
		4606=sH|m1458|x48.99|y18.32 -- Undercity/0, Aelthalyste
		4607=sH|m1458|x49.13|y14.6 -- Undercity/0, Father Lankester
		4608=sH|m1458|x47.56|y18.9 -- Undercity/0, Father Lazarus
		6018=sH|m1454|x35.59|y87.81 -- Orgrimmar/0, Ur'kyo
		5994=sH|m1454|x35.44|y87.30 -- Orgrimmar/0, Zayus
		6014=sH|m1454|x35.69|y87.60 -- Orgrimmar/0, X'yera
		16276=sH|m1941|x47.80|y47.80 -- Eversong Woods/0, Ponaris
		16660=sH|m1954|x54.40|y27.60 -- Silvermoon City/0, Belestra
		16659=sH|m1954|x54.80|y25.80 -- Silvermoon City/0, Lotheolan
		16658=sH|m1954|x53.65|y26.52 -- Silvermoon City/0, Aldrae
		-- NEUTRAL --
		17511=sB|m1947|x39.54|y51.50 -- The Exodar/0, Fallat
		17510=sB|m1947|x39.75|y51.70 -- The Exodar/0, Izmir
		16756=sB|m1947|x38.59|y50.90 -- The Exodar/0, Caedmos
	]],
	["ClassRogue"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		918=sA|m1453|x77.42|y65.30 -- Stormwind City/0, Osborne the Night Man (Checked 8/24/2022)
		13283=sA|m1453|x80.28|y68.57|wInside the building -- Stormwind City/0, Lord Tony Romano (Checked 8/24/2022)
		915=sA|m1429|x50.31|y39.91 -- Elwynn Forest/0, Jorik Kerridan
		917=sA|m1429|x43.87|y65.93 -- Elwynn Forest/0, Keryn Sylvius
		916=sA|m1426|x28.36|y67.51 -- Dun Morogh/0, Solm Hargrin
		1234=sA|m1426|x47.56|y52.6 -- Dun Morogh/0, Hogral Bakkan
		3594=sA|m1438|x59.63|y38.66 -- Teldrassil/0, Frahun Shadewhisper
		3599=sA|m1438|x56.38|y60.13 -- Teldrassil/0, Jannok Breezesong
		4163=sA|m1457|x36.99|y21.9 -- Darnassus/0, Syurna
		4214=sA|m1457|x34.52|y25.93 -- Darnassus/0, Erion Shadewhisper
		4215=sA|m1457|x37.92|y20.91 -- Darnassus/0, Anishar
		5165=sA|m1455|x51.95|y14.84 -- Ironforge/0, Hulfdan Blackbeard
		5166=sA|m1455|x52.88|y15.0 -- Ironforge/0, Ormyr Flinteye
		5167=sA|m1455|x51.5|y15.32 -- Ironforge/0, Fenthwick
		-- HORDE --
		2122=sH|m1420|x32.53|y65.65 -- Tirisfal Glades/0, David Trias
		2130=sH|m1420|x61.75|y51.99 -- Tirisfal Glades/0, Marion Call
		3155=sH|m1411|x41.27|y68.0 -- Durotar/0, Rwag
		3170=sH|m1411|x51.97|y43.69 -- Durotar/0, Kaplak
		3327=sH|m1454|x42.69|y51.47 -- Orgrimmar/0, Gest
		3328=sH|m1454|x43.9|y54.62 -- Orgrimmar/0, Ormok
		3401=sH|m1454|x43.04|y53.73 -- Orgrimmar/0, Shenthul
		4582=sH|m1458|x83.85|y72.06 -- Undercity/0, Carolyn Ward
		4583=sH|m1458|x85.21|y71.57 -- Undercity/0, Miles Dexter
		4584=sH|m1458|x84.88|y73.52 -- Undercity/0, Gregory Charles
		15285=sH|m1941|x38.80|y20.20 -- Eversong Woods/0, Pathstalker Avokor
		16279=sH|m1941|x48.50|y45.90 -- Eversong Woods/0, Tannaria
		16684=sH|m1954|x79.50|y50.54 -- Silvermoon City/0, Zelanis
		16686=sH|m1954|x58.40|y39.40 -- Silvermoon City/0, Nerisen
		16685=sH|m1954|x62.80|y34.80 -- Silvermoon City/0, Elara
		-- NEUTRAL --
		1411=sB|m1434|x26.81|y77.14 -- Stranglethorn Vale/0, Ian Strom
	]],
	["ClassShaman"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		20407=sA|m1453|x67.51|y89.42|wNext to the lake by the Stormwind entry bridge -- Stormwind City/0, Farseer Umbrua (Checked 8/24/2022)
		23127=sA|m1455|x55.00|y30.40 -- Ironforge/0, Farseer Javad
		17212=sA|m1943|x48.00|y50.40 -- Azuremyst Isle/0, Tuluun
		17089=sA|m1943|x79.20|y49.00 -- Azuremyst Isle/0, Firmanvaar
		17519=sA|m1947|x34.80|y10.80 -- The Exodar/0, Hobahken
		17204=sA|m1947|x29.60|y33.00 -- The Exodar/0, Farseer Nobundo
		17219=sA|m1947|x32.60|y24.20 -- The Exodar/0, Sulaa
		17520=sA|m1947|x25.20|y39.29 -- The Exodar/0, Gurrag
		-- HORDE --
		986=sH|m1435|x48.18|y57.94 -- Swamp of Sorrows/0, Haromm
		3030=sH|m1456|x22.82|y21.11 -- Thunder Bluff/0, Siln Skychaser
		3031=sH|m1456|x23.64|y18.79 -- Thunder Bluff/0, Tigor Skychaser
		3032=sH|m1456|x21.98|y18.8 -- Thunder Bluff/0, Beram Skychaser
		3062=sH|m1412|x45.01|y75.94 -- Mulgore/0, Meela Dawnstrider
		3066=sH|m1412|x48.38|y59.15 -- Mulgore/0, Narm Skychaser
		3157=sH|m1411|x42.39|y69.0 -- Durotar/0, Shikrik
		3173=sH|m1411|x54.41|y42.58 -- Durotar/0, Swart
		3344=sH|m1454|x38.8|y36.36 -- Orgrimmar/0, Kardris Dreamseeker
		3403=sH|m1454|x37.83|y36.45 -- Orgrimmar/0, Sian'tsu
		13417=sH|m1454|x38.65|y35.92 -- Orgrimmar/0, Sagorne Creststrider
		-- NEUTRAL --

	]],
	["ClassWarlock"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		461=sA|m1453|x39.24|y84.96|wDownstairs inside The Slaughtered Lamb -- Stormwind City/0, Demisette Cloyce (Checked 8/24/2022)
		5495=sA|m1453|x39.88|y84.18|wDownstairs inside The Slaughtered Lamb -- Stormwind City/0, Ursula Deline (Checked 8/24/2022)
		5496=sA|m1453|x39.65|y85.74|wDownstairs inside The Slaughtered Lamb -- Stormwind City/0, Sandahl (Checked 8/24/2022)
		459=sA|m1429|x49.87|y42.64 -- Elwynn Forest/0, Drusilla La Salle
		906=sA|m1429|x44.39|y66.24 -- Elwynn Forest/0, Maximillian Crowe
		460=sA|m1426|x28.64|y66.14 -- Dun Morogh/0, Alamar Grimm
		5171=sA|m1455|x51.08|y6.61 -- Ironforge/0, Thistleheart
		5172=sA|m1455|x50.34|y5.65 -- Ironforge/0, Briarthorn
		5173=sA|m1455|x50.08|y7.45 -- Ironforge/0, Alexander Calder
		5612=sA|m1426|x47.32|y53.69 -- Dun Morogh/0, Gimrizz Shadowcog
		-- HORDE --
		988=sH|m1435|x48.65|y55.63 -- Swamp of Sorrows/0, Kartosh
		2126=sH|m1420|x30.91|y66.33 -- Tirisfal Glades/0, Maximillion
		2127=sH|m1420|x61.58|y52.39 -- Tirisfal Glades/0, Rupert Boch
		3156=sH|m1411|x40.65|y68.51 -- Durotar/0, Nartok
		3172=sH|m1411|x54.38|y41.19 -- Durotar/0, Dhugru Gorelust
		3324=sH|m1454|x47.98|y45.93 -- Orgrimmar/0, Grol'dar
		3325=sH|m1454|x48.61|y46.95 -- Orgrimmar/0, Mirket
		3326=sH|m1454|x48.46|y45.42 -- Orgrimmar/0, Zevrost
		4563=sH|m1458|x86.2|y15.92 -- Undercity/0, Kaal Soulreaper
		4564=sH|m1458|x86.42|y15.25 -- Undercity/0, Luther Pickman
		4565=sH|m1458|x88.9|y15.86 -- Undercity/0, Richard Kerwin
		16266=sH|m1941|x48.20|y47.80 -- Eversong Woods/0, Celoenus
		16646=sH|m1954|x63.60|y36.40 -- Silvermoon City/0, Alamma
		16647=sH|m1954|x62.40|y35.40 -- Silvermoon City/0, Talionia
		16648=sH|m1954|x63.40|y36.00 -- Silvermoon City/0, Zanien
		-- NEUTRAL --
		6251=sB|m1413|x62.60|y35.40 -- The Barrens/0, Strahad Farsan
	]],
	["ClassWarrior"] = [[
		-- ALLIANCE --
		-- HORDE --
		-- NEUTRAL --

		-- ALLIANCE --
		914=sA|m1453|x80.19|y61.25|wUpstairs inside the building -- Stormwind City/0, Ander Germaine (Checked 8/24/2022)
		5479=sA|m1453|x80.55|y59.86|wUpstairs inside the building -- Stormwind City/0, Wu Shen (Checked 8/24/2022)
		5480=sA|m1453|x80.41|y59.80|wUpstairs inside the building -- Stormwind City/0, Ilsa Corbin (Checked 8/24/2022)
		911=sA|m1429|x50.24|y42.28 -- Elwynn Forest/0, Llane Beshere
		913=sA|m1429|x41.08|y65.76 -- Elwynn Forest/0, Lyria Du Lac
		912=sA|m1426|x28.83|y67.23 -- Dun Morogh/0, Thran Khorman
		1229=sA|m1426|x47.35|y52.64 -- Dun Morogh/0, Granis Swiftaxe
		1901=sA|m1455|x66.96|y90.14 -- Ironforge/0, Kelstrum Stonebreaker
		3593=sA|m1438|x59.63|y38.44 -- Teldrassil/0, Alyissia
		3598=sA|m1438|x56.22|y59.19 -- Teldrassil/0, Kyra Windblade
		4087=sA|m1457|x58.71|y34.89 -- Darnassus/0, Arias'ta Bladesinger
		4089=sA|m1457|x61.77|y42.21 -- Darnassus/0, Sildanair
		5113=sA|m1455|x70.33|y90.65 -- Ironforge/0, Kelv Sternhammer
		5114=sA|m1455|x65.9|y88.4 -- Ironforge/0, Bilban Tosslespanner
		7315=sA|m1457|x58.93|y35.34 -- Darnassus/0, Darnath Bladesinger
		8141=sA|m1445|x67.87|y48.4 -- Dustwallow Marsh/0, Captain Evencane
		17480=sA|m1943|x49.90|y50.50 -- Azuremyst Isle/0, Ruada
		17120=sA|m1947|x55.40|y81.20 -- The Exodar/0, Behomat
		-- HORDE --
		985=sH|m1435|x44.89|y57.62 -- Swamp of Sorrows/0, Malosh
		2119=sH|m1420|x32.68|y65.56 -- Tirisfal Glades/0, Dannal Stern
		2131=sH|m1420|x61.85|y52.53 -- Tirisfal Glades/0, Austil de Mon
		3041=sH|m1456|x57.24|y87.37 -- Thunder Bluff/0, Torm Ragetotem
		3042=sH|m1456|x56.99|y89.51 -- Thunder Bluff/0, Sark Ragetotem
		3043=sH|m1456|x57.57|y85.5 -- Thunder Bluff/0, Ker Ragetotem
		3059=sH|m1412|x44.0|y76.13 -- Mulgore/0, Harutt Thunderhorn
		3063=sH|m1412|x49.51|y60.58 -- Mulgore/0, Krang Stonehoof
		3153=sH|m1411|x42.88|y69.43 -- Durotar/0, Frang
		3169=sH|m1411|x54.18|y42.46 -- Durotar/0, Tarshaw Jaggedscar
		3353=sH|m1454|x79.78|y31.41 -- Orgrimmar/0, Grezz Ragefist
		3354=sH|m1454|x80.39|y32.38 -- Orgrimmar/0, Sorek
		3408=sH|m1454|x80.37|y29.5 -- Orgrimmar/0, Zel'mak
		4593=sH|m1458|x46.93|y15.22 -- Undercity/0, Christoph Walker
		4594=sH|m1458|x48.32|y15.96 -- Undercity/0, Angela Curthas
		4595=sH|m1458|x47.4|y17.29 -- Undercity/0, Baltus Fowler
		-- NEUTRAL --
		17504=sB|m1947|x56.80|y83.80 -- The Exodar/0, Kazi
		16771=sB|m1947|x54.80|y82.20 -- The Exodar/0, Ahonan
	]],
}
-- s = side (A=Alliance H=Horde B=both)
-- m = map
-- x,y = coordinates
-- Can add f if a floor # is needed.
-- t = type (M = mailbox)
ZGV._MailboxData = [[
	sA|m1453|x49.64|y86.99|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x50.58|y89.75|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x40.84|y61.90|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x36.80|y69.21|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x45.66|y53.97|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x37.90|y34.34|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x30.35|y49.18|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x30.32|y25.53|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x54.60|y57.57|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x61.51|y43.36|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x67.35|y49.78|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x64.66|y36.97|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x72.86|y48.64|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x74.54|y55.39|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x75.72|y64.64|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x72.49|y69.20|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x66.63|y65.39|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x54.65|y62.89|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x57.41|y71.71|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x50.92|y70.39|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x61.64|y76.07|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x62.51|y74.73|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1453|x61.59|y70.75|tM	-- Stormwind City/0 (Checked 8/24/2022)
	sA|m1429|x42.91|y65.51|tM	-- Elwynn Forest/0
	sA|m1419|x64.05|y19.21|tM	-- Blasted Lands/0
	sA|m1439|x37.32|y43.73|tM	-- Darkshore/0
	sA|m1457|x41.63|y41.84|tM	-- Darnassus/0
	sA|m1457|x67.17|y16.46|tM	-- Darnassus/0
	sA|m1440|x36.33|y50.22|tM	-- Ashenvale/0
	sA|m1443|x65.43|y6.8|tM		-- Desolace/0
	sA|m1426|x47.02|y52.58|tM	-- Dun Morogh/0
	sA|m1431|x73.72|y46.1|tM	-- Duskwood/0
	sA|m1445|x65.96|y45.28|tM	-- Dustwallow Marsh/0
	sA|m1444|x31.26|y43.8|tM	-- Feralas/0
	sA|m1424|x50.41|y58.69|tM	-- Hillsbrad Foothills/0
	sA|m1455|x20.95|y52.41|tM	-- Ironforge/0
	sA|m1455|x71.3|y72.13|tM	-- Ironforge/0
	sA|m1455|x33.21|y64.65|tM	-- Ironforge/0
	sA|m1455|x72.27|y49.09|tM	-- Ironforge/0
	sA|m1432|x34.81|y47.73|tM	-- Loch Modan/0
	sA|m1433|x26.41|y46.5|tM	-- Redridge Mountains/0
	sA|m1442|x36.01|y7.2|tM		-- Stonetalon Mountains/0
	sA|m1438|x56.11|y58.42|tM	-- Teldrassil/0
	sA|m1425|x14.04|y45.7|tM	-- The Hinterlands/0
	sA|m1436|x53.1|y53.33|tM	-- Westfall/0
	sA|m1437|x10.85|y59.72|tM	-- Wetlands/0
	sA|m1943|x48.89|y49.89|tM	-- Azuremyst Isle/0
	sA|m1949|x36.24|y64.28|tM	-- Blade's Edge Mountains/0
	sA|m1949|x60.85|y68.36|tM	-- Blade's Edge Mountains/0
	sA|m1949|x62.60|y38.40|tM	-- Blade's Edge Mountains/0
	sA|m1950|x55.21|y59.20|tM	-- Bloodmyst Isle/0
	sA|m1944|x54.96|y63.53|tM	-- Hellfire Peninsula/0
	sA|m1944|x23.49|y37.34|tM	-- Hellfire Peninsula/0
	sA|m1951|x54.42|y73.71|tM	-- Nagrand/0
	sA|m1948|x37.24|y57.47|tM	-- Shadowmoon Valley/0
	sA|m1952|x56.93|y53.59|tM	-- Terokkar Forest/0
	sA|m1947|x59.88|y51.85|tM	-- The Exodar/0
	sA|m1947|x51.06|y43.05|tM	-- The Exodar/0
	sA|m1947|x79.32|y63.26|tM	-- The Exodar/0
	sA|m1947|x58.91|y27.47|tM	-- The Exodar/0
	sA|m1946|x67.48|y49.15|tM	-- Zangarmarsh/0
	sA|m1946|x42.03|y27.01|tM	-- Zangarmarsh/0

	sH|m1417|x73.85|y33.1|tM	-- Arathi Highlands/0
	sH|m1440|x73.62|y60.88|tM	-- Ashenvale/0
	sH|m1418|x3.82|y47.29|tM	-- Badlands/0
	sH|m1443|x24.78|y68.75|tM	-- Desolace/0
	sH|m1411|x51.9|y42.15|tM	-- Durotar/0
	sH|m1444|x74.87|y44.0|tM	-- Feralas/0
	sH|m1424|x62.37|y19.7|tM	-- Hillsbrad Foothills/0
	sH|m1412|x47.0|y60.3|tM		-- Mulgore/0
	sH|m1454|x50.69|y70.37|tM	-- Orgrimmar/0
	sH|m1454|x62.26|y40.5|tM	-- Orgrimmar/0
	sH|m1421|x43.4|y41.52|tM	-- Silverpine Forest/0
	sH|m1442|x48.0|y61.13|tM	-- Stonetalon Mountains/0
	sH|m1434|x32.51|y28.65|tM	-- Stranglethorn Vale/0
	sH|m1435|x45.44|y55.13|tM	-- Swamp of Sorrows/0
	sH|m1413|x52.02|y30.43|tM	-- The Barrens/0
	sH|m1413|x45.07|y58.67|tM	-- The Barrens/0
	sH|m1425|x78.84|y80.5|tM	-- The Hinterlands/0
	sH|m1441|x45.85|y51.05|tM	-- Thousand Needles/0
	sH|m1456|x45.23|y59.39|tM	-- Thunder Bluff/0
	sH|m1420|x61.49|y53.07|tM	-- Tirisfal Glades/0
	sH|m1458|x68.16|y38.26|tM	-- Undercity/0
	sH|m1949|x52.70|y55.73|tM	-- Blade's Edge Mountains/0
	sH|m1941|x47.81|y46.95|tM	-- Eversong Woods/0
	sH|m1941|x44.22|y70.71|tM	-- Eversong Woods/0
	sH|m1942|x47.78|y31.26|tM	-- Ghostlands/0
	sH|m1944|x26.87|y60.33|tM	-- Hellfire Peninsula/0
	sH|m1944|x56.47|y37.99|tM	-- Hellfire Peninsula/0
	sH|m1951|x56.49|y35.55|tM	-- Nagrand/0
	sH|m1948|x30.13|y28.30|tM	-- Shadowmoon Valley/0
	sH|m1954|x87.94|y50.79|tM	-- Silvermoon City/0
	sH|m1954|x68.15|y29.11|tM	-- Silvermoon City/0
	sH|m1954|x64.40|y74.57|tM	-- Silvermoon City/0
	sH|m1954|x74.97|y55.08|tM	-- Silvermoon City/0
	sH|m1954|x71.18|y75.06|tM	-- Silvermoon City/0
	sH|m1954|x65.93|y53.70|tM	-- Silvermoon City/0
	sH|m1954|x59.06|y61.49|tM	-- Silvermoon City/0
	sH|m1954|x82.50|y43.28|tM	-- Silvermoon City/0
	sH|m1954|x71.13|y79.09|tM	-- Silvermoon City/0
	sH|m1954|x82.83|y65.60|tM	-- Silvermoon City/0
	sH|m1954|x82.79|y62.22|tM	-- Silvermoon City/0
	sH|m1952|x49.36|y44.87|tM	-- Terokkar Forest/0
	sH|m1946|x31.91|y50.01|tM	-- Zangarmarsh/0

	sB|m1448|x34.82|y52.95|tM	-- Felwood/0
	sB|m1451|x51.74|y37.96|tM	-- Silithus/0
	sB|m1434|x26.7|y76.36|tM	-- Stranglethorn Vale/0
	sB|m1446|x52.33|y27.81|tM	-- Stonetalon Mountains/0
	sB|m1413|x62.16|y39.18|tM	-- The Barrens/0
	sB|m1452|x61.27|y38.62|tM	-- Winterspring/0
	sB|m1949|x27.64|y52.46|tM	-- Blade's Edge Mountains/0
	sB|m1953|x32.22|y64.57|tM	-- Netherstorm/0
	sB|m1953|x43.51|y35.89|tM	-- Netherstorm/0
	sB|m1948|x61.35|y28.95|tM	-- Shadowmoon Valley/0
	sB|m1948|x56.23|y58.20|tM	-- Shadowmoon Valley/0
	sB|m1955|x74.77|y48.69|tM	-- Shattrath City/0
	sB|m1955|x60.10|y65.14|tM	-- Shattrath City/0
	sB|m1955|x61.18|y64.32|tM	-- Shattrath City/0
	sB|m1955|x28.03|y47.51|tM	-- Shattrath City/0
	sB|m1955|x55.40|y80.61|tM	-- Shattrath City/0
	sB|m1955|x46.92|y25.36|tM	-- Shattrath City/0
	sB|m1955|x47.98|y24.56|tM	-- Shattrath City/0
	sB|m1955|x73.76|y34.42|tM	-- Shattrath City/0
	sB|m1946|x78.91|y63.67|tM	-- Zangarmarsh/0
]]
