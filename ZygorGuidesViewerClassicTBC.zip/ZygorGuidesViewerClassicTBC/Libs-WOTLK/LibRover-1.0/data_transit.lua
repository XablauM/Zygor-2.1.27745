local name,addon = ...

addon.LibRoverData = addon.LibRoverData or {}
local data=addon.LibRoverData

data.basenodes.transit = {






---------------------
----   PORTALS   ----
---------------------

	--## ALLIANCE ##--
		-- Rut'theran Village / Darnassus Pink Portal
			"Teldrassil 55.91,89.64 <region:ruttheran> -x- Darnassus 30.06,41.44 {fac:A} {mode:PORTAL} {title_atob:Enter the pink portal to Darnassus} {title_btoa:Enter the pink portal to Rut'theran Village}",

		-- Moonglade to Rut'theran Village Druid fake taxi
			"Moonglade 44.19,45.33 -to- Teldrassil 58.33,93.86 <region:ruttheran> {mode:PORTAL} {fac:A} {title:Take hippogryph to Rut'theran Village } {cost:145} {cond:ZGV:RaceClassMatch('DRUID')}",

		-- Darnassus, Kalimdor -to- Blasted Lands, Eastern Kingdoms
			"Darnassus/0 40.51,81.68 -to- Blasted Lands/0 57.50,51.12 {fac:A} {mode:PORTAL}"..
				"{cond:PlayerLevel() >= 52}",

		-- Stormwind City - Elwynn Forest, Eastern Kingdoms -to- Blasted Lands, Eastern Kingdoms
			"Stormwind City/0 48.98,87.35 -to- Blasted Lands/0 57.50,51.12 {fac:A} {mode:PORTAL}"..
				"{cond:PlayerLevel() >= 52}",

	--## HORDE ##--

		-- Moonglade to Thunderbluff Druid fake taxi
			"Moonglade 44.27,45.77 -to- Thunder Bluff 46.70,49.92 {mode:PORTAL} {fac:H} {title:Take windrider to Thunder Bluff} {cost:515} {cond:ZGV:RaceClassMatch('DRUID')}",

		-- Silvermoon City to Undercity (Orb of Translocation)
			"Silvermoon City/0 49.50,14.80 -to- Undercity/0 56.93,11.40 {mode:PORTAL} {fac:H} {title:Click the Orb of Translocation\nInside the Building to\nTeleport to Undercity}",

		-- Undercity to Silvermoon City (Orb of Translocation)
			"Undercity/0 54.85,11.26 -to- Silvermoon City/0 50.62,16.45 {mode:PORTAL} {fac:H} {title:Click the Orb of Translocation\nto Teleport to Undercity}",

		-- Orgrimmar, Kalimdor -to- Blasted Lands, Eastern Kingdoms
			"Orgrimmar/0 38.07,85.70 -to- Blasted Lands/0 57.50,51.12 {fac:H} {mode:PORTAL} {title:Click the Portal to\nBlasted Lands Upstairs\nInside the Hut}"..
				"{cond:PlayerLevel() >= 52}",

	--## NEUTRAL ##--

		-- Eastern Plaguelands / Darnassus Pink Portal
			"Eastern Plaguelands/0 59.73,12.50 -x- Ghostlands/0 51.98,97.99 {mode:PORTAL} {title_atob:Enter the Portal to\nGhostlands} {title_btoa:Enter the Portal to\nEastern Plaguelands}",
		
		-- The Dark Portal (Blasted Lands)
			"Blasted Lands/0 58.72,59.93 -to- Hellfire Peninsula/0 89.39,50.22 {mode:PORTAL} {title:Enter the Dark Portal\nto Hellfire Peninsula} "..
			"{cond:(PlayerCompletedQuest(10119) or PlayerIsOnQuest(10119)) or (PlayerCompletedQuest(9407) or PlayerIsOnQuest(9407))}",

		-- The Dark Portal (Hellfire Peninsula)
			"Hellfire Peninsula/0 89.82,50.21 -to- Blasted Lands/0 58.66,59.56 {title:Enter the Dark Portal\nto Blasted Lands} "..
			"{cond:(PlayerCompletedQuest(10119) or PlayerIsOnQuest(10119)) or (PlayerCompletedQuest(9407) or PlayerIsOnQuest(9407))}",

		-- Shattrath City, Terokkar Forest -to- Sun's Reach, Isle of Quel'Danas
			"Shattrath City/0 48.58,42.02 -to- Isle of Quel'Danas/0 48.25,34.48 {mode:PORTAL} {title:Click the Shattrath Portal\nto Isle of Quel'Danas} "..
			"{cond:PlayerCompletedQuest(11534)}",


	-- SHATTRATH PORTALS:
		"Shattrath City/0 55.19,36.49 -to- Darnassus/0 39.69,82.44 {fac:A} {mode:PORTAL} {cost:15}",
		"Shattrath City/0 55.80,36.63 -to- Stormwind City/0 49.59,86.53 {fac:A} {mode:PORTAL}",
		"Shattrath City/0 56.32,36.87 -to- Ironforge/0 25.51,8.43 {fac:A} {mode:PORTAL}",
		"Shattrath City/0 59.53,46.65 -to- The Exodar/0 47.62,59.82 {fac:A} {mode:PORTAL}",

		"Shattrath City/0 52.77,53.09 -to- Thunder Bluff/0 22.21,16.87 {fac:H} {mode:PORTAL}",
		"Shattrath City/0 52.19,52.81 -to- Orgrimmar/0 38.64,85.94 {fac:H} {mode:PORTAL}",
		"Shattrath City/0 51.65,52.56 -to- Undercity/0 84.58,16.33 {fac:H} {mode:PORTAL}",
		"Shattrath City/0 59.17,48.32 -to- Silvermoon City/0 58.26,19.24 {fac:H} {mode:PORTAL}",
	
-------------------------
-- BOATS AND ZEPPELINS --
-------------------------

	--## ALLIANCE ##--

		-- Stormwind City (Elwynn Forest) / Auberdine (Darkshore) Boat
			"Stormwind City/0 22.49,56.18 -x- Darkshore/0 32.42,43.82 {fac:A} {mode:SHIP} {title_atob:Ride the Boat to Auberdine} {title_btoa:Ride the Boat to Stormwind}",
		
		-- Rut'theran Village (Teldrassil) / Auberdine (Darkshore) Boat
			"Teldrassil 54.86,96.79 <region:ruttheran> -x- Darkshore 33.19,40.13 {fac:A} {mode:SHIP} {title_atob:Ride the Boat to Auberdine} {title_btoa:Ride the Boat to Rut'theran Village}",

		-- Menethil Harbor (Wetlands) / Theramore Isle (Dustwallow Marsh) Boat
			"Wetlands 5.08,63.40 -x- Dustwallow Marsh 71.54,56.34 {fac:A} {mode:SHIP} {title_atob:Ride the Boat to Theramore Isle} {title_btoa:Ride the Boat to Menethil Harbor}",

		-- Azuremyst Isle / Auberdine (Darkshore) Boat
			"Azuremyst Isle/0 20.42,54.17 -x- Darkshore 30.77,41.00 {fac:A} {mode:SHIP} {title_atob:Ride the Boat to Darkshore} {title_btoa:Ride the Boat to Azuremyst Isle}",

		-- DEEPRUN TRAM (Ironforge / Stormwind City)
			-- Stormwind - Elwyyn Forest, Eastern Kingdoms --
			--"Stormwind City/0 69.62,31.11 -x- Deeprun Tram/1 42.53,11.53 @deeprun_sw {mode:PORTAL} {title_atob:Enter the Deeprun Tram Portal\nand Ride the Tram to Ironforge} "..
			--	"{title_btoa:Enter Ironforge through the Portal}",

			-- Ironforge - Dun Morogh, Eastern Kingdoms --
			--"Ironforge/0 76.93,51.25 -x- Deeprun Tram/1 45.77,12.47 @deeprun_if {mode:PORTAL} {title_atob:Enter the Deeprun Tram Portal\nand Ride the Tram to Stormwind City} "..
			--	"{title_btoa:Ride the Tram to Ironforge\nand Enter Ironforge through the Portal}",
			"Stormwind City/0 69.12,30.79 -x- Ironforge 72.90,50.27 {fac:A} {mode:PORTAL} {cost:500} {title_atob:Ride the Deeprun Tram to Ironforge} {title_btoa:Ride the Deeprun Tram to Stormwind}",

		-- Stormwind City / Valiance Keep (Borean Tundra) Boat
			--"Stormwind City 18.04,25.49 -x- Borean Tundra 59.69,69.41 {mode:SHIP} {fac:A} {title_atob:Ride the Boat to Valiance Keep in Borean Tundra} {title_btoa:Ride the Boat to Stormwind City}",

		-- Menethil Harbor (Wetlands) / Valgarde (Howling Fjord) Boat
			--"Wetlands 4.65,57.11 -x- Howling Fjord 61.34,62.59 {mode:SHIP} {fac:A} {title_atob:Ride the Boat to Valgarde in Howling Fjord} {title_btoa:Ride the Boat to Menethil Harbor}",

		-- Stormwind City / Valiance Keep (Borean Tundra) NPC
			"Stormwind City/0 18.47,26.48 -to- Borean Tundra/0 59.60,69.33 {fac:A} {mode:PORTAL} {title:Talk to Leesha Tannerby\nTell her |cfff0e081\"I'd like to take the\nship to Valiance Keep.\"|r}",

		-- Valiance Keep (Borean Tundra) NPC / Stormwind City
			"Borean Tundra/0 59.70,69.26 -to- Stormwind City/0 18.47,26.48 {fac:A} {mode:PORTAL} {title:Talk to Nelno Copperbeam\nTell him |cfff0e081\"I'd like to take the\nship to Stormwind Harbor.\"|r}",

		-- Menethil Harbor (Wetlands) / Valgarde (Howling Fjord) NPC
			"Wetlands/0 4.53,57.28 -to- Howling Fjord/0 61.28,62.68 {fac:A} {mode:PORTAL} {title:Talk to Ludin Farrow\nTell him |cfff0e081\"I'd like to take the\nship to Valgarde.\"|r}",

		-- Valgarde (Howling Fjord) NPC / Menethil Harbor (Wetlands)
			"Howling Fjord/0 61.31,62.57 -to- Wetlands/0 4.68,57.11 {fac:A} {mode:PORTAL} {title:Talk to Basil Crowe\nTell him |cfff0e081\"I'd like to take the\nship to Menethil Harbor.\"|r}",


	--## HORDE ##--

		-- Undercity (Tirisfal Glades) / Orgrimmar (Durotar) Zeppelin
			"Tirisfal Glades 60.70,58.76 -x- Durotar 50.82,13.81 {fac:H} {mode:ZEPPELIN} {title_atob:Ride the Zeppelin to Orgrimmar} {title_btoa:Ride the Zeppelin to Undercity}",

		-- Undercity (Tirisfal Glades) / Grom'gol Base Camp (Stranglethorn Vale) Zeppelin
			"Tirisfal Glades 61.88,59.10 -x- Stranglethorn Vale 31.53,29.15 {fac:H} {mode:ZEPPELIN} {title_atob:Ride the Zeppelin to Grom'gol Base Camp} {title_btoa:Ride the Zeppelin to Undercity}",

		-- Orgrimmar (Durotar) / Grom'gol Base Camp (Stranglethorn Vale) Zeppelin
			"Durotar 50.57,12.66 -x- Stranglethorn Vale 31.35,30.12 {fac:H} {mode:ZEPPELIN} {title_atob:Ride the Zeppelin to Grom'gol Base Camp} {title_btoa:Ride the Zeppelin to Orgrimmar}",
	
		-- Undercity (Tirisfal Glades) / Vengeance Landing (Howling Fjord) Zeppelin
			--"Tirisfal Glades 59.08,59.01 -x- Howling Fjord 77.73,28.32 {fac:H} {mode:ZEPPELIN} {title_atob:Ride the Zeppelin to Vengeance Landing} {title_btoa:Ride the Zeppelin to Undercity}",

		-- Orgrimmar (Durotar) / Warsong Hold (Borean Tundra) Zeppelin
			--"Durotar 41.36,17.73 -x- Borean Tundra 41.38,53.60 {fac:H} {mode:ZEPPELIN} {title_atob:Ride the Zeppelin to Warsong Hold} {title_btoa:Ride the Zeppelin to Orgrimmar}",

		-- Durotar / Valiance Keep (Borean Tundra) NPC
			"Durotar/0 41.42,17.98 -to- Borean Tundra/0 41.47,53.77 {fac:H} {mode:PORTAL} {title:Talk to Greeb Ramrocket\nTell him |cfff0e081\"I'd like to take the\nzeppelin to Warsong Hold.\"|r}",

		-- Valiance Keep (Borean Tundra) NPC / Durotar
			"Borean Tundra/0 41.53,54.12 -to- Durotar/0 41.43,18.05 {fac:H} {mode:PORTAL} {title:Talk to Nargo Screwbore\nTell him |cfff0e081\"I'd like to take the\nzeppelin to Durotar.\"|r}",

		--Undercity (Tirisfal Glades) / Vengeance Landing (Howling Fjord) NPC
			"Tirisfal Glades/0 59.21,59.07 -to- Howling Fjord/0 77.73,28.30 {fac:H} {mode:PORTAL} {title:Talk to Meefi Farthrottle\nTell her |cfff0e081\"I'd like to take the\nzeppelin to Vengeance Landing.\"|r}",

		-- Vengeance Landing (Howling Fjord) NPC / Undercity (Tirisfal Glades)
			"Howling Fjord/0 77.69,28.32 -to- Tirisfal Glades/0 59.28,58.92 {fac:H} {mode:PORTAL} {title:Talk to Drenk Spannerspark\nTell him |cfff0e081\"I'd like to take the\nzeppelin to Tirisfal Glades.\"|r}",


	--## NEUTRAL ##--

		-- Booty Bay (Stranglethorn Vale) -x- Rachet (The Barrens) Boat
			"Stranglethorn Vale 25.92,73.15 -x- The Barrens 63.66,38.65 {fac:B} {mode:SHIP} {title_atob:Ride the Boat to Ratchet} {title_btoa:Ride the Boat to Booty Bay}",

		-- Dragonblight Kalu'ak ships
			"Borean Tundra 78.90,53.60 <radius:30> -x- Dragonblight 48.00,78.70 <radius:30> {cost:500} {fac:B} {mode:SHIP} {title_atob:Ride the Boat to Dragonblight} {title_btoa:Ride the Boat to Borean Tundra}",
			"Dragonblight 49.60,78.40 <radius:30> -x- Howling Fjord 23.50,57.80 <radius:30> {cost:500} {fac:B} {mode:SHIP} {title_atob:Ride the Boat to Howling Fjord} {title_btoa:Ride the Boat to Dragonblight}",
	---------------
	-- NORTHREND --
	---------------

	--## ALLIANCE ##--

		-- Dalaran - Crystalsong Forest, Northrend -to- Stormwind City - Elwynn Forest, Eastern Kingdoms
		"Dalaran/1 40.11,62.80 -to- Stormwind City/0 46.35,90.23 {fac:A} {mode:PORTAL} {title:Click the Dalaran Portal to Stormwind}",

		-- Dalaran - Crystalsong Forest, Northrend -to- Ironforge - Dun Morogh, Eastern Kingdoms
		"Dalaran/1 39.48,63.98 -to- Ironforge/0 25.52,8.41 {fac:A} {mode:PORTAL} {title:Click the Dalaran Portal to Ironforge}",

		-- Dalaran - Crystalsong Forest, Northrend -to- Darnassus - Teldrassil, Kalimdor
		"Dalaran/1 38.84,65.16 -to- Darnassus/0 40.13,81.83 {fac:A} {mode:PORTAL} {title:Click the Dalaran Portal to Darnassus}",

		-- Dalaran - Crystalsong Forest, Northrend -to- Exodar - Azuremyst Isle, Kalimdor
		"Dalaran/1 38.21,66.34 -to- The Exodar/0 47.62,59.82 {fac:A} {mode:PORTAL} {title:Click the Dalaran Portal to Exodar}",

		-- Dalaran - Crystalsong Forest, Northrend -to- Shattrath City - Terokkar Forest, Outland
		"Dalaran/1 37.05,66.72 -to- Shattrath City/0 54.97,40.23 {fac:A} {mode:PORTAL} {title:Click the Dalaran Portal to Shattrath}",

		-- Dalaran - Crystalsong Forest, Northrend -to- Wintergrasp Fortress - Wintergrasp, Northrend --
		--"Dalaran 33.6,68.6 -to- Wintergrasp 50.0,16.7 {fac:A} {mode:PORTAL} {cond:hasbuff("spell:57940" or hasbuff("spell:58045")}",

		-- Wintergrasp Fortress - Wintergrasp, Northrend -to- Dalaran - Crystalsong Forest, Northrend --
		--"Wintergrasp/0 49.10,15.32 -to- Dalaran 33.6,68.6 {fac:A} {mode:PORTAL} {cond:hasbuff("spell:57940" or hasbuff("spell:58045")} "..
			--"{title:Click the Portal to The Violet Citadel}",

	--## HORDE ##--

		-- Dalaran - Crystalsong Forest, Northrend -to- Orgrimmar - Durotar, Kalimdor
		"Dalaran/1 55.30,25.46 -to- Orgrimmar/0 38.57,85.95 {fac:H} {mode:PORTAL} {title:Click the Dalaran Portal to Orgrimmar}",

		-- Dalaran - Crystalsong Forest, Northrend -to- Undercity - Tirisfal Glades, Kalimdor
		"Dalaran/1 55.63,23.85 -to- Undercity/0 84.65,16.32 {fac:H} {mode:PORTAL} {title:Click the Dalaran Portal to Undercity}",

		-- Dalaran - Crystalsong Forest, Northrend -to- Shattrath City - Terokkar Forest, Outland
		"Dalaran/1 56.31,22.59 -to- Shattrath City/0 53.01,49.21 {fac:H} {mode:PORTAL} {title:Click the Dalaran Portal to Shattrath}",

		-- Dalaran - Crystalsong Forest, Northrend -to- Thunder Bluff - Mulgore, Kalimdor
		"Dalaran/1 57.25,21.82 -to- Thunder Bluff/0 22.35,16.52 {fac:H} {mode:PORTAL} {title:Click the Dalaran Portal to Thunder Bluff}",

		-- Dalaran - Crystalsong Forest, Northrend -to- Silvermoon City - Eversong Woods, Eastern Kingdoms
		"Dalaran/1 58.32,21.61 -to- Silvermoon City/0 58.26,19.24 {fac:H} {mode:PORTAL} {title:Click the Dalaran Portal to Silvermoon City}",

		-- Dalaran - Crystalsong Forest, Northrend -to- Wintergrasp Fortress - Wintergrasp, Northrend --
		--"Dalaran 33.6,68.6 -to- Wintergrasp 50.0,16.7 {fac:H} {mode:PORTAL} {cond:hasbuff("spell:57940" or hasbuff("spell:58045")}",

		-- Wintergrasp Fortress - Wintergrasp, Northrend -to- Dalaran - Crystalsong Forest, Northrend --
		--"Wintergrasp/0 49.10,15.32 -to- Dalaran/1 26.84,44.71 {fac:H} {mode:PORTAL} {cond:hasbuff("spell:57940" or hasbuff("spell:58045")} "..
			--"{title:Click the Portal to The Violet Citadel}",

	--## NEUTRAL ##--

		-- Dalaran - Crystalsong Forest, Northrend -to- The Violet Stand - Crystalsong Forest, Northrend --CHECKED
		--"Dalaran/1 55.93,46.77 -to- Crystalsong Forest/0 15.81,42.85 {mode:PORTAL} {title:Click the Teleport to Violet Stand Crystal Inside the Building}",

			-- The Violet Stand - Crystalsong Forest, Northrend -to- Dalaran - Crystalsong Forest, Northrend --CHECKED
			--"Crystalsong Forest/0 15.74,42.47 -to- Dalaran/1 55.92,46.79 {mode:PORTAL} {title:Click the Teleport to Dalaran Crystal}",






------------------
-- CLASS SPELLS --
------------------

	----------------
	---   MAGE   ---		-- NOTE: ACCOUNT FOR "Rune of Teleportation" REQUIRED TO CAST TELEPORT SPELLS
	----------------
	
	--## ALLIANCE ##--
		-- Teleport: Darnassus
			"Darnassus/0 40.13,81.83	<spell:3565>	<faction:A>",

		-- Teleport: Exodar
			"The Exodar/0 47.62,59.82	<spell:32271>	<faction:A>",
		
		-- Teleport: Ironforge
			"Ironforge/0 25.52,8.41		<spell:3562>	<faction:A>",

		-- Teleport: Shattrath
			"Shattrath City/0 54.97,40.23	<spell:33690>	<faction:A>",
		
		-- Teleport: Stormwind
			"Stormwind City/0 49.59,86.53	<spell:3561>	<faction:A>",

		-- Teleport: Theramore
			"Dustwallow Marsh/0 66.00,48.99	<spell:49359>	<faction:A>",

		



	--## HORDE ##--
		-- Teleport: Orgrimmar
			"Orgrimmar/0 38.57,85.95	<spell:3567>	<faction:H>",

		-- Teleport: Shattrath
			"Shattrath City/0 53.01,49.21	<spell:35715>	<faction:H>",

		-- Teleport: Silvermoon
			"Silvermoon City/0 58.26,19.24	<spell:32272>	<faction:H>",

		-- Teleport: Stonard
			"Swamp of Sorrows/0 48.33,55.47	<spell:49358>	<faction:H>",

		-- Teleport: Thunder Bluff
			"Thunder Bluff/0 22.35,16.52	<spell:3566>	<faction:H>",

		-- Teleport: Undercity
			"Undercity/0 84.65,16.32	<spell:3563>	<faction:H>",

		
		
		
		
	

	-----------------
	---   DRUID   ---
	-----------------
		-- Teleport: Moonglade
			"Moonglade 56.26,32.46		<spell:18960>",
	
		-- Teleport: Dalaran
			"Dalaran/1 55.92,46.79		<spell:53140>",


	------------------
	---   SHAMAN   ---
	------------------

		-- NOTE: ADD "Astral Recall" SPELL, IF POSSIBLE.
}
