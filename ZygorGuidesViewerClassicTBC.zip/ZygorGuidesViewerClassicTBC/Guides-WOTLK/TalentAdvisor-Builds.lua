local ZygorTalentAdvisor=ZygorGuidesViewer.ZTA
if not ZygorTalentAdvisor then return end

--/run local c=0 for _,d in pairs(ZGV.ZTA.currentBuild.maxcounts) do for _,p in pairs(d) do c=c+p end end print(c)
--Run 

------------------------------
------   Death Knight   ------
------------------------------

ZygorTalentAdvisor:RegisterBuild("DEATHKNIGHT","Unholy Leveling (12/0/59)",3,[[
	--Level 10-11
	2/2 Vicious Strikes
	--Level 12-14
	3/3 Virulence
	--Level 15-17
	3/3 Morbidity
	--Level 18-20
	3/3 Ravenous Dead
	--Level 21-22
	2/2 Outbreak
	--Level 23-27
	5/5 Necrosis
	--Level 28-29
	2/2 On a Pale Horse
	--Level 30-32
	3/3 Blood-Caked Blade
	--Level 33-34
	2/2 Night of the Dead
	--Level 35-39
	5/5 Impurity
	--Level 40
	1/1 Master of Ghouls
	--Level 41-42
	2/2 Desecration
	--Level 43
	1/1 Ghoul Frenzy
	--Level 44-48
	5/5 Desolation
	--Level 49
	1/1 Bone Shield
	--Level 50-52
	3/3 Crypt Fever
	--Level 53-55
	3/3 Wandering Plague
	--Level 56-58
	3/3 Ebon Plaguebringer
	--Level 59
	1 Rage of Rivendare
	--Level 60
	1/1 Summon Gargoyle
	--Level 61-64
	4 Rage of Rivendare --5/5 Now
	--Level 65
	1/1 Scourge Strike
	--Level 66-68
	3/3 Reaping
	--Level 69-70
	2/2 Butchery
	--Level 71-73
	3 Blade Barrier
	--Level 74-75
	2/2 Two-Handed Weapon Specialization
	--Level 76-80
	5/5 Bladed Armor
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of the Ghoul
	--Major Glyph 2 Level 20
	Major Glyph of Icy Touch
	--Major Glyph 3 Level 80
	Major Glyph of Dark Death
	--Minor Glyph 1 Level 15
	Minor Glyph of Raise Dead
	--Minor Glyph 2 Level 50
	Minor Glyph of Pestilence
	--Minor Glyph 3 Level 70
	Minor Glyph of Horn of Winter
]])

ZygorTalentAdvisor:RegisterBuild("DEATHKNIGHT","Blood Tank Leveling (51/20/0)",1,[[
	--Level 10-14
	5/5 Blade Barrier
	--Level 69-70
	2/2 Butchery
	--Level 18-19
	2/2 Two-Handed Weapon Specialization
	--Level 15-17
	5/5 Bladed Armor
	--Level 20
	1/1 Rune Tap
	--Level 23-24
	5/5 Dark Conviction
	--Level 49-51
	3/3 Death Rune Mastery
	--Level 25-27
	3/3 Improved Rune Tap
	--Level 33-35
	3/3 Vendetta
	--Level 33-35
	3/3 Veteran of the Third War
	--Level 30-32
	3/3 Bloody Strikes
	--Level 36-37
	2/2 Abomination's Might
	--Level 40
	1/1 Unholy Frenzy
	--Level 46-47
	2/2 Improved Death Strike
	--Level 45
	1/1 Vampiric Blood
	--Level 48
	1/1 Heart Strike
	--Level 48
	3/3 Might of Mograine
	--Level 48
	5/5 Blood Gorged
	--Level 48
	1/1 Dancing Rune Weapon
	--Level 55-57
	3/3 Improved Icy Touch
	--Level 58-59
	2 Toughness
	--Level 60-64
	5/5 Black Ice
	--Level 65-67
	5/5 Icy Talons
	--Level 39
	2/2 Endless Winter
	--Level 68-70
	3 Toughness --5/5 Now
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Disease
	--Major Glyph 2 Level 20
	Major Glyph of Vampiric Blood
	--Major Glyph 3 Level 80
	Major Glyph of Icy Touch
	--Minor Glyph 1 Level 15
	Minor Glyph of Pestilence
	--Minor Glyph 2 Level 50
	Minor Glyph of Raise Dead
	--Minor Glyph 3 Level 70
	Minor Glyph of Blood Tap
]])

ZygorTalentAdvisor:RegisterBuild("DEATHKNIGHT","Frost DPS Leveling (13/58/0)",2,[[
	--Level 10-12
	3/3 Improved Icy Touch
	--Level 13-14
	2/2 Runic Power Mastery
	--Level 15-17
	3/3 Nerves of Cold Steel
	--Level 18-19
	5/5 Black Ice
	--Level 20-22
	3/3 Annihilation
	--Level 23-27
	5/5 Icy Talons
	--Level 28-32
	5/5 Killing Machine
	--Level 40-41
	2/2 Endless Winter
	--Level 33-35
	3/3 Glacier Rot
	--Level 36
	1/1 Improved Icy Talons
	--Level 37-39
	3/3 Rime
	--Level 63-64
	2/2 Merciless Combat
	--Level 45-47
	3/3 Chilblains
	--Level 36
	1/1 Hungering Cold
	--Level 45-47
	3/3 Threat of Thassarian
	--Level 65
	1/1 Unbreakable Armor
	--Level 50
	1/1 Frost Strike
	--Level 50
	1 Guile of Gorefiend
	--Level 61-62
	2/2 Icy Reach
	--Level 50
	1/1 Lichborne
	--Level 60
	1/1 Howling Blast
	--Level 50
	2 Guile of Gorefiend --3/3 Now
	--Level 66-68
	3 Blade Barrier
	--Level 55-59
	5/5 Tundra Stalker
	--Level 69-70
	2/2 Butchery
	--Level 52-54
	5/5 Bladed Armor
	--Level 52-54
	3/3 Death Rune Mastery
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Frost Strike
	--Major Glyph 2 Level 20
	Major Glyph of Disease
	--Major Glyph 3 Level 80
	Major Glyph of Icy Touch
	--Minor Glyph 1 Level 15
	Minor Glyph of Pestilence
	--Minor Glyph 2 Level 50
	Minor Glyph of Raise Dead
	--Minor Glyph 3 Level 70
	Minor Glyph of Blood Tap
]])

-----------------------
------   Druid   ------
-----------------------

ZygorTalentAdvisor:RegisterBuild("DRUID","Feral DPS Leveling (0/55/16)",2,[[
	--Level 10-14
	5/5 Ferocity
	--Level 15-16
	2/2 Savage Fury
	--Level 17-19
	3/3 Feral Instinct
	--Level 20-21
	2/2 Feral Swiftness
	--Level 22-24
	3/3 Sharpened Claws
	--Level 30-31
	2/2 Primal Precision
	--Level 25-27
	3/3 Predatory Strikes
	--Level 34
	1/1 Feral Charge
	--Level 28-29
	2/2 Primal Fury
	--Level 28-29
	2/2 Nurturing Instinct
	--Level 43-45
	3/3 Survival of the Fittest
	--Level 43-45
	2 Natural Reaction
	--Level 40
	1/1 Leader of the Pack
	--Level 43-45
	1 Natural Reaction --3/3 Now
	--Level 60
	1/1 Survival Instincts
	--Level 35-39
	2 Heart of the Wild
	--Level 41-42
	3/3 Protector of the Pack
	--Level 35-39
	2 Heart of the Wild --4/5 Now
	--Level 50
	1/1 Mangle
	--Level 50
	3/3 Improved Mangle
	--Level 35-39
	1 Heart of the Wild --5/5 Now
	--Level 55-59
	5/5 Rend and Tear
	--Level 61
	1/1 Primal Gore
	--Level 60
	1/1 Berserk
	--Level 51-53
	3/3 King of the Jungle
	--Level 62-63
	2/2 Improved Mark of the Wild
	--Level 64-66
	3 Furor
	--Level 67-70
	5/5 Naturalist
	--Level 32-33
	1/1 Omen of Clarity
	--Level 46-48
	3/3 Natural Shapeshifter
	--Level 32-33
	2/2 Master Shapeshifter
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Rip
	--Major Glyph 2 Level 20
	Major Glyph of Shred
	--Major Glyph 3 Level 80
	Major Glyph of Claw
	--Minor Glyph 1 Level 15
	Minor Glyph of the Wild
	--Minor Glyph 2 Level 50
	Minor Glyph of Dash
	--Minor Glyph 3 Level 70
	Minor Glyph of Unburdened Rebirth
]])

ZygorTalentAdvisor:RegisterBuild("DRUID","Feral Tank Leveling (0/55/16)",2,[[
	--Level 10-14
	5/5 Ferocity
	--Level 15-16
	2/2 Savage Fury
	--Level 17-19
	3/3 Feral Instinct
	--Level 20-21
	2/2 Feral Swiftness
	--Level 22-24
	3/3 Sharpened Claws
	--Level 30-31
	2/2 Primal Precision
	--Level 25-27
	3/3 Predatory Strikes
	--Level 34
	1/1 Feral Charge
	--Level 28-29
	2/2 Primal Fury
	--Level 28-29
	2/2 Nurturing Instinct
	--Level 43-45
	3/3 Survival of the Fittest
	--Level 43-45
	2 Natural Reaction
	--Level 40
	1/1 Leader of the Pack
	--Level 43-45
	1 Natural Reaction --3/3 Now
	--Level 60
	1/1 Survival Instincts
	--Level 35-39
	2 Heart of the Wild
	--Level 41-42
	3/3 Protector of the Pack
	--Level 35-39
	2 Heart of the Wild --4/5 Now
	--Level 50
	1/1 Mangle
	--Level 50
	3/3 Improved Mangle
	--Level 35-39
	1 Heart of the Wild --5/5 Now
	--Level 55-59
	5/5 Rend and Tear
	--Level 61
	1/1 Primal Gore
	--Level 60
	1/1 Berserk
	--Level 51-53
	3/3 King of the Jungle
	--Level 62-63
	2/2 Improved Mark of the Wild
	--Level 64-66
	3 Furor
	--Level 67-70
	5/5 Naturalist
	--Level 32-33
	1/1 Omen of Clarity
	--Level 46-48
	3/3 Natural Shapeshifter
	--Level 32-33
	2/2 Master Shapeshifter
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Maul
	--Major Glyph 2 Level 20
	Major Glyph of Frenzied Regeneration
	--Major Glyph 3 Level 80
	Major Glyph of Survival Instincts
	--Minor Glyph 1 Level 15
	Minor Glyph of the Wild
	--Minor Glyph 2 Level 50
	Minor Glyph of Dash
	--Minor Glyph 3 Level 70
	Minor Glyph of Challenging Roar
]])

ZygorTalentAdvisor:RegisterBuild("DRUID","Restoration Healer Leveling (11/0/60)",3,[[
	--Level 10-12
	3/3 Nature's Focus
	--Level 13-14
	2/2 Improved Mark of the Wild
	--Level 15-17
	3/3 Natural Shapeshifter
	--Level 18-19
	2 Subtlety
	--Level 20
	1/1 Omen of Clarity
	--Level 21-23
	3/3 Intensity
	--Level 24-25
	2/2 Master Shapeshifter
	--Level 26-28
	3/3 Improved Rejuvenation
	--Level 26-28
	1 Tranquil Spirit
	--Level 30
	1/1 Nature's Swiftness
	--Level 31-35
	5/5 Gift of Nature
	--Level 36-39
	4 Nature's Bounty
	--Level 40
	1/1 Swiftmend
	--Level 41-43
	3/3 Living Spirit
	--Level 44
	1 Nature's Bounty --5/5 Now
	--Level 45-49
	5/5 Empowered Rejuvenation
	--Level 50
	1/1 Tree of Life
	--Level 54
	3 Revitalize
	--Level 51-53
	1 Improved Tree of Life
	--Level 55-59
	5/5 Gift of the Earthmother
	--Level 60
	1/1 Wild Growth
	--Level 51-53
	2 Improved Tree of Life --3/3 Now
	--Level 63-67
	5/5 Genesis
	--Level 68-70
	3/3 Moonglow
	--Level 29
	2/2 Nature's Majesty
	--Level 29
	1/1 Nature's Splendor
	--Level 68-70
	3/3 Living Seed
	--Level 29
	2/2 Empowered Touch
	--Level 51-53
	2 Natural Perfection
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Rejuvenation
	--Major Glyph 2 Level 20
	Major Glyph of Rebirth
	--Major Glyph 3 Level 80
	Major Glyph of Wild Growth
	--Minor Glyph 1 Level 15
	Minor Glyph of the Wild
	--Minor Glyph 2 Level 50
	Minor Glyph of Dash
	--Minor Glyph 3 Level 70
	Minor Glyph of Unburdened Rebirth
]])

ZygorTalentAdvisor:RegisterBuild("DRUID","Balance DPS Leveling (58/0/13)",1,[[
	--Level 10-14
	5/5 Starlight Wrath
	--Level 15-16
	2/2 Improved Moonfire
	--Level 17-18
	2/2 Nature's Majesty
	--Level 19
	1 Moonglow
	--Level 23
	1/1 Nature's Splendor
	--Level 24-25
	2/2 Nature's Reach
	--Level 24-25
	2 Brambles
	--Level 44
	3/3 Celestial Focus
	--Level 24-25
	1 Brambles --3/3 Now
	--Level 20-22
	1 Nature's Grace
	--Level 30
	1/1 Insect Swarm
	--Level 31-33
	3/3 Lunar Guidance
	--Level 20-22
	1 Nature's Grace --2/3 Now
	--Level 35-37
	3/3 Moonfury
	--Level 35-37
	2 Dreamstate
	--Level 40
	1/1 Moonkin Form
	--Level 41-43
	3/3 Improved Moonkin Form
	--Level 35-37
	1 Dreamstate --3/3 Now
	--Level 50-52
	3/3 Owlkin Frenzy
	--Level 20-22
	1 Nature's Grace --3/3 Now
	--Level 45-49
	1 Wrath of Cenarius
	--Level 53
	1/1 Force of Nature
	--Level 59
	1/1 Typhoon
	--Level 64-65
	2/2 Gale Winds
	--Level 45-49
	1 Wrath of Cenarius --2/5 Now
	--Level 55-57
	3/3 Earth and Moon
	--Level 45-49
	2 Wrath of Cenarius --4/5 Now
	--Level 60
	1/1 Starfall
	--Level 66-67
	2/2 Improved Mark of the Wild
	--Level 68-70
	5/5 Furor
	--Level 46-48
	3/3 Natural Shapeshifter
	--Level 32-33
	2/2 Master Shapeshifter
	--Level 32-33
	1/1 Omen of Clarity
	--Level 45-49
	1 Wrath of Cenarius --5/5 Now
	--Level 26-29
	5/5 Vengeance
	--Level 38-39
	1 Genesis
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Moonfire
	--Major Glyph 2 Level 20
	Major Glyph of Starfire
	--Major Glyph 3 Level 80
	Major Glyph of Starfall
	--Minor Glyph 1 Level 15
	Minor Glyph of the Wild
	--Minor Glyph 2 Level 50
	Minor Glyph of Dash
	--Minor Glyph 3 Level 70
	Minor Glyph of Unburdened Rebirth
]])

------------------------
------   Hunter   ------
------------------------

ZygorTalentAdvisor:RegisterBuild("HUNTER","Beast Mastery DPS Leveling (53/18/0)",1,[[
	--Level 10-14
	5/5 Improved Aspect of the Hawk
	--Level 15-16
	2/2 Improved Revive Pet
	--Level 17-18
	2/2 Focused Fire
	--Level 19
	1 Endurance Training
	--Level 20
	1/1 Aspect Mastery
	--Level	21-25
	5/5 Unleashed Fury
	--Level 26-29
	4 Ferocity
	--Level 30
	1/1 Intimidation
	--Level 31-32
	2/2 Bestial Discipline
	--Level 26-29
	1 Ferocity --5/5 Now
	--Level 33
	1 Spirit Bond
	--Level 37-39
	4 Frenzy
	--Level 35-36
	1 Animal Handler
	--Level 40
	1/1 Bestial Wrath
	--Level 35-36
	1 Animal Handler --2/2 Now
	--Level 41-43
	3/3 Ferocious Inspiration
	--Level 45-49
	5/5 Serpent's Swiftness
	--Level 50
	1/1 The Beast Within
	--Level 51-53
	2/2 Invigoration
	--Level 54
	2 Longevity
	--Level 55-59
	5/5 Kindred Spirits
	--Level 60
	1/1 Beast Mastery
	--Level 63-67
	5/5 Lethal Shots
	--Level 63-67
	5/5 Mortal Shots
	--Level 34
	1/1 Aimed Shot
	--Level 51-53
	2/2 Rapid Killing
	--Level 51-53
	2/2 Go for the Throat
	--Level 33
	1 Spirit Bond --2/2 Now
	--Level 68-70
	3/3 Focused Aim
	--Level 61-62
	1 Longevity --3/3 Now
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Bestial Wrath
	--Major Glyph 2 Level 20
	Major Glyph of Steady Shot
	--Major Glyph 3 Level 80
	Major Glyph of Serpent Sting
	--Minor Glyph 1 Level 15
	Minor Glyph of Mend Pet
	--Minor Glyph 2 Level 50
	Minor Glyph of Revive Pet
	--Minor Glyph 3 Level 70
	Minor Glyph of Feign Death
]])

ZygorTalentAdvisor:RegisterBuild("HUNTER","Marksmanship DPS Leveling (7/57/7)",2,[[
	--Level 63-67
	5/5 Lethal Shots
	--Level 63-67
	5/5 Mortal Shots
	--Level 34
	1/1 Aimed Shot
	--Level 51-53
	2/2 Go for the Throat
	--Level 51-53
	2/2 Rapid Killing
	--Level 10-12
	3/3 Focused Aim
	--Level 24
	2 Careful Aim
	--Level 30
	1/1 Readiness
	--Level 32-34
	3/3 Barrage
	--Level 24
	1 Careful Aim --3/3 Now
	--Level 35-37
	3/3 Ranged Weapon Specialization
	--Level 38-39
	2/2 Combat Experience
	--Level 40
	1/1 Trueshot Aura
	--Level 41-43
	3/3 Piercing Shots
	--Level 44
	1 Improved Barrage
	--Level 45-49
	5/5 Master Marksman
	--Level 60
	1/1 Silencing Shot
	--Level 25-27
	2/2 Rapid Recuperation
	--Level 53-54
	2 Wild Quiver
	--Level 55-59
	5/5 Marked for Death
	--Level 60
	1/1 Chimera Shot
	--Level 61
	1 Wild Quiver --3/3 Now
	--Level 50-52
	3/3 Improved Steady Shot
	--Level 44
	2 Improved Barrage --3/3 Now
	--Level 62-66
	5/5 Improved Tracking
	--Level 62-66
	5/5 Improved Aspect of the Hawk
	--Level 69-70
	2/2 Focused Fire
	--Level 69-70
	2/2 Survival Instincts
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Steady Shot
	--Major Glyph 2 Level 20
	Major Glyph of Serpent Sting
	--Major Glyph 3 Level 80
	Major Glyph of Kill Shot
	--Minor Glyph 1 Level 15
	Minor Glyph of Mend Pet
	--Minor Glyph 2 Level 50
	Minor Glyph of Revive Pet
	--Minor Glyph 3 Level 70
	Minor Glyph of Feign Death
]])

ZygorTalentAdvisor:RegisterBuild("HUNTER","Survival DPS Leveling (5/15/51)",3,[[
	--Level 10-14
	5/5 Improved Tracking
	--Level 18-19
	2/2 Survival Instincts
	--Level 15-17
	3/3 Trap Mastery
	--Level 15-17
	3/3 Hawk Eye
	--Level 15-17
	2 Entrapment
	--Level 25-27
	3/3 Lock and Load
	--Level 28-29
	3/3 T.N.T.
	--Level 30-32
	3/3 Killer Instinct
	--Level 15-17
	1 Entrapment --3/3 Now
	--Level 35-39
	5/5 Lightning Reflexes
	--Level 40
	1/1 Wyvern Sting
	--Level 44
	3/3 Expose Weakness
	--Level 41-43
	1 Thrill of the Hunt
	--Level 48-49
	5/5 Master Tactician
	--Level 50
	1/1 Black Arrow
	--Level 51-53
	3/3 Sniper Training
	--Level 41-43
	2 Thrill of the Hunt --3/3 Now
	--Level 45-47
	3/3 Resourcefulness
	--Level 59
	1 Hunting Party
	--Level 60
	1/1 Explosive Shot
	--Level 61-65
	5/5 Lethal Shots
	--Level 66-70
	5/5 Mortal Shots
	--Level 34
	1/1 Aimed Shot
	--Level 51-53
	1 Go for the Throat
	--Level 51-53
	2/2 Rapid Killing
	--Level 51-53
	1 Go for the Throat --2/2 Now
	--Level 62-66
	5/5 Improved Aspect of the Hawk
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Explosive Shot
	--Major Glyph 2 Level 20
	Major Glyph of Serpent Sting
	--Major Glyph 3 Level 80
	Major Glyph of Explosive Trap
	--Minor Glyph 1 Level 15
	Minor Glyph of Mend Pet
	--Minor Glyph 2 Level 50
	Minor Glyph of Revive Pet
	--Minor Glyph 3 Level 70
	Minor Glyph of Feign Death
]])

ZygorTalentAdvisor:RegisterBuild("PET Ferocity","Ferocity DPS (Wolf Recommended) Leveling",0,[[
	--Level 20
	Cobra Reflexes
	--Level 24
	Cobra Reflexes
	--Level 28
	Dive|Dash
	--Level 32
	Spiked Collar
	--Level 36
	Spiked Collar
	--Level 40
	Spiked Collar
	--Level 44
	Culling the Herd
	--Level 48
	Culling the Herd
	--Level 52
	Culling the Herd
	--Level 56
	Spider's Bite
	--Level 60
	Spider's Bite
	--Level 64
	Spider's Bite
	--Level 68
	Call of the Wild
	--Level 72
	Wild Hunt
	--Level 76
	Rabid
	--Level 80
	Bloodthirsty
	--Beast Mastery Bonus Talents-
	Wild Hunt
	Bloodthirsty
	Shark Attack
	Shark Attack
]])

ZygorTalentAdvisor:RegisterBuild("PET Cunning","Cunning PvP (Bird of Prey Recommended) Leveling",0,[[
	--Level 20
	Cobra Reflexes
	--Level 24
	Cobra Reflexes
	--Level 28
	Dive|Dash
	--Level 32
	Spiked Collar
	--Level 36
	Spiked Collar
	--Level 40
	Spiked Collar
	--Level 44
	Culling the Herd
	--Level 48
	Culling the Herd
	--Level 52
	Culling the Herd
	--Level 56
	Cornered
	--Level 60
	Cornered
	--Level 64
	Feeding Frenzy
	--Level 68
	Bullheaded
	--Level 72
	Wolverine Bite
	--Level 76
	Roar of Recovery
	--Level 80
	Wild Hunt
	--Beast Mastery Bonus Talents-
	Wild Hunt
	Lionhearted
	Lionhearted
	Boar's Speed
]])

ZygorTalentAdvisor:RegisterBuild("PET Tenacity","Tenacity Tank (Bear Recommended) Leveling",0,[[
	--Level 20
	Great Stamina
	--Level 24
	Great Stamina
	--Level 28
	Great Stamina
	--Level 32
	Blood of the Rhino
	--Level 36
	Blood of the Rhino
	--Level 40
	Natural Armor
	--Level 44
	Thunderstomp
	--Level 48
	Natural Armor
	--Level 52
	Pet Barding
	--Level 56
	Grace of the Mantis
	--Level 60
	Grace of the Mantis
	--Level 64
	Pet Barding
	--Level 68
	Roar of Sacrifice
	--Level 72
	Charge
	--Level 76
	Guard Dog
	--Level 80
	Wild Hunt
	--Beast Mastery Bonus Talents-
	Wild Hunt
	Culling the Herd
	Culling the Herd
	Culling the Herd
]])

----------------------
------   Mage   ------
----------------------

ZygorTalentAdvisor:RegisterBuild("MAGE","Frost DPS Leveling (18/0/53)",3,[[
	--Level 10-14
	5/5 Improved Frostbolt
	--Level 32-34
	3/3 Precision
	--Level 18-19
	2 Frostbite
	--Level 20
	1/1 Icy Veins
	--Level 18-19
	1 Frostbite --3/3 Now
	--Level 15-17
	3/3 Ice Shards
	--Level 25-27
	3/3 Shatter
	--Level 21-23
	2 Piercing Ice
	--Level 30
	1/1 Cold Snap
	--Level 21-23
	1 Piercing Ice --3/3 Now
	--Level 35-37
	3/3 Ice Floes
	--Level 35-37
	3/3 Winter's Chill
	--Level 51
	2/2 Arctic Reach
	--Level 40
	1/1 Ice Barrier
	--Level 41-44
	4 Arctic Winds
	--Level 47-48
	2/2 Fingers of Frost
	--Level 45-46
	2/2 Empowered Frostbolt
	--Level 41-44
	1 Arctic Winds --5/5 Now
	--Level 50
	1/1 Summon Water Elemental
	--Level 35-37
	3/3 Enduring Winter
	--Level 35-37
	3/3 Brain Freeze
	--Level 35-37
	5/5 Chilled to the Bone
	--Level 50
	1/1 Deep Freeze
	--Level 56-57
	2/2 Arcane Subtlety
	--Level 53-55
	3/3 Arcane Focus
	--Level 58-62
	5/5 Arcane Concentration
	--Level 63-65
	3/3 Spell Impact
	--Level 67
	2 Student of the Mind
	--Level 68-70
	3/3 Torment the Weak
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Eternal Water
	--Major Glyph 2 Level 20
	Major Glyph of Mana Gem
	--Major Glyph 3 Level 80
	Major Glyph of Molten Armor
	--Minor Glyph 1 Level 15
	Minor Glyph of Arcane Intellect
	--Minor Glyph 2 Level 50
	Minor Glyph of Slow Fall
	--Minor Glyph 3 Level 70
	Minor Glyph of Fire Ward
]])

ZygorTalentAdvisor:RegisterBuild("MAGE","Fire DPS Leveling (0/54/17)",2,[[
	--Level 10-14
	5/5 Improved Fireball
	--Level 15-19
	5/5 Ignite
	--Level 20
	1/1 Pyroblast
	--Level 21-22
	2/2 Burning Soul
	--Level 28-29
	3/3 World in Flames
	--Level 28-29
	3/3 Master of Elements
	--Level 25-27
	1 Improved Scorch
	--Level 30-32
	3/3 Critical Mass
	--Level 34
	2 Playing with Fire
	--Level 35-39
	5/5 Fire Power
	--Level 40
	1/1 Combustion
	--Level 41-43
	3/3 Pyromaniac
	--Level 44
	2/2 Molten Fury
	--Level 45-47
	3/3 Empowered Fire
	--Level 33
	1/1 Blast Wave
	--Level 51-53
	3/3 Hot Streak
	--Level 50
	1/1 Dragon's Breath
	--Level 54
	1 Firestarter
	--Level 55-59
	5/5 Burnout
	--Level 60
	1/1 Living Bomb
	--Level 25-27
	2 Improved Scorch --3/3 Now
	--Level 34
	1 Playing with Fire --3/3 Now
	--Level 63-65
	3/3 Ice Floes
	--Level 66-67
	2 Improved Frostbolt
	--Level 68-70
	3/3 Precision
	--Level 
	2 Permafrost
	--Level 
	1/1 Icy Veins
	--Level 
	3/3 Improved Blizzard
	--Level 
	3/3 Ice Shards
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Evocation
	--Major Glyph 2 Level 20
	Major Glyph of Mana Gem
	--Major Glyph 3 Level 80
	Major Glyph of Molten Armor
	--Minor Glyph 1 Level 15
	Minor Glyph of Arcane Intellect
	--Minor Glyph 2 Level 50
	Minor Glyph of Slow Fall
	--Minor Glyph 3 Level 70
	Minor Glyph of Fire Ward
]])

ZygorTalentAdvisor:RegisterBuild("MAGE","Arcane DPS Leveling (59/0/12)",1,[[
	--Level 35-37
	3 Arcane Stability
	--Level 10-12
	3 Arcane Focus
	--Level 35-37
	2 Arcane Stability --5/5 Now
	--Level 15-19
	5/5 Arcane Concentration
	--Level 13-14
	2/2 Magic Attunement
	--Level 44
	3/3 Arcane Meditation
	--Level 25-27
	2 Torment the Weak
	--Level 30
	1/1 Presence of Mind
	--Level 25-27
	1 Torment the Weak --3/3 Now
	--Level 31-34
	3 Arcane Mind
	--Level 38-39
	2/2 Arcane Potency
	--Level 35-37
	3/3 Arcane Instability
	--Level 40
	1/1 Arcane Power
	--Level 41-43
	3/3 Arcane Empowerment
	--Level 31-34
	1 Arcane Mind --4/5 Now
	--Level 45-46
	2/2 Arcane Flows
	--Level 47-49
	5/5 Mind Mastery
	--Level 31-34
	1 Arcane Mind --5/5 Now
	--Level 50-54
	2 Missile Barrage
	--Level 55-56
	2/2 Spell Power
	--Level 57-59
	3/3 Netherwind Presence
	--Level 60
	1/1 Arcane Barrage
	--Level 50-54
	3 Missile Barrage --5/5 Now
	--Level 20-22
	3/3 Spell Impact
	--Level 63-65
	3/3 Ice Floes
	--Level 66-67
	2 Improved Frostbolt
	--Level 68-70
	3/3 Precision
	--Level 63-65
	2 Ice Shards
	--Level 63-65
	1/1 Icy Veins
	--Level 63-65
	1 Ice Shards --3/3 Now
	--Level 13-14
	2/2 Arcane Subtlety
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Arcane Power
	--Major Glyph 2 Level 20
	Major Glyph of Arcane Missiles
	--Major Glyph 3 Level 80
	Major Glyph of Molten Armor
	--Minor Glyph 1 Level 15
	Minor Glyph of Arcane Intellect
	--Minor Glyph 2 Level 50
	Minor Glyph of Slow Fall
	--Minor Glyph 3 Level 70
	Minor Glyph of Fire Ward
]])

-------------------------
------   Paladin   ------
-------------------------

ZygorTalentAdvisor:RegisterBuild("PALADIN","Retribution DPS Leveling (7/7/57)",3,[[
	--Level 10-14
	5/5 Benediction
	--Level 18-19
	2/2 Improved Judgements
	--Level 15-17
	3/3 Heart of the Crusader
	--Level 20
	1/1 Seal of Command
	--Level 21-22
	2/2 Pursuit of Justice
	--Level 23-24
	2 Conviction
	--Level 62-64
	3/3 Crusade
	--Level 28-29
	2 Conviction --4/5 Now
	--Level 33
	1/1 Sanctified Retribution
	--Level 30-32
	3/3 Two-Handed Weapon Specialization
	--Level 34
	1 Conviction --5/5 Now
	--Level 35-37
	3/3 Vengeance
	--Level 38-39
	2/2 Divine Purpose
	--Level 41-43
	3/3 Judgements of the Wise
	--Level 40
	1/1 Repentance
	--Level 44
	2/2 The Art of War
	--Level 45-47
	3/3 Fanaticism
	--Level 48-49
	1 Sanctified Wrath
	--Level 50
	1/1 Crusader Strike
	--Level 25-27
	3/3 Sanctity of Battle
	--Level 51-53
	2 Sheath of Light
	--Level 55-57
	3/3 Righteous Vengeance
	--Level 51-53
	1 Sheath of Light --3/3 Now
	--Level 60
	1/1 Divine Storm
	--Level 58-59
	3/3 Swift Retribution
	--Level 38-39
	2/2 Improved Blessing of Might
	--Level 48-49
	1 Sanctified Wrath --2/2 Now
	--Level 65-69
	5/5 Divine Strength
	--Level 70
	5/5 Seals of the Pure
	--Level 38-39
	2/2 Guardian's Favor
	--Level 38-39
	2 Healing Light
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Judgement
	--Major Glyph 2 Level 20
	Major Glyph of Exorcism
	--Major Glyph 3 Level 80
	Major Glyph of Avenging Wrath
	--Minor Glyph 1 Level 15
	Minor Glyph of Lay on Hands
	--Minor Glyph 2 Level 50
	Minor Glyph of Sense Undead
	--Minor Glyph 3 Level 70
	Minor Glyph of Blessing of Kings
]])

ZygorTalentAdvisor:RegisterBuild("PALADIN","Holy Healer Leveling (51/20/0)",1,[[
	--Level 10-14
	5/5 Seals of the Pure
	--Level 18-19
	5/5 Divine Intellect
	--Level 15-17
	3/3 Healing Light
	--Level 44
	2/2 Improved Lay on Hands
	--Level 20-24
	5/5 Illumination
	--Level 30
	1/1 Divine Favor
	--Level 26-27
	2/2 Improved Blessing of Wisdom
	--Level 31-33
	2 Sanctified Light
	--Level 35-39
	5/5 Holy Power
	--Level 40
	1/1 Holy Shock
	--Level 41-43
	3/3 Light's Grace
	--Level 31-33
	1 Sanctified Light --3/3 Now
	--Level 45-49
	5/5 Holy Guidance
	--Level 50
	1/1 Divine Illumination
	--Level 51-54
	5/5 Judgements of the Pure
	--Level 57-58
	2/2 Enlightened Judgements
	--Level 55-56
	2/2 Infusion of Light
	--Level 60
	1/1 Beacon of Light
	--Level 10-14
	5/5 Divine Strength
	--Level 38-39
	2/2 Guardian's Favor
	--Level 41-43
	3/3 Stoicism
	--Level 10-14
	5/5 Toughness
	--Level 10-14
	3/3 Improved Righteous Fury
	--Level 10-14
	2/2 Improved Hammer of Justice
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Holy Light
	--Major Glyph 2 Level 20
	Major Glyph of Flash of Light
	--Major Glyph 3 Level 80
	Major Glyph of Divinity
	--Minor Glyph 1 Level 15
	Minor Glyph of Lay on Hands
	--Minor Glyph 2 Level 50
	Minor Glyph of Sense Undead
	--Minor Glyph 3 Level 70
	Minor Glyph of Blessing of Kings
]])

ZygorTalentAdvisor:RegisterBuild("PALADIN","Protection Tank Leveling (0/58/13)",2,[[
	--Level 10-14
	5/5 Divine Strength
	--Level 15-19
	3/3 Stoicism
	--Level 15-19
	2 Anticipation
	--Level 23
	1/1 Divine Sacrifice
	--Level 20-22
	3/3 Improved Righteous Fury
	--Level 24
	5/5 Toughness
	--Level 20-22
	1 Improved Hammer of Justice
	--Level 30
	1/1 Blessing of Sanctuary
	--Level 31-33
	5/5 Reckoning
	--Level 35-37
	3/3 One-Handed Weapon Specialization
	--Level 38-39
	1 Sacred Duty
	--Level 40
	1/1 Holy Shield
	--Level 44
	1 Spiritual Attunement
	--Level 41-43
	3/3 Ardent Defender
	--Level 48-49
	3/3 Combat Expertise
	--Level 45-47
	2 Redoubt
	--Level 50
	1/1 Avenger's Shield
	--Level 45-47
	1 Redoubt --3/3 Now
	--Level 51-53
	2/2 Guarded by the Light
	--Level 51-53
	3/3 Touched by the Light
	--Level 38-39
	1 Sacred Duty --2/2 Now
	--Level 55-57
	2 Shield of the Templar
	--Level 60
	1/1 Hammer of the Righteous
	--Level 55-57
	1 Shield of the Templar --3/3 Now
	--Level 20-22
	1 Improved Hammer of Justice --2/2 Now
	--Level 61-65
	5/5 Benediction
	--Level 66-67
	2/2 Improved Judgements
	--Level 68-70
	3/3 Heart of the Crusader
	--Level 60
	1/1 Seal of Command
	--Level 58-59
	2/2 Pursuit of Justice
	--Level 25-26
	2 Conviction
	--Level 25-26
	3/3 Crusade
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Judgement
	--Major Glyph 2 Level 20
	Major Glyph of Righteous Defense
	--Major Glyph 3 Level 80
	Major Glyph of Consecration
	--Minor Glyph 1 Level 15
	Minor Glyph of Lay on Hands
	--Minor Glyph 2 Level 50
	Minor Glyph of Sense Undead
	--Minor Glyph 3 Level 70
	Minor Glyph of Blessing of Kings
]])

------------------------
------   Priest   ------
------------------------

ZygorTalentAdvisor:RegisterBuild("PRIEST","Shadow DPS Leveling (13/0/58)",3,[[
	--Level 17-19
	3/3 Spirit Tap
	--Level 10-14
	2 Darkness
	--Level 32-34
	3/3 Shadow Focus
	--Level 10-14
	2 Darkness --4/5 Now
	--Level 20
	1/1 Mind Flay
	--Level 10-14
	1 Darkness --5/5 Now
	--Level 15-16
	2/2 Improved Shadow Word: Pain
	--Level 21-24
	1 Improved Mind Blast
	--Level 27-29
	3/3 Shadow Weaving
	--Level 25-26
	2/2 Shadow Reach
	--Level 30
	1/1 Vampiric Embrace
	--Level 30
	2/2 Improved Vampiric Embrace
	--Level 21-24
	2 Improved Mind Blast --3/5 Now
	--Level 35-37
	3/3 Improved Devouring Plague
	--Level 38-39
	2/2 Mind Melt
	--Level 40
	1/1 Shadowform
	--Level 21-24
	2 Improved Mind Blast --5/5 Now
	--Level 61-62
	2/2 Improved Spirit Tap
	--Level 47-49
	3/3 Misery
	--Level 45-46
	2/2 Improved Shadowform
	--Level 50
	1/1 Vampiric Touch
	--Level 51-53
	3/3 Pain and Suffering
	--Level 60
	1/1 Psychic Horror
	--Level 55-59
	5/5 Twisted Faith
	--Level 60
	1/1 Dispersion
	--Level 65-69
	5/5 Twin Disciplines
	--Level 51-53
	3/3 Improved Inner Fire
	--Level 51-53
	2/2 Improved Power Word: Fortitude
	--Level 51-53
	3/3 Meditation
	--Level 63-64
	2/2 Improved Psychic Scream
	--Level 60
	1/1 Silence
	--Level 41-44
	4 Shadow Power
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Mind Flay
	--Major Glyph 2 Level 20
	Major Glyph of Shadow Word: Pain
	--Major Glyph 3 Level 80
	Major Glyph of Fade
	--Minor Glyph 1 Level 15
	Minor Glyph of Fortitude
	--Minor Glyph 2 Level 50
	Minor Glyph of Shadow Protection
	--Minor Glyph 3 Level 70
	Minor Glyph of Levitate
]])

ZygorTalentAdvisor:RegisterBuild("PRIEST","Holy Healer Leveling (40/28/3)",2,[[
	--Level 17-19
	3/3 Spirit Tap
	--Level 23-24
	5/5 Holy Specialization
	--Level 15-19
	5/5 Divine Fury
	--Level 50
	1/1 Desperate Prayer
	--Level 13-14
	2/2 Healing Focus
	--Level 10-12
	2 Improved Renew
	--Level 13-14
	2/2 Searing Light
	--Level 28-29
	2/2 Holy Reach
	--Level 10-12
	1 Improved Renew --3/3 Now
	--Level 31-34
	5/5 Spiritual Guidance
	--Level 35-36
	2/2 Surge of Light
	--Level 30
	1/1 Spirit of Redemption
	--Level 64-68
	5/5 Twin Disciplines
	--Level 51-53
	3/3 Improved Inner Fire
	--Level 51-53
	2/2 Improved Power Word: Fortitude
	--Level 51-53
	3/3 Meditation
	--Level 50
	1/1 Inner Focus
	--Level 23-25
	1 Improved Power Word: Shield
	--Level 29-31
	3/3 Mental Agility
	--Level 23-25
	2 Improved Power Word: Shield --3/3 Now
	--Level 33-37
	5/5 Mental Strength
	--Level 41
	2/2 Focused Power
	--Level 38-40
	3/3 Enlightenment
	--Level 42
	1/1 Power Infusion
	--Level 69-70
	3/3 Focused Will
	--Level 32
	1/1 Soul Warding
	--Level 47-49
	3/3 Rapture
	--Level 50-51
	2/2 Renewed Hope
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Flash Heal
	--Major Glyph 2 Level 20
	Major Glyph of Power Word: Shield
	--Major Glyph 3 Level 80
	Major Glyph of Fade
	--Minor Glyph 1 Level 15
	Minor Glyph of Fortitude
	--Minor Glyph 2 Level 50
	Minor Glyph of Shadow Protection
	--Minor Glyph 3 Level 70
	Minor Glyph of Levitate
]])

ZygorTalentAdvisor:RegisterBuild("PRIEST","Discipline Healer Leveling (1-59) (30/17/3)",1,[[
	--Level 17-19
	3/3 Spirit Tap
	--Level 23-24
	5/5 Holy Specialization
	--Level 15-19
	5/5 Divine Fury
	--Level 50
	1/1 Desperate Prayer
	--Level 13-14
	2/2 Healing Focus
	--Level 10-12
	2 Improved Renew
	--Level 13-14
	2/2 Searing Light
	--Level 64-68
	5/5 Twin Disciplines
	--Level 51-53
	3/3 Improved Inner Fire
	--Level 51-53
	2/2 Improved Power Word: Fortitude
	--Level 51-53
	3/3 Meditation
	--Level 50
	1/1 Inner Focus
	--Level 23-25
	1 Improved Power Word: Shield
	--Level 29-31
	3/3 Mental Agility
	--Level 23-25
	2 Improved Power Word: Shield --3/3 Now
	--Level 41
	2/2 Reflective Shield
	--Level 32
	1/1 Soul Warding
	--Level 33-37
	2 Mental Strength
	--Level 41
	2/2 Focused Power
	--Level 38-40
	3/3 Enlightenment
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Power Word: Shield
	--Major Glyph 2 Level 20
	Major Glyph of Flash Heal
	--Major Glyph 3 Level 80
	Major Glyph of Fade
	--Minor Glyph 1 Level 15
	Minor Glyph of Fortitude
	--Minor Glyph 2 Level 50
	Minor Glyph of Shadow Protection
	--Minor Glyph 3 Level 70
	Minor Glyph of Levitate
]])

ZygorTalentAdvisor:RegisterBuild("PRIEST","Discipline Healer Leveling (60-80) (51/17/3)",1,[[
	--Level 64-68
	5/5 Twin Disciplines
	--Level 51-53
	3/3 Improved Inner Fire
	--Level 51-53
	2/2 Improved Power Word: Fortitude
	--Level 51-53
	3/3 Meditation
	--Level 50
	1/1 Inner Focus
	--Level 23-25
	1 Improved Power Word: Shield
	--Level 29-31
	3/3 Mental Agility
	--Level 23-25
	2 Improved Power Word: Shield --3/3 Now
	--Level 33-37
	5/5 Mental Strength
	--Level 41
	2/2 Reflective Shield
	--Level 32
	1/1 Soul Warding
	--Level 41
	2/2 Focused Power
	--Level 38-40
	3/3 Enlightenment
	--Level 50
	1/1 Power Infusion
	--Level 
	1 Focused Will
	--Level 
	3/3 Rapture
	--Level 
	2/2 Aspiration
	--Level 
	1 Renewed Hope
	--Level 
	1/1 Pain Suppression
	--Level 
	3/3 Divine Aegis
	--Level 
	5/5 Borrowed Time
	--Level 
	1/1 Penance
	--Level 17-19
	3/3 Spirit Tap
	--Level 23-24
	5/5 Holy Specialization
	--Level 15-19
	5/5 Divine Fury
	--Level 50
	1/1 Desperate Prayer
	--Level 13-14
	2/2 Healing Focus
	--Level 10-12
	2 Improved Renew
	--Level 13-14
	2/2 Searing Light
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Power Word: Shield
	--Major Glyph 2 Level 20
	Major Glyph of Flash Heal
	--Major Glyph 3 Level 80
	Major Glyph of Fade
	--Minor Glyph 1 Level 15
	Minor Glyph of Fortitude
	--Minor Glyph 2 Level 50
	Minor Glyph of Shadow Protection
	--Minor Glyph 3 Level 70
	Minor Glyph of Levitate
]])

-----------------------
------   Rogue   ------
-----------------------

ZygorTalentAdvisor:RegisterBuild("ROGUE","Subtlety DPS Leveling (5/15/51)",3,[[
	--Level 15-19
	5/5 Relentless Strikes
	--Level 22-24
	3/3 Camouflage
	--Level 20-21
	2/2 Opportunity
	--Level 35
	1/1 Ghostly Strike
	--Level 25-27
	3/3 Serrated Blades
	--Level 28-29
	2/2 Elusiveness
	--Level 30-32
	3/3 Initiative
	--Level 33-34
	1 Improved Ambush
	--Level 35
	1/1 Hemorrhage
	--Level 37-38
	2/2 Dirty Deeds
	--Level 36
	1/1 Preparation
	--Level 33-34
	1 Improved Ambush --2/2 Now
	--Level 40-44
	5/5 Deadliness
	--Level 45
	1/1 Premeditation
	--Level 46-48
	3/3 Master of Subtlety
	--Level 49
	1 Cheat Death
	--Level 50-54
	5/5 Sinister Calling
	--Level 55
	1/1 Shadowstep
	--Level 58-59
	3/3 Honor Among Thieves
	--Level 49
	1 Cheat Death --2/3 Now
	--Level 60-64
	5/5 Slaughter from the Shadows
	--Level 65
	1/1 Shadow Dance
	--Level 67-70
	5/5 Malice
	--Level 10-14
	5/5 Dual Wield Specialization
	--Level 10-14
	5/5 Precision
	--Level 10-14
	5/5 Close Quarters Combat
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Slice and Dice
	--Major Glyph 2 Level 20
	Major Glyph of Eviscerate
	--Major Glyph 3 Level 80
	Major Glyph of Evasion
	--Minor Glyph 1 Level 15
	Minor Glyph of Blurred Speed
	--Minor Glyph 2 Level 50
	Minor Glyph of Distract
	--Minor Glyph 3 Level 70
	Minor Glyph of Safe Fall
]])

ZygorTalentAdvisor:RegisterBuild("ROGUE","Combat DPS Leveling (13/58/0)",2,[[
	--Level 15-16
	2/2 Improved Sinister Strike
	--Level 10-14
	5/5 Dual Wield Specialization
	--Level 41-43
	3/3 Deflection
	--Level 66-70
	1 Riposte
	--Level 19-23
	2 Precision
	--Level 24
	2/2 Endurance
	--Level 25-27
	3/3 Lightning Reflexes
	--Level 17-18
	2/2 Improved Slice and Dice
	--Level 30
	1/1 Blade Flurry
	--Level 31-35
	5/5 Hack and Slash
	--Level 36-37
	2/2 Weapon Expertise
	--Level 38-39
	2/2 Blade Twisting
	--Level 40
	1/1 Adrenaline Rush
	--Level 41-43
	3/3 Vitality
	--Level 19-23
	1 Precision --3/5 Now
	--Level 45-49
	5/5 Combat Potency
	--Level 50
	1/1 Surprise Attacks
	--Level 38-39
	2/2 Unfair Advantage
	--Level 51-52
	2/2 Savage Combat
	--Level 55-59
	5/5 Prey on the Weak
	--Level 60
	1/1 Killing Spree
	--Level 19-23
	2 Precision --5/5 Now
	--Level 28-29
	5/5 Aggression
	--Level 66-70
	5/5 Malice
	--Level 61-65
	2/2 Remorseless Attacks
	--Level 24
	3/3 Ruthlessness
	--Level 24
	1/1 Vigor
	--Level 61-65
	2 Lethality
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Sinister Strike
	--Major Glyph 2 Level 20
	Major Glyph of Slice and Dice
	--Major Glyph 3 Level 80
	Major Glyph of Evasion
	--Minor Glyph 1 Level 15
	Minor Glyph of Blurred Speed
	--Minor Glyph 2 Level 50
	Minor Glyph of Distract
	--Minor Glyph 3 Level 70
	Minor Glyph of Safe Fall
]])

ZygorTalentAdvisor:RegisterBuild("ROGUE","Assassination DPS Leveling (1-49) (0/40/0)",1,[[
	--Level 15-16
	2/2 Improved Sinister Strike
	--Level 10-14
	5/5 Dual Wield Specialization
	--Level 41-43
	3/3 Deflection
	--Level 66-70
	1 Riposte
	--Level 19-23
	2 Precision
	--Level 24
	2/2 Endurance
	--Level 25-27
	3/3 Lightning Reflexes
	--Level 17-18
	2/2 Improved Slice and Dice
	--Level 30
	1/1 Blade Flurry
	--Level 31-35
	5/5 Hack and Slash
	--Level 36-37
	2/2 Weapon Expertise
	--Level 38-39
	2/2 Blade Twisting
	--Level 40
	1/1 Adrenaline Rush
	--Level 41-43
	3/3 Vitality
	--Level 19-23
	1 Precision --3/5 Now
	--Level 45-49
	5/5 Combat Potency
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Sinister Strike
	--Major Glyph 2 Level 20
	Major Glyph of Slice and Dice
	--Major Glyph 3 Level 80
	Major Glyph of Evasion
	--Minor Glyph 1 Level 15
	Minor Glyph of Blurred Speed
	--Minor Glyph 2 Level 50
	Minor Glyph of Distract
	--Minor Glyph 3 Level 70
	Minor Glyph of Safe Fall
]])

ZygorTalentAdvisor:RegisterBuild("ROGUE","Assassination DPS Leveling (50-80) (51/18/2)",1,[[
	--Level 66-70
	5/5 Malice
	--Level 61-65
	2/2 Remorseless Attacks
	--Level 24
	3/3 Puncturing Wounds
	--Level 61-65
	5/5 Lethality
	--Level 30-32
	3/3 Vile Poisons
	--Level 38-39
	4 Improved Poisons --4/5 Now
	--Level 35
	1/1 Cold Blood
	--Level 36-37
	2/2 Fleet Footed
	--Level 36-37
	2/2 Quick Recovery
	--Level 40-44
	5/5 Seal Fate
	--Level 46-47
	2/2 Murder
	--Level 45
	1/1 Overkill
	--Level 50-52
	3/3 Focused Attacks
	--Level 53-54
	2 Find Weakness
	--Level 55
	1/1 Mutilate
	--Level 20-21
	2/2 Opportunity
	--Level 53-54
	1 Find Weakness --3/3 Now
	--Level 56-58
	3/3 Master Poisoner
	--Level 60-64
	5/5 Cut to the Chase
	--Level 65
	1/1 Hunger For Blood
	--Level 10-14
	5/5 Dual Wield Specialization
	--Level 10-14
	5/5 Precision
	--Level 15-19
	5/5 Close Quarters Combat
	--Level 30-32
	3/3 Lightning Reflexes
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Mutilate
	--Major Glyph 2 Level 20
	Major Glyph of Slice and Dice
	--Major Glyph 3 Level 80
	Major Glyph of Evasion
	--Minor Glyph 1 Level 15
	Minor Glyph of Blurred Speed
	--Minor Glyph 2 Level 50
	Minor Glyph of Distract
	--Minor Glyph 3 Level 70
	Minor Glyph of Safe Fall
]])

------------------------
------   Shaman   ------
------------------------

ZygorTalentAdvisor:RegisterBuild("SHAMAN","Restoration Healer Leveling (0/13/58)",3,[[
	--Level 10-14
	5/5 Improved Healing Wave
	--Level 15-19
	5/5 Tidal Focus
	--Level 23
	1/1 Tidal Force
	--Level 34
	3/3 Ancestral Healing
	--Level 20-22
	1 Healing Focus
	--Level 44
	5/5 Tidal Mastery
	--Level 30
	1/1 Nature's Swiftness
	--Level 31-33
	3/3 Healing Way
	--Level 27-29
	1 Restorative Totems
	--Level 35-39
	5/5 Purification
	--Level 27-29
	2 Restorative Totems --3/3 Now
	--Level	40
	1/1 Mana Tide Totem
	--Level 20-22
	2 Healing Focus --3/3 Now
	--Level 48-49
	2/2 Blessing of the Eternals
	--Level 45-47
	3/3 Nature's Blessing
	--Level 50
	1/1 Earth Shield
	--Level 51-52
	2/2 Improved Earth Shield
	--Level 53-54
	2 Ancestral Awakening
	--Level 55-59
	5/5 Tidal Waves
	--Level 60
	1/1 Riptide
	--Level 61
	1 Ancestral Awakening --3/3 Now
	--Level 62-63
	2/2 Improved Chain Heal
	--Level 41
	1/1 Cleanse Spirit
	--Level 24-26
	3/3 Improved Water Shield
	--Level 13-14
	5/5 Ancestral Knowledge
	--Level 15-19
	5/5 Thundering Strikes
	--Level 24
	3/3 Improved Shields
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Earth Shield
	--Major Glyph 2 Level 20
	Major Glyph of Earthliving Weapon
	--Major Glyph 3 Level 80
	Major Glyph of Lesser Healing Wave
	--Minor Glyph 1 Level 15
	Minor Glyph of Water Shield
	--Minor Glyph 2 Level 50
	Minor Glyph of Renewed Life
	--Minor Glyph 3 Level 70
	Minor Glyph of Water Walking
]])

ZygorTalentAdvisor:RegisterBuild("SHAMAN","Enhancement DPS Leveling (19/52/0)",2,[[
	--Level 10-12
	3/3 Enhancing Totems
	--Level 13-14
	2 Ancestral Knowledge
	--Level 15-19
	5/5 Thundering Strikes
	--Level 20
	1/1 Shamanistic Focus
	--Level 21-23
	3/3 Elemental Weapons
	--Level 13-14
	1 Ancestral Knowledge --3/5 Now
	--Level 25-29
	5/5 Flurry
	--Level 30
	1/1 Spirit Weapons
	--Level 31-33
	3/3 Mental Dexterity
	--Level 34
	1 Improved Windfury Totem
	--Level 35-37
	3/3 Unleashed Rage
	--Level 38-39
	2 Weapon Mastery
	--Level 41
	1/1 Stormstrike
	--Level 40
	1/1 Dual Wield
	--Level 54
	1 Weapon Mastery --3/3 Now
	--Level 42-44
	2 Dual Wield Specialization
	--Level 49
	2/2 Improved Stormstrike
	--Level 42-44
	1 Dual Wield Specialization --3/3 Now
	--Level 34
	1 Improved Windfury Totem --2/2 Now
	--Level 45
	1/1 Lava Lash
	--Level 50
	1/1 Shamanistic Rage
	--Level 51-53
	3/3 Mental Quickness
	--Level 62-66
	5/5 Concussion
	--Level 51-53
	3/3 Call of Flame
	--Level 67-69
	2 Elemental Devastation
	--Level 60
	1/1 Elemental Focus
	--Level 55-59
	4 Elemental Fury
	--Level 55-59
	2/2 Improved Fire Nova
	--Level 13-14
	1 Ancestral Knowledge --4/5 Now
	--Level 55-59
	5/5 Maelstrom Weapon
	--Level 60
	1/1 Feral Spirit
	--Level 55-59
	1 Elemental Fury --5/5 Now
	--Level 67-69
	1 Elemental Devastation --3/3 Now
	--Level 13-14
	1 Ancestral Knowledge --5/5 Now
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Windfury Weapon
	--Major Glyph 2 Level 20
	Major Glyph of Lightning Shield
	--Major Glyph 3 Level 80
	Major Glyph of Fire Nova
	--Minor Glyph 1 Level 15
	Minor Glyph of Water Walking
	--Minor Glyph 2 Level 50
	Minor Glyph of Water Breathing
	--Minor Glyph 3 Level 70
	Minor Glyph of Renewed Life
]])

ZygorTalentAdvisor:RegisterBuild("SHAMAN","Elemental DPS Leveling (60/11/0)",1,[[
	--Level 10-14
	5/5 Concussion
	--Level 15-17
	3/3 Call of Flame
	--Level 18-19
	2 Elemental Warding
	--Level 20
	1/1 Elemental Focus
	--Level 18-19
	1 Elemental Warding --3/3 Now
	--Level 21-24
	3 Elemental Fury
	--Level 29
	2/2 Improved Fire Nova
	--Level 25-27
	3/3 Eye of the Storm
	--Level 30
	1/1 Call of Thunder
	--Level 28
	2 Elemental Fury --5/5 Now
	--Level 31-32
	2/2 Elemental Reach
	--Level 35-39
	5/5 Lightning Mastery
	--Level 40
	1/1 Elemental Mastery
	--Level 41-43
	3/3 Storm, Earth and Fire
	--Level 44
	1 Elemental Precision
	--Level 45-46
	2/2 Elemental Oath
	--Level 47-49
	3/3 Lightning Overload
	--Level 50
	1/1 Totem of Wrath
	--Level 51-52
	2/2 Booming Echoes
	--Level 44
	2 Elemental Precision --3/3 Now
	--Level 55-59
	5/5 Shamanism
	--Level 60
	1/1 Thunderstorm
	--Level 18-19
	2/2 Earth's Grasp
	--Level 61-65
	3 Ancestral Knowledge
	--Level 66-70
	5/5 Thundering Strikes
	--Level 34
	1/1 Shamanistic Focus
	--Level 34
	3/3 Unrelenting Storm
	--Level 34
	3/3 Lava Flows
	--Level 18-19
	3 Convection
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Lightning Bold
	--Major Glyph 2 Level 20
	Major Glyph of Totem of Wrath
	--Major Glyph 3 Level 80
	Major Glyph of Fire Nova
	--Minor Glyph 1 Level 15
	Minor Glyph of Water Walking
	--Minor Glyph 2 Level 50
	Minor Glyph of Water Shield
	--Minor Glyph 3 Level 70
	Minor Glyph of Renewed Life
]])

-------------------------
------   Warlock   ------
-------------------------

ZygorTalentAdvisor:RegisterBuild("WARLOCK","Destruction DPS Leveling (0/12/59)",3,[[
	--Level 10-14
	5/5 Bane
	--Level 15-16
	2/2 Aftermath
	--Level 17-19
	3/3 Cataclysm
	--Level 29
	5/5 Ruin
	--Level 27-28
	2/2 Demonic Power
	--Level 20
	1/1 Shadowburn
	--Level 25-26
	2/2 Intensity
	--Level 31-33
	3/3 Backlash
	--Level 34-36
	3/3 Improved Immolate
	--Level 30
	1/1 Devastation
	--Level 37-39
	3 Emberstorm
	--Level 40
	1/1 Conflagrate
	--Level 41-42
	2 Emberstorm --5/5 Now
	--Level 43-44
	3/3 Pyroclasm
	--Level 45-49
	5/5 Shadow and Flame
	--Level 50
	1/1 Shadowfury
	--Level 51-53
	3/3 Backdraft
	--Level 66-68
	3/3 Empowered Imp
	--Level 55-59
	2 Fire and Brimstone
	--Level 60
	1/1 Chaos Bolt
	--Level 55-59
	3 Fire and Brimstone --5/5 Now
	--Level 54
	3/3 Improved Imp
	--Level 54
	3/3 Demonic Embrace
	--Level 27-28
	1 Fel Synergy
	--Level 54
	3/3 Fel Vitality
	--Level 54
	1/1 Fel Domination
	--Level 54
	3/3 Soul Leech
	--Level 54
	2/2 Improved Soul Leech
	--Level 27-28
	1/1 Soul Link
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Incinerate
	--Major Glyph 2 Level 20
	Major Glyph of Imp
	--Major Glyph 3 Level 80
	Major Glyph of Healthstone
	--Minor Glyph 1 Level 15
	Minor Glyph of Drain Soul
	--Minor Glyph 2 Level 50
	Minor Glyph of Unending Breath
	--Minor Glyph 3 Level 70
	Minor Glyph of Subjugate Demon
]])

ZygorTalentAdvisor:RegisterBuild("WARLOCK","Demonology DPS Leveling (0/39/32)",2,[[
	--Level 54
	3/3 Improved Imp
	--Level 27-28
	2/2 Fel Synergy
	--Level 54
	3/3 Fel Vitality
	--Level 54
	2 Demonic Embrace
	--Level 54
	3/3 Demonic Aegis
	--Level 54
	1/1 Fel Domination
	--Level 27-28
	1/1 Soul Link
	--Level 25-29
	5/5 Unholy Power
	--Level 33-34
	2/2 Master Conjuror
	--Level 20
	1/1 Mana Feed
	--Level 30-31
	1 Master Summoner
	--Level 54
	1 Demonic Embrace --3/3 Now
	--Level 35-39
	5/5 Master Demonologist
	--Level 41-43
	3/3 Molten Core
	--Level 40
	1/1 Demonic Empowerment
	--Level 44
	3/3 Demonic Knowledge
	--Level 51-52
	2/2 Decimation
	--Level 61-65
	5/5 Bane
	--Level 17-19
	3/3 Cataclysm
	--Level 15-16
	2/2 Aftermath
	--Level 29
	5/5 Ruin
	--Level 27-28
	2/2 Demonic Power
	--Level 20
	1/1 Shadowburn
	--Level 25-26
	2/2 Intensity
	--Level 30
	1/1 Devastation
	--Level 34-36
	3/3 Improved Immolate
	--Level 31-33
	1 Backlash
	--Level 37-39
	5/5 Emberstorm
	--Level 40
	1/1 Conflagrate
	--Level 31-33
	1 Backlash --2/3 Now
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Shadow Bolt
	--Major Glyph 2 Level 20
	Major Glyph of Corruption
	--Major Glyph 3 Level 80
	Major Glyph of Healthstone
	--Minor Glyph 1 Level 15
	Minor Glyph of Drain Soul
	--Minor Glyph 2 Level 50
	Minor Glyph of Unending Breath
	--Minor Glyph 3 Level 70
	Minor Glyph of Subjugate Demon
]])

ZygorTalentAdvisor:RegisterBuild("WARLOCK","Affliction DPS Leveling (62/9/0)",1,[[
	--Level 10-14
	5/5 Improved Corruption
	--Level 15-16
	2/2 Soul Siphon
	--Level 19
	2/2 Improved Life Tap
	--Level 31-34
	1 Suppression
	--Level 20-22
	3/3 Fel Concentration
	--Level 31-34
	2 Suppression --3/3 Now
	--Level 27-29
	3/3 Empowered Corruption
	--Level 19
	2/2 Grim Reach
	--Level 30
	1/1 Siphon Life
	--Level 31-34
	4 Shadow Embrace
	--Level 35-39
	5/5 Shadow Mastery
	--Level 40-44
	5/5 Contagion
	--Level 48-49
	3/3 Eradication
	--Level 45-47
	2 Malediction
	--Level 50
	1/1 Unstable Affliction
	--Level 51
	1/1 Pandemic
	--Level 45-47
	1 Malediction --3/3 Now
	--Level 31-34
	1 Shadow Embrace --5/5 Now
	--Level 54
	1 Death's Embrace
	--Level 55-59
	5/5 Everlasting Affliction
	--Level 60
	1/1 Haunt
	--Level 66-67
	2 Death's Embrace --3/3 Now
	--Level 24
	2/2 Improved Curse of Agony
	--Level 24
	2/2 Improved Felhunter
	--Level 60
	1/1 Amplify Curse
	--Level 24
	2/2 Improved Howl of Terror
	--Level 25-26
	2/2 Nightfall
	--Level 27-28
	2/2 Fel Synergy
	--Level 54
	3/3 Demonic Embrace
	--Level 54
	3/3 Fel Vitality
	--Level 24
	1 Improved Healthstone
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Shadow Bolt
	--Major Glyph 2 Level 20
	Major Glyph of Corruption
	--Major Glyph 3 Level 80
	Major Glyph of Healthstone
	--Minor Glyph 1 Level 15
	Minor Glyph of Drain Soul
	--Minor Glyph 2 Level 50
	Minor Glyph of Unending Breath
	--Minor Glyph 3 Level 70
	Minor Glyph of Subjugate Demon
]])

-------------------------
------   Warrior   ------
-------------------------

ZygorTalentAdvisor:RegisterBuild("WARRIOR","Protection Tank Leveling (1-57) (0/0/48)",3,[[
	--Level 33-34
	3/3 Improved Thunder Clap
	--Level 10-14
	2 Shield Specialization
	--Level 15-17
	3/3 Incite
	--Level 10-14
	2 Shield Specialization --4/5 Now
	--Level 21-22
	2/2 Improved Revenge
	--Level 23-24
	2/2 Shield Mastery
	--Level 10-14
	1 Shield Specialization --5/5 Now
	--Level 21-22
	2/2 Improved Bloodrage
	--Level 18-19
	3 Anticipation
	--Level 30
	1/1 Concussion Blow
	--Level 18-19
	2 Anticipation --5/5 Now
	--Level 44
	2/2 Improved Disciplines
	--Level 35-39
	5/5 One-Handed Weapon Specialization
	--Level 41-42
	2/2 Improved Defensive Stance
	--Level 45-47
	3/3 Focused Rage
	--Level 45-47
	3/3 Vitality
	--Level 31-32
	2/2 Gag Order
	--Level 50
	1/1 Devastate
	--Level 51
	1/1 Warbringer
	--Level 52-54
	3/3 Critical Block
	--Level 55-57
	3/3 Sword and Board
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Heroic Strike
	--Major Glyph 2 Level 20
	Major Glyph of Revenge
	--Major Glyph 3 Level 80
	Major Glyph of Cleaving
	--Minor Glyph 1 Level 15
	Minor Glyph of Thunder Clap
	--Minor Glyph 2 Level 50
	Minor Glyph of Bloodrage
	--Minor Glyph 3 Level 70
	Minor Glyph of Charge
]])

ZygorTalentAdvisor:RegisterBuild("WARRIOR","Protection Tank Leveling (58-80) (37/2/32)",3,[[
	--Level 10-14
	4 Shield Specialization --4/5 Now
	--Level 33-34
	3/3 Improved Thunder Clap
	--Level 15-17
	3/3 Incite
	--Level 21-22
	2/2 Improved Revenge
	--Level 63-67
	5/5 Deflection
	--Level 44
	1 Improved Heroic Strike
	--Level 21-22
	2/2 Improved Charge
	--Level 33-34
	3/3 Iron Will
	--Level 33-34
	3/3 Tactical Mastery
	--Level 44
	1/1 Anger Management
	--Level 21-22
	2/2 Impale
	--Level 33-34
	3/3 Deep Wounds
	--Level 44
	1/1 Sweeping Strikes
	--Level 35-39
	5/5 Poleaxe Specialization
	--Level 21-22
	2/2 Weapon Mastery
	--Level 21-22
	2/2 Trauma
	--Level 44
	1/1 Mortal Strike
	--Level 21-22
	2/2 Second Wind
	--Level 21-22
	2/2 Strength of Arms
	--Level 21-22
	2/2 Unrelenting Assault
	--Level 23-24
	2/2 Shield Mastery
	--Level 10-14
	1 Shield Specialization --5/5 Now
	--Level 21-22
	2/2 Improved Bloodrage
	--Level 18-19
	3 Anticipation
	--Level 30
	1/1 Concussion Blow
	--Level 31-32
	2/2 Gag Order
	--Level 18-19
	2 Anticipation --5/5 Now
	--Level 35-39
	5/5 One-Handed Weapon Specialization
	--Level 41-42
	2/2 Improved Defensive Stance
	--Level 49
	2 Armored to the Teeth
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Heroic Strike
	--Major Glyph 2 Level 20
	Major Glyph of Revenge
	--Major Glyph 3 Level 80
	Major Glyph of Cleaving
	--Minor Glyph 1 Level 15
	Minor Glyph of Thunder Clap
	--Minor Glyph 2 Level 50
	Minor Glyph of Bloodrage
	--Minor Glyph 3 Level 70
	Minor Glyph of Charge
]])

ZygorTalentAdvisor:RegisterBuild("WARRIOR","2-H Fury DPS Leveling (18/53/0)",2,[[
	--Level 10-14
	5/5 Cruelty
	--Level 15-17
	3/3 Armored to the Teeth
	--Level	18-19
	2/2 Booming Voice
	--Level 20-24
	5/5 Commanding Presence
	--Level 25-29
	5/5 Dual Wield Specialization
	--Level 31-33
	3/3 Precision
	--Level 30
	1/1 Death Wish
	--Level 30
	1/1 Piercing Howl
	--Level 35-39
	5/5 Flurry
	--Level 40
	1/1 Bloodthirst
	--Level 44
	2/2 Improved Whirlwind
	--Level 45-49
	2/2 Improved Berserker Rage
	--Level 45-49
	5/5 Improved Berserker Stance
	--Level 50
	1/1 Rampage
	--Level 52-54
	3/3 Bloodsurge
	--Level 41-43
	1 Intensify Rage
	--Level 55-59
	5/5 Unending Fury
	--Level 60
	1/1 Titan's Grip
	--Level 60
	5/5 Deflection
	--Level 21-22
	2/2 Improved Charge
	--Level 33-34
	3/3 Tactical Mastery
	--Level 62-63
	2/2 Impale
	--Level 64-66
	3/3 Deep Wounds
	--Level 35-39
	3/3 Two-Handed Weapon Specialization
	--Level 41-43
	2 Intensify Rage --3/3 Now
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Victory Rush
	--Major Glyph 2 Level 20
	Major Glyph of Whirlwind
	--Major Glyph 3 Level 80
	Major Glyph of Cleaving
	--Minor Glyph 1 Level 15
	Minor Glyph of Battle
	--Minor Glyph 2 Level 50
	Minor Glyph of Bloodrage
	--Minor Glyph 3 Level 70
	Minor Glyph of Enduring Victory
]])

ZygorTalentAdvisor:RegisterBuild("WARRIOR","Arms DPS Leveling (55/8/8)",1,[[
	--Level 13-14
	2/2 Improved Rend
	--Level 10-12
	1 Improved Heroic Strike
	--Level 60
	2 Deflection
	--Level 18-19
	2/2 Improved Charge
	--Level 60
	3 Deflection --5/5 Now
	--Level 20-21
	2/2 Impale
	--Level 32-33
	2/2 Improved Overpower
	--Level 10-12
	1/1 Anger Management
	--Level 28-29
	3/3 Taste for Blood
	--Level 25-27
	2 Two-Handed Weapon Specialization
	--Level 30
	1/1 Sweeping Strikes
	--Level 25-27
	1 Two-Handed Weapon Specialization --3/3 Now
	--Level 22-24
	3/3 Deep Wounds
	--Level 49
	2/2 Weapon Mastery
	--Level 35-36
	2/2 Trauma
	--Level 34
	1 Poleaxe Specialization
	--Level 43-44
	2/2 Improved Slam
	--Level 40
	1/1 Mortal Strike
	--Level 41-42
	2/2 Strength of Arms
	--Level 46-47
	2/2 Unrelenting Assault
	--Level 37-39
	3 Poleaxe Specialization --4/5 Now
	--Level 50
	1/1 Endless Rage
	--Level 51-52
	2/2 Blood Frenzy
	--Level 48
	1 Poleaxe Specialization --5/5 Now
	--Level 53-54
	1 Sudden Death
	--Level 55-59
	5/5 Wrecking Crew
	--Level 60
	1/1 Bladestorm
	--Level 68-70
	3/3 Armored to the Teeth
	--Level 63-67
	5/5 Cruelty
	--Level 53-54
	2 Sudden Death --3/3 Now
	--Level 51-52
	2/2 Second Wind
	--Level 51-52
	2/2 Improved Bloodrage
	--Level 68-70
	3/3 Improved Thunder Clap
	--Level 68-70
	3/3 Incite
]],[[
	--Major Glyph 1 Level 15
	Major Glyph of Rending
	--Major Glyph 2 Level 20
	Major Glyph of Heroic Strike
	--Major Glyph 3 Level 80
	Major Glyph of Cleaving
	--Minor Glyph 1 Level 15
	Minor Glyph of Thunder Clap
	--Minor Glyph 2 Level 50
	Minor Glyph of Bloodrage
	--Minor Glyph 3 Level 70
	Minor Glyph of Charge
]])

--ZygorTalentAdvisor:RegisterBuild("CLASSNAMECAPS","SpecName DPS/Tank/Healer (5/56/0)",2,[[
--The #/#/# is the number of talents alloted to the corresponding talent tree.
--The number following that is the number matching the talent spec in Data\Item-Statweights.lua	
	--Level #-#
	--#/# Talent Name
	--Level #-#
	--#/# Talent Name
--]],[[
	--Major Glyph 1 Level 15
	--Major Glyph of 
	--Major Glyph 2 Level 20
	--Major Glyph of 
	--Major Glyph 3 Level 80
	--Major Glyph of 
	--Minor Glyph 1 Level 15
	--Minor Glyph of 
	--Minor Glyph 2 Level 50
	--Minor Glyph of 
	--Minor Glyph 3 Level 70
	--Minor Glyph of 
--]])