local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end

ZygorGuidesViewer:RegisterGuide("Leveling Guides\\Points of interest",{
	poiloader = true
},[[
	step
		Please select a point of interest from world map.
]])
