local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end
if UnitFactionGroup("player")~="Horde" then return end
if ZGV:DoMutex("LevelingHLK") then return end
ZygorGuidesViewer.GuideMenuTier = "TRI"
ZygorGuidesViewer:RegisterGuide("Leveling Guides\\Starter Guides (1-12) & Death Knight (55-58)\\Death Knight Starter (55-58)",{
author="support@zygorguides.com",
image=ZGV.IMAGESDIR.."Death Knight",
condition_valid=function() return raceclass('DeathKnight') end,
condition_valid_msg="Death Knight only.",
condition_suggested=function() return (raceclass('DeathKnight') and not completedq(13189)) end,
condition_suggested_exclusive=true,
condition_end=function() return completedq(13189) end,
},[[
step
talk The Lich King##25462
|tip On the upper floor of the floating building.
accept In Service Of The Lich King##12593 |goto Plaguelands: The Scarlet Enclave 51.34,35.18
step
talk Instructor Razuvious##28357
|tip He walks around this area, on the upper floor of the floating building.
turnin In Service Of The Lich King##12593 |goto 48.27,28.38
accept The Emblazoned Runeblade##12619 |goto 48.27,28.38
step
click Battle-worn Sword##190584+
|tip They look like swords leaning up against objects around this area.
|tip On the upper floor of the floating building.
collect Battle-worn Sword##38607 |goto 47.82,27.77 |q 12619
step
use the Battle-worn Sword##38607
|tip Next to a Runeforge.
|tip They look like large skulls with grey metal pipes connected to them, next to the wall around this area.
|tip On the upper floor of the floating building.
collect Runebladed Sword##38631 |q 12619/1 |goto 47.88,27.54
step
talk Instructor Razuvious##28357
|tip He walks around this area, on the upper floor of the floating building.
turnin The Emblazoned Runeblade##12619 |goto 48.27,28.38
accept Runeforging: Preparation For Battle##12842 |goto 48.27,28.38
step
cast Runeforging##53428
|tip Next to a Runeforge.
|tip They look like large skulls with grey metal pipes connected to them, next to the wall around this area.
|tip On the upper floor of the floating building.
Engrave the Rune
|tip Choose the rune you prefer and click the "Engrave" button.
|tip Select the sword you received in the previous step.
Emblazon Your Weapon |q 12842/1 |goto 47.88,27.54
step
talk Instructor Razuvious##28357
|tip He walks around this area, on the upper floor of the floating building.
turnin Runeforging: Preparation For Battle##12842 |goto 48.27,28.38
accept The Endless Hunger##12848 |goto 48.27,28.38
step
click Acherus Soul Prison##8115+
|tip They look like horned skulls on the wall, chaining the prisoners around this area.
|tip On the upper floor of the floating building.
Watch the dialogue
kill Unworthy Initiate##29565
Dominate an Unworthy Initiate |q 12848/1 |goto 48.87,29.67
step
talk Instructor Razuvious##28357
|tip He walks around this area, on the upper floor of the floating building.
turnin The Endless Hunger##12848 |goto 48.27,28.38
accept The Eye Of Acherus##12636 |goto 48.27,28.38
step
talk The Lich King##25462
|tip On the upper floor of the floating building.
turnin The Eye Of Acherus##12636 |goto 51.34,35.18
accept Death Comes From On High##12641 |goto 51.34,35.18
step
click Eye of Acherus Control Mechanism##191609
Take Control of the Eye of Acherus |havebuff spell:51852 |goto 52.13,35.21 |q 12641
step
Watch the dialogue
|tip You will automatically fly away while controlling the Eye of Acherus.
Reach New Avalon |complete subzone("New Avalon") |q 12641
step
_Fly to the Northeast:_
Locate the Blacksmith Building
|tip Stay floating high, so the soldiers on the ground will not attack you.
Use the _"Siphon of Acherus"_ ability |petaction 1
|tip Near the red arrow bouncing above the blacksmith building.
Analyze the New Avalon Forge |q 12641/1
step
_Fly to the South:_
Locate the Fort Building
|tip Stay floating high, so the soldiers on the ground will not attack you.
Use the _"Siphon of Acherus"_ ability |petaction 1
|tip Near the red arrow bouncing above the fort building.
Analyze the Scarlet Hold |q 12641/3
step
_Fly to the West:_
Locate the Town Hall Building
|tip Stay floating high, so the soldiers on the ground will not attack you.
Use the _"Siphon of Acherus"_ ability |petaction 1
|tip Near the red arrow bouncing above the town hall building.
Analyze the New Avalon Town Hall |q 12641/2
step
_Fly to the South:_
Locate the Church Building
|tip Stay floating high, so the soldiers on the ground will not attack you.
Use the _"Siphon of Acherus"_ ability |petaction 1
|tip Near the red arrow bouncing above the church building.
Analyze the Chapel of the Crimson Flame |q 12641/4
step
Use the _"Recall Eye of Acherus"_ ability |petaction 5
Recall the Eye of Acherus |nobuff spell:51852 |q 12641
step
talk The Lich King##25462
|tip On the upper floor of the floating building.
turnin Death Comes From On High##12641 |goto 51.34,35.18
accept The Might Of The Scourge##12657 |goto 51.34,35.18
step
Teleport to the Hall of Command |complete subzone("Hall of Command") |goto 50.49,33.37 |q 12657
|tip Walk onto the teleport pad.
|tip On the upper floor of the floating building.
step
talk Highlord Darion Mograine##28444
|tip On the bottom floor of the floating building.
turnin The Might Of The Scourge##12657 |goto 48.88,29.76
accept Report To Scourge Commander Thalanor##12850 |goto 48.88,29.76
step
talk Lord Thorval##28472
|tip He walks around this area, on the bottom floor of the floating building.
accept The Power Of Blood, Frost And Unholy##12849 |goto 47.48,26.56 |instant
step
talk Scourge Commander Thalanor##28510
|tip He walks around this area on a skeletal bird mount.
|tip On the bottom floor of the floating building.
turnin Report To Scourge Commander Thalanor##12850 |goto 51.10,34.63
accept The Scarlet Harvest##12670 |goto 51.10,34.63
step
clicknpc Scourge Gryphon##29488
|tip On the upper floor of the floating building.
Begin Flying to Death's Breach |ontaxi |goto 50.96,36.15 |q 12670
step
Fly Down to Death's Breach |offtaxi |goto 53.20,31.14 |q 12670 |notravel
step
talk Prince Valanar##28377
turnin The Scarlet Harvest##12670 |goto 52.28,33.96
accept If Chaos Drives, Let Suffering Hold The Reins##12678 |goto 52.28,33.96
step
talk Salanar the Horseman##28653
|tip He walks back and forth along this path.
accept Grand Theft Palomino##12680 |goto 52.51,34.61
step
talk Olrun the Battlecaller##29047
|tip She flies close to the ground around this area.
accept Death's Challenge##12733 |goto 54.63,33.95
step
talk Death Knight Initiate##28406+
|tip They look like NPCs wearing brown robes.
|tip You can find them all around the Death's Breach area.
Tell them _"I challenge you, death knight!"_
kill Death Knight Initiate##28392+
|tip They will eventually surrender.
Defeat #5# Death Knights in a Duel |q 12733/1 |goto 52.51,34.46
step
talk Olrun the Battlecaller##29047
|tip She flies around this small area.
turnin Death's Challenge##12733 |goto 54.63,33.95
step
talk Orithos the Sky Darkener##28647
|tip He walks around this area.
accept Tonight We Dine In Havenshire##12679 |goto 52.96,37.27
stickystart "Slay_Scarlet_Crusaders"
stickystart "Citizens_Of_Havenshire"
stickystart "Saronite_Arrows"
step
click Havenshire Horse+
|tip They look like various color horses.
|tip You can find them all around the Havenshire Stables area.
|tip Be careful to avoid Stable Master Kitrik.
|tip He's elite and will pull you off the horse.
Ride the Havenshire Horse |invehicle |goto 55.93,42.21 |q 12680
step
Follow the path up to Death's Breach |goto 51.60,42.66 < 60 |only if walking and not subzone("Death's Breach")
Successfully Steal a Horse |q 12680/1 |goto 52.51,34.61
|tip Use the "Deliver Stolen Horse" ability next to Salanar the Horseman.
|tip He walks back and forth along this path.
stickystop "Slay_Scarlet_Crusaders"
stickystop "Citizens_Of_Havenshire"
stickystop "Saronite_Arrows"
step
talk Salanar the Horseman##28653
|tip He walks back and forth along this path.
turnin Grand Theft Palomino##12680 |goto 52.51,34.61
accept Into the Realm of Shadows##12687 |goto 52.51,34.61
step
kill Dark Rider of Acherus##28768+
|tip They ride around on dark colored horses with horns and white glowing feet.
|tip You can find them all around the Havenshire area.
clicknpc Acherus Deathcharger##28302
|tip The horse next to you that the Dark Rider of Acherus was riding on.
Steal an Acherus Deathcharger |invehicle |goto 54.27,44.54 |q 12687
step
Watch the dialogue
|tip Use the "Horseman's Call" ability on your action bar.
Complete the Horseman's Challenge |q 12687/1 |goto 50.88,41.74
step
talk Salanar the Horseman##28653
|tip He walks back and forth along this path.
turnin Into the Realm of Shadows##12687 |goto 52.51,34.61
step
_NOTE:_
You Can Now Mount Up
|tip You just earned your ground mount.
|tip When you need to travel now, you can use your mount to move faster.
|tip Press Shift+P to open your Mounts window and move your horse to your action bar.
Click Here to Continue |confirm |q 12678
stickystart "Slay_Scarlet_Crusaders"
stickystart "Citizens_Of_Havenshire"
stickystart "Saronite_Arrows"
step
click Abandoned Mail##190917
|tip It looks like a rolled up scroll on top of the mailbox.
accept Abandoned Mail##12711 |goto 55.26,46.15 |instant
step
label "Slay_Scarlet_Crusaders"
Kill Scarlet enemies around this area
|tip They look like human soldiers with red and white armor, or civilians chopping wood.
|tip You can find them all around the northern part of the Havenshire area. |notinsticky
Slay #10# Scarlet Crusaders |q 12678/1 |goto 55.17,43.39
step
label "Citizens_Of_Havenshire"
kill 10 Citizen of Havenshire##28660 |q 12678/2 |goto 57.10,47.55
|tip They look like humans running south.
|tip You can find them all around the southern part of the Havenshire area. |notinsticky
step
label "Saronite_Arrows"
click Saronite Arrow##190691+
|tip They look like green glowing arrows stuck in the ground around this area.
|tip You can find them all around the northern and southern parts of the Havenshire area. |notinsticky
collect 15 Saronite Arrow##39160 |q 12679/1 |goto 57.10,47.55
step
Follow the path up to Death's Breach |goto 51.60,42.66 < 60 |only if walking and not subzone("Death's Breach")
talk Orithos the Sky Darkener##28647
|tip He paces around this area.
turnin Tonight We Dine In Havenshire##12679 |goto 52.96,37.27
step
talk Prince Valanar##28377
turnin If Chaos Drives, Let Suffering Hold The Reins##12678 |goto 52.27,33.97
accept Gothik the Harvester##12697 |goto 52.27,33.97
step
talk Gothik the Harvester##28658
turnin Gothik the Harvester##12697 |goto 54.07,35.03
accept The Gift That Keeps On Giving##12698 |goto 54.07,35.03
step
use the Gift of the Harvester##39253
|tip Use it on Scarlet Miners.
|tip They appear at the entrance of the mine, but you can find them throughout.
Gather _5_ Scarlet Ghouls
|tip The miners have a chance to become a friendly ghoul that will begin following you.
|tip Some of them may turn into ghosts and attack you.
Click Here Once You Have 5 Ghouls |confirm |c |goto 58.29,30.92 |q 12698
step
Leave the mine |goto 58.25,30.97 < 15 |walk |only if subzone("Havenshire Mine") and _G.IsIndoors()
Follow the path up to Death's Breach |goto 55.79,31.11 < 30 |only if not subzone("Death's Breach")
Return #5# Scarlet Ghouls |q 12698/1 |goto 54.07,35.03
|tip Bring the ghouls to this location.
step
talk Gothik the Harvester##28658
turnin The Gift That Keeps On Giving##12698 |goto 54.07,35.03
accept An Attack Of Opportunity##12700 |goto 54.07,35.03
step
talk Hargus the Gimp##28760
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Hargus the Gimp##28760 |goto 52.90,35.21 |q 12700
step
talk Prince Valanar##28377
turnin An Attack Of Opportunity##12700 |goto 52.27,33.97
accept Massacre At Light's Point##12701 |goto 52.27,33.97
step
click Inconspicuous Mine Car##190767
Hide in the Inconspicuous Mine Cart |invehicle |goto 58.52,33.00 |q 12701
step
Watch the dialogue
|tip A Scarlet Miner will bring you down to the beach in the cart.
Ride to the Scarlet Fleet Ship |outvehicle |goto 67.80,38.65 |q 12701 |notravel
step
click Scarlet Cannon##176216
|tip On the deck of the ship.
kill Scarlet Fleet Defender##28834+
|tip Use the abilities on your action bar to kill the soldiers on the beach nearby.
Slay #100# Scarlet Defenders |q 12701/1 |goto 67.73,39.01
step
Call for a Skeletal Gryphon |ontaxi |goto 67.73,39.01 |q 12701
|tip Use the "Skeletal Gryphon Escape" ability on your action bar.
|tip A skeletal gryphon will pick you up and fly you away.
step
Escape to Death's Breach |offtaxi |goto 52.57,34.45 |q 12701 |notravel
step
talk Prince Valanar##28377
turnin Massacre At Light's Point##12701 |goto 52.27,33.97
accept Victory At Death's Breach!##12706 |goto 52.27,33.97
step
clicknpc Scourge Gryphon##29501
Begin Flying to Acherus |ontaxi |goto 53.09,32.48 |q 12706
step
Fly Up to Archerus |offtaxi |goto 51.09,34.63 |q 12706 |notravel
step
talk Highlord Darion Mograine##28444
|tip On the upper floor of the floating building.
turnin Victory At Death's Breach!##12706 |goto 48.87,29.76
accept The Will Of The Lich King##12714 |goto 48.87,29.76
step
clicknpc Scourge Gryphon##29488
|tip On the upper floor of the floating building.
Begin Flying to Death's Breach |ontaxi |goto 50.96,36.15 |q 12714
step
Fly Down to Death's Breach |offtaxi |goto 53.20,31.14 |q 12714 |notravel
step
talk Prince Valanar##28907
turnin The Will Of The Lich King##12714 |goto 53.46,36.56
accept The Crypt of Remembrance##12715 |goto 53.46,36.56
step
talk Noth the Plaguebringer##28919
accept The Plaguebringer's Request##12716 |goto 55.89,52.40
step
Enter the crypt and run down the stairs |goto 54.11,58.14 < 10 |walk |only if not (subzone("Crypt of Remembrance") and _G.IsIndoors())
talk Prince Keleseth##28911
|tip Downstairs inside the crypt.
turnin The Crypt of Remembrance##12715 |goto 54.30,57.31
accept Nowhere To Run And Nowhere To Hide##12719 |goto 54.30,57.31
step
talk Baron Rivendare##28910
|tip Downstairs inside the crypt.
accept Lambs To The Slaughter##12722 |goto 54.66,57.43
stickystart "Slay_Scarlet_Crusade_Soldiers"
stickystart "Collect_Crusader_Skulls"
stickystart "Kill_Citizens_Of_New_Avalaon"
step
Run up the stairs and leave the crypt |complete not (subzone("Crypt of Remembrance") and _G.IsIndoors()) |goto 54.34,58.13 |q 12719
step
Enter the building |goto 53.20,71.01 < 10 |walk |only if not (subzone("New Avalon Town Hall") and _G.IsIndoors())
kill Mayor Quimby##28945 |q 12719/1 |goto 52.24,71.17
|tip Inside the building.
step
click New Avalon Registry##190947
|tip Inside the building.
collect New Avalon Registry##39362 |q 12719/2 |goto 52.45,71.00
step
Leave the building |goto 53.20,71.01 < 10 |walk |only if subzone("New Avalon Town Hall") and _G.IsIndoors()
Enter the crypt and run down the stairs |goto 54.11,58.14 < 10 |walk |only if not (subzone("Crypt of Remembrance") and _G.IsIndoors())
talk Prince Keleseth##28911
|tip Downstairs inside the crypt.
turnin Nowhere To Run And Nowhere To Hide##12719 |goto 54.30,57.31
accept How To Win Friends And Influence Enemies##12720 |goto 54.30,57.31
step
Run up the stairs and leave the crypt |complete not (subzone("Crypt of Remembrance") and _G.IsIndoors()) |goto 54.34,58.13 |q 12716
step
Enter the building |goto 61.46,60.73 < 15 |walk
click Iron Chain##190938
|tip Inside the building.
collect Iron Chain##39326 |q 12716/2 |goto 62.05,60.24
step
Enter the building |goto 57.68,64.37 < 10 |walk
click Empty Cauldron##190937
|tip Downstairs inside the building.
collect Empty Cauldron##39324 |q 12716/1 |goto 57.86,61.84
step
use the Ornately Jeweled Box##39418
collect Keleseth's Persuader##39371 |q 12720 |only if Frost
collect Keleseth's Persuader##142274 |q 12720 |only if Blood or Unholy
step
Equip Keleseth's Persuaders |equipped Keleseth's Persuader##39371 |q 12720 |only if Frost
Equip Keleseth's Persuader |equipped Keleseth's Persuader##142274 |q 12720 |only if Blood or Unholy
|tip Equip both of Keleseth's Persuaders in your bag. |only if Frost
|tip Equip the Keleseth's Persuader in your bag. |only if Blood or Unholy
step
Leave the building |goto 57.68,64.37 < 10 |walk |only if subzone("New Avalon") and _G.IsIndoors()
Kill Scarlet enemies around this area
|tip They look like soldiers with red and white armor.
|tip You can find them all around the New Avalon area. |notinsticky
|tip Try not to kill them too fast.
|tip Stop attacking when they start talking.
|tip Eventually one of the enemies will give you information.
|tip You must have Keleseth's Persuader weapon(s) equipped to get the enemies to talk to you.
Reveal the "Crimson Dawn" |q 12720/1 |goto 56.75,67.50
You can find more around [56.27,75.81]
step
Equip Your Normal Weapon
Click Here After Equipping Your Normal Weapon |confirm |q 12720
step
label "Slay_Scarlet_Crusade_Soldiers"
Kill Scarlet enemies around this area
|tip They look like soldiers with red and white armor.
|tip You can find them all around the New Avalon area. |notinsticky
Slay #10# Scarlet Crusade Soldiers |q 12722/1 |goto 56.75,67.50
You can find more around [56.27,75.81]
step
label "Collect_Crusader_Skulls"
Kill enemies around this area
|tip You can kill soldiers or civilians.
|tip You can find them all around the New Avalon area. |notinsticky
collect 10 Crusader Skull##39328 |q 12716/3 |goto 56.75,67.50
You can find more around [56.27,75.81]
step
label "Kill_Citizens_Of_New_Avalaon"
kill 15 Citizen of New Avalon##28942 |q 12722/2 |goto 56.75,67.50
|tip They look like human civilians in regular clothes.
|tip They are mostly inside the buildings.
|tip You can find them all around the New Avalon area. |notinsticky
You can find more around [56.27,75.81]
step
talk Noth the Plaguebringer##28919
turnin The Plaguebringer's Request##12716 |goto 55.89,52.40
accept Noth's Special Brew##12717 |goto 55.89,52.40
step
click Plague Cauldron##190936
turnin Noth's Special Brew##12717 |goto 56.15,51.98
step
click Plague Cauldron##190936
|tip Turn in the "More Skulls For Brew!" quest to get more potions of Noth's Special Brew.
|tip Keep doing this until you don't have enough skulls to get more potions.
Create More Noth's Special Brew |complete itemcount(39328) < 20 |goto 56.15,51.98
|only if itemcount(39328) >= 20
step
_Destroy These Items:_
|tip They are no longer needed.
trash Crusader Skull##39328
step
Enter the crypt and run down the stairs |goto 54.11,58.14 < 10 |walk |only if not (subzone("Crypt of Remembrance") and _G.IsIndoors())
talk Prince Keleseth##28911
|tip Downstairs inside the crypt.
turnin How To Win Friends And Influence Enemies##12720 |goto 54.30,57.31
accept Behind Scarlet Lines##12723 |goto 54.30,57.31
step
talk Baron Rivendare##28910
|tip Downstairs inside the crypt.
turnin Lambs To The Slaughter##12722 |goto 54.66,57.43
step
Run up the stairs and leave the crypt |complete not (subzone("Crypt of Remembrance") and _G.IsIndoors()) |goto 54.34,58.13 |q 12716
Enter the building |goto 56.14,79.97 < 10 |walk
talk Orbaz Bloodbane##28914
|tip Upstairs inside the building.
turnin Behind Scarlet Lines##12723 |goto 56.26,79.84
accept The Path Of The Righteous Crusader##12724 |goto 56.26,79.84
step
talk Thassarian##28913
|tip Upstairs inside the building.
accept Brothers In Death##12725 |goto 56.27,80.15
step
Enter the building |goto 61.10,68.06 < 15 |walk |only if not (subzone("Scarlet Hold") and _G.IsIndoors())
Run down the stairs |goto 62.77,68.63 < 7 |walk
talk Koltira Deathweaver##28912
|tip Downstairs in the building.
turnin Brothers In Death##12725 |goto 62.96,67.85
accept Bloody Breakout##12727 |goto 62.96,67.85
step
Kill the enemies that attack in waves
|tip Downstairs in the building.
kill High Inquisitor Valroth##29001
|tip Stay inside the bubble Koltira Deathweaver forms.
|tip It reduces spell damage, so you'll live.
click High Inquisitor Valroth's Remains##191092
|tip It appears on the ground where you killed High Inquisitor Valroth.
collect Valroth's Head##39510 |q 12727/1 |goto 62.91,68.10
step
click New Avalon Patrol Schedule##191084
|tip It looks like a thick book sitting on a long table.
|tip Upstairs inside the building, in a large room.
collect New Avalon Patrol Schedule##39504|q 12724/1 |goto 62.99,68.31
step
Leave the building |goto 61.10,68.06 < 15 |walk |only if subzone("Scarlet Hold") and _G.IsIndoors()
Enter the building |goto 56.14,79.97 < 10 |walk
talk Orbaz Bloodbane##28914
|tip Upstairs inside the building.
turnin The Path Of The Righteous Crusader##12724 |goto 56.26,79.84
step
talk Thassarian##28913
|tip Upstairs inside the building.
turnin Bloody Breakout##12727 |goto 56.27,80.15
accept A Cry For Vengeance!##12738 |goto 56.27,80.15
step
talk Knight Commander Plaguefist##29053
|tip He walks around this area.
turnin A Cry For Vengeance!##12738 |goto 52.97,81.95
accept A Special Surprise##12742 |goto 52.97,81.95 |only Human
accept A Special Surprise##12743 |goto 52.97,81.95 |only NightElf
accept A Special Surprise##12744 |goto 52.97,81.95 |only Dwarf
accept A Special Surprise##12745 |goto 52.97,81.95 |only Gnome
accept A Special Surprise##12746 |goto 52.97,81.95 |only Draenei
accept A Special Surprise##12739 |goto 52.97,81.95 |only Tauren
accept A Special Surprise##12747 |goto 52.97,81.95 |only BloodElf
accept A Special Surprise##12748 |goto 52.97,81.95 |only Orc
accept A Special Surprise##12749 |goto 52.97,81.95 |only Troll
accept A Special Surprise##12750 |goto 52.97,81.95 |only Scourge
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Valok the Righteous##29070 |q 12746/1 |goto 54.55,83.42
|only Draenei
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Yazmina Oakenthorn##29065 |q 12743/1 |goto 54.25,83.91
|only NightElf
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Goby Blastenheimer##29068 |q 12745/1 |goto 53.93,83.81
|only Gnome
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Ellen Stanbridge##29061 |q 12742/1 |goto 53.53,83.79
|only Human
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Donovan Pulfrost##29067 |q 12744/1 |goto 54.02,83.28
|only Dwarf
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Malar Bravehorn##29032 |q 12739/1 |goto 54.51,83.87
|only Tauren
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Lady Eonys##29074 |q 12747/1 |goto 54.28,83.29
|only BloodElf
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Kug Ironjaw##29072 |q 12748/1 |goto 53.77,83.27
|only Orc
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Iggy Darktusk##29073 |q 12749/1 |goto 53.80,83.77
|only Troll
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Antoine Brack##29071 |q 12750/1 |goto 53.54,83.30
|only Scourge
step
talk Knight Commander Plaguefist##29053
|tip He walks around this area.
turnin A Special Surprise##12742 |goto 52.97,81.95 |only Human
turnin A Special Surprise##12743 |goto 52.97,81.95 |only NightElf
turnin A Special Surprise##12744 |goto 52.97,81.95 |only Dwarf
turnin A Special Surprise##12745 |goto 52.97,81.95 |only Gnome
turnin A Special Surprise##12746 |goto 52.97,81.95 |only Draenei
turnin A Special Surprise##28649 |goto 52.97,81.95 |only Worgen
turnin A Special Surprise##12739 |goto 52.97,81.95 |only Tauren
turnin A Special Surprise##12747 |goto 52.97,81.95 |only BloodElf
turnin A Special Surprise##12748 |goto 52.97,81.95 |only Orc
turnin A Special Surprise##12749 |goto 52.97,81.95 |only Troll
turnin A Special Surprise##12750 |goto 52.97,81.95 |only Scourge
turnin A Special Surprise##28650 |goto 52.97,81.95 |only Goblin
accept A Sort Of Homecoming##12751 |goto 52.97,81.95
step
Enter the building |goto 56.14,79.97 < 10 |walk
talk Thassarian##28913
|tip Upstairs inside the building.
turnin A Sort Of Homecoming##12751 |goto 56.27,80.15
step
talk Orbaz Bloodbane##28914
|tip Upstairs inside the building.
accept Ambush At The Overlook##12754 |goto 56.26,79.84
step
use the Makeshift Cover##39645
Watch the dialogue
|tip A Scarlet Courier walks up to you on a horse.
kill Scarlet Courier##29076
collect Scarlet Courier's Belongings##39646 |q 12754/1 |goto 59.97,78.57
collect Scarlet Courier's Message##39647 |q 12754/2 |goto 59.97,78.57
step
Enter the building |goto 56.14,79.97 < 10 |walk
talk Orbaz Bloodbane##28914
|tip Upstairs inside the building.
turnin Ambush At The Overlook##12754 |goto 56.26,79.84
accept A Meeting With Fate##12755 |goto 56.26,79.84
step
Follow the path down to the beach |goto 60.63,80.73 < 70 |only if walking and not subzone("King's Harbor")
talk High General Abbendis##29077
turnin A Meeting With Fate##12755 |goto 65.65,83.82
accept The Scarlet Onslaught Emerges##12756 |goto 65.65,83.82
step
Follow the path up back to the orchard |goto 62.92,85.10 < 50 |only if walking
Enter the building |goto 56.14,79.97 < 10 |walk
talk Orbaz Bloodbane##28914
|tip Upstairs inside the building.
turnin The Scarlet Onslaught Emerges##12756 |goto 56.26,79.84
accept Scarlet Armies Approach...##12757 |goto 56.26,79.84
step
Watch the dialogue
|tip Orbaz Bloodbane will create a portal.
|tip Upstairs inside the building.
click Portal to Acherus##8046
Return to Acherus |complete subzone("Acherus: The Ebon Hold") |goto 56.18,80.04 |q 12757
step
talk Highlord Darion Mograine##28444
|tip On the bottom floor of the floating building.
turnin Scarlet Armies Approach...##12757 |goto 48.89,29.77
accept The Scarlet Apocalypse##12778 |goto 48.89,29.77
step
clicknpc Scourge Gryphon##29488
|tip On the upper floor of the floating building.
Begin Flying to Death's Breach |ontaxi |goto 50.96,36.15 |q 12778
step
Fly Down to Death's Breach |offtaxi |goto 53.20,31.14 |q 12778 |notravel
step
talk The Lich King##29110
turnin The Scarlet Apocalypse##12778 |goto 53.57,36.85
accept An End To All Things...##12779 |goto 53.57,36.85
step
use the Horn of the Frostbrood##39700
Summon a Frostbrood Vanquisher |invehicle |q 12779
stickystart "Kill_Scarlet_Soldiers_12779"
step
kill Scarlet Ballista##29104+
|tip They look like large brown wooden crossbow machines.
|tip They are up on the walls or on the ground all around the New Avalon area.
|tip Use the abilities on your action bar.
Destroy #10# Scarlet Ballistas |q 12779/2 |goto 57.70,59.97
You can find more around [57.72,70.29]
step
label "Kill_Scarlet_Soldiers_12779"
kill 150 Scarlet Soldier##4286 |q 12779/1 |goto 57.72,70.29
|tip They look like humans wearing red and white armor.
|tip You can find them all around the New Avalon area.
|tip Use the abilities on your action bar.
step
Return to Death's Breach |complete subzone("Death's Breach") |goto 53.57,36.85 |q 12779
|tip Fly back to Death's Breach manually with the dragon.
|tip Don't click the red arrow to stop controlling the dragon until you get back to Death's Breach.
step
Release the Frostbrood Vanquisher |outvehicle |goto 53.57,36.85 |q 12779
|tip Click the red arrow on your action bar.
step
talk The Lich King##29110
turnin An End To All Things...##12779 |goto 53.57,36.85
accept The Lich King's Command##12800 |goto 53.57,36.85
step
talk Hargus the Gimp##28760
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Hargus the Gimp##28760 |goto 52.90,35.21 |q 12800
step
_Destroy These Items:_
|tip They are no longer needed.
trash Crusader Skull##39328
step
Run through the tunnel |goto 49.08,28.31 < 20 |only if walking and not subzone("Browman Mill")
Follow the path down |goto 39.91,19.41 < 30 |only if walking and not subzone("Browman Mill")
talk Scourge Commander Thalanor##31082
|tip He walks around this area.
turnin The Lich King's Command##12800 |goto 33.99,30.36
accept The Light of Dawn##12801 |goto 33.99,30.36
step
talk Highlord Darion Mograine##29173
|tip If he's not here, then another player already started the battle.
|tip You may be able to join the battle.  Skip to the next step, try to do it, and see if it works.
|tip If you're unable to join the battle, skip back to this step and wait for Highlord Darion Mograine to respawn.
Tell him _"I am ready, Highlord.  Let the siege of Light's Hope begin!"_
|tip If he's here, but you can't choose this dialogue, then another player already did it.
|tip Now you just need to wait for the battle to start.
|tip The battle starts 5 minutes after someone initiates this dialogue with him.
Click Here Once the Battle Begins |confirm |c |goto 34.44,31.10 |q 12801
|tip Highlord Darion Mograine will start yelling when the battle is beginning.
step
Kill enemies around this area
|tip Follow your allies into battle and help them fight.
Watch the dialogue
Uncover The Light of Dawn |q 12801/1 |goto 38.79,38.34
step
talk Highlord Darion Mograine##29173
turnin The Light of Dawn##12801 |goto 39.11,39.16
accept Taking Back Acherus##13165 |goto 39.11,39.16
step
cast Death Gate##50977
|tip Click the purple portal that appears nearby.
Return to Acherus |complete subzone("Acherus: The Ebon Hold") |q 13165
step
talk Highlord Darion Mograine##29173
|tip On the bottom floor of the floating building.
turnin Taking Back Acherus##13165 |goto Eastern Plaguelands 83.44,49.46
accept The Battle For The Ebon Hold##13166 |goto Eastern Plaguelands 83.44,49.46
stickystart "Slay_Scourge_13166"
step
Walk onto the teleport pad to go to the upper floor |goto 83.19,48.90 < 7 |walk
kill Patchwerk##31099 |q 13166/1 |goto 81.99,46.37
|tip He looks like a larger abomination that walks around this area.
|tip On the upper floor of the floating building.
step
label "Slay_Scourge_13166"
Kill enemies around this area
|tip On the upper floor of the floating building. |notinsticky
Slay #10# Scourge |q 13166/2 |goto 81.99,46.37
step
Walk onto the teleport pad to go to the bottom floor |goto 83.28,49.12 < 7 |walk
talk Highlord Darion Mograine##31084
|tip On the bottom floor of the floating building.
turnin The Battle For The Ebon Hold##13166 |goto 83.44,49.46
accept Warchief's Blessing##13189 |goto 83.44,49.46
step
clicknpc Portal to Orgrimmar##103191
|tip On the bottom floor of the floating building.
Teleport to Orgrimmar |complete zone("Durotar") |goto 84.55,50.46 |q 13189
step
Enter the building |goto Orgrimmar 40.30,36.96 < 15 |walk
talk Thrall ##4949
|tip Inside the building.
turnin Warchief's Blessing##13189 |goto 31.61,37.83
]])
ZygorGuidesViewer:RegisterGuide("Leveling Guides\\Northrend (69-80)\\Howling Fjord (69-71)",{
author="support@zygorguides.com",
image=ZGV.IMAGESDIR.."Howling",
condition_suggested=function() return level >= 69 and level <= 71 and not completedq(11572) end,
next="Leveling Guides\\Northrend (69-80)\\Borean Tundra (70-72)",
},[[
step
talk Apothecary Lysander##24126
accept The New Plague##11167 |goto Howling Fjord 78.55,28.98
step
talk Bat Handler Adeline##27344
fpath Vengeance Landing |goto 79.04,29.71
step
Enter the building |goto 79.04,30.37 < 7 |walk
talk Timothy Holland##24342
|tip Downstairs inside the building.
home Vengeance Landing |goto 79.73,30.84
step
Leave the building |goto 79.04,30.37 < 7 |walk |only if subzone("Vengeance Landing Inn, Howling Fjord")
talk Pontius##23938
|tip Outside, next to the building.
accept Let Them Eat Crow##11227 |goto 79.15,31.22
step
talk High Executor Anselm##23780
accept War is Hell##11270 |goto 78.61,31.23
stickystart "Burn_Fallen_Combatants"
step
use Plaguehound Cage##33221
|tip A Plaguehound will appear and start following you.
kill Fjord Crow##23945+
|tip They look like black birds flying in the air.
|tip You can find them all around the Bleeding Vale area.
collect 5 Crow Meat##33238+ |n
use Crow Meat##33238
|tip Use it multiple times.
Feed Your Plaguehound #5# Times |q 11227/1 |goto 75.28,33.32
step
label "Burn_Fallen_Combatants"
use Burning Torch##33278
|tip Use it on Corpses.
|tip They look like Horde and Alliance dead bodies on the ground.
|tip You can find them all around the Bleeding Vale area.
Burn #10# Fallen Combatants |q 11270/1 |goto 75.26,32.60
step
click Plague Containers##186390+
|tip They look like dark barrels with a green ring around the middle of them.
|tip They can also be underwater inside the ship.
collect 10 Intact Plague Container##33099 |q 11167/1 |goto 80.81,35.32
step
talk High Executor Anselm##23780
turnin War is Hell##11270 |goto 78.61,31.23
accept Reports from the Field##11221 |goto 78.61,31.23
step
talk Pontius##23938
turnin Let Them Eat Crow##11227 |goto 79.15,31.22
accept Sniff Out the Enemy##11253 |goto 79.15,31.22
step
talk Apothecary Lysander##24126
turnin The New Plague##11167 |goto 78.54,28.98
accept Spiking the Mix##11168 |goto 78.54,28.98
stickystart "Collect_Giant_Toxic_Glands"
step
Enter the cave |goto 76.30,19.99 < 20 |walk
click Dragonskin Scroll##186585
|tip Inside the cave.
turnin Sniff Out the Enemy##11253 |goto 75.93,19.75
accept The Dragonskin Map##11254 |goto 75.93,19.75
step
label "Collect_Giant_Toxic_Glands"
kill Giant Tidecrawler##23929+
|tip They look like red and white crabs.
|tip You can find them all along the beach and in the water nearby.
collect 3 Giant Toxin Gland##33337 |q 11168/1 |goto 77.92,22.36
step
talk Apothecary Lysander##24126
|tip Outside, in front of the building.
turnin Spiking the Mix##11168 |goto 78.54,28.98
accept Test at Sea##11170 |goto 78.54,28.98
step
talk High Executor Anselm##23780
turnin The Dragonskin Map##11254 |goto 78.61,31.23
accept The Offensive Begins##11295 |goto 78.61,31.23
step
talk Bat Handler Camille##23816
Tell her _"I need a riding bat to intercept the Alliance reinforcements."_
Borrow a Bat |ontaxi |goto 79.05,29.81 |q 11170
step
use Plague Vials##33349
|tip Use it on North Fleet Reservists as you fly.
|tip They look like humans on the decks of the ships around this area.
Infect #16# North Fleet Reservists |q 11170/1 |goto 89.72,82.98 |notravel
step
Return to Vengeance Landing |offtaxi |goto 79.06,29.84 |q 11170 |notravel
step
talk Apothecary Lysander##24126
turnin Test at Sea##11170 |goto 78.54,28.98
step
talk Brock Olson##24343
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Brock Olson##24343 |goto 78.71,29.66 |q 11221
step
talk Deathstalker Razael##23998
Tell him _"High Executor Anseim wants a report on the situation."_
Listen to Razael's Report |q 11221/1 |goto 77.59,34.70
step
talk Dark Ranger Lyana##23778
Tell her _"High Executor Anseim requests your report."_
Listen to Lyana's Report |q 11221/2 |goto 78.68,37.13
step
talk High Executor Anselm##23780
turnin Reports from the Field##11221 |goto 78.61,31.23
accept The Windrunner Fleet##11229 |goto 78.61,31.23
step
talk Bat Handler Camille##23816
Tell her _"I need to fly to the Windrunner. Official business!"_
Begin Flying to the Windrunner |ontaxi |goto 79.05,29.82 |q 11229
step
Fly to the Windrunner |offtaxi |goto 84.59,36.31 |q 11229 |notravel
step
talk Captain Harker##24037
|tip On the top deck of the ship.
turnin The Windrunner Fleet##11229 |goto 84.66,36.46
accept Ambushed!##11230 |goto 84.66,36.46
step
kill 15 North Fleet Marine##23983 |q 11230/1 |goto 84.36,35.85
|tip On the deck and inside the ship.
You can find more on another ship around [83.47,37.94]
step
talk Captain Harker##24037
|tip On the top deck of the ship.
turnin Ambushed!##11230 |goto 84.66,36.46
accept Guide Our Sights##11232 |goto 84.66,36.46
step
Run up the stairs |goto 80.44,38.37 < 10 |only if walking
use Cannoneer's Smoke Flare##33335
|tip Next to cannon on top of the makeshift wooden wall.
Mark the Eastern Cannon |q 11232/1 |goto 80.35,38.21
step
Run up the stairs |goto 79.40,40.36 < 10 |only if walking
use Cannoneer's Smoke Flare##33335
|tip Next to cannon on top of the makeshift wooden wall.
Mark the Western Cannon |q 11232/2 |goto 79.33,40.16
step
talk Dark Ranger Lyana##23778
|tip She will eventually run to this location.
turnin Guide Our Sights##11232 |goto 78.68,37.13
accept Landing the Killing Blow##11233 |goto 78.68,37.13
step
kill Sergeant Lorric##23963 |q 11233/3 |goto 82.22,40.72
step
kill Captain Olster##23962 |q 11233/1 |goto 81.50,43.37
step
kill Lieutenant Celeyne##23964 |q 11233/2 |goto 83.20,43.15
step
talk Apothecary Hanes##23784
|tip This is an escort quest.
|tip If he's not here, someone may be escorting him.
|tip Wait until he respawns.
accept Trail of Fire##11241 |goto 83.23,43.10
step
Watch the dialogue
|tip Follow Apothecary Hanes and protect him as he walks.
|tip He will eventually walk to this location.
Escort Apothecary Hanes to Safety |q 11241/1 |goto 78.73,37.25
step
talk Dark Ranger Lyana##23778
turnin Landing the Killing Blow##11233 |goto 78.68,37.13
accept Report to Anselm##11234 |goto 78.68,37.13
step
talk High Executor Anselm##23780
turnin Report to Anselm##11234 |goto 78.61,31.23
step
talk Brock Olson##24343
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Brock Olson##24343 |goto 78.71,29.66 |q 11241
step
talk Apothecary Lysander##24126
turnin Trail of Fire##11241 |goto 78.54,28.98
accept New Agamand##11304 |goto 78.54,28.98
step
Ride the lift up the cliff |goto 73.33,35.44 < 20 |only if walking
talk Longrunner Nanik##28314
accept Help for Camp Winterhoof##12566 |goto 71.47,39.21
step
talk Sergeant Gorth##24027
turnin The Offensive Begins##11295 |goto 71.11,39.08
accept A Lesson in Fear##11282 |goto 71.11,39.08
stickystart "Impale_Gunnar_Thorvardsson"
stickystart "Impale_Ulf_The_Bloodletter"
step
kill Winterskorn Defender##24015+
|tip They look like large humans.
|tip You can find them all around the Balejar Watch area.
|tip Kill them around this area until Oric the Baleful spawns at this location.
kill Oric the Baleful##24161
use Forsaken Banner##33563
|tip Use it on his corpse.
Impale Oric the Baleful |q 11282/1 |goto 69.12,38.47
step
label "Impale_Gunnar_Thorvardsson"
kill Winterskorn Defender##24015+ |notinsticky
|tip They look like large humans. |notinsticky
|tip You can find them all around the Balejar Watch area. |notinsticky
|tip Kill them around this area until Gunnar Thorvardsson spawns at this location. |notinsticky
kill Gunnar Thorvardsson##24162
use Forsaken Banner##33563
|tip Use it on his corpse.
Impale Gunnar Thorvardsson |q 11282/3 |goto 69.62,40.06
step
label "Impale_Ulf_The_Bloodletter"
kill Winterskorn Defender##24015+ |notinsticky
|tip They look like large humans. |notinsticky
|tip You can find them all around the Balejar Watch area. |notinsticky
|tip Kill them around this area until Ulf the Bloodletter spawns at this location. |notinsticky
kill Ulf the Bloodletter##24016
use Forsaken Banner##33563
|tip Use it on his corpse.
Impale Ulf the Bloodletter |q 11282/2 |goto 69.38,39.56
step
talk Sergeant Gorth##24027
turnin A Lesson in Fear##11282 |goto 71.11,39.08
accept Baleheim Bodycount##11283 |goto 71.11,39.08
accept Baleheim Must Burn!##11285 |goto 71.11,39.08
stickystart "Slay_Winterskorn_Vrykuls"
step
use Gorth's Torch##33472
|tip Use it near the building.
|tip You don't have to use it in this exact location.
Burn the Winterskorn Watchtower |q 11285/2 |goto 67.12,39.44
step
use Gorth's Torch##33472
|tip Use it near the building.
|tip You don't have to use it in this exact location.
Burn the Winterskorn Bridge |q 11285/3 |goto 66.18,39.79
step
use Gorth's Torch##33472
|tip Use it near the building.
|tip You don't have to use it in this exact location.
Burn the Winterskorn Dwelling |q 11285/1 |goto 65.00,41.01
step
Follow the path up |goto 63.55,41.80 < 20 |only if walking
use Gorth's Torch##33472
|tip Use it near the building.
|tip You don't have to use it in this exact location.
Burn the Winterskorn Barracks |q 11285/4 |goto 63.95,40.65
step
label "Slay_Winterskorn_Vrykuls"
Kill Winterskorn enemies around this area
|tip They look like large humans.
|tip You can find them all around the Baleheim area. |notinsticky
Slay #16# Winterskorn Vrykuls |q 11283/1 |goto 65.18,40.46
step
talk Sergeant Gorth##24027
turnin Baleheim Bodycount##11283 |goto 71.11,39.08
turnin Baleheim Must Burn!##11285 |goto 71.11,39.08
accept The Ambush##11303 |goto 71.11,39.08
step
talk Lydell##24458
turnin The Ambush##11303 |goto 65.87,36.78
accept Adding Injury to Insult##12481 |goto 65.87,36.78
step
use Vrykul Insult##33581
|tip Use it on Bjorn Halgurdsson.
|tip You don't have to be very close to him, so try to use it at max range.
|tip After you use it on him, start running back to Lydell, the NPC who just gave you the quest.
|tip You don't have to kite Born Halgurdsson, he will follow you the whole way.
Insult Bjorn Halgurdsson |q 12481/1 |goto 64.02,39.80
step
kill Bjorn Halgurdsson##24238
|tip Lead him back to Lydell, where he and the other NPCs will help you to defeat him.
|tip You must lead him here for the quest to complete.
Defeat Bjorn Halgurdsson |q 12481/2 |goto 65.87,36.78
step
talk Lydell##24458
turnin Adding Injury to Insult##12481 |goto 65.87,36.78
step
Follow the path up to Camp Winterhoof |goto 48.31,15.15 < 50 |only if walking and not subzone("Camp Winterhoof")
talk Celea Frozenmane##24032
fpath Camp Winterhoof |goto 49.57,11.59
step
talk Chieftain Ashtotem##24129
turnin Help for Camp Winterhoof##12566 |goto 48.04,10.75
step
talk Talu Frosthoof##24028
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Talu Frosthoof##24028 |goto 48.10,11.02 |q 11271 |future
step
talk Ahota Whitefrost##24127
accept Hasty Preparations##11271 |goto 48.38,11.04
step
talk Wind Tamer Kagan##24256
accept Suppressing the Elements##11311 |goto 48.92,11.98
step
talk Nokoma Snowseer##24123
accept Making the Horn##11275 |goto 49.32,11.98
stickystart "Collect_Spotted_Hippogryph_Down"
step
kill Frosthorn Ram##23740+
collect 6 Undamaged Ram Horn##33351 |q 11275/1 |goto |goto 46.05,17.03
You can find more around: |notinsticky
[56.96,15.74]
[52.58,10.15]
[50.97,3.19]
step
talk Talu Frosthoof##24028
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Talu Frosthoof##24028 |goto 48.10,11.02 |q 11275
stickystop "Collect_Spotted_Hippogryph_Down"
step
talk Nokoma Snowseer##24123
turnin Making the Horn##11275 |goto 49.32,11.98
accept Mimicking Nature's Call##11281 |goto 49.32,11.98
accept The Frozen Glade##11312 |goto 49.32,11.98
step
talk Longrunner Pembe##24362
accept The Book of Runes##11350 |goto 49.23,12.24
step
Enter the building |goto 49.42,10.91 < 10 |walk
talk Bori Wintertotem##24033
|tip Inside the building.
home Camp Winterhoof |goto 49.50,10.79
step
talk Junat the Wanderer##24234
accept Keeping Watch on the Interlopers##11297 |goto 48.43,10.43
stickystart "Collect_Spotted_Hippogryph_Down"
stickystart "Kill_Iceshard_Elementals"
step
use the Carved Horn##33450
Watch the dialogue
|tip Frostgore will run up to you.
kill Frostgore##24173
Test Nokoma's Horn |q 11281/1 |goto 52.42,3.83
step
label "Kill_Iceshard_Elementals"
kill Iceshard Elemental##24228+
|tip They look like grey rock elementals.
Slay #8# Mountain Elementals |q 11311/1 |goto 52.37,2.77
step
talk Lurielle##24117
|tip Avoid Fort Wildervar while traveling here.
turnin The Frozen Glade##11312 |goto 61.49,22.86
accept Spirits of the Ice##11313 |goto 61.49,22.86
step
kill Ice Elemental##23919+
|tip They look like small grey rock elementals.
|tip You can find them all around the Frozen Glade area.
collect 15 Icy Core##33605 |q 11313/1 |goto 60.85,22.08
step
talk Lurielle##24117
turnin Spirits of the Ice##11313 |goto 61.49,22.86
accept The Fallen Sisters##11314 |goto 61.49,22.86
accept Wild Vines##11315 |goto 61.49,22.86
stickystart "Collect_Book_of_Runes_Chapter_2"
stickystart "Collect_Book_of_Runes_Chapter_3"
step
Kill Iron Rune enemies around this area
|tip They look like dwarves wearing dark colored armor.
|tip You can find them all around the Giant's Run area. |notinsticky
collect Book of Runes - Chapter 1##33778 |goto 65.04,28.94 |q 11350
You can find more around [67.78,28.95]
step
label "Collect_Book_of_Runes_Chapter_2"
Kill Iron Rune enemies around this area |notinsticky
|tip They look like dwarves wearing dark colored armor. |notinsticky
|tip You can find them all around the Giant's Run area. |notinsticky
collect Book of Runes - Chapter 2##33779 |goto 65.04,28.94 |q 11350
You can find more around [67.78,28.95]
step
label "Collect_Book_of_Runes_Chapter_3"
Kill Iron Rune enemies around this area |notinsticky
|tip They look like dwarves wearing dark colored armor. |notinsticky
|tip You can find them all around the Giant's Run area. |notinsticky
collect Book of Runes - Chapter 3##33780 |goto 65.04,28.94 |q 11350
You can find more around [67.78,28.95]
step
use Book of Runes - Chapter 1##33778
collect The Book of Runes##33781 |q 11350/1
step
use the Hearthstone##6948
Hearth to Camp Winterhoof |complete subzone("Camp Winterhoof") |q 11350
|only if (subzone("Giant's Run"))
stickystop "Collect_Spotted_Hippogryph_Down"
step
talk Nokoma Snowseer##24123
turnin Mimicking Nature's Call##11281 |goto 49.32,11.98
step
talk Longrunner Pembe##24362
turnin The Book of Runes##11350 |goto 49.23,12.24
accept Mastering the Runes##11351 |goto 49.23,12.24
step
talk Wind Tamer Kagan##24256
turnin Suppressing the Elements##11311 |goto 48.92,11.98
step
talk Chieftain Ashtotem##24129
accept Skorn Must Fall!##11256 |goto 48.04,10.75
step
talk Talu Frosthoof##24028
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Talu Frosthoof##24028 |goto 48.10,11.02 |q 11256
stickystart "Collect_Spotted_Hippogryph_Down"
stickystart "Kill_Scarlet_Ivy"
step
kill Chill Nymph##23678+
|tip Don't kill them, just weaken them to about half health.
use Lurielle's Pendant##33606
|tip Use it on weakened Chill Nymphs.
|tip They look like female centaurs.
|tip You can find them all around the Vibrant Glade area.
Free #7# Chill Nymphs |q 11314/1 |goto 51.57,27.61
step
label "Kill_Scarlet_Ivy"
kill 8 Scarlet Ivy##23763 |q 11315/1 |goto 51.57,27.61
|tip They look like large walking flowers.
|tip You can find them all around the Vibrant Glade area. |notinsticky
step
talk Lurielle##24117
turnin The Fallen Sisters##11314 |goto 61.49,22.86
turnin Wild Vines##11315 |goto 61.49,22.86
accept Spawn of the Twisted Glade##11316 |goto 61.49,22.86
accept Seeds of the Blacksouled Keepers##11319 |goto 61.49,22.86
stickystart "Kill_Thornvine_Creepers"
step
kill Spore##23876+
|tip They look like orange spikey balls.
|tip You can find them all around the Twisted Glade area.
use the Enchanted Ice Core##33607
|tip Use it on their corpses.
Freeze #8# Spores |q 11319/1 |goto 54.05,17.75
step
label "Kill_Thornvine_Creepers"
kill 10 Thornvine Creeper##23874+ |q 11316/1 |goto 54.05,17.75
|tip They look like black and purple swmap elementals.
|tip You can find them all around the Twisted Glade area. |notinsticky
step
talk Lurielle##24117
turnin Spawn of the Twisted Glade##11316 |goto 61.49,22.86
turnin Seeds of the Blacksouled Keepers##11319 |goto 61.49,22.86
accept Keeper Witherleaf##11428 |goto 61.49,22.86
step
click Iron Rune Carving Tools##186684
|tip It looks like a small metal chest.
|tip It can spawn in multiple locations.
collect Iron Rune Carving Tools##33794 |q 11351/1 |goto 67.54,23.33
It can also be located at: |notinsticky
[72.40,17.80]
[69.10,22.80]
[67.50,29.20]
[71.20,28.70]
[73.30,24.89]
step
kill Keeper Witherleaf##24638 |q 11428/1 |goto 53.64,18.34
|tip He looks like a green and brown centaur that walks around this area.
step
label "Collect_Spotted_Hippogryph_Down"
click Spotted Hippogryph Down##186591+
|tip They look like brown feathers on the ground around this area.
|tip You can find them all around this area. |notinsticky
collect 10 Spotted Hippogryph Down##33348 |q 11271/1 |goto 52.80,18.98
step
Follow the path up to Camp Winterhoof |goto 48.31,15.15 < 50 |only if walking and not subzone("Camp Winterhoof")
talk Longrunner Pembe##24362
turnin Mastering the Runes##11351 |goto 49.23,12.24
accept The Rune of Command##11352 |goto 49.23,12.24
step
talk Ahota Whitefrost##24127
turnin Hasty Preparations##11271 |goto 48.38,11.04
step
talk Talu Frosthoof##24028
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Talu Frosthoof##24028 |goto 48.10,11.02 |q 11352
step
talk Lurielle##24117
turnin Keeper Witherleaf##11428 |goto 61.49,22.86
step
use the Rune of Command##33796
|tip Use it on a neutral Stone Giant around this area.
|tip It will not work on a Runed Stone Giant.
Test the Rune of Command |q 11352/1 |goto 70.41,23.92
step
kill Binder Murdis##24334 |q 11352/2 |goto 71.85,24.56
|tip Your Captive Stone Giant minion from the previous step will help you fight.
step
use Winterhoof Emblem##33340
talk Winterhoof Brave##24130
|tip He appears next to you.
turnin Skorn Must Fall!##11256 |goto 44.37,26.36
accept Gruesome, But Necessary##11257 |goto 44.37,26.36
accept Burn Skorn, Burn!##11258 |goto 44.37,26.36
accept Towers of Certain Doom##11259 |goto 44.37,26.36
stickystart "Dismember_Winterskorn_Vrykul"
stickystart "Accept_Stop_The_Ascension"
step
Enter the building |goto 43.73,28.31 < 10 |walk
use the Brave's Flare##33344
|tip Use it inside this building.
Set the Northwest Longhouse Ablaze |q 11258/1 |goto 43.66,28.57
step
use the Brave's Flare##33344
Target the Northwest Tower |q 11259/1 |goto 43.66,28.57
step
Enter the building |goto 46.18,28.36 < 10 |walk
use the Brave's Flare##33344
|tip Use it inside this building.
Set the Northeast Longhouse Ablaze |q 11258/2 |goto 46.33,28.21
step
Enter the building |goto 45.74,30.38 < 10 |walk
use the Brave's Torch##33343
|tip Use it inside this building.
Set the Barracks Ablaze |q 11258/3 |goto 45.93,30.71
step
_Next to you:_
use Winterhoof Emblem##33340
talk Winterhoof Brave##24130
|tip He should already be next to you.
|tip Use the item if he's not there.
turnin Burn Skorn, Burn!##11258
step
Follow the path up |goto 44.90,32.14 < 30 |only if walking
use the Brave's Flare##33344
Target the East Tower |q 11259/2 |goto 46.44,33.21
step
use the Brave's Flare##33344
Target the Southeast Tower |q 11259/4 |goto 46.95,36.37
step
label "Accept_Stop_The_Ascension"
Kill Winterskorn enemies around this area
collect Vrykul Scroll of Ascension##33345 |n
use the Vrykul Scroll of Ascension##33345
accept Stop the Ascension!##11260 |goto 44.86,35.07
step
use the Vrykul Scroll of Ascension##33346
Watch the dialogue
|tip Halfdan the Ice-Hearted appears nearby.
kill Halfdan the Ice-Hearted##23671 |q 11260/1 |goto 44.86,35.07
step
label "Dismember_Winterskorn_Vrykul"
Kill Winterskorn enemies around this area
use The Brave's Machete##33343
|tip Use it on their corpses.
Dismember #20# Winterskorn Vrykul |q 11257/1 |goto 44.78,31.41
step
_Next to you:_
use Winterhoof Emblem##33340
talk Winterhoof Brave##24130
|tip He should already be next to you.
|tip Use the item if he's not there.
turnin Gruesome, But Necessary##11257
step
use the Brave's Flare##33344
Target the Southwest Tower |q 11259/3 |goto 43.30,35.93
step
use Winterhoof Emblem##33340
talk Winterhoof Brave##24130
|tip He should already be next to you.
|tip Use the item if he's not there.
turnin Towers of Certain Doom##11259
accept The Conqueror of Skorn!##11261
step
use the Hearthstone##6948
Hearth to Camp Winterhoof |complete subzone("Camp Winterhoof") |q 11261
|only if (subzone("Skorn"))
step
talk Chieftain Ashtotem##24129
turnin The Conqueror of Skorn!##11261 |goto 48.04,10.75
accept Dealing With Gjalerbron##11263 |goto 48.04,10.75
step
talk Greatmother Ankha##24135
turnin Stop the Ascension!##11260 |goto 48.16,10.66
accept Of Keys and Cages##11265 |goto 48.16,10.66
accept Find Sage Mistwalker##11287 |goto 48.16,10.66
step
talk Talu Frosthoof##24028
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Talu Frosthoof##24028 |goto 48.10,11.02 |q 11263
step
talk Longrunner Pembe##24362
turnin The Rune of Command##11352 |goto 49.23,12.24
step
talk Longrunner Skycloud##24209
|tip On the wooden platform.
accept Rivenwood Captives##11296 |goto 31.28,24.34
step
talk Sage Mistwalker##24186
|tip On the wooden platform.
turnin Find Sage Mistwalker##11287 |goto 31.16,24.52
accept The Artifacts of Steel Gate##11286 |goto 31.16,24.52
step
Follow the path down |goto 32.01,24.30 < 40 |only if walking
click Steel Gate Artifact##186397+
|tip They look like grey broken stone tablets laying on the ground.
|tip You can find them all around the Steel Gate area.
collect 10 Steel Gate Artifact##33109 |q 11286/1 |goto 30.88,26.81
step
Follow the path up |goto 31.97,25.85 < 15 |only if walking and subzone("Steel Gate")
talk Sage Mistwalker##24186
|tip On the wooden platform.
turnin The Artifacts of Steel Gate##11286 |goto 31.16,24.52
accept The Cleansing##11317 |goto 31.16,24.52
step
talk Lilleth Radescu##26844
fpath Apothecary Camp |goto 25.98,25.07
step
talk Apothecary Anastasia##24359
|tip She walks around this area.
accept And You Thought Murlocs Smelled Bad!##11397 |goto 26.24,24.61
step
talk Apothecary Malthus##24152
turnin Keeping Watch on the Interlopers##11297 |goto 26.43,24.50
accept What's in That Brew?##11298 |goto 26.43,24.50
step
talk Apothecary Grick##24218
accept Brains! Brains! Brains!##11301 |goto 25.96,24.43
step
talk Samuel Rosemond##24188
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Samuel Rosemond##24188 |goto 25.94,24.65 |q 11263
step
Follow the path to the top of the mountain |goto 54.30,8.23 < 30 |only if walking
click Frostblade Shrine##186649
|tip At the top of the mountain.
Watch the dialogue
kill Your Inner Turmoil##27959
Become Cleansed of Your Inner Turmoil |q 11317/1 |goto 61.12,2.02
step
_NOTE:_
Jump Off the Mountain Toward Camp Winterhoof
|tip You received a slow fall buff.
|tip Jump off the mountain toward this location and float down to Camp Winterhoof.
Reach Camp Winterhoof |complete subzone("Camp Winterhoof") |goto 49.56,11.59 |q 11317
|only if hasbuff("spell:50237")
step
talk Sage Mistwalker##24186
|tip On the wooden platform.
turnin The Cleansing##11317 |goto 31.16,24.52
accept In Worg's Clothing##11323 |goto 31.16,24.52
step
kill Riven Widow Cocoon##24210+
|tip They look like big squirming white cocoons.
|tip You can find them all around the Rivenwood area.
Free #7# Winterhoof Longrunners |q 11296/1 |goto 29.41,17.69
step
use Worg Disguise##33618
Wear the Worg Disguise |complete hasbuff("spell:68347") |goto 29.21,7.56 |q 11323
step
Enter the cave |goto 29.30,6.01 < 15 |walk
talk Ulfang##24261
|tip Inside the small cave.
turnin In Worg's Clothing##11323 |goto 29.70,5.66
accept Brother Betrayers##11415 |goto 29.70,5.66
step
kill Bjomolf##24516 |q 11415/1 |goto 27.47,21.50
|tip He looks like a larger brown wolf that walks around this area.
step
talk Longrunner Skycloud##24209
|tip On the wooden platform.
turnin Rivenwood Captives##11296 |goto 31.28,24.34
step
kill Varg##24517 |q 11415/2 |goto 34.12,30.42
|tip He looks like a larger grey wolf that walks around this area.
stickystart "Kill_Gjalerbron_Warriors"
stickystart "Kill_Gjalerbron_Rune_Casters"
stickystart "Kill_Gjalerbron_Sleep_Watchers"
stickystart "Accept_Gjalerbron_Attack_Plans"
step
Kill Gjalerbron enemies around this area
|tip They look like large humans.
|tip You can find them all around the Gjalerbron area.
collect Gjalerbron Cage Key##33284+ |n
collect Large Gjalerbron Cage Key##33290 |n
|tip This key is rare to find.
|tip It can be used to open the Large Gjalerbron Cage at this location.
|tip The Large Gjalerbron Cage at this location contains multiple prisoners.
click Gjalerbron Cage+
|tip They look like wood and metal cages.
Free #10# Gjalerbron Prisoners |q 11265/1 |goto 35.80,11.46
step
label "Kill_Gjalerbron_Warriors"
kill 15 Gjalerbron Warrior##23991 |q 11263/1 |goto 35.37,11.30
|tip They look like large humans with an axe and a shield.
|tip You can find them all around the Gjalerbron area. |notinsticky
step
label "Kill_Gjalerbron_Rune_Casters"
kill 8 Gjalerbron Rune-Caster##23990 |q 11263/2 |goto 33.64,13.20
|tip They look like large humans wearing white robes.
|tip You can find them all around the Gjalerbron area. |notinsticky
step
label "Kill_Gjalerbron_Sleep_Watchers"
kill 8 Gjalerbron Sleep-Watcher##23989 |q 11263/3 |goto 35.37,11.30
|tip They look like large humans wearing brown robes.
|tip You can find them all around the Gjalerbron area. |notinsticky
step
label "Accept_Gjalerbron_Attack_Plans"
Kill Gjalerbron enemies around this area
|tip They look like large humans. |notinsticky
|tip You can find them all around the Gjalerbron area. |notinsticky
collect Gjalerbron Attack Plans##33347 |n
use the Gjalerbron Attack Plans##33347w
accept Gjalerbron Attack Plans##11266 |goto 33.69,13.12
step
Leave Gjalerbron and run around the mountain |goto 31.39,13.03 < 70 |only if walking and subzone("Gjalerbron")
use the Worg Disguise##33618
Wear the Worg Disguise |complete hasbuff("spell:68347") |goto 29.21,7.56 |q 11415
step
Enter the cave |goto 29.30,6.01 < 15 |walk
talk Ulfang##24261
|tip Inside the small cave.
turnin Brother Betrayers##11415 |goto 29.69,5.67
accept Eyes of the Eagle##11417 |goto 29.69,5.67
step
click Talonshrike's Egg##190283
|tip At the bottom of the waterfall.
kill Talonshrike##24518
|tip It flies down to you.
collect Eyes of the Eagle##34027 |q 11417/1 |goto 41.46,37.69
stickystart "Collect_Deranged_Explorer_Brains"
step
Follow the path up out of the canyon |goto 40.64,35.93 < 15 |only if walking and not subzone("Whisper Gulch")
Follow the path down into Whisper Gulch |goto 37.64,36.05 < 15 |only if walking and not subzone("Whisper Gulch")
click Dwarven Kegs##186632+
|tip They look like large dark wooden kegs on the ground.
|tip You can find them all around inside the Whisper Gulch canyon.
collect 5 Dwarven Keg##33541 |q 11298/1 |goto 33.51,36.68
step
label "Collect_Deranged_Explorer_Brains"
kill Deranged Explorer##23967+
|tip They look like dwarves.
|tip You can find them all around inside the Whisper Gulch canyon. |notinsticky
use Grick's Bonesaw##33554
|tip Use it on their corpses.
collect 12 Deranged Explorer Brain##33558 |q 11301/1 |goto 33.51,36.68
stickystart "Kill_Chillmere_Coast_Scourge"
step
Jump down carefully to leave Whisper Gulch |goto 30.36,36.55 < 10 |only if walking and subzone("Whisper Gulch")
Follow the shore to leave Whisper Gulch |goto 28.39,38.00 < 40 |only if walking and subzone("Whisper Gulch")
Kill enemies around this area
collect Scourge Device##33962 |n
use the Scourge Device##33962
accept It's a Scourge Device##11398 |goto 22.73,31.08
step
Follow the path up the cliff |goto 23.71,21.80 < 15 |only if walking and subzone("Chillmere Coast")
talk Apothecary Malthus##24152
turnin What's in That Brew?##11298 |goto 26.43,24.50
stickystop "Kill_Chillmere_Coast_Scourge"
step
talk Apothecary Anastasia##24359
|tip She walks around this area.
turnin It's a Scourge Device##11398 |goto 26.24,24.61
accept Bring Down Those Shields##11399 |goto 26.24,24.61
step
talk Apothecary Grick##24218
turnin Brains! Brains! Brains!##11301 |goto 25.96,24.43
step
talk Samuel Rosemond##24188
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Samuel Rosemond##24188 |goto 25.94,24.65 |q 11399
stickystart "Kill_Chillmere_Coast_Scourge"
step
Follow the path down the cliff |goto 25.48,20.01 < 30 |only if walking and not subzone("Chillmere Coast")
use the Scourging Crystal Controller##33960
|tip Use it near the Scourge Crystal.
|tip It looks like a large floating purple crystal.
kill Scourging Crystal##24464
|tip Attack the crystal when the purple bubble shield disappears.
|tip If you have a pet, make you you get the killing blow, not your pet, or you won't get credit.
Destroy the Scourging Crystal |q 11399/1 |goto 22.51,17.62 |count 1
step
use the Scourging Crystal Controller##33960
|tip Use it near the Scourge Crystal.
|tip It looks like a large floating purple crystal.
kill Scourging Crystal##24464
|tip Attack the crystal when the purple bubble shield disappears.
|tip If you have a pet, make you you get the killing blow, not your pet, or you won't get credit.
Destroy the Scourging Crystal |q 11399/1 |goto 22.91,20.07 |count 2
step
use the Scourging Crystal Controller##33960
|tip Use it near the Scourge Crystal.
|tip It looks like a large floating purple crystal.
kill Scourging Crystal##24464
|tip Attack the crystal when the purple bubble shield disappears.
|tip If you have a pet, make you you get the killing blow, not your pet, or you won't get credit.
Destroy the Scourging Crystal |q 11399/1 |goto 21.75,22.47 |count 3
step
talk Old Icefin##24544
accept Trident of the Son##11422 |goto 19.78,22.21
step
kill Rotgill##24546
|tip He looks like a white murloc that walks along the coast around this area.
collect Rotgill's Trident##34035 |q 11422/1 |goto 22.89,33.81
step
talk Old Icefin##24544
turnin Trident of the Son##11422 |goto 19.78,22.21
step
label "Kill_Chillmere_Coast_Scourge"
Kill enemies around this area
|tip You can find them all around the Chillmere Coast area.
Kill #15# Chillmere Coast Scourge |q 11397/1 |goto 22.27,22.02
step
Follow the path up the cliff |goto 23.71,21.80 < 15 |only if walking and subzone("Chillmere Coast")
talk Apothecary Anastasia##24359
|tip She walks around this area.
turnin And You Thought Murlocs Smelled Bad!##11397 |goto 26.24,24.61
turnin Bring Down Those Shields##11399 |goto 26.24,24.61
step
talk Samuel Rosemond##24188
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Samuel Rosemond##24188 |goto 25.94,24.65 |q 11266
step
talk Celea Frozenmane##24032
turnin Gjalerbron Attack Plans##11266 |goto 49.57,11.59
step
talk Greatmother Ankha##24135
turnin Of Keys and Cages##11265 |goto 48.16,10.66
accept The Walking Dead##11268 |goto 48.16,10.66
step
talk Chieftain Ashtotem##24129
turnin Dealing With Gjalerbron##11263 |goto 48.04,10.75
accept Necro Overlord Mezhen##11264 |goto 48.04,10.75
step
talk Ahota Whitefrost##24127
accept Sleeping Giants##11433 |goto 48.38,11.04
step
use the Worg Disguise##33618
Wear the Worg Disguise |complete hasbuff("spell:68347") |goto 29.21,7.56 |q 11417
step
Enter the cave |goto 29.33,5.97 < 15 |walk
talk Ulfang##24261
|tip Inside the small cave.
turnin Eyes of the Eagle##11417 |goto 29.69,5.67
accept Alpha Worg##11324 |goto 29.69,5.67
step
kill Garwal##24277 |q 11324/1 |goto 27.32,15.39
|tip He looks like a larger grey wolf that walks around this area.
stickystart "Kill_Deathless_Watchers"
stickystart "Collect_Awakening_Rods"
stickystart "Kill_Putrid_Wights"
step
Run up the ramp |goto 38.33,10.88 < 15 |only if walking
kill Necro Overlord Mezhen##24018 |q 11264/1 |goto 38.79,13.08
collect Mezhen's Writings##34091 |goto 38.79,13.08 |q 11453 |future
step
use Mezhen's Writings##34091
accept The Slumbering King##11453
step
Enter the building |goto 39.77,7.61 < 15 |walk
kill Queen Angerboda##24023 |q 11453/1 |goto 40.89,6.48
|tip Inside the building.
|tip Follow the path around inside the building to get to her.
step
label "Kill_Deathless_Watchers"
Leave the building |goto 39.77,7.61 < 15 |walk |only if subzone("Winter's Terrace")
kill 10 Deathless Watcher##24013 |q 11268/1 |goto 33.72,9.96
You can find more around: |notinsticky
[36.40,15.73]
[36.87,8.19]
step
label "Collect_Awakening_Rods"
kill Necrolord##24014+
collect 5 Awakening Rod##34083 |goto 38.50,12.53 |q 11433
You can find more around [33.25,9.33]
step
label "Kill_Putrid_Wights"
kill 2 Putrid Wight##23992 |q 11268/3 |goto 33.72,9.96
You can find more around: |notinsticky
[36.40,15.73]
[36.87,8.19]
stickystart "Kill_Fearsome_Horrors"
step
Enter the building |goto 34.43,13.16 < 15 |walk
use the Awakening Rod##34083+
|tip Use them on Dormant Vrykul.
|tip They look like vrykul sleeping upright inside the walls like mummies around this area inside the building.
kill 5 Dormant Vrykul##24669 |q 11433/1 |goto 35.12,11.70
step
label "Kill_Fearsome_Horrors"
kill 4 Fearsome Horror##24073 |q 11268/2 |goto 35.35,12.19
|tip Inside the building.
|tip They can be spread out in all of the rooms in this underground building.
step
use the Hearthstone##6948
Hearth to Camp Winterhoof |complete subzone("Camp Winterhoof") |q 11268
|only if (subzone("The Waking Halls"))
step
talk Ahota Whitefrost##24127
turnin Sleeping Giants##11433 |goto 48.38,11.04
step
talk Greatmother Ankha##24135
turnin The Walking Dead##11268 |goto 48.16,10.66
step
talk Chieftain Ashtotem##24129
turnin Necro Overlord Mezhen##11264 |goto 48.04,10.75
turnin The Slumbering King##11453 |goto 48.04,10.75
step
talk Talu Frosthoof##24028
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Talu Frosthoof##24028 |goto 48.10,11.02 |q 11324
step
talk Sage Mistwalker##24186
turnin Alpha Worg##11324 |goto 31.16,24.52
step
talk Orfus of Kamagua##23804
accept The Dead Rise!##11504 |goto 40.29,60.25
step
Enter New Agamand |goto 51.30,67.81 < 30 |only if walking and not subzone("New Agamand")
talk Tobias Sarkhoff##24155
fpath New Agamand |goto 52.01,67.38
step
talk Plaguebringer Tillinghast##24157
accept Green Eggs and Whelps##11279 |goto 53.07,66.93
step
talk Chief Plaguebringer Harris##24251
turnin New Agamand##11304 |goto 53.59,66.36
accept A Tailor-Made Formula##11305 |goto 53.59,66.36
step
talk "Hacksaw" Jenny##24252
accept Shield Hill##11424 |goto 53.68,65.21
step
kill Thorvald##27926
collect Dragonflayer Patriarch's Blood##38098 |q 11305/1 |goto 46.80,68.09
step
Enter New Agamand |goto 51.30,67.81 < 30 |only if walking and not subzone("New Agamand")
talk Chief Plaguebringer Harris##24251
turnin A Tailor-Made Formula##11305 |goto 53.59,66.36
accept Apply Heat and Stir##11306 |goto 53.59,66.36
step
_Gather a Flask:_
use Empty Apothecary's Flask##33614
|tip Nearby, next to the metal cauldron.
|tip This will give you a Flask of Vrykul Blood.
collect Flask of Vrykul Blood##33614+ |n
_Test the Flask:_
use the Flask of Vrykul Blood##33615+
|tip Nearby, next to the table with chemistry instruments on it.
|tip Enemies way spawn after you use the flask, if you don't get the quest item.
_Repeat the Process:_
|tip Continue filling the Empty Apothecary's Flasks at the cauldron, and testing the Flasks of Vrykul Blood at the table.
|tip You will eventually create a Balanced Concoction.
collect Balanced Concoction##33617 |q 11306/1 |goto 53.57,66.39
step
talk Chief Plaguebringer Harris##24251
turnin Apply Heat and Stir##11306 |goto 53.59,66.36
accept Field Test##11307 |goto 53.59,66.36
step
use the Plague Spray##33621
|tip Use it on Plagued Dragonflayer enemies.
|tip They look like green large humans.
|tip You can find them all around the Halgrind area.
Spray #10# Plagued Vrykul |q 11307/1 |goto 49.78,54.61
stickystart "Collect_Plagued_Proto_Whelp_Specimens"
step
Follow the path to leave Halgrind |goto 49.50,50.28 < 30 |only if walking and subzone("Halgrind")
talk Ember Clutch Ancient##23870+
|tip They look like large trees that walks around this area.
accept Root Causes##11182 |goto 41.18,49.34
stickystart "Kill_Dragonflayer_Handlers"
step
Enter the building |goto 41.35,52.85 < 10 |walk
kill Skeld Drakeson##23940 |q 11182/2 |goto 41.46,52.35
|tip Inside the building.
step
label "Kill_Dragonflayer_Handlers"
kill 5 Dragonflayer Handler##23871 |q 11182/1 |goto 41.44,53.87
step
talk Ember Clutch Ancient##23870+
|tip They look like large trees that walks around this area.
turnin Root Causes##11182 |goto 41.18,49.34
step
label "Collect_Plagued_Proto_Whelp_Specimens"
use Tillinghast's Plague Canister##33418
|tip Use it on Proto-Drake Eggs.
|tip They look like large white eggs.
|tip You can find them all around the Ember Clutch area.
kill Plagued Proto-Whelp##24160+
|tip They appear after you destroy the eggs.
collect 10 Plagued Proto-Whelp Specimen##33420 |q 11279/1 |goto 39.38,50.75
step
Enter New Agamand |goto 51.30,67.81 < 30 |only if walking and not subzone("New Agamand")
talk Plaguebringer Tillinghast##24157
turnin Green Eggs and Whelps##11279 |goto 53.07,66.93
accept Draconis Gastritis##11280 |goto 53.07,66.93
step
talk Chief Plaguebringer Harris##24251
turnin Field Test##11307 |goto 53.59,66.36
accept Time for Cleanup##11308 |goto 53.59,66.36
step
talk "Hacksaw" Jenny##24252
turnin Time for Cleanup##11308 |goto 53.68,65.21
accept Parts for the Job##11309 |goto 53.68,65.21
step
talk Orson Locke##24330
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Orson Locke##24330 |goto 53.85,66.94 |q 11309
step
map Howling Fjord
path	follow strictbounce;	loop off;	ants curved;	dist 30;	markers none
path	52.15,73.51		50.58,73.81		50.19,74.25		49.33,74.32		48.20,73.22
path	48.05,72.85		47.80,72.52		47.61,72.03		47.62,71.36		47.20,70.79
path	46.93,70.27		46.21,70.06		45.57,69.04
talk Anton##24291
|tip He looks like an undead in a black robe.
|tip He walks along the road.
buy Fresh Pound of Flesh##33612 |q 11309/2
stickystart "Collect_Ancient_Vrykul_Bones"
step
click Mound of Debris##187022
|tip It looks like a pile of dirt.
collect Fengir's Clue##34222 |q 11504/1 |goto 57.68,77.52
step
click Unlocked Chest##187023
|tip It looks like a small brown metal and wooden chest.
collect Rodin's Clue##34223 |q 11504/2 |goto 59.23,76.98
step
click Long Tail Feather##187026
|tip It looks like a blue feather.
collect Isuldof's Clue##34224 |q 11504/3 |goto 59.79,79.39
step
click Cannonball##187027
|tip It looks like a grey boulder.
collect Windan's Clue##34225 |q 11504/4 |goto 61.97,80.06
step
label "Collect_Ancient_Vrykul_Bones"
kill Risen Vrykul Ancestor##24871+
|tip They look like large skeletons.
|tip You can find them all around the Shield Hill area.
collect 5 Ancient Vrykul Bone##34043 |q 11424/1 |goto 59.95,78.45
step
Cross the bridge |goto 59.39,72.99 < 30 |only if walking and subzone("Shield Hill")
talk Ranger Captain Areiel##27922
accept Against Nifflevar##12482 |goto 67.45,60.58
step
talk Scribe Seguine##24548
accept The Enemy's Legacy##11423 |goto 67.35,60.32
stickystart "Slay_Dragonflayer_Warriors"
stickystart "Slay_Dragonflayer_RuneSeers"
stickystart "Slay_Dragonflayer_Hunting_Hounds"
step
Enter the building |goto 67.61,56.61 < 10 |walk
click Saga of the Val'kyr##186830
|tip It looks like an unrolled scroll.
|tip Inside the building.
collect Saga of the Val'kyr##34042 |q 11423/2 |goto 67.42,57.16
step
Enter the building |goto 66.18,53.95 < 20 |walk
click the Saga of the Twins##525
|tip It looks like an unrolled scroll.
|tip Inside the building.
collect Saga of the Twins##34040 |q 11423/1 |goto 64.68,53.57
step
Enter the building |goto 68.69,53.10 < 10 |walk
click the Saga of the Winter Curse##525
|tip It looks like an unrolled scroll.
|tip Inside the building.
collect Saga of the Winter Curse##34041 |q 11423/3 |goto 68.93,52.62
step
label "Slay_Dragonflayer_Warriors"
kill 5 Dragonflayer Warrior##23654 |q 12482/1 |goto 67.94,53.88
|tip They look like large humans holding an axe and a club.
|tip You can find them all around the Nifflevar area. |notinsticky
step
label "Slay_Dragonflayer_RuneSeers"
kill 4 Dragonflayer Rune-Seer##23656 |q 12482/2 |goto 67.94,53.88
|tip They look like large humans wearing robes.
|tip You can find them all around the Nifflevar area. |notinsticky
step
label "Slay_Dragonflayer_Hunting_Hounds"
kill 4 Dragonflayer Hunting Hound##23994 |q 12482/3 |goto 67.94,53.88
|tip They look like hyenas.
|tip You can find them all around the Nifflevar area. |notinsticky
step
talk Ranger Captain Areiel##27922
turnin Against Nifflevar##12482 |goto 67.45,60.58
step
talk Scribe Seguine##24548
turnin The Enemy's Legacy##11423 |goto 67.35,60.32
step
Kill Shoveltusk enemies around this area
|tip They look like buffalo.
collect 6 Shoveltusk Ligament##33611 |q 11309/1 |goto 67.93,62.99
You can: |notinsticky
Find more around [69.05,69.78]
Cross the bridge at [62.30,72.19]
Find more across the bridge around [54.04,71.38]
step
talk Orson Locke##24330
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Orson Locke##24330 |goto 53.85,66.94 |q 11309
step
talk "Hacksaw" Jenny##24252
turnin Parts for the Job##11309 |goto 53.68,65.21
accept Warning: Some Assembly Required##11310 |goto 53.68,65.21
turnin Shield Hill##11424 |goto 53.68,65.21
step
use Abomination Assembly Kit##33613
|tip You will start to control a Mindless Abomination.
|tip Send your Mindless Abomination into groups of enemies.
|tip You can find them all around the Halgrind area.
|tip Gather them up so that a group of many are attacking your abomination.
|tip Use the "Plagued Blood Explosion" ability on your pet action bar when you have many attacking your abomination.
|tip Your abomination will blow up and kill the enemies.
|tip Do this multiple times.
|tip Blow up the Abomination before it dies, or the Vrykul he aggroed may attack you.
Exterminate #20# Plagued Vrykul |q 11310/1 |goto 49.50,57.29
step
use Tillinghast's Plagued Meat##33441
|tip Use it on a Proto-Drake.
|tip They look like dragons flying in the sky around this area.
|tip The drake will fly down and die.
Observe the Proto-Drake Plague Results |q 11280/1 |goto 39.18,50.38
step
talk Orfus of Kamagua##23804
turnin The Dead Rise!##11504 |goto 40.29,60.25
accept Elder Atuik and Kamagua##11507 |goto 40.29,60.25
step
Enter the building |goto 25.09,57.20 < 15 |walk
talk Elder Atuik##24755
|tip Inside the building.
turnin Elder Atuik and Kamagua##11507 |goto 25.02,56.97
accept Grezzix Spindlesnap##11508 |goto 25.02,56.97
accept Feeding the Survivors##11456 |goto 25.02,56.97
step
talk Kip Trawlskip##28197
fpath Kamagua |goto 24.66,57.77
step
talk Deniigi##27151
|tip In the doorway of the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Deniigi##27151 |goto 25.65,57.44 |q 11456
step
kill Island Shoveltusk##24681+
|tip They look like buffalo.
|tip The grey wolves will kill nearby Shoveltusks, so kill those too, if you need to.
|tip You can find them all around the Isle of Spears area.
collect 6 Island Shoveltusk Meat##36776 |q 11456/1 |goto 30.53,60.03
You can find more around:
[29.21,58.55]
[27.24,63.61]
[28.62,64.69]
[32.64,66.28]
[36.38,53.29]
[29.16,66.53]
[30.95,62.43]
step
Enter the building |goto 25.09,57.20 < 15 |walk
talk Elder Atuik##24755
|tip Inside the building.
turnin Feeding the Survivors##11456 |goto 25.02,56.97
accept Arming Kamagua##11457 |goto 25.02,56.97
step
talk Deniigi##27151
|tip In the doorway of the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Deniigi##27151 |goto 25.65,57.44 |q 11457
step
kill Frostwing Chimaera##24673+
|tip They look like blue and white two-headed dragons.
collect 3 Chimaera Horn##34101 |q 11457/1 |goto 28.12,54.71
You can find more around [27.52,67.05]
step
Enter the building |goto 25.09,57.20 < 15 |walk
talk Elder Atuik##24755
|tip Inside the building.
turnin Arming Kamagua##11457 |goto 25.02,56.97
accept Avenge Iskaal##11458 |goto 25.02,56.97
step
talk Deniigi##27151
|tip In the doorway of the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Deniigi##27151 |goto 25.65,57.44 |q 11458
step
Enter the underground building |goto 25.34,59.35 < 10 |walk
talk Caregiver Iqniq##27148
|tip Inside the building.
home Kamagua |goto 25.39,59.85
step
talk Grezzix Spindlesnap##24643
|tip On the small boat.
turnin Grezzix Spindlesnap##11508 |goto 23.08,62.66
accept Street "Cred"##11509 |goto 23.08,62.66
step
talk Lou the Cabin Boy##24896
|tip On the small canoe.
Tell him _"I don't have time for chit-chat, Lou. Take me to Scalawag Point."_
Begin Traveling to Scalawag Point |invehicle |goto 23.10,62.58 |q 11509
step
Watch the dialogue
|tip You will eventually travel to this location.
Travel to Scalawag Point |outvehicle |goto 35.51,82.40 |q 11509 |notravel
step
talk "Silvermoon" Harry##24539
|tip Inside the tent.
turnin Street "Cred"##11509 |goto 35.09,80.94
accept "Scoodles"##11510 |goto 35.09,80.94
step
talk Handsome Terry##24537
accept Forgotten Treasure##11434 |goto 35.60,80.22
step
Board the ship |goto 37.21,78.96 < 10 |only if walking
talk Scuttle Frostprow##24784
accept Swabbin' Soap##11469 |goto 37.75,79.58
step
kill "Scoodles"##24899
|tip It looks like an orca that swims in the water around this area.
collect Sin'dorei Scrying Crystal##34235 |q 11510/1 |goto 38.85,84.12
step
use the Fish Bladder##34076
|tip This will allow you to breathe underwater for 3 minutes.
Gain Water Breathing |havebuff spell:44235 |q 11434
step
Swim through the small window underwater |goto 38.15,84.45 < 7 |walk
click Eagle Figurine##186886
|tip It looks like a small grey and blue stone bird statue.
|tip Underwater, inside the ship.
collect Eagle Figurine##34070 |q 11434/2 |goto 37.77,84.62
step
click Amani Vase##186885
|tip It looks like a grey stone jar.
|tip Underwater, inside the broken boat.
collect Amani Vase##34069 |q 11434/1 |goto 37.15,85.49
step
talk Handsome Terry##24537
turnin Forgotten Treasure##11434 |goto 35.60,80.22
accept The Fragrance of Money##11455 |goto 35.60,80.22
step
talk Taruk##24541
accept Gambling Debt##11464 |goto 36.32,80.48
step
talk "Silvermoon" Harry##24539
|tip Inside the tent.
turnin "Scoodles"##11510 |goto 35.09,80.94
accept The Staff of Storm's Fury##11511 |goto 35.09,80.94
accept The Frozen Heart of Isuldof##11512 |goto 35.09,80.94
accept The Lost Shield of the Aesirites##11519 |goto 35.09,80.94
accept The Ancient Armor of the Kvaldir##11567 |goto 35.09,80.94
step
talk "Silvermoon" Harry##24539
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor "Silvermoon" Harry##24539 |goto 35.09,80.94 |q 11511
step
talk "Silvermoon" Harry##24539
|tip Inside the tent.
Tell him _"Taruk sent me to collect what you owe."_
kill "Silvermoon" Harry##24539
|tip Don't kill him, just get him to low health.
|tip You will eventually be able to talk to him again.
talk "Silvermoon" Harry##24539
Tell him _"Pay up, Harry!"_
collect "Silvermoon" Harry's Debt##34115 |q 11464/1 |goto 35.09,80.94
step
talk Taruk##24541
turnin Gambling Debt##11464 |goto 36.32,80.48
accept Jack Likes His Drink##11466 |goto 36.32,80.48
step
Enter the building |goto 35.28,80.22 < 10 |walk
talk Olga, the Scalawag Wench##24639
|tip Inside the building.
Tell her _"I'd like to buy Jack a drink. Perhaps something... extra strong."_
Click Here After You Buy Jack Adams a Drink |confirm |goto 35.31,79.59 |q 11466
step
Watch the dialogue
|tip Jack Adams will pass out on the table.
|tip Inside the building.
talk Jack Adams##24788
Choose _<Discreetly search the pirate's pockets for Taruk's payment.>_
collect Jack Adams' Debt##34116 |q 11466/1 |goto 35.49,79.38
step
Leave the building |goto 35.28,80.22 < 10 |walk |only if subzone("Scalawag Point") and _G.IsIndoors()
talk Taruk##24541
turnin Jack Likes His Drink##11466 |goto 36.32,80.48
accept Dead Man's Debt##11467 |goto 36.32,80.48
step
Follow the road to leave Scalawag Point |goto 36.51,77.46 < 40 |only if walking and subzone("Scalawag Point")
kill Rabid Brown Bear##24633+
|tip They look like brown bears.
|tip You can find them all around the Garvan's Reef area.
collect 4 Bear Musk##34084 |q 11455/1 |goto 34.09,77.91
step
kill Big Roy##24785
|tip He looks like a big seal that swims in the water around this area.
collect Big Roy's Blubber##34122 |q 11469/1 |goto 31.40,78.62
step
talk Handsome Terry##24537
turnin The Fragrance of Money##11455 |goto 35.60,80.22
accept A Traitor Among Us##11473 |goto 35.60,80.22
step
talk Zeh'gehn##24525
turnin A Traitor Among Us##11473 |goto 35.56,80.63
accept Zeh'gehn Sez##11459 |goto 35.56,80.63
step
talk Handsome Terry##24537
turnin Zeh'gehn Sez##11459 |goto 35.60,80.22
accept A Carver and a Croaker##11476 |goto 35.60,80.22
step
talk "Silvermoon" Harry##24539
|tip Inside the tent.
buy Shiny Knife##35813 |n
collect Shiny Knife##35813 |q 11476/2 |goto 35.1,80.9
step
talk "Silvermoon" Harry##24539
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor "Silvermoon" Harry##24539 |goto 35.09,80.94 |q 11476
step
clicknpc Scalawag Frog##26503
|tip They look like blue and green frogs that hop around on the ground around this area.
collect Scalawag Frog##35803 |q 11476/1 |goto 35.56,81.81
step
talk Zeh'gehn##24525
turnin A Carver and a Croaker##11476 |goto 35.56,80.63
step
Watch the dialogue
talk Zeh'gehn##24525
accept "Crowleg" Dan##11479 |goto 35.56,80.63
step
Board the ship |goto 35.85,82.26 < 10 |only if walking
talk "Crowleg" Dan##24713
Tell him _"Ummm... the frog says you're a traitor, "matey.""_
kill "Crowleg" Dan##24713 |q 11479/1 |goto 35.95,83.60
step
talk Handsome Terry##24537
turnin "Crowleg" Dan##11479 |goto 35.60,80.22
accept Meet Number Two##11480 |goto 35.60,80.22
step
Enter the building |goto 35.27,80.21 < 10 |walk
talk Annie Bonn##24741
|tip She walks around this area.
|tip Upstairs inside the building.
turnin Meet Number Two##11480 |goto 35.44,79.42
accept The Jig is Up##11471 |goto 35.44,79.42
step
Leave the building |goto 35.27,80.21 < 10 |walk |only if subzone("Scalawag Point") and _G.IsIndoors()
Board the ship |goto 37.21,78.96 < 10 |only if walking
talk Scuttle Frostprow##24784
turnin Swabbin' Soap##11469 |goto 37.75,79.58
step
talk Captain Ellis##24910
|tip He's on the top deck of a pirate ship that sails around this area.
|tip Board the ship when it stops at this location.
turnin The Lost Shield of the Aesirites##11519 |goto 37.85,74.79
accept Mutiny on the Mercy##11527 |goto 37.85,74.79
step
_Downstairs Inside the Ship:_
kill Mutinous Sea Dog##25026+
|tip Downstairs, on the bottom deck, inside the pirate ship that sails around this area.
collect 5 Barrel of Blasting Powder##34387 |q 11527/1
step
_On the Ship Desk:_
talk Captain Ellis##24910
|tip He's on the top deck of a pirate ship that sails around this area.
turnin Mutiny on the Mercy##11527
accept Sorlof's Booty##11529
step
clicknpc The Big Gun##24992
|tip At the front of the ship, on the top deck of the pirate ship that sails around this area.
|tip Keep clicking it repeatedly until Sorlof is dead on the shore.
kill Sorlof##24914
|tip He looks like a large tree that walks along the shore around this area.
click Sorlof's Booty##187238
|tip It looks like a yellow pile of gold that appears on the ground after Sorlof dies.
|tip Jump off the ship to loot it.
collect Sorlof's Booty##34468 |q 11529/1
step
Enter the cave |goto 33.57,75.64 < 10 |walk
kill "Mad" Jonah Sterling##24742
|tip He looks like a human wearing a red coat.
|tip He walks around this small area inside the cave.
|tip He eventually runs away and gets eaten by a large white bear on the bottom level of the cave.
|tip He is a level 70 elite enemy, but you should be able to kill him at this level.
|tip If you have trouble, try to find someone to help you, or skip the quest.
Click Here After Killing "Mad" Jonah Sterling |confirm |goto 33.78,78.02 |q 11471
step
kill Hozzer##24547
|tip He looks like a large white bear.
|tip Downstairs inside the cave.
|tip He is a level 71 elite enemy, but you should be able to kill him at this level.
|tip If you have trouble, try to find someone to help you, or skip the quest.
collect Jonah Sterling's Spyglass##34128 |q 11471/1 |goto 33.39,78.30
step
Follow the path up |goto 32.99,78.18 < 10 |walk
click The Frozen Heart of Isuldof##187032
|tip Downstairs inside the cave.
collect The Frozen Heart of Isuldof##34237 |q 11512/1 |goto 32.34,78.68
step
Follow the path back up and leave the cave |goto 33.57,75.64 < 10 |walk |only if subzone("Garvan's Reef") and _G.IsIndoors()
Follow the path up |goto 28.85,60.99 < 30 |only if walking
Cross the hanging bridge |goto 29.83,60.87 < 10 |only if walking
click Dirt Mound##186944
Watch the dialogue
Kill the enemies that attack
kill Black Conrad's Ghost##24790
collect Black Conrad's Treasure##34118 |q 11467/1 |goto 32.69,60.21
step
kill 8 Crazed Northsea Slaver##24676 |q 11458/1 |goto 33.71,63.84
step
Board the ship while being careful to avoid Abdul the Insane |goto 34.94,63.68 < 10 |only if walking
Wait for Adbul the Insane to walk to the top deck of the ship, then enter the ship here |goto 35.39,64.68 < 7 |walk
click The Staff of Storm's Fury##187033
|tip Downstairs inside the ship, on the bottom level.
collect The Staff of Storm's Fury##34236 |q 11511/1 |goto 35.26,64.84
step
use the Hearthstone##6948
Hearth to Kamagua |complete subzone("Kamagua") |q 11511
|only if subzone("Iskaal")
step
Enter the building |goto 25.09,57.20 < 15 |walk
talk Elder Atuik##24755
|tip Inside the building.
turnin Avenge Iskaal##11458 |goto 25.02,56.97
step
talk Deniigi##27151
|tip In the doorway of the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Deniigi##27151 |goto 25.65,57.44 |q 11511
step
talk Anuniaq##24810
accept Travel to Moa'ki Harbor##12117 |goto 24.59,58.86 |or
accept Travel to Moa'ki Harbor##12118 |goto 24.59,58.86 |or
step
Enter the building |goto 35.27,80.21 < 10 |walk
talk Annie Bonn##24741
|tip Upstairs inside the building.
turnin The Jig is Up##11471 |goto 35.41,79.43
step
Leave the building |goto 35.27,80.21 < 10 |walk |only if subzone("Scalawag Point") and _G.IsIndoors()
talk Taruk##24541
turnin Dead Man's Debt##11467 |goto 36.32,80.48
step
talk Alanya##27933
Tell her _"Harry said I could take his bomber to Bael'gun's. I'm ready to go!"_
Begin Flying to Bael'gun's |invehicle |goto 36.09,81.60 |q 11567
step
Fly to Bael'gun's |outvehicle |goto 80.87,75.10 |q 11567 |notravel
step
Enter the ship |goto 82.26,74.77 < 10 |walk
click The Ancient Armor of the Kvaldir##187381
|tip It looks like a floating metal chest armor.
|tip Downstairs inside the ship.
collect The Ancient Armor of the Kvaldir##34239 |q 11567/1 |goto 81.78,73.91
step
clicknpc Harry's Bomber##28277
Choose _<Get in the bomber and return to Scalawag Point.>_
Begin Flying Back to Scalawag Point |invehicle |goto 80.89,75.10 |q 11567 |or
step
Return to Scalawag Point |outvehicle |goto 36.07,81.68 |q 11567 |notravel
step
talk Captain Ellis##24910
|tip He's on the top deck of a pirate ship that sails around this area.
|tip Board the ship when it stops at this location.
turnin Sorlof's Booty##11529 |goto 37.85,74.79
accept The Shield of the Aesirites##11530 |goto 37.85,74.79
step
Ride the lift up |goto 42.07,67.71 < 15 |only if walking and (subzone("Scalawag Point") or subzone("Garvan's Reef") or subzone("Sorlof's Strand"))
talk Orfus of Kamagua##23804
turnin The Shield of the Aesirites##11530 |goto 40.29,60.25
turnin The Staff of Storm's Fury##11511 |goto 40.29,60.25
turnin The Frozen Heart of Isuldof##11512 |goto 40.29,60.25
turnin The Ancient Armor of the Kvaldir##11567 |goto 40.29,60.25
accept A Return to Resting##11568 |goto 40.29,60.25
step
Enter New Agamand |goto 51.30,67.81 < 30 |only if walking and not subzone("New Agamand")
talk Plaguebringer Tillinghast##24157
turnin Draconis Gastritis##11280 |goto 53.07,66.93
step
talk "Hacksaw" Jenny##24252
turnin Warning: Some Assembly Required##11310 |goto 53.68,65.21
step
use the Bundle of Vrykul Artifacts##34624
Return the Shield of Aesirites |q 11568/1 |goto 57.64,77.41
step
use the Bundle of Vrykul Artifacts##34624
Return the Staff of Storm's Fury |q 11568/2 |goto 59.30,77.20
step
use the Bundle of Vrykul Artifacts##34624
Return the Frozen Heart of Isuldof |q 11568/3 |goto 59.78,79.40
step
use the Bundle of Vrykul Artifacts##34624
Return the Ancient Armor of the Kvaldir |q 11568/4 |goto 61.89,80.14
step
talk Orfus of Kamagua##23804
turnin A Return to Resting##11568 |goto 40.29,60.25
accept Return to Atuik##11572 |goto 40.29,60.25
step
Enter the building |goto 25.09,57.20 < 15 |walk
talk Elder Atuik##24755
|tip Inside the building.
turnin Return to Atuik##11572 |goto 25.02,56.97
step
talk Deniigi##27151
|tip In the doorway of the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Deniigi##27151 |goto 25.65,57.44 |q 11585 |future
]])
ZygorGuidesViewer:RegisterGuide("Leveling Guides\\Northrend (69-80)\\Borean Tundra (70-72)",{
author="support@zygorguides.com",
image=ZGV.IMAGESDIR.."Borean",
condition_suggested=function() return level >= 70 and level <= 72 and not completedq(12728) end,
next="Leveling Guides\\Northrend (69-80)\\Dragonblight (72-74)",
},[[
step
talk Warsong Recruitment Officer##25273
|tip Inside the building, on the top floor.
accept Hellscream's Vigil##11585 |goto Borean Tundra 41.62,53.99
step
talk Garrosh Hellscream##25237
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
turnin Hellscream's Vigil##11585 |goto 41.35,53.58
step
talk High Overlord Saurfang##25256
|tip Inside the building, on the bottom floor.
accept The Defense of Warsong Hold##11596 |goto 41.36,53.70
step
talk Williamson##25278
|tip Inside the building, on the bottom floor.
home Warsong Hold |goto 41.92,54.48
step
Leave the building |goto 42.73,55.83 < 20 |walk |only if subzone("Warsong Hold") and _G.IsIndoors()
Enter the building |goto 43.28,55.07 < 10 |walk
talk Overlord Razgor##25279
|tip Inside the building.
turnin The Defense of Warsong Hold##11596 |goto 43.19,54.97
accept Taking Back Mightstone Quarry##11598 |goto 43.19,54.97
step
talk Quartermaster Holgoth##25327
accept Patience is a Virtue that We Don't Need##11606 |goto 43.33,55.36
step
talk Foreman Mortuus##25280
|tip He walks around this area.
accept Taken by the Scourge##11611 |goto 42.02,56.13
stickystart "Collect_Warsong_Munitions"
stickystart "Slay_Nerubar"
step
kill Nerub'ar Victim##25284+
|tip They look like white squirming cocoons on the ground.
|tip You can find them all around the Mightstone Quarry area.
|tip The Mightstone Quarry wraps around the entire building.
Free #5# Warsong Peons |q 11611/1 |goto 40.89,58.21
step
label "Collect_Warsong_Munitions"
click Warsong Munitions Crate##187661+
|tip They look like wooden crates on the ground.
|tip You can find them all around the Mightstone Quarry area. |notinsticky
|tip The Mightstone Quarry wraps around the entire building. |notinsticky
collect 15 Warsong Munitions##34709 |q 11606/1 |goto 40.89,58.21
step
label "Slay_Nerubar"
Kill Nerub'ar enemies around this area
|tip They look like insects.
|tip You can find them all around the Mightstone Quarry area. |notinsticky
|tip The Mightstone Quarry wraps around the entire building. |notinsticky
Slay #15# Nerub'ar |q 11598/1 |goto 40.89,58.21
step
talk Foreman Mortuus##25280
|tip He walks around this area.
turnin Taken by the Scourge##11611 |goto 42.02,56.13
step
talk Quartermaster Holgoth##25327
turnin Patience is a Virtue that We Don't Need##11606 |goto 43.33,55.36
accept Bury Those Cockroaches!##11608 |goto 43.33,55.36
step
Enter the building |goto 43.28,55.07 < 10 |walk
talk Overlord Razgor##25279
|tip Inside the building.
turnin Taking Back Mightstone Quarry##11598 |goto 43.19,54.97
accept Cutting Off the Source##11602 |goto 43.19,54.97
step
talk Shadowstalker Barthus##25394
|tip Inside the building.
accept Untold Truths##11614 |goto 43.20,55.05
step
Enter the building |goto 42.73,55.84 < 15 |walk |only if not (subzone("Warsong Hold") and _G.IsIndoors())
talk Endorah##25247
|tip Inside the building, on the bottom floor.
accept Too Close For Comfort##11574 |goto 41.73,54.73
step
talk Ambassador Talonga##25978
|tip Inside the building, on the bottom floor.
accept Ride to Taunka'le Village##11888 |goto 41.70,54.59
step
talk Armorer Orkuruk##25274
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Armorer Orkuruk##25274 |goto 41.15,55.54 |q 11574
step
talk Sauranok the Mystic##25272
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
accept To Bor'gorok Outpost, Quickly!##12486 |goto 41.36,53.23
stickystart "Destroy_Nerubar_Egg_Sacs"
step
Leave the building |goto 42.73,55.83 < 20 |walk |only if subzone("Warsong Hold") and _G.IsIndoors()
use Seaforium Depth Charge Bundle##34710
Watch the dialogue
|tip A countdown will take place before the bomb explodes.
Destroy the East Nerub'ar Sinkhole |q 11608/2 |goto 44.23,56.76
step
use Seaforium Depth Charge Bundle##34710
Watch the dialogue
|tip A countdown will take place before the bomb explodes.
Destroy the South Nerub'ar Sinkhole |q 11608/1 |goto 41.62,58.29
step
use Seaforium Depth Charge Bundle##34710
|tip Outside, behind the building.
|tip Follow the path around the building to travel here.
Watch the dialogue
|tip A countdown will take place before the bomb explodes.
Destroy the West Nerub'ar Sinkhole |q 11608/3 |goto 39.81,52.54
step
talk Shadowstalker Luther##25328
|tip Outside, behind the building.
turnin Untold Truths##11614 |goto 40.07,52.06
accept Nerub'ar Secrets##11615 |goto 40.07,52.06
step
use Seaforium Depth Charge Bundle##34710
|tip Outside, behind the building.
Watch the dialogue
|tip A countdown will take place before the bomb explodes.
Destroy the North Nerub'ar Sinkhole |q 11608/4 |goto 41.35,50.36
step
label "Destroy_Nerubar_Egg_Sacs"
click Nerub'ar Egg Sac##187655+
|tip They look like white eggs sitting upright on small brown stands.
|tip They can only be found on the metal and wooden platforms along the perimeter of Mightstone Quarry.
|tip Enemies may spawn when you break the eggs.
Destroy #10# Nerub'ar Egg Sacs |q 11602/1 |goto 40.04,50.86
You can find more around: |notinsticky
[39.12,55.10]
[40.08,58.19]
[42.46,61.67]
[43.90,59.12]
step
talk Quartermaster Holgoth##25327
|tip Outside, in front of the building.
turnin Bury Those Cockroaches!##11608 |goto 43.33,55.36
step
Enter the building |goto 43.28,55.07 < 10 |walk
talk Overlord Razgor##25279
|tip Inside the building.
turnin Cutting Off the Source##11602 |goto 43.19,54.97
accept Wind Master To'bor##11634 |goto 43.19,54.97
step
talk Shadowstalker Barthus##25394
|tip Inside the building.
turnin Nerub'ar Secrets##11615 |goto 43.20,55.05
accept Message to Hellscream##11616 |goto 43.20,55.05
step
Enter the building |goto 42.73,55.84 < 15 |walk |only if not (subzone("Warsong Hold") and _G.IsIndoors())
talk Armorer Orkuruk##25274
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Armorer Orkuruk##25274 |goto 41.15,55.54 |q 11616
step
talk Garrosh Hellscream##25237
|tip Inside the building, on the bottom floor.
turnin Message to Hellscream##11616 |goto 41.35,53.59
accept Reinforcements Incoming...##11618 |goto 41.35,53.59
step
Run up the ramp and ride the elevator up |goto 40.71,52.54 < 15 |only if walking
talk Turida Coldwind##25288
|tip Outside, on top of the building.
fpath Warsong Hold |goto 40.36,51.40
step
talk Wind Master To'bor##25289
|tip He walks around this area.
|tip Outside, on top of the building.
turnin Wind Master To'bor##11634 |goto 42.48,55.21
accept Magic Carpet Ride##11636 |goto 42.48,55.21
step
talk Yanni##25459
|tip Outside, on top of the building.
Tell him _"Send me to Garrosh's Landing, Yanni."_
Begin Flying to Garrosh's Landing |invehicle |goto 42.29,55.68 |q 11636
step
Fly to Garrosh's Landing |outvehicle |goto 32.13,54.64 |q 11636 |notravel
step
talk Gorge the Corpsegrinder##25329
turnin Magic Carpet Ride##11636 |goto 32.25,54.07
accept Tank Ain't Gonna Fix Itself##11642 |goto 32.25,54.07
step
talk Waltor of Pal'ea##25476
accept Into the Mist##11655 |goto 32.34,54.27
accept Horn of the Ancient Mariner##11660 |goto 32.34,54.27
step
talk Mobu##25475
|tip He walks around this area.
turnin Tank Ain't Gonna Fix Itself##11642 |goto 32.10,54.21
accept Mobu's Pneumatic Tank Transjigamarig##11643 |goto 32.10,54.21
accept Super Strong Metal Plates!##11644 |goto 32.10,54.21
stickystart "Collect_Super_Strong_Metal_Plates"
stickystart "Collect_Tuskarr_Relics"
stickystart "Collect_Horn_of_the_Ancient_Mariner"
step
Enter the building |goto 32.20,48.85 < 10 |walk
click Pneumatic Tank Transjigamarig##187683
|tip Inside the building.
collect Pneumatic Tank Transjigamarig##34785 |q 11643/1 |goto 32.38,49.16
step
Enter the building |goto 31.73,51.88 < 10 |walk
talk Mootoo the Younger##25504
|tip Upstairs inside the building.
|tip This is an escort quest.
|tip If she's not here, someone may be escorting her.
|tip Wait until she respawns.
accept Escaping the Mist##11664 |goto Borean Tundra/0 31.88,52.32
step
Watch the dialogue
|tip Follow Mootoo the Younger and protect her as she walks.
|tip She eventually walks to this location.
Save Mootoo |q 11664/1 |goto 31.63,54.38
step
talk Elder Mootoo##25503
turnin Escaping the Mist##11664 |goto 31.68,54.37
step
label "Collect_Super_Strong_Metal_Plates"
click Super Strong Metal Plate##187687+
|tip They look like scraps of tan metal objects on the ground.
|tip You can find them all around the Garrosh's Landing area. |notinsticky
collect 10 Super Strong Metal Plate##34786 |q 11644/1 |goto 30.67,50.99
step
label "Collect_Tuskarr_Relics"
Kill Kvaldir enemies around this area
|tip They look like large humans.
|tip You can find them all around the Garrosh's Landing area. |notinsticky
collect 8 Tuskarr Relic##34814 |q 11655/1 |goto 30.67,50.99
step
label "Collect_Horn_of_the_Ancient_Mariner"
Kill Kvaldir enemies around this area
|tip They look like large humans.
|tip You can find them all around the Garrosh's Landing area. |notinsticky
collect Horn of the Ancient Mariner##34813 |q 11660/1 |goto 30.67,50.99
step
talk Mobu##25475
|tip He walks around this area.
turnin Mobu's Pneumatic Tank Transjigamarig##11643 |goto 32.10,54.21
turnin Super Strong Metal Plates!##11644 |goto 32.10,54.21
accept Tanks a lot...##11651 |goto 32.10,54.21
step
talk Gorge the Corpsegrinder##25329
turnin Tanks a lot...##11651 |goto 32.25,54.07
accept The Plains of Nasam##11652 |goto 32.25,54.07
step
talk Waltor of Pal'ea##25476
turnin Into the Mist##11655 |goto 32.34,54.27
accept Burn in Effigy##11656 |goto 32.34,54.27
turnin Horn of the Ancient Mariner##11660 |goto 32.34,54.27
accept Orabus the Helmsman##11661 |goto 32.34,54.27
step
use Tuskarr Torch##34830
Destroy Bor's Anvil |q 11656/4 |goto 30.00,61.67
step
use Horn of the Ancient Mariner##34844
Watch the dialogue
|tip A boat approaches and stops near you.
|tip Enemies will attack one at a time, then Orabus the Helmsman will attack.
kill Kvaldir Crewman##32577+
kill Orabus the Helmsman##32576 |q 11661/1 |goto 26.76,54.67
step
use the Tuskarr Torch##34830
|tip At the front of the ship.
Destroy Bor's Hammer |q 11656/3 |goto 29.78,52.57
step
use the Tuskarr Torch##34830
|tip At the front of the ship.
Destroy The Kur Drakkar |q 11656/2 |goto 31.00,48.94
step
use the Tuskarr Torch##34830
|tip At the front of the ship.
Destroy The Serpent's Maw |q 11656/1 |goto 31.69,48.32
step
talk Waltor of Pal'ea##25476
turnin Burn in Effigy##11656 |goto 32.34,54.27
turnin Orabus the Helmsman##11661 |goto 32.34,54.27
accept Seek Out Karuk!##11662 |goto 32.34,54.27
step
clicknpc Horde Siege Tank##25334+
|tip They look like horde wooden artillery machines.
|tip Click any of them.
Control a Horde Siege Tank |invehicle |goto 31.92,54.40 |q 11652
step
_NOTE:_
In the Next Steps:
|tip You will use the siege tank abilities to kill enemies and rescue allies.
|tip Drive over the red metal Abandoned Fuel Tank barrels to get more mana.
|tip Be careful to not aggro too many enemies at once, or you might lose the siege tank.
|tip If you lose the siege tank, go back a few steps to get another one.
Click to Continue |confirm |q 11652
stickystart "Rescue_Injured_Warsong_Soldiers"
stickystart "Obliterate_Scourge_Units"
step
Enter the Plains of Nasam |goto 33.51,56.87 < 40 |only if walking and not subzone("Plains of Nasam")
Identify the Scourge Leader |q 11652/3 |goto 36.15,63.75
step
label "Rescue_Injured_Warsong_Soldiers"
Rescue #3# Injured Warsong Soldiers |q 11652/2 |goto 36.15,63.75
|tip Use the "Rescue Injured Soldier" ability on your action bar on Injured Warsong Mages.
|tip They look like friendly Horde NPCs of various races.
|tip They are usually in the outskirts surrounding the undead enemies.
|tip You can find them all around the Plains of Nasam area. |notinsticky
step
label "Obliterate_Scourge_Units"
Kill enemies around this area
|tip They look like undead enemies.
|tip Use the abilities on your action bar.
|tip You can find them all around the Plains of Nasam area. |notinsticky
Obliterate #100# Scourge Units |q 11652/1 |goto 36.15,63.75
step
talk Karuk##25435
turnin Seek Out Karuk!##11662 |goto 47.13,75.48
accept Karuk's Oath##11613 |goto 47.13,75.48
stickystart "Kill_Skadir_Raiders"
stickystart "Kill_Skadir_Longboatsmen"
step
kill Riplash Myrmidon##24576
|tip Kill the cheering npc's nearby as well.
talk Captured Tuskarr Prisoner##25636
|tip Shortly after killing the attacking Myrmidon, he will have dialogue followed by a quest.
|tip The window to which you can accept the quest is short, so be ready.
|tip If he's not here, wait for him to respawn, or skip the quest.
|tip The quest becomes available to accept a few minutes after he spawns.
accept Cruelty of the Kvaldir##12471 |goto 44.09,77.90
step
label "Kill_Skadir_Raiders"
kill 6 Skadir Raider##25522 |q 11613/1 |goto 46.70,78.05
|tip They look like large green humans holding spears.
|tip You can find them all around the Riplash Strand area. |notinsticky
step
label "Kill_Skadir_Longboatsmen"
kill 5 Skadir Longboatsman##25521 |q 11613/2 |goto 46.70,78.05
|tip They look like large green humans holding wooden mallets.
|tip You can find them all around the Riplash Strand area. |notinsticky
step
talk Karuk##25435
turnin Karuk's Oath##11613 |goto 47.13,75.48
accept Gamel the Cruel##11619 |goto 47.13,75.48
turnin Cruelty of the Kvaldir##12471 |goto 47.13,75.48
step
Enter the cave |goto 46.15,79.32 < 20 |walk
kill Gamel the Cruel##26449 |q 11619/1 |goto 46.42,78.23
|tip Inside the small cave.
step
Leave the cave |goto 46.15,79.32 < 20 |walk |only if subzone("Riplash Strand") and _G.IsIndoors()
talk Karuk##25435
turnin Gamel the Cruel##11619 |goto 47.13,75.48
accept A Father's Words##11620 |goto 47.13,75.48
step
talk Veehja##25450
turnin A Father's Words##11620 |goto 43.61,80.52
step
use the Hearthstone##6948
Hearth to Warsong Hold |complete subzone("Warsong Hold") |q 11652
|only if (subzone("Shrine of Scales") or subzone("Riplash Strand"))
step
talk Armorer Orkuruk##25274
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Armorer Orkuruk##25274 |goto 41.15,55.54 |q 11652
step
talk Garrosh Hellscream##25237
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
turnin The Plains of Nasam##11652 |goto 41.35,53.59
step
Leave the building |goto 39.88,55.54 < 15 |walk |only if subzone("Warsong Hold") and _G.IsIndoors()
Run up the ramp to leave Mightstone Quarry |goto 39.18,55.53 < 10 |only if walking and (subzone("Warsong Hold") or subzone("Mightstone Quarry"))
talk Shadowstalker Ickoris##25437
|tip He walks around this area.
turnin Reinforcements Incoming...##11618 |goto 38.08,52.55
accept The Warsong Farms##11686 |goto 38.08,52.55
step
talk Shadowstalker Canarius##25438
accept Merciful Freedom##11676 |goto 37.92,52.58
step
talk Farmer Torp##25607
accept Damned Filthy Swine##11688 |goto 37.91,52.33
stickystart "Free_Scourge_Prisoners"
stickystart "Kill_Unliving_Swine"
step
Scout the Warsong Slaughterhouse |q 11686/3 |goto 39.65,48.15
|tip Be careful to avoid the elite enemy nearby.
step
Scout Torp's Farm |q 11686/2 |goto 36.43,52.20
step
Scout the Warsong Granary |q 11686/1 |goto 34.82,54.83
step
label "Free_Scourge_Prisoners"
Kill enemies around this area
|tip The Unliving Swine boars will not drop the cage keys.
collect Scourge Cage Key##34908+ |n
click Scourge Cage##45807+
|tip They look like tall metal cages with large white skulls on top of them around this area.
Free #5# Scourge Prisoners |q 11676/1 |goto 36.20,49.53
step
label "Kill_Unliving_Swine"
kill 10 Unliving Swine##25600 |q 11688/1 |goto 35.75,50.85
|tip They look like grey boars around this area.
step
talk Farmer Torp##25607
turnin Damned Filthy Swine##11688 |goto 37.91,52.33
accept Bring 'Em Back Alive##11690 |goto 37.91,52.33
step
talk Shadowstalker Canarius##25438
turnin Merciful Freedom##11676 |goto 37.92,52.58
step
talk Shadowstalker Ickoris##25437
|tip He walks around this area.
turnin The Warsong Farms##11686 |goto 38.08,52.55
accept Get to Getry##11703 |goto 38.08,52.55
step
use Torp's Kodo Snaffle##34954
|tip Use it on an Infected Kodo Beasts.
|tip They look like large green dinosaurs laying on the ground around this area.
Return the Infected Kodo Beasts
|tip Bring the kodos back to Farmer Torp, and use the "Deliver Kodo" ability on your action bar.
|tip Repeat this process.
Rescue #8# Kodos |q 11690/1 |goto 36.76,50.68
Bring the Kodos to [37.91,52.33]
step
talk Farmer Torp##25607
turnin Bring 'Em Back Alive##11690 |goto 37.91,52.33
step
talk Shadowstalker Getry##25729
|tip At the top of the tower.
turnin Get to Getry##11703 |goto 34.59,46.42
accept Foolish Endeavors##11705 |goto 34.59,46.42
step
Watch the dialogue
|tip Follow Shadowstalker Getry as he walks.
|tip You will become stunned.
kill Varidus the Flenser##25618
|tip Your allies will help you fight.
Defeat Varidus the Flenser |q 11705/1 |goto 35.25,46.25
step
Enter Warsong Hold |goto 39.88,55.54 < 15 |walk |only if not (subzone("Warsong Hold") and _G.IsIndoors())
talk Armorer Orkuruk##25274
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Armorer Orkuruk##25274 |goto 41.15,55.54 |q 11705
step
talk Garrosh Hellscream##25237
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
turnin Foolish Endeavors##11705 |goto 41.35,53.59
accept Nork Bloodfrenzy's Charge##11709 |goto 41.35,53.59
step
Leave the building |goto 42.73,55.85 < 15 |walk |only if subzone("Warsong Hold") and _G.IsIndoors()
talk Warden Nork Bloodfrenzy##25379
turnin Nork Bloodfrenzy's Charge##11709 |goto 43.72,54.43
accept Coward Delivery... Under 30 Minutes or it's Free##11711 |goto 43.72,54.43
step
Run up the ramp to leave Mightstone Quarry |goto 43.84,53.15 < 10 |only if walking and subzone("Mightstone Quarry")
talk Bloodmage Laurith##25381
|tip Make sure the Alliance Deserter follows you to this location.
|tip Don't get too far away from him, or you will lose him and have to restart the quest.
accept The Wondrous Bloodspore##11716 |goto 52.07,52.49
stickystart "Collect_Bloodspore_Carpels"
step
use Warsong Flare Gun##34971
|tip Make sure the Alliance Deserter follows you to this location.
|tip Don't get too far away from him, or you will lose him and have to restart the quest.
Watch the dialogue
Deliver the Alliance Deserter |q 11711/1 |goto 55.31,50.80
step
talk Scout Tungok##25440
|tip He walks around this area riding a grey and white wolf.
turnin Coward Delivery... Under 30 Minutes or it's Free##11711 |goto 52.55,52.19
accept Vermin Extermination##11714 |goto 52.55,52.19
stickystart "Kill_Bloodspore_Roasters"
stickystart "Kill_Bloodspore_Firestarters"
stickystart "Kill_Bloodspore_Harvesters"
step
label "Collect_Bloodspore_Carpels"
click Bloodspore Carpel##187902+
|tip They look like red flowery plant stalks with a bright red bulb at the top of them.
|tip You can find them all around the Bloodspore Plains area. |notinsticky
collect 10 Bloodspore Carpel##34974 |q 11716/1 |goto 51.76,51.93
You can find more around [51.54,61.35]
step
talk Bloodmage Laurith##25381
turnin The Wondrous Bloodspore##11716 |goto 52.07,52.49
accept Pollen from the Source##11717 |goto 52.07,52.49
step
kill Bloodspore Moth##25464+
|tip They look like large flying insects.
|tip You can find them all around the Bloodspore Plains area. |notinsticky
collect 5 Bloodspore Moth Pollen##34976 |q 11717/1 |goto 51.76,51.93
You can find more around [51.54,61.35]
step
label "Kill_Bloodspore_Roasters"
kill 2 Bloodspore Roaster##25468 |q 11714/3 |goto 51.76,51.93
|tip They look like blue kobolds.
|tip You can find them all around the Bloodspore Plains area. |notinsticky
You can find more around [51.54,61.35]
step
label "Kill_Bloodspore_Firestarters"
kill 5 Bloodspore Firestarter##25470 |q 11714/2 |goto 51.76,51.93
|tip They look like smaller kobolds with orange glowing fists.
|tip You can find them all around the Bloodspore Plains area. |notinsticky
You can find more around [51.54,61.35]
step
label "Kill_Bloodspore_Harvesters"
kill 8 Bloodspore Harvester##25467 |q 11714/1 |goto 51.76,51.93
|tip They look like slightly larger kobolds.
|tip You can find them all around the Bloodspore Plains area. |notinsticky
You can find more around [51.54,61.35]
step
talk Bloodmage Laurith##25381
turnin Pollen from the Source##11717 |goto 52.07,52.49
accept A Suitable Test Subject##11719 |goto 52.07,52.49
step
use Pollinated Bloodspore Flower##34978
Watch the dialogue
|tip You will receive a buff.
|tip The quest goal will complete when the buff expires.
Use the Bloodspore Flower |q 11719/1 |goto 52.07,52.49
step
talk Bloodmage Laurith##25381
turnin A Suitable Test Subject##11719 |goto 52.07,52.49
accept The Invasion of Gammoth##11720 |goto 52.07,52.49
step
talk Primal Mighthorn##25380
turnin The Invasion of Gammoth##11720 |goto 52.18,52.82
accept Gammothra the Tormentor##11721 |goto 52.18,52.82
step
talk Scout Tungok##25440
|tip He walks around this area riding a grey and white wolf.
turnin Vermin Extermination##11714 |goto 52.55,52.19
step
Follow the path up and around above the cave |goto  47.55,54.84 < 15 |only if walking and not (subzone("Gammoth") and _G.IsIndoors())
click Massive Glowing Egg##187905
accept Massive Moth Omelet?##11724 |goto 48.55,59.03
step
_In The Next Step:_
Use the Pouch of Crushed Bloodspore
|tip You can use the pouch on any large blue magnataur elites inside the cave.
|tip They will be become non-elite.
Click Here to Continue |confirm |q 11721
step
Jump down and enter the cave |goto 49.36,58.40 < 20 |walk |only if not (subzone("Gammoth") and _G.IsIndoors())
use Pouch of Crushed Bloodspore##34979
|tip Use it on Gammothra the Tormentor.
|tip He look like a large blue magnataur that walks around this area.
|tip Inside the cave, on the bottom floor.
|tip Follow the spiral path down, or jump down the center of the cave into the water, to get to this location.
kill Gammothra the Tormentor##25789
|tip He will become non-elite.
collect Head of Gammothra##34980 |q 11721/1 |goto 46.08,62.19
step
Follow the spiral path up |goto 46.13,60.52 < 10 |walk |only if subzone("Gammoth") and _G.IsIndoors()
Continue up the spiral path and leave the cave |goto 49.46,58.35 < 40 |walk |only if subzone("Gammoth") and _G.IsIndoors()
talk Primal Mighthorn##25380
turnin Gammothra the Tormentor##11721 |goto 52.18,52.82
accept Trophies of Gammoth##11722 |goto 52.18,52.82
step
talk Bloodmage Laurith##25381
turnin Massive Moth Omelet?##11724 |goto 52.07,52.49
step
use the Hearthstone##6948
Hearth to Warsong Hold |complete subzone("Warsong Hold") |q 11722
|only if subzone("Bloodspore Plains")
step
talk Armorer Orkuruk##25274
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Armorer Orkuruk##25274 |goto 41.15,55.54 |q 11722
step
talk Garrosh Hellscream##25237
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
turnin Trophies of Gammoth##11722 |goto 41.35,53.59
accept Hellscream's Champion##11916 |goto 41.35,53.59
step
talk Durkot Wolfbrother##26044
|tip He walks around this area.
|tip Inside the building, on the bottom floor.
Tell him _"I am ready to leave, Durkot."_
Begin Traveling to Taunka'le Village |ontaxi |goto 40.23,55.09 |q 11916
step
Watch the dialogue
|tip You will travel automatically.
Travel to Taunka'le Village |offtaxi |goto 77.49,37.84 |q 11916 |notravel
step
talk Omu Spiritbreeze##26847
fpath Taunka'le Village |goto 77.76,37.77
step
talk Sage Earth and Sky##25982
turnin Ride to Taunka'le Village##11888 |goto 77.25,38.47
accept What Are They Up To?##11890 |goto 77.25,38.47
step
talk Greatfather Mahan##24702
accept Scouting the Sinkholes##11684 |goto 77.07,37.82
step
talk Fezzix Geartwist##25849
accept Load'er Up!##11881 |goto 77.49,36.96
step
Enter the building |goto 77.34,37.01 < 10 |walk
talk Greatmother Taiga##25602
|tip Inside the building.
accept Sage Highmesa is Missing##11674 |goto 77.30,36.88
step
Enter the building |goto 76.71,37.33 < 15 |walk
talk Chieftain Wintergale##24703
|tip Outside, on the balcony of the building.
turnin Hellscream's Champion##11916 |goto 75.89,37.25
step
use Map of the Geyser Fields##34920
Mark the Location of the South Sinkhole |q 11684/1 |goto 70.51,37.01
step
use Map of the Geyser Fields##34920
Mark the Location of the Northeast Sinkhole |q 11684/2 |goto 69.88,32.88
step
use Map of the Geyser Fields##34920
Mark the Location of the Northwest Sinkhole |q 11684/3 |goto 66.50,32.84
step
Inspect the Fizzcrank Pumping Station Environs |q 11890/1 |goto 64.68,24.49
step
talk Crashed Recon Pilot##25984
accept Emergency Supplies##11887 |goto 64.03,35.76
step
clicknpc Fizzcrank Recon Pilot##25841+
|tip They look like dead gnomes in black clothing laying on the ground.
|tip They are usually on the white parts of the ground next to water.
|tip You can find them all around the Scalding Pools area.
Choose _Search the body for the pilot's emergency toolkit._
collect 7 Gnomish Emergency Toolkit##35276 |q 11887/1 |goto 62.98,35.75
You can find more around: |notinsticky
[62.39,38.87]
[60.56,36.41]
step
use Jenny's Whistle##35272
|tip Jenny will appear next to you.
|tip She looks like a mule with cargo strapped to her back.
|tip You need to lead her back to safety at Taunka'le Village without her losing cargo.
|tip Be careful to not allow Jenny to get attacked as you travel.
|tip She will follow you as you walk.
Click Here Once Jenny is Following You |confirm |goto 63.49,36.90 |q 11881
step
Watch the dialogue
|tip Make sure Jenny follows you at all times, and protect her as she walks.
|tip Be careful to not allow Jenny to get attacked as you travel.
|tip You need to lead her back to safety at Taunka'le Village without her losing cargo.
|tip Don't get too far away from her, or you'll lose her and have to restart the quest.
Return Jenny to Safety Without Losing Cargo |q 11881/1 |goto 77.52,37.04 |notravel
step
talk Fezzix Geartwist##25849
turnin Load 'er Up!##11881 |goto 77.49,36.96
turnin Emergency Supplies##11887 |goto 77.49,36.96
step
talk Dorain Frosthoof##25983
accept The Power of the Elements##11893 |goto 77.62,36.95
step
talk Greatfather Mahan##24702
turnin Scouting the Sinkholes##11684 |goto 77.07,37.82
accept The Heart of the Elements##11685 |goto 77.07,37.82
step
talk Sage Earth and Sky##25982
turnin What Are They Up To?##11890 |goto 77.25,38.47
accept Master the Storm##11895 |goto 77.25,38.47
step
clicknpc Storm Totem##26048
|tip Inside the building.
|tip An air elemental will appear.
kill Storm Tempest##26045
Master the Storm |q 11895/1 |goto 77.06,38.71
step
talk Sage Earth and Sky##25982
turnin Master the Storm##11895 |goto 77.25,38.47
accept Weakness to Lightning##11896 |goto 77.25,38.47
step
talk Iron Eyes##26104
accept Cleaning Up the Pools##11906 |goto 76.92,37.63
step
Enter the building |goto 77.34,37.01 < 10 |walk
talk Greatmother Taiga##25602
|tip Inside the building.
accept Souls of the Decursed##11899 |goto 77.30,36.88
step
Enter the building |goto 76.72,37.34 < 15 |walk
talk Tewah Chillmane##26697
|tip Inside the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Tewah Chillmane##26697 |goto 76.61,37.18 |q 11899
step
use the Windsoul Totem##35281
|tip This will plant a Windsoul Totem in the ground.
kill Steam Rager##24601+
|tip They look like white ghosts.
|tip Kill them near the Windsoul Totem.
|tip You can find them all around the Steam Springs area.
Collect #10# Energy |q 11893/1 |goto 72.12,31.43
stickystart "Capture_Gnome_Souls"
stickystart "Collect_Fizzcrank_Spare_Parts"
step
use Sage's Lightning Rod##35352
|tip Use it on enemies that look like robots.
|tip You can find them all around the Geyser Fields area.
|tip The gnomes will not count for the quest goal.
Kill enemies around this area
|tip Kill them after using the lightning rod on them.
Weaken and Destroy #15# Robots |q 11896/1 |goto 63.11,21.53
step
label "Capture_Gnome_Souls"
kill Fizzcrank Mechagnome##25814+
|tip They look like small mechanical gnomes.
|tip You can find them all around the Geyser Fields area. |notinsticky
use The Greatmother's Soulcatcher##35401
|tip Use it on their corpses.
Capture #10# Gnome Souls |q 11899/1 |goto 63.11,21.53
step
label "Collect_Fizzcrank_Spare_Parts"
click Fizzcrank Spare Parts##187901+
|tip They look like various shaped metal parts on the ground.
|tip You can find them all around the Geyser Fields area. |notinsticky
collect 15 Fizzcrank Spare Parts##34972 |q 11906/1 |goto 63.11,21.53
step
use the Hearthstone##6948
Hearth to Taunka'le Village |complete subzone("Taunka'le Village") |q 11906
|only if subzone("The Geyser Fields") or subzone("Festering Pools") or subzone("Fizzcrank Pumping Station") or subzone("Mid Point Station")
step
talk Tewah Chillmane##26697
|tip Inside the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Tewah Chillmane##26697 |goto 76.61,37.18 |q 11906
step
talk Iron Eyes##26104
turnin Cleaning Up the Pools##11906 |goto 76.92,37.63
step
talk Sage Earth and Sky##25982
turnin Weakness to Lightning##11896 |goto 77.25,38.47
accept The Sub-Chieftains##11907 |goto 77.25,38.47
step
Enter the building |goto 77.33,37.00 < 10 |walk
talk Greatmother Taiga##25602
|tip Inside the building.
turnin Souls of the Decursed##11899 |goto 77.30,36.88
accept Defeat the Gearmaster##11909 |goto 77.30,36.88
step
talk Dorain Frosthoof##25983
turnin The Power of the Elements##11893 |goto 77.62,36.95
step
talk Fezzix Geartwist##25849
accept Patching Up##11894 |goto 77.49,36.96
step
kill Marsh Caribou##25680+
|tip They look like brown deer bucks.
|tip You can find them all around the Flood Plains area.
collect 5 Uncured Caribou Hide##35288 |goto 78.11,40.29 |q 11894
You can find more around [78.29,32.61]
step
kill Frozen Elemental##25715+
|tip They look like white rock elementals.
|tip You can find them all around this icy beach area.
collect 5 Elemental Heart##34956 |q 11685/1 |goto 85.57,46.18
step
Enter the building |goto 76.72,37.34 < 15 |walk
talk Tewah Chillmane##26697
|tip Inside the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Tewah Chillmane##26697 |goto 76.61,37.18 |q 11685
step
talk Wind Tamer Barah##24730
turnin The Heart of the Elements##11685 |goto 75.58,35.77
accept The Horn of Elemental Fury##11695 |goto 75.58,35.77
step
_Destroy These Items:_
|tip They are no longer needed.
trash The Legend of the Horn##34960
step
use Uncured Caribou Hide##35288
collect 5 Steam Cured Hide##35289 |q 11894/1 |goto 75.87,32.49
step
kill Chieftain Gurgleboggle##25725
|tip He looks like a larger green gremlin.
|tip He walks around this area.
collect Gurbleboggle's Key##34962 |goto 78.40,28.70 |q 11695
step
click Gurbleboggle's Bauble
|tip It looks like a large white pearl sitting on a stone table in the water.
collect Lower Horn Half##34963 |q 11695/2 |goto 78.72,28.33
step
click North Point Station Valve##188107
kill ED-210##25831 |q 11907/2 |goto 65.44,17.45
step
click West Point Station Valve##188106
kill Twonky##25830 |q 11907/1 |goto 60.19,20.38
step
click Mid Point Station Valve##188108
kill Max Blasto##25832 |q 11907/3 |goto 63.66,22.48
step
Run up the ramp and follow the path to the top of the platform |goto 65.55,23.03 < 15 |only if walking
Enter the building at the top of the platform |goto 64.59,23.15 < 10 |walk
click The Gearmaster's Manual##190335
|tip Inside the building at the top of the platform.
|tip Gearmaster Mechazod will appear and attack you after you click the book.
Research the Gearmaster's Manual |q 11909/1 |goto 64.42,23.40
step
Watch the dialogue
|tip Inside the building at the top of the platform.
kill Gearmaster Mechazod##25834
collect Mechazod's Head##35486 |q 11909/2 |goto 64.42,23.40
step
click South Point Station Valve##188109
kill The Grinder##25833 |q 11907/4 |goto 65.25,28.75
step
kill Chieftain Burblegobble##25726
|tip He looks like a larger red gremlin.
|tip He walks around this area.
collect Burblegobble's Key##34961 |goto 68.33,40.26 |q 11695
step
click Burblegobble's Bauble##187886
|tip It looks like a large white pearl sitting on a stone table in the water.
collect Upper Horn Half##34964 |q 11695/1 |goto 68.52,40.38
step
talk Wind Tamer Barah##24730
turnin The Horn of Elemental Fury##11695 |goto 75.58,35.77
step
Watch the dialogue
talk Wind Tamer Barah##24730
accept The Collapse##11706 |goto 75.58,35.77
step
talk Fezzix Geartwist##25849
turnin Patching Up##11894 |goto 77.49,36.96
step
Enter the building |goto 77.33,37.01 < 10 |walk
talk Greatmother Taiga##25602
|tip Inside the building.
turnin Defeat the Gearmaster##11909 |goto 77.30,36.88
step
talk Sage Earth and Sky##25982
turnin The Sub-Chieftains##11907 |goto 77.25,38.47
step
Enter the building |goto 76.72,37.34 < 15 |walk
talk Tewah Chillmane##26697
|tip Inside the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Tewah Chillmane##26697 |goto 76.61,37.18 |q 11706
step
talk Chieftain Wintergale##24703
|tip Outside, on the balcony of the building.
accept Shrouds of the Scourge##11628 |goto 75.89,37.25
step
use The Horn of Elemental Fury##34968
Watch the dialogue
|tip Lord Kryxix will appear nearby.
Collapse the Nerubian Tunnels |q 11706/2 |goto 70.52,37.00
step
kill Lord Kryxix##25629 |q 11706/1 |goto 70.69,36.55
|tip He looks like a huge blue beetle that walks around this area.
step
talk Sage Highmesa##25604
turnin Sage Highmesa is Missing##11674 |goto 74.67,23.66
accept A Proper Death##11675 |goto 74.67,23.66
stickystart "Collect_Scourged_Mammoth_Pelts"
step
kill 10 Plagued Magnataur##25615 |q 11675/1 |goto 76.09,20.97
|tip They look like large blue centaurs.
step
label "Collect_Scourged_Mammoth_Pelts"
kill Scourged Mammoth##25452+
|tip They look like brown hairy elephants.
collect 5 Scourged Mammoth Pelt##34775 |q 11628/1 |goto 76.09,20.97
You can find more around [79.26,25.60]
step
talk Sage Highmesa##25604
turnin A Proper Death##11675 |goto 74.67,23.66
accept Stop the Plague##11677 |goto 74.67,23.66
step
Enter the cave |goto 77.93,18.80 < 20 |walk
use Highmesa's Cleansing Seeds##34913
|tip Inside the cave.
Neutralize the Plague Cauldron |q 11677/1 |goto 78.30,17.97
step
talk Sage Highmesa##25604
turnin Stop the Plague##11677 |goto 74.67,23.66
accept Find Bristlehorn##11678 |goto 74.67,23.66
accept Fallen Necropolis##11683 |goto 74.67,23.66
stickystart "Destroy_Talramas_Scourge"
step
Enter the building |goto 68.62,15.26 < 40 |walk
Follow the path up |goto 69.10,12.58 < 15 |walk
talk Longrunner Bristlehorn##25658
|tip Inside a cage.
|tip Upstairs inside the building.
turnin Find Bristlehorn##11678 |goto 69.76,12.62
accept The Doctor and the Lich-Lord##11687 |goto 69.76,12.62
step
Follow the winding path up to the very top of the building |goto 69.51,15.82 < 10 |only if walking
kill Lich-Lord Chillwinter##25682 |q 11687/2 |goto 70.13,13.40
|tip He walks around this area.
|tip On top of the building.
step
kill Doctor Razorgrin##25678 |q 11687/1 |goto 69.70,12.87
|tip He walks around this area inside the building.
|tip Jump down to him from on top of the building.
step
label "Destroy_Talramas_Scourge"
Kill enemies around this area
Destroy #20# Talramas Scourge |q 11683/1 |goto 68.24,19.13
step
talk Sage Highmesa##25604
turnin Fallen Necropolis##11683 |goto 74.67,23.66
turnin The Doctor and the Lich-Lord##11687 |goto 74.67,23.66
accept Return with the Bad News##11689 |goto 74.67,23.66
step
talk Wind Tamer Barah##24730
turnin The Collapse##11706 |goto 75.58,35.77
step
talk Chieftain Wintergale##24703
|tip Outside, on the balcony of the building.
turnin Shrouds of the Scourge##11628 |goto 75.89,37.25
accept The Bad Earth##11630 |goto 75.89,37.25
step
talk Tewah Chillmane##26697
|tip Inside the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Tewah Chillmane##26697 |goto 76.61,37.18 |q 11630
step
Enter the building |goto 77.33,37.00 < 10 |walk
talk Greatmother Taiga##25602
|tip Inside the building.
turnin Return with the Bad News##11689 |goto 77.30,36.88
step
click Scourged Earth##187677+
|tip They look like piles of brown dirt on the ground.
|tip You can find them all around this area.
collect 8 Scourged Earth##34774 |q 11630/1 |goto 80.58,32.38
step
talk Chieftain Wintergale##24703
|tip Outside, on the balcony of the building.
turnin The Bad Earth##11630 |goto 75.89,37.25
accept Blending In##11633 |goto 75.89,37.25
step
_NOTE:_
During the Next Steps:
|tip You will use an item to become invisible.
|tip As you travel around to complete the quest goals, avoid abomination enemies.
|tip They can see through your invisibility and will attack you.
|tip You won't lose your invisibility if you mount.
|tip If you get attacked and lose your invisibility, unequip the cloak, and equip it again to regain the invisibility buff.
Click Here to Continue |confirm |q 11633
step
use the Imbued Scourge Shroud##34782
|tip You will become invisible.
Gain the Shroud of the Scourge Buff |havebuff spell:45614 |goto 84.27,30.79 |q 11633
step
Enter the Temple City of En'kilah |goto 84.27,30.78 < 30 |only if walking and not subzone("Temple City of En'kilah")
Run up the stairs and enter the building |goto 88.64,28.33 < 15 |walk
Scout the Spire of Pain |q 11633/3 |goto 88.96,28.56
|tip Inside the building.
step
Run up the stairs |goto 89.02,26.70 < 30 |only if walking and subzone("Spire of Pain")
Run up the stairs |goto 87.54,22.36 < 30 |only if walking and not subzone("Spire of Blood")
Run up the stairs and enter the building |goto 88.56,21.31 < 15 |walk
Scout the Spire of Blood |q 11633/2 |goto 88.07,20.89
|tip Upstairs inside the building.
step
Enter the building |goto 84.24,21.82 < 15 |walk
Scout the Spire of Decay |q 11633/1 |goto 84.00,20.89
|tip Inside the building.
step
Follow the path to leave the Temple City of En'kilah |goto 85.07,28.76 < 40 |only if walking and (subzone("Temple City of En'kilah") or subzone("Spire of Pain") or subzone("Spire of Blood") or subzone("Spire of Decay"))
Enter the building |goto 76.72,37.34 < 15 |walk
talk Chieftain Wintergale##24703
|tip Outside, on the balcony of the building.
turnin Blending In##11633 |goto 75.89,37.25
accept Words of Power##11640 |goto 75.89,37.25
step
Equip Your Regular Back Armor
Click Here After Equipping Your Regular Back Armor |confirm |q 11640
step
talk Durm Icehide##24706
|tip Outside, on the balcony of the building.
accept A Courageous Strike##11641 |goto 75.96,37.16
step
talk Sage Aeire##24709
|tip Outside, on the balcony of the building.
accept Neutralizing the Cauldrons##11647 |goto 75.96,37.34
step
talk Pahu Frosthoof##26709
|tip Inside the building.
home Taunka'le Village |goto 76.25,37.19
step
talk Tewah Chillmane##26697
|tip Inside the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Tewah Chillmane##26697 |goto 76.61,37.18 |q 11647
stickystart "Skay_Enkilah_Necromancers"
stickystart "Slay_Enkilah_Ghouls"
step
Enter the Temple City of En'kilah |goto 84.27,30.78 < 30 |only if walking and not subzone("Temple City of En'kilah")
Run up the stairs |goto 87.32,27.41 < 30 |only if walking
use Sage Aeire's Totem##34806
|tip Next to the large cauldron with orange liquid in it.
Cleanse the East Cauldron |q 11647/1 |goto 87.73,29.78
step
Run up the stairs and enter the building |goto 88.63,28.33 < 5 |walk
kill High Priest Talet-Kha##26073
|tip Inside the building.
|tip You must kill the 2 cocoons next to him before you can attack him.
collect High Priest Talet-Kha's Scroll##35354 |q 11640/2 |goto 89.38,28.86
step
Run up the stairs |goto 89.02,26.70 < 30 |only if walking and subzone("Spire of Pain")
Run up the stairs |goto 87.54,22.36 < 30 |only if walking and not subzone("Spire of Blood")
kill Darkfallen Bloodbearer##26115
|tip He looks like a blood elf wearing black armor.
|tip He walks up and down the path around this area on the building.
collect Vial of Fresh Blood##34815 |n
use Vial of Fresh Blood##34815
accept The Spire of Blood##11654 |goto 87.22,21.24
step
Enter the bottom floor of the building |goto 87.78,21.67 < 15 |walk
talk Snow Tracker Grumm##25516
|tip Inside the building, on the bottom floor.
turnin The Spire of Blood##11654 |goto 87.57,19.95
accept Shatter the Orbs!##11659 |goto 87.57,19.95
step
kill En'Kilah Blood Globe##25534+
|tip They look like red globes sitting on golden pedestals.
|tip Inside the building, on the bottom floor.
Shatter #5# Blood Globes |q 11659/1 |goto 87.73,19.61
step
Run up the stairs and enter the building |goto 88.56,21.31 < 15 |walk
kill High Priest Andorath##25392
|tip Inside the building, on the top floor.
|tip To find him, follow the path up, outside the building, and enter the top floor of the building from either side.
collect High Priest Andorath's Scroll##35355 |q 11640/3 |goto 88.05,20.94
step
use Sage Aeire's Totem##34806
|tip Next to the large cauldron with orange liquid in it.
Cleanse the Central Cauldron |q 11647/2 |goto 86.20,22.61
step
use Sage Aeire's Totem##34806
|tip Next to the large cauldron with orange liquid in it.
Cleanse the West Cauldron |q 11647/3 |goto 85.51,20.22
step
Enter the building |goto 84.24,21.82 < 15 |walk
kill High Priest Naferset##26076
|tip Inside the building.
|tip You must kill the 3 enemies channeling on him before you can attack him.
collect High Priest Naferset's Scroll##35353 |q 11640/1 |goto 83.89,20.46
step
label "Skay_Enkilah_Necromancers"
kill 5 En'kilah Necromancer##25378 |q 11641/2 |goto 84.41,22.30
|tip They look like large humans wearing robes.
|tip You can find them all around the Temple City of En'kilah area. |notinsticky
step
label "Slay_Enkilah_Ghouls"
kill 15 En'kilah Ghoul##25393 |q 11641/1 |goto 86.60,25.15
|tip They look like zombies.
|tip You can find them all around the Temple City of En'kilah area. |notinsticky
step
use the Hearthstone##6948
Hearth to Taunka'le Village |complete subzone("Taunka'le Village") |q 11640
|only if subzone("Temple City of En'kilah") or subzone("Spire of Pain") or subzone("Spire of Blood") or subzone("Spire of Decay")
step
talk Durm Icehide##24706
|tip Outside, on the balcony of the building.
turnin A Courageous Strike##11641 |goto 75.96,37.16
step
talk Chieftain Wintergale##24703
|tip Outside, on the balcony of the building.
turnin Words of Power##11640 |goto 75.89,37.25
step
talk Sage Aeire##24709
|tip Outside, on the balcony of the building.
turnin Neutralizing the Cauldrons##11647 |goto 75.96,37.34
step
talk Tewah Chillmane##26697
|tip Inside the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Tewah Chillmane##26697 |goto 76.61,37.18 |q 11659
step
talk Snow Tracker Junek##24733
|tip Outside the building.
turnin Shatter the Orbs!##11659 |goto 76.75,37.88
step
talk Ataika##26169
accept Not Without a Fight!##11949 |goto 63.80,46.12
step
talk Utaik##26213
accept Preparing for the Worst##11945 |goto 63.95,45.72
|only if subzone("Kaskala")
stickystart "Kill_Kvaldir_Raiders"
step
click Kaskala Supplies+
|tip They look like brown wicker baskets on the ground around this area.
|tip They can also be inside the buildings.
collect 8 Kaskala Supplies##35711 |q 11945 |goto 65.51,47.45
|only if haveq(11945)
step
label "Kill_Kvaldir_Raiders"
kill 12 Kvaldir Raider##25760 |q 11949/1 |goto 67.27,53.03
|tip They look like large green humans.
|tip You can find them all around the Kaskala area. |notinsticky
You can find more around [67.51,47.93]
step
talk Ataika##26169
turnin Not Without a Fight!##11949 |goto 63.80,46.12
accept Muahit's Wisdom##11950 |goto 63.80,46.12
step
talk Utaik##26213
turnin Preparing for the Worst##11945 |goto 63.95,45.72
|only if haveq(11945) or completedq(11945)
step
talk Elder Muahit##26218
turnin Muahit's Wisdom##11950 |goto 67.20,54.85
accept Spirits Watch Over Us##11961 |goto 67.20,54.85
step
clicknpc Iruk##26219
|tip Underwater.
Choose _<Search corpse for Issliruk's Totem.>_
collect Issliruk's Totem##35701 |q 11961/1 |goto 67.64,50.41
step
talk Elder Muahit##26218
turnin Spirits Watch Over Us##11961 |goto 67.20,54.85
accept The Tides Turn##11968 |goto 67.20,54.85
step
kill Heigarr the Horrible##26266 |q 11968/1 |goto 67.60,56.70
|tip He fights around this area.
step
talk Elder Muahit##26218
turnin The Tides Turn##11968 |goto 67.20,54.85
step
Follow the road to leave Kaskala |goto 63.11,45.56 < 40 |only if walking and (subzone("Njord's Breath Bay") or subzone("Kaskala"))
talk Arch Druid Lathorius##25809
accept A Mission Statement##11864 |goto 57.05,44.32 |instant
step
talk Arch Druid Lathorius##25809
accept Ears of Our Enemies##11866 |goto 57.05,44.32
accept Help Those That Cannot Help Themselves##11876 |goto 57.05,44.32
step
talk Hierophant Cenius##25810
accept Happy as a Clam##11869 |goto 57.32,44.08
step
talk Zaza##25811
accept Unfit for Death##11865 |goto 56.80,44.03
step
use the Pile of Fake Furs##35127
|tip Use it next to Caribou Traps.
|tip They look like metal spiked traps on the ground around this area.
Trap #8# Nesingwary Trappers |q 11865/1 |goto 56.86,49.77
stickystart "Kill_Lootcrazed_Divers"
step
kill Loot Crazed Diver##25836+
|tip They look like human scuba divers.
|tip You can find them underwater all around the Lake Kum'uya area.
collect 15 Nesingwary Lackey Ear##35188 |q 11866/1 |goto 51.13,44.68
step
label "Kill_Lootcrazed_Divers"
kill 10 Loot Crazed Diver##25836 |q 11869/1 |goto 51.13,44.68
|tip They look like human scuba divers. |notinsticky
|tip You can find them underwater all around the Lake Kum'uya area. |notinsticky
step
use the D.E.H.T.A. Trap Smasher##35228
|tip Use it next to Trapped Mammoth Calves.
|tip They look like baby elephants stuck in metal traps on the ground around this area.
|tip Avoid killing any mammoths, since you'll get a debuff that will cause druid guards to attack you.
Free #8# Mammoth Calves |q 11876/1 |goto 56.38,39.08
You can find more around: |notinsticky
[55.79,32.94]
[54.72,28.92]
step
talk Zaza##25811
turnin Unfit for Death##11865 |goto 56.80,44.04
accept The Culler Cometh##11868 |goto 56.80,44.04
step
talk Arch Druid Lathorius##25809
turnin Ears of Our Enemies##11866 |goto 57.05,44.32
turnin Help Those That Cannot Help Themselves##11876 |goto 57.05,44.32
accept Khu'nok Will Know##11878 |goto 57.05,44.32
step
talk Hierophant Cenius##25810
turnin Happy as a Clam##11869 |goto 57.33,44.09
accept The Abandoned Reach##11870 |goto 57.33,44.09
step
Deliver the Orphaned Mammoth Calf to Khu'nok |q 11878/1 |goto 59.44,30.37
|tip Make sure the Orphaned Mammoth Calf continues following you.
|tip The calf that follows you is slow.
|tip Don't move too fast, or you'll lose it.
step
talk Khu'nok the Behemoth##25862
turnin Khu'nok Will Know##11878 |goto 59.44,30.37
accept Kaw the Mammoth Destroyer##11879 |goto 59.44,30.37
step
clicknpc Wooly Mammoth Bull##25743
|tip They look like larger brown hairy elephants.
|tip You can find them all around this area.
Ride a Wooly Mammoth Bull |invehicle |goto 55.88,31.39 |q 11879
step
Watch the dialogue
|tip Kaw the Mammoth Destroyer will jump on Moria, the mammoth.
kill Kaw the Mammoth Destroyer##25802
|tip Use the abilities on your action bar.
click Kaw's War Halberd##188066
|tip It looks like an axe that appears on the ground after you kill Kaw the Mammoth Destroyer.
|tip You will have to stop riding the mammoth to be able to loot it.
|tip Click the red arrow on your action bar to stop riding the mammoth.
collect Kaw's War Halberd##35234 |q 11879/1 |goto 53.99,24.29
step
talk Arch Druid Lathorius##25809
turnin Kaw the Mammoth Destroyer##11879 |goto 57.05,44.32
step
kill Karen "I Don't Caribou" the Culler##25803 |q 11868/1 |goto 57.26,56.45
|tip She walks around this area.
|tip Two enemies will appear and help her fight after you attack her.
|tip If you have trouble, try to find someone to help you, or skip the quest.
step
talk Hierophant Liandra##25838
turnin The Abandoned Reach##11870 |goto 57.80,55.11
accept Not On Our Watch##11871 |goto 57.80,55.11
step
kill Northsea Thug##25843+
|tip They look like humans carrying tan bags over their shoulders.
click Shipment of Animal Parts##188018+
|tip They look like brown bags and crates on the ground.
|tip You can find them all around the Abandoned Reach area.
collect 12 Shipment of Animal Parts##35222 |q 11871/1 |goto 59.53,58.66
step
talk Hierophant Liandra##25838
turnin Not On Our Watch##11871 |goto 57.80,55.11
accept The Nefarious Clam Master...##11872 |goto 57.80,55.11
step
kill Clam Master K##25800 |q 11872/1 |goto 61.72,66.42
|tip He walks east and west underwater around this area.
|tip Beware of Great Reef Sharks that will attack while you are fighting him.
|tip He respawns quickly.
step
Return to the Abandoned Reach |complete subzone("The Abandoned Reach") |goto 60.71,62.65 |q 11872
|only if (dist("Borean Tundra 60.71,62.65") < 1000) and not subzone("The Abandoned Reach")
step
Follow the path up to leave the Abandoned Reach |goto 57.63,55.03 < 20 |only if walking and subzone("The Abandoned Reach")
talk Hierophant Cenius##25810
turnin The Nefarious Clam Master...##11872 |goto 57.33,44.08
step
talk Zaza##25811
turnin The Culler Cometh##11868 |goto 56.80,44.04
step
click Elder Atkanok##187565
accept The Honored Ancestors##11605 |goto 54.60,36.00
step
talk Etaruk##25292
accept Reclaiming the Quarry##11612 |goto 54.29,36.10
step
talk Surristrasz##24795
|tip Follow the road to get to this location.
fpath Amber Ledge |goto 45.33,34.50
step
talk Librarian Donathan##25262
turnin Too Close for Comfort##11574|goto 45.26,33.35
accept Prison Break##11587 |goto 45.26,33.35
step
talk Librarian Garren##25291
accept Monitoring the Rift: Cleftcliff Anomaly##11576 |goto 44.98,33.38
step
talk Librarian Hamilton##27141
|tip He walks around this area.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Librarian Hamilton##27141 |goto 45.27,33.94 |q 11576
step
kill Beryl Mage Hunter##25585+
collect Beryl Prison Key##34688 |goto 42.46,37.14 |q 11587
You can find more around [41.81,41.59]
step
click Arcane Prison##187561+
|tip They look like large boxes hovering above circular blue rune platforms around this area.
|tip If the Arcane Prison doesn't complete the quest goal, click others.
|tip It seems random as to which Arcane Prison contains the prisoners.
Rescue the Arcane Prisoners |q 11587/1 |goto 40.44,39.16
You can find more Arcane Prisons at: |notinsticky
[41.79,42.54]
[42.59,36.76]
step
use the Arcanometer##34669
|tip Next to the purple crack in the ground, next to the water.
Take the Cleftcliff Anomaly Reading |q 11576/1 |goto 34.36,42.06
step
Follow the path up |goto 39.96,42.04 < 30 |only if walking and subzone("The Westrift")
Follow the path up into Amber Ledge |goto 43.72,37.46 < 15 |only if walking and not subzone("Amber Ledge")
talk Librarian Garren##25291
turnin Monitoring the Rift: Cleftcliff Anomaly##11576 |goto 44.98,33.38
accept Monitoring the Rift: Sundered Chasm##11582 |goto 44.98,33.38
step
talk Librarian Donathan##25262
turnin Prison Break##11587 |goto 45.26,33.35
accept Abduction##11590 |goto 45.26,33.35
step
kill Beryl Sorcerer##25316+
|tip They look like humans in purple robes.
|tip Don't kill them, just weaken them.
|tip You can find them all around the Beryl Point area.
use the Arcane Binder##34691
|tip Use it on the Beryl Sorcerer when it is low health.
Capture a Beryl Sorcerer |q 11590/1 |goto 42.66,38.06
step
Follow the path up into Amber Ledge |goto 43.72,37.46 < 15 |only if walking and not subzone("Amber Ledge")
talk Librarian Donathan##25262
turnin Abduction##11590 |goto 45.26,33.35
accept The Borean Inquisition##11646 |goto 45.26,33.35
step
Enter the building |goto 46.11,33.12 < 10 |walk
talk Librarian Normantis##25480
|tip Upstairs inside the tower, on a middle floor.
turnin The Borean Inquisition##11646 |goto 46.33,32.85
accept The Art of Persuasion##11648 |goto 46.33,32.85
step
use the Neural Needler##34811
|tip Use it on the Imprisoned Beryl Sorcerer repeatedly.
|tip Upstairs inside the tower, on a middle floor.
Interrogate the Prisoner |q 11648/1 |goto 46.32,32.92
step
talk Librarian Normantis##25480
|tip Upstairs inside the tower, on a middle floor.
turnin The Art of Persuasion##11648 |goto 46.33,32.85
accept Sharing Intelligence##11663 |goto 46.33,32.85
step
Leave the building |goto 46.11,33.12 < 10 |walk |only if subzone("Amber Ledge") and _G.IsIndoors()
talk Librarian Donathan##25262
turnin Sharing Intelligence##11663 |goto 45.26,33.35
accept A Race Against Time##11671|goto 45.26,33.35
step
talk Librarian Hamilton##27141
|tip He walks around this area.
|tip Sell any items you don't need, to clear some bag space.
|tip Follow the road to get to this location.
Visit the Vendor |vendor Librarian Hamilton##27141 |goto 45.27,33.94 |q 11671
step
use the Beryl Shield Detonator##34897
|tip If it won't let you, wait until Inquisitor Salrand appears again.
kill Inquisitor Salrand##25584
click Salrand's Lockbox##187875
|tip It appears on the ground after you kill Inquisitor Salrand.
collect Salrand's Broken Key##34909 |q 11671/1 |goto 41.80,39.16
step
Follow the path up into Amber Ledge |goto 43.72,37.46 < 15 |only if walking and not subzone("Amber Ledge")
talk Librarian Donathan##25262
turnin A Race Against Time##11671 |goto 45.26,33.35
accept Reforging the Key##11679 |goto 45.26,33.35
step
talk Surristrasz##24795
turnin Reforging the Key##11679 |goto 45.32,34.52
accept Taking Wing##11680 |goto 45.32,34.52
step
talk Warmage Anzim##25356
turnin Taking Wing##11680 |goto 46.38,37.31
accept Rescuing Evanor##11681 |goto 46.38,37.31
step
Watch the dialogue
|tip You will automatically be teleported back to Amber Ledge.
Return to Amber Ledge |goto 46.45,32.55 < 20 |noway |c |q 11681
step
talk Archmage Evanor##25785
|tip Inside the tower, on the top floor.
turnin Rescuing Evanor##11681 |goto 46.37,32.40
accept Dragonspeak##11682 |goto 46.37,32.40
step
talk Librarian Whitley##27139
|tip Inside the tower, on the bottom floor.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Librarian Whitley##27139 |goto 46.52,32.56 |q 11682
step
Leave the building |goto 46.11,33.12 < 10 |walk |only if subzone("Amber Ledge") and _G.IsIndoors()
talk Surristrasz##24795
turnin Dragonspeak##11682 |goto 45.32,34.52
step
use the Arcanometer##34669
|tip Swim down to the pink chasm underwater.
Take the Sundered Chasm Reading |q 11582/1 |goto 43.98,28.49
stickystart "Kill_Beryl_Treasure_Hunters"
step
Follow the path back up to cliff |goto 45.44,31.11 < 15 |only if walking and subzone("The Westrift")
click "Elder Kesuk"##187662
Identify the Elder Kesuk |q 11605/1 |goto 50.87,32.39
step
click "Elder Takret"##187664
Identify the Elder Takret |q 11605/3 |goto 52.31,31.15
step
click "Elder Sagani"##187663
Identify the Elder Sagani |q 11605/2 |goto 52.82,34.03
step
label "Kill_Beryl_Treasure_Hunters"
kill 12 Beryl Treasure Hunter##25353 |q 11612/1 |goto 51.97,32.61
|tip They look like humans in purple robes.
|tip You can find them all around the Coldrock Quarry area. |notinsticky
step
click Elder Atkanok##187565
turnin The Honored Ancestors##11605 |goto 54.62,35.74
accept The Lost Spirits##11607 |goto 54.62,35.74
step
talk Etaruk##25292
turnin Reclaiming the Quarry##11612 |goto 54.29,36.10
accept Hampering Their Escape##11617 |goto 54.29,36.10
stickystart "Free_Kaskala_Craftsman_Spirits"
stickystart "Free_Kaskala_Shaman_Spirits"
step
kill Beryl Reclaimer##25449+
|tip They look like gnomes.
|tip You can find them all around the Coldrock Quarry area.
collect 3 Gnomish Grenade##34772 |q 11617 |goto 51.62,35.90
step
use the Gnomish Grenade##34772
|tip Use it while standing near the floating platform.
Destroy the East Platform |q 11617/1 |goto 52.47,35.44
step
use the Gnomish Grenade##34772
|tip Use it while standing near the the floating platform.
Destroy the West Platform |q 11617/3 |goto 50.35,34.52
step
use the Gnomish Grenade##34772
|tip Use it while standing near the floating platform.
Destroy the North Platform |q 11617/2 |goto 52.26,31.80
step
label "Free_Kaskala_Craftsman_Spirits"
kill Beryl Hound##25355+
|tip They look like blue dogs.
collect Core of Malice##34711+ |n
use the Cores of Malice##34711
|tip Use them on Kaskala Craftsmen.
|tip They look like walrus people spirits holding hammers.
|tip You can find them all around the Coldrock Quarry area. |notinsticky
Free #3# Kaskala Craftsman Spirits |q 11607/1 |goto 51.49,31.33
step
label "Free_Kaskala_Shaman_Spirits"
kill Beryl Hound##25355+
|tip They look like blue dogs.
collect Core of Malice##34711+ |n
use the Cores of Malice##34711
|tip Use them on Kaskala Shamans.
|tip They look like walrus people spirits holding staves.
|tip You can find them all around the Coldrock Quarry area. |notinsticky
Free #3# Kaskala Shaman Spirits |q 11607/2 |goto 51.49,31.33
step
click Elder Atkanok##187565
turnin The Lost Spirits##11607 |goto 54.62,35.74
accept Picking Up the Pieces##11609 |goto 54.62,35.74
step
talk Etaruk##25292
turnin Hampering Their Escape##11617 |goto 54.29,36.10
accept A Visit to the Curator##11623 |goto 54.29,36.10
stickystart "Collect_Tuskarr_Ritual_Objects"
step
kill Curator Insivius##25448 |q 11623/1 |goto 50.09,32.56
|tip He walks around this area.
|tip Follow the path along the top of the cliff to get to him.
step
label "Collect_Tuskarr_Ritual_Objects"
click Tuskarr Ritual Object##187671+
|tip They look like stone fish and incense smoke bowls on the ground.
|tip You can find them all around the Coldrock Quarry area. |notinsticky
collect 6 Tuskarr Ritual Object##34713 |q 11609/1 |goto 51.95,32.94
step
click Elder Atkanok##187565
turnin Picking Up the Pieces##11609 |goto 54.62,35.74
accept Leading the Ancestors Home##11610 |goto 54.62,35.74
step
talk Etaruk##25292
turnin A Visit to the Curator##11623 |goto 54.29,36.10
step
use the Tuskarr Ritual Object##34715
|tip Next to the Elder Sagani totem.
Complete Elder Sagani's Ceremony |q 11610/2 |goto 52.82,34.04
step
use the Tuskarr Ritual Object##34715
|tip Next to the Elder Takret totem.
Complete Elder Takret's Ceremony |q 11610/3 |goto 52.31,31.15
step
use the Tuskarr Ritual Object##34715
|tip Next to the Elder Kesuk totem.
Complete Elder Kesuk's Ceremony |q 11610/1 |goto 50.87,32.39
step
click Elder Atkanok##187565
turnin Leading the Ancestors Home##11610 |goto 54.62,35.74
step
talk Librarian Hamilton##27141
|tip He walks around this area.
|tip Sell any items you don't need, to clear some bag space.
|tip Follow the road to get to this location.
Visit the Vendor |vendor Librarian Hamilton##27141 |goto 45.27,33.94 |q 11582
step
talk Librarian Garren##25291
turnin Monitoring the Rift: Sundered Chasm##11582 |goto 44.98,33.38
accept Monitoring the Rift: Winterfin Cavern##12728 |goto 44.98,33.38
step
talk Surristrasz##24795
accept Traversing the Rift##11733 |goto 45.32,34.52
step
talk Surristrasz##24795
Ask him _"May I use a drake to fly elsewhere?"_
|tip Choose to fly to "Transitus Shield, Coldarra".
Begin Flying to Transitus Shield |ontaxi |goto 45.32,34.52 |q 11733
step
Fly to Transitus Shield |offtaxi |goto 33.12,34.41 |notravel |q 11733
step
talk Warmage Adami##27046
fpath Transitus Shield |goto 33.13,34.44
step
talk Archmage Berinand##25314
|tip Inside the building.
turnin Traversing the Rift##11733 |goto 32.95,34.40
accept Reading the Meters##11900 |goto 32.95,34.40
accept Secrets of the Ancients##11910 |goto 32.95,34.40
step
talk Raelorasz##26117
accept Basic Training##11918 |goto 33.31,34.53
step
talk Librarian Serrah##26110
accept Nuts for Berries##11912 |goto 33.49,34.38
stickystart "Kill_Coldarra_Spellweavers"
step
kill Coldarra Spellbinder##25719+
|tip They look like large humans wearing purple robs.
collect Scintillating Fragment##35648 |n
use the Scintillating Fragment##35648
accept Puzzling...##11941 |goto 32.92,28.99
step
talk Raelorasz##26117
turnin Puzzling...##11941 |goto 33.31,34.53
accept The Cell##11943 |goto 33.31,34.53
stickystart "Collect_Glacial_Splinters"
stickystart "Collect_Magic_Bound_Splinters"
stickystart "Collect_Frostberries"
step
click Coldarra Geological Monitor##188100
|tip Right inside the doorway of the building.
Take the Southern Coldarra Reading |q 11900/2 |goto 28.27,35.02
step
kill Warbringer Goredrak##25712
|tip He looks like a large blue humanoid dragon in brown armor.
collect Energy Core##35669 |q 11943/1 |goto 24.13,29.59
step
_NOTE:_
Check for Frostberry Bushes
|tip There are usually a few Frostberry bushes around this area with the trees.
|tip They look like medium sized snow covered bushes with dark leaves on the ground around this area.
|tip Collect the few you can find here, and continue on.
Click Here to Continue |confirm |goto 21.62,26.80 |q 11912
step
click Coldarra Geological Monitor##188100
|tip Right inside the doorway of the building.
Take the Western Coldarra Reading |q 11900/4 |goto 22.62,23.45
step
_NOTE:_
Check for Frostberry Bushes
|tip There are usually a few Frostberry bushes around this area with the trees.
|tip They look like medium sized snow covered bushes with dark leaves on the ground around this area.
|tip Collect the few you can find here, and continue on.
Click Here to Continue |confirm |goto 23.86,21.70 |q 11912
step
_NOTE:_
Check for Frostberry Bushes
|tip There are usually a few Frostberry bushes around this area with the trees.
|tip They look like medium sized snow covered bushes with dark leaves on the ground around this area.
|tip Collect the few you can find here, and continue on.
Click Here to Continue |confirm |goto 25.41,19.93 |q 11912
step
kill General Cerulean##25716
|tip He looks like a large blue and white dragon.
collect Prison Casing##35668 |q 11943/2 |goto 27.32,20.40
step
label "Collect_Frostberries"
click Frostberry Bush##188113+
|tip They look like medium sized snow covered bushes with dark leaves on the ground.
|tip You should be able to finish up with these here. |notinsticky
|tip You can find them all around the Coldarra area. |notinsticky
collect 10 Frostberry##35492 |q 11912/1 |goto 29.53,20.54
step
click Coldarra Geological Monitor##188100
|tip Right inside the doorway of the building.
Take the Northern Coldarra Reading |q 11900/3 |goto 31.72,20.56
step
label "Collect_Glacial_Splinters"
kill Glacial Ancient##25709+
|tip They look like large white and brown walking trees.
|tip You can find them all around the Coldarra area. |notinsticky
collect 3 Glacial Splinter##35483 |q 11910/1 |goto 34.13,25.70
step
label "Collect_Magic_Bound_Splinters"
kill Magic-Bound Ancient##25707+
|tip They look like large purple and white walking trees.
|tip You can find them all around the Coldarra area. |notinsticky
collect 3 Magic-Bound Splinter##35484 |q 11910/2 |goto 34.13,25.70
step
label "Kill_Coldarra_Spellweavers"
kill 10 Coldarra Spellweaver##25722 |q 11918/1 |goto 31.45,29.44
|tip You can find them all around the Coldarra area. |notinsticky
step
talk Archmage Berinand##25314
|tip Inside the building.
turnin Secrets of the Ancients##11910 |goto 32.95,34.40
step
talk Archmage Berinand##25314
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Archmage Berinand##25314 |goto 32.97,34.38 |q 11918
step
talk Raelorasz##26117
turnin Basic Training##11918 |goto 33.31,34.53
accept Hatching a Plan##11936 |goto 33.31,34.53
step
talk Raelorasz##26117
turnin The Cell##11943 |goto 33.31,34.53
step
talk Librarian Serrah##26110
turnin Nuts for Berries##11912 |goto 33.49,34.38
accept Keep the Secret Safe##11914 |goto 33.49,34.38
step
use the Augmented Arcane Prison##35671
talk Keristrasza##26206
|tip She appears next to you.
accept Keristrasza##11946 |goto 33.20,34.19
step
use the Augmented Arcane Prison##35671
talk Keristrasza##26206
|tip She appears next to you.
turnin Keristrasza##11946
accept Bait and Switch##11951 |goto 33.20,34.19
stickystart "Collect_Crystallized_Mana_Shards"
step
kill Coldarra Wyrmkin##25728+
|tip They look like larger armored blue dragonkin.
|tip You can find them all around the Coldarra area. |notinsticky
|tip You need these axes to destroy dragon eggs in a few steps.
collect 5 Frozen Axe##35586 |goto 29.57,30.52 |q 11936
You can find more around: |notinsticky
[25.27,35.16]
[24.14,25.21]
step
label "Collect_Crystallized_Mana_Shards"
click Crystallized Mana##188140+
|tip They look like clusters of pink crystals on the ground.
|tip They are usually near the 3 purple cracks in the ground around the perimeter of the large trench surrounding the Nexus building.
|tip You can find them all around the Coldarra area. |notinsticky
collect 10 Crystallized Mana Shard##35685 |q 11951/1 |goto 24.64,24.34
You can find more around: |notinsticky
[29.93,22.39]
[29.12,31.77]
stickystart "Destroy_Dragon_Eggs"
stickystart "Collect_Nexus_Mana_Essences"
step
click Coldarra Geological Monitor##188100
|tip On the ground in the trench, outside of the Nexus building.
Take the Nexus Geological Reading |q 11900/1 |goto 28.32,28.48
step
label "Destroy_Dragon_Eggs"
click Blue Dragon Egg##188133+
|tip They look like large dark colored eggs with white crystals on them on the ground around this area.
|tip In the trench, all around the perimeter of the Nexus building. |notinsticky
Destroy #5# Dragon Eggs |q 11936/1 |goto 28.08,29.18
step
label "Collect_Nexus_Mana_Essences"
kill Arcane Serpent##25721+
|tip They look like pink flying snakes in the air.
|tip In the trench, all around the perimeter of the Nexus building. |notinsticky
collect 5 Nexus Mana Essence##35493 |q 11914/1 |goto 27.95,24.20
step
use the Augmented Arcane Prison##35671
talk Keristrasza##26237
|tip She appears next to you.
turnin Bait and Switch##11951
accept Saragosa's End##11957
step
_Next to you:_
talk Keristrasza##26237
Tell her _"I am prepared to face Saragosa!"_
Teleport to Saragosa's Landing |complete subzone("Saragosa's Landing") |q 11957
step
use the Arcane Power Focus##35690
|tip In the middle of the floating platform.
Watch the dialogue
kill Saragosa##26232
|tip She will fly to the floating platform, and turn into her non-elite human form.
|tip You won't have to fight her elite dragon form.
collect Saragosa's Corpse##35709 |q 11957/1 |goto 21.59,22.55
step
use the Augmented Arcane Prison##35671
talk Keristrasza##26237
|tip She appears next to you.
turnin Saragosa's End##11957
accept Mustering the Reds##11967
step
_Next to you:_
talk Keristrasza##26237
Tell her _"Keristrasa, I am finished here. Please return me to the Transitus Shield."_
Return to Transitus Shield |condition subzone("Transitus Shield") |q 11967
step
talk Raelorasz##26117
turnin Hatching a Plan##11936 |goto 33.31,34.53
turnin Mustering the Reds##11967 |goto 33.31,34.53
step
talk Librarian Serrah##26110
turnin Keep the Secret Safe##11914 |goto 33.49,34.38
step
talk Archmage Berinand##25314
|tip Inside the building.
turnin Reading the Meters##11900 |goto 32.95,34.40
step
talk Archmage Berinand##25314
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Archmage Berinand##25314 |goto 32.97,34.38 |q 12486
step
talk Spirit Talker Snarlfang##25339
turnin To Bor'gorok Outpost, Quickly!##12486 |goto 50.28,9.72
accept The Sky Will Know##11624 |goto 50.28,9.72
step
talk Kimbiza##26848
fpath Bor'gorok Outpost |goto 49.65,11.05
step
talk Overlord Bor'gorok##25326
accept Report to Steeljaw's Caravan##11591 |goto 49.62,10.58
step
talk Supply Master Taz'ishi##25736
accept King Mrgl-Mrgl##11702 |goto 48.96,10.27
step
talk Imperean##25376
turnin The Sky Will Know##11624 |goto 46.57,9.35
accept Boiling Point##11627 |goto 46.57,9.35
step
kill Churn##25418
|tip He looks like a water elemental.
|tip He will eventually surrender.
Fight Churn Until He Submits |q 11627/2 |goto 45.89,13.09
step
kill Simmer##25416
|tip He looks like a fire elemental.
|tip He will eventually surrender.
Fight Simmer Until He Submits |q 11627/1 |goto 50.95,15.30
step
talk Imperean##25376
turnin Boiling Point##11627 |goto 46.57,9.35
accept Motes of the Enraged##11649 |goto 46.57,9.35
step
kill Enraged Tempest##25415+
|tip They look like air elementals.
|tip You can find them all around the Ruins of Eldra'nath area.
collect 5 Tempest Mote##34800 |q 11649/1 |goto 44.06,9.13
step
talk King Mrgl-Mrgl##25197
turnin King Mrgl-Mrgl##11702 |goto 43.50,13.97
accept Learning to Communicate##11571 |goto 43.50,13.97
stickystart "Collect_Winterfin_Clams"
step
kill Scalder##25226
|tip He looks like a blue water elemental that swims along this purple trench underwater around this area.
use The King's Empty Conch##34598
|tip Use it on his corpse.
collect The King's Filled Conch##34623 |q 11571/1 |goto 42.78,17.07
step
label "Collect_Winterfin_Clams"
Kill Winterfin enemies around this area
|tip They look like murlocs.
click Winterfin Clam##187367+
|tip They look like small grey clams on the ground around this area.
collect 5 Winterfin Clam##34597 |goto 40.61,16.85 |q 11559 |future
|tip Be careful not to accidentally sell these to a vendor.
|tip You will need them for a quest soon.
step
talk King Mrgl-Mrgl##25197
turnin Learning to Communicate##11571 |goto 43.50,13.97
accept Winterfin Commerce##11559 |goto 43.50,13.97
step
talk Ahlurglgr##25206
turnin Winterfin Commerce##11559 |goto 43.04,13.81
step
talk Ahlurglgr##25206
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Ahlurglgr##25206 |goto Borean Tundra/0 43.04,13.81 |q 11560 |future
step
talk King Mrgl-Mrgl##25197
accept Oh Noes, the Tadpoles!##11560 |goto 43.50,13.97
step
talk Brglmurgl##25199
accept Them!##11561 |goto 42.83,13.65
stickystart "Rescue_Winterfin_Tadpoles"
stickystart "Slay_Winterfin_Murlocs"
step
use the Arcanometer##34669
|tip At the entrance of the cave.
Take the Winterfin Cavern Reading |q 12728/1 |goto 39.88,19.76
step
label "Rescue_Winterfin_Tadpoles"
click Cage##238791+
|tip They look like yellow wooden cages on the ground around this area.
Rescue #20# Winterfin Tadpoles |q 11560/1 |goto 40.61,16.85
You can find more inside the cave at [39.88,19.76]
step
label "Slay_Winterfin_Murlocs"
Kill Winterfin enemies around this area
Slay #15# Winterfin Murlocs |q 11561/1 |goto 40.61,16.85
You can find more inside the cave at [39.88,19.76]
step
Leave the cave |goto 39.92,19.98 < 40 |walk |only if subzone("Winterfin Caverns")
talk Brglmurgl##25199
turnin Them!##11561 |goto 42.83,13.65
step
talk Ahlurglgr##25206
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Ahlurglgr##25206 |goto Borean Tundra/0 43.04,13.81 |q 11560
step
talk King Mrgl-Mrgl##25197
turnin Oh Noes, the Tadpoles!##11560 |goto 43.50,13.97
accept I'm Being Blackmailed By My Cleaner##11562 |goto 43.50,13.97
step
talk Mrmrglmr##25205
turnin I'm Being Blackmailed By My Cleaner##11562 |goto 42.00,12.77
accept Grmmurggll Mrllggrl Glrggl!!!##11563 |goto 42.00,12.77
step
talk Cleaver Bmurglbrm##25211
accept Succulent Orca Stew##11564 |goto 42.03,13.15
stickystart "Collect_Succulent_Orca_Blubber"
step
kill Glrggl##25203
|tip It looks like a larger orca that swims on the surface of the water around this area.
collect Glrggl's Head##34617 |q 11563/1 |goto 36.47,8.23
step
label "Collect_Succulent_Orca_Blubber"
kill Glimmer Bay Orca##25204+
|tip They look like black and white whales.
|tip Underwater around this area.
collect 7 Succulent Orca Blubber##34618 |q 11564/1 |goto 39.94,12.37
You can find more around: |notinsticky
[40.74,7.39]
[42.70,15.83]
step
talk Mrmrglmr##25205
turnin Grmmurggll Mrllggrl Glrggl!!!##11563 |goto 42.00,12.77
accept The Spare Suit##11565 |goto 42.00,12.77
step
talk Cleaver Bmurglbrm##25211
turnin Succulent Orca Stew##11564 |goto 42.03,13.15
step
talk Ahlurglgr##25206
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Ahlurglgr##25206 |goto Borean Tundra/0 43.04,13.81 |q 11565
step
talk King Mrgl-Mrgl##25197
turnin The Spare Suit##11565 |goto 43.50,13.97
accept Surrender... Not!##11566 |goto 43.50,13.97
step
use King Mrgl-Mrgl's Spare Suit##34620
Wear King Mrgl-Mrgl's Spare Suit |havebuff spell:45278 |goto 40.33,19.21 |q 11566
step
Enter the cave |goto 39.92,19.97 < 40 |walk
Follow the path |goto 38.06,22.72 < 10 |walk
talk Glrglrglr##28375
|tip Inside the cave, on the top floor.
accept Keymaster Urmgrgl##11569 |goto 37.84,23.19
step
Remove King Mrgl-Mrgl's Spare Suit |nobuff spell:45278 |q 11566
|tip Right-click the "King Mrgl-Mrgl's Spare Suit" buff near your minimap.
|tip Be careful, enemies will attack you.
step
Jump down and follow the path |goto 38.10,22.16 < 10 |walk
kill Keymaster Urmgrgl##25210
|tip He walks around this area.
|tip Inside the cave, on the bottom floor.
collect Urmgrgl's Key##34600 |q 11569/1 |goto 39.07,22.69
step
use King Mrgl-Mrgl's Spare Suit##34620
Wear King Mrgl-Mrgl's Spare Suit |havebuff spell:45278 |q 11566
step
Follow the path |goto 37.50,21.87 < 10 |walk
kill Claximus##25209
|tip Inside the cave, on the top floor.
|tip To reach him, hug the right wall as you follow the path.
collect Claw of Claximus##34621 |q 11566/1 |goto 37.55,27.51
step
use King Mrgl-Mrgl's Spare Suit##34620
Wear King Mrgl-Mrgl's Spare Suit |havebuff spell:45278 |q 11566
step
Hug the left wall as you walk and follow the path up |goto 37.49,21.57 < 10 |walk
Follow the path |goto 38.06,22.72 < 10 |walk
talk Glrglrglr##28375
|tip Inside the cave, on the top floor.
turnin Keymaster Urmgrgl##11569 |goto 37.84,23.19
step
Remove King Mrgl-Mrgl's Spare Suit |nobuff spell:45278 |goto 37.75,23.02 |q 11570 |future
|tip Right-click the "King Mrgl-Mrgl's Spare Suit" buff near your minimap.
|tip Be careful, enemies will attack you.
step
talk Lurgglbr##25208
|tip Inside the cave, on the top floor.
accept Escape from the Winterfin Caverns##11570 |goto 37.75,23.02
step
Escort Lurgglbr to Safety |q 11570/1 |goto 41.34,16.34
|tip Follow Lurgglbr and protect him as he walks.
|tip Let him get attacked first, otherwise he won't stop to help you fight.
|tip He eventually walks to this location outside the cave.
step
talk Ahlurglgr##25206
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Ahlurglgr##25206 |goto 43.04,13.81 |q 11570
step
talk King Mrgl-Mrgl##25197
turnin Surrender... Not!##11566 |goto 43.50,13.97
turnin Escape from the Winterfin Caverns##11570 |goto 43.50,13.97
step
Follow the path up the cliffside |goto 42.64,12.41 < 15 |only if walking and subzone("Winterfin Retreat")
talk Imperean##25376
turnin Motes of the Enraged##11649 |goto 46.57,9.35
accept Return to the Spirit Talker##11629 |goto 46.57,9.35
step
talk Spirit Talker Snarlfang##25339
turnin Return to the Spirit Talker##11629 |goto 50.28,9.72
accept Vision of Air##11631 |goto 50.28,9.72
step
use Imperean's Primal##34779
Watch the dialogue
Divine Farseer Grimwalker's Fate |q 11631/1 |goto 50.22,9.73
step
talk Spirit Talker Snarlfang##25339
turnin Vision of Air##11631 |goto 50.28,9.72
accept Farseer Grimwalker's Spirit##11635 |goto 50.28,9.72
step
Enter the building |goto 49.53,10.16 < 10 |walk
talk Matron Magah##27069
|tip Inside the building.
home Bor'gorok Outpost |goto 49.67,10.19
step
talk Ortrosh##25374
|tip He walks around this area.
accept Revenge Upon Magmoth##11639 |goto 50.07,10.14
stickystart "Kill_Magmoth_Foragers"
stickystart "Kill_Magmoth_Shamans"
step
kill 3 Magmoth Crusher##25434 |q 11639/3 |goto 56.49,11.92
|tip They look like large blue magnataurs.
|tip You can find them all around the Magmoth area.
step
label "Kill_Magmoth_Foragers"
kill 5 Magmoth Forager##25429 |q 11639/2 |goto 54.99,13.12
|tip They look like brown kobolds holding torches.
|tip You can find them all around the Magmoth area. |notinsticky
stickystart "Kill_Mates_of_Magmothregar"
step
Enter the cave |goto 54.01,13.48 < 20 |walk
Jump down carefully into the water here |goto 54.80,12.34 < 10 |walk
Follow the path at the bottom of the cave |goto 56.34,11.35 < 30 |walk
talk Farseer Grimwalker's Spirit##25425
|tip He looks like an armored tauren ghost.
|tip Inside the cave, on the bottom floor.
|tip Kill the Magmoth Shamans to free Farseer Grimwalker's Spirit, so that you can talk to him.
turnin Farseer Grimwalker's Spirit##11635 |goto 56.17,9.11
accept Kaganishu##11637 |goto 56.17,9.11
step
kill Kaganishu##25427
|tip Inside the cave, on the bottom floor.
collect Kaganishu's Fetish##34781 |q 11637/2 |goto 56.19,12.77
step
use Kaganishu's Fetish##34781
|tip Use it on Farseer Grimwalker's Spirit.
|tip He looks like an armored tauren ghost.
|tip Inside the cave, on the bottom floor.
Set Farseer Grimwalker Free |q 11637/1 |goto 56.17,9.11
step
talk Farseer Grimwalker's Spirit##25425
|tip He looks like an armored tauren ghost.
|tip Inside the cave, on the bottom floor.
turnin Kaganishu##11637 |goto 56.17,9.11
accept Return My Remains##11638 |goto 56.17,9.11
step
click Farseer Grimwalker's Remains##187673
|tip It looks like a skeleton on the ground.
|tip Inside the cave, on the bottom floor.
collect Farseer Grimwalker's Remains##34773 |q 11638/1 |goto 56.17,9.11
step
label "Kill_Mates_of_Magmothregar"
kill 3 Mate of Magmothregar##25432 |q 11639/4 |goto 54.01,13.48
|tip They look like large blue magnataurs.
|tip All around inside the cave.
step
label "Kill_Magmoth_Shamans"
kill 10 Magmoth Shaman##25428 |q 11639/1 |goto 54.01,13.48
|tip They look like blue kobolds next to fire totems channeling an orange fire spell on objects.
|tip Inside and outside the cave. |notinsticky
|tip You can find them all around the Magmoth area. |notinsticky
step
use the Hearthstone##6948
Hearth to Bor'gorok Outpost |complete subzone("Bor'gorok Outpost") |q 11638
|only if subzone("Magmoth")
step
talk Drigoth##27067
|tip Inside the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Drigoth##27067 |goto 49.74,10.08 |q 11638
step
talk Ortrosh##25374
|tip Inside the building.
turnin Revenge Upon Magmoth##11639 |goto 49.55,9.98
He can also be found here [50.07,10.15]
step
talk Spirit Talker Snarlfang##25339
turnin Return My Remains##11638 |goto 50.28,9.72
step
talk Grunt Ragefist##25336
|tip She walks around this area.
turnin Report to Steeljaw's Caravan##11591 |goto 48.39,19.32
accept The Honored Dead##11593 |goto 48.39,19.32
accept Put Them to Rest##11594 |goto 48.39,19.32
step
talk Longrunner Proudhoof##25335
|tip This is an escort quest.
|tip If he's not here, someone may be escorting him.
|tip Wait for him to respawn.
accept We Strike!##11592 |goto 48.32,19.76
stickystart "Torch_Fallen_Caravan_Guards_And_Workers"
stickystart "Lay_Taunka_Spirits_to_Rest"
step
Watch the dialogue
|tip Follow Longrunner Proudhoof and protect him as he walks.
|tip He eventually walks to this location.
kill Force-Commander Steeljaw##25359
Successfully Assist Longrunner Proudhoof's Assault |q 11592/1 |goto 49.50,26.52
step
label "Torch_Fallen_Caravan_Guards_And_Workers"
use Ragefist's Torch##34692
|tip Use it next to Dead Caravan Guards and Dead Caravan Workers.
|tip They look like armored corpses of various Horde races laying on the ground.
|tip You can find them all around the Steeljaw's Caravan area. |notinsticky
Torch #10# Fallen Caravan Guards & Workers |q 11593/1 |goto 49.36,24.54
step
label "Lay_Taunka_Spirits_to_Rest"
Kill enemies around this area
|tip They look like Tauren ghosts.
|tip You can find them all around the Steeljaw's Caravan area. |notinsticky
Lay #20# Taunka Spirits to Rest |q 11594/1 |goto 49.36,24.54
step
talk Grunt Ragefist##25336
|tip She walks around this area.
turnin The Honored Dead##11593 |goto 48.39,19.32
turnin Put Them to Rest##11594 |goto 48.39,19.32
step
talk Overlord Bor'gorok##25326
turnin We Strike!##11592 |goto 49.62,10.58
step
Enter the building |goto 49.53,10.16 < 10 |walk
talk Drigoth##27067
|tip Inside the building.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Drigoth##27067 |goto 49.74,10.08 |q 11638
step
talk Librarian Garren##25291
turnin Monitoring the Rift: Winterfin Cavern##12728 |goto 44.98,33.38
]])
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\Dragonblight (72-74)")
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\Grizzly Hills (74-75)")
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\Zul'Drak (75-76)")
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\Sholazar Basin (76-78)")
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\The Storm Peaks (78-79)")
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\Icecrown (79-80)")
